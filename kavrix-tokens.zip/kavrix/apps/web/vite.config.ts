import { defaultClientConditions, defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

export default defineConfig({
  plugins: [react(), tailwindcss()],
  // Workspace packages are consumed from source; the default conditions must be kept explicitly.
  resolve: { conditions: ["development", ...defaultClientConditions] },
  server: {
    port: 5173,
    strictPort: true,
    proxy: {
      // Mirrors Caddy: /api/* is forwarded to the API with the prefix stripped.
      "/api": { target: "http://127.0.0.1:3000", rewrite: (path) => path.replace(/^\/api/, "") },
    },
  },
  build: {
    target: "es2022",
    sourcemap: false,
    assetsInlineLimit: 0,
  },
});
