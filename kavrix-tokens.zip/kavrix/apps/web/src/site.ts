/** Build-time public settings (Vite inlines them). Nothing here is secret. */
// `env` is undefined outside Vite (unit tests, SSR smoke checks).
const env: Partial<ImportMetaEnv> = import.meta.env ?? {};

export const SITE_ORIGIN: string = env.VITE_SITE_ORIGIN ?? "http://localhost:5173";

/** Legal name of the operator. While unset, legal pages render as drafts with a visible banner. */
export const LEGAL_ENTITY: string | undefined = env.VITE_LEGAL_ENTITY || undefined;

export const SUPPORT_EMAIL: string | undefined = env.VITE_SUPPORT_EMAIL || undefined;
