import { isAddressLike, type SupportedChainId } from "@kavrix/shared";
import type { Lang } from "../i18n/lang.ts";

export type Direction = "buy" | "sell";
export type Fiat = "USD" | "EUR" | "GBP";

export interface RampDraft {
  readonly direction: Direction;
  readonly fiat: Fiat;
  readonly amount: string;
  readonly chainId: SupportedChainId;
  /** Token contract (or the native sentinel) on `chainId`. */
  readonly token: `0x${string}` | null;
  readonly tokenDecimals: number;
  readonly wallet: string;
}

const TEXT = {
  en: {
    token: "Choose what to buy or sell.",
    amount: "Enter an amount.",
    decimals: (d: number) => `Enter a positive amount with up to ${d} decimal places.`,
    walletBuy: "Enter the 0x… address of the wallet that will receive the crypto.",
    walletSell: "Enter the 0x… address that should receive a refund if the sale cannot complete.",
  },
  ru: {
    token: "Выберите, что покупаете или продаёте.",
    amount: "Введите сумму.",
    decimals: (d: number) => `Введите положительную сумму, не больше ${d} знаков после запятой.`,
    walletBuy: "Введите адрес 0x… кошелька, на который придёт криптовалюта.",
    walletSell: "Введите адрес 0x…, на который вернётся криптовалюта, если продажа не состоится.",
  },
} as const;

export function validateRampDraft(d: RampDraft, lang: Lang = "en"): Partial<Record<"amount" | "wallet" | "token", string>> {
  const t = TEXT[lang];
  const errors: Partial<Record<"amount" | "wallet" | "token", string>> = {};
  const maxDecimals = d.direction === "buy" ? 2 : Math.min(d.tokenDecimals, 18);
  if (d.token === null) errors.token = t.token;
  if (d.amount === "") errors.amount = t.amount;
  else if (!new RegExp(`^(0|[1-9]\\d{0,9})(\\.\\d{1,${maxDecimals}})?$`).test(d.amount) || Number(d.amount) <= 0) {
    errors.amount = t.decimals(maxDecimals);
  }
  if (!isAddressLike(d.wallet.trim())) {
    errors.wallet = d.direction === "buy" ? t.walletBuy : t.walletSell;
  }
  return errors;
}
