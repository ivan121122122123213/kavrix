import { useEffect, useRef, useState } from "react";
import { useLang } from "../i18n/core.tsx";
import { useConnection } from "wagmi";
import { CHAINS, SUPPORTED_CHAIN_IDS, isSupportedChainId } from "@kavrix/shared";
import { apiPost, describeError, type Capabilities } from "../lib/api.ts";
import { useTokens } from "../lib/data.ts";
import { normalizeAmountInput } from "../lib/format.ts";
import type { Resource } from "../lib/resource.ts";
import { Button } from "../ui/Button.tsx";
import { Field, inputClass } from "../ui/Field.tsx";
import { Notice } from "../ui/Notice.tsx";
import { Segmented } from "../ui/Segmented.tsx";
import { validateRampDraft, type Fiat, type RampDraft } from "./validate.ts";

type Provider = "moonpay" | "transak";
const PROVIDER_LABEL: Record<Provider, string> = { moonpay: "MoonPay", transak: "Transak" };
const FIATS: readonly Fiat[] = ["USD", "EUR", "GBP"];
const RAMP_SYMBOLS = new Set(["USDC", "USDT"]);

export function RampPanel({ capabilities }: { capabilities: Resource<Capabilities> }) {
  const lang = useLang();
  const ru = lang === "ru";
  const connection = useConnection();
  const connected = connection.status === "connected" ? connection.address : undefined;
  const [draft, setDraft] = useState<RampDraft>({ direction: "buy", fiat: "USD", amount: "", chainId: 8453, token: null, tokenDecimals: 18, wallet: connected ?? "" });
  const [touched, setTouched] = useState(false);
  const [provider, setProvider] = useState<Provider | null>(null);
  const [submit, setSubmit] = useState<{ status: "idle" | "busy" } | { status: "error"; message: string }>({ status: "idle" });
  const attemptKey = useRef<string | null>(null);
  const tokens = useTokens(draft.chainId);

  const assets = tokens.status === "ready" ? tokens.data.filter((t) => t.native || RAMP_SYMBOLS.has(t.symbol)) : [];
  useEffect(() => {
    const first = assets[0];
    if (draft.token === null && first !== undefined) setDraft((d) => ({ ...d, token: first.address, tokenDecimals: first.decimals }));
  }, [assets, draft.token]);
  useEffect(() => {
    if (connected !== undefined) setDraft((d) => (d.wallet === "" ? { ...d, wallet: connected } : d));
  }, [connected]);

  const caps = capabilities.status === "ready" ? capabilities.data : null;
  const enabled = (["moonpay", "transak"] as const).filter((p) => caps?.ramp[p] === true);
  const chosen = provider !== null && enabled.includes(provider) ? provider : (enabled[0] ?? null);
  const errors = validateRampDraft(draft, lang);
  const valid = Object.keys(errors).length === 0;
  const asset = assets.find((a) => a.address === draft.token);

  const update = (patch: Partial<RampDraft>) => {
    attemptKey.current = null; // any change is a new attempt
    setSubmit({ status: "idle" });
    setDraft((d) => ({ ...d, ...patch }));
  };

  const start = async () => {
    setTouched(true);
    if (!valid || chosen === null || draft.token === null) return;
    attemptKey.current ??= crypto.randomUUID();
    setSubmit({ status: "busy" });
    try {
      const body = await apiPost(
        "/v1/ramp/sessions",
        {
          provider: chosen,
          direction: draft.direction,
          chainId: draft.chainId,
          token: draft.token,
          fiatCurrency: draft.fiat,
          amount: draft.amount,
          wallet: draft.wallet.trim().toLowerCase(),
        },
        undefined,
        { "idempotency-key": attemptKey.current },
      );
      const url = typeof body === "object" && body !== null ? (body as Record<string, unknown>)["widgetUrl"] : undefined;
      const allowed = ["buy.moonpay.com", "buy-sandbox.moonpay.com", "sell.moonpay.com", "sell-sandbox.moonpay.com", "global.transak.com", "global-stg.transak.com"];
      if (typeof url !== "string" || !url.startsWith("https://") || !allowed.includes(new URL(url).host)) throw new Error("Unexpected checkout address");
      window.location.assign(url);
    } catch (err) {
      setSubmit({ status: "error", message: describeError(err, lang) });
    }
  };

  return (
    <section aria-labelledby="ramp-title" className="k-glass k-seam-corner p-4 sm:p-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 id="ramp-title" className="text-lg font-semibold">
          {draft.direction === "buy" ? (ru ? "Купить криптовалюту" : "Buy crypto") : ru ? "Продать криптовалюту" : "Sell crypto"}
        </h2>
        <Segmented
          label={ru ? "Покупка или продажа" : "Buy or sell"}
          options={[
            { value: "buy", label: ru ? "Купить" : "Buy" },
            { value: "sell", label: ru ? "Продать" : "Sell" },
          ]}
          value={draft.direction}
          onChange={(v) => update({ direction: v, amount: "" })}
        />
      </div>

      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        <Field label={ru ? "Сеть" : "Network"}>
          {(control) => (
            <select
              {...control}
              className={inputClass}
              value={draft.chainId}
              onChange={(e) => {
                const id = Number(e.target.value);
                if (isSupportedChainId(id)) update({ chainId: id, token: null });
              }}
            >
              {SUPPORTED_CHAIN_IDS.map((id) => (
                <option key={id} value={id}>
                  {CHAINS[id].name}
                </option>
              ))}
            </select>
          )}
        </Field>
        <Field label={draft.direction === "buy" ? (ru ? "Получаете" : "You receive") : ru ? "Продаёте" : "You sell"} error={touched ? errors.token : undefined}>
          {(control) => (
            <select
              {...control}
              className={inputClass}
              value={draft.token ?? ""}
              disabled={tokens.status !== "ready"}
              onChange={(e) => {
                const t = assets.find((a) => a.address === e.target.value);
                if (t !== undefined) update({ token: t.address, tokenDecimals: t.decimals });
              }}
            >
              {tokens.status !== "ready" ? <option value="">{ru ? "Загрузка…" : "Loading…"}</option> : null}
              {assets.map((a) => (
                <option key={a.address} value={a.address}>
                  {a.symbol}
                </option>
              ))}
            </select>
          )}
        </Field>
        <Field
          label={draft.direction === "buy" ? (ru ? `Платите (${draft.fiat})` : `You spend (${draft.fiat})`) : ru ? `Сумма (${asset?.symbol ?? "крипто"})` : `Amount (${asset?.symbol ?? "crypto"})`}
          error={touched ? errors.amount : undefined}
          {...(draft.direction === "buy" && caps?.ramp.buyLimits != null
            ? {
                hint: ru
                  ? `Лимит Kavrix на заказ: ${caps.ramp.buyLimits.min}–${caps.ramp.buyLimits.max} ${draft.fiat}. У провайдера могут быть свои.`
                  : `Kavrix limit per order: ${caps.ramp.buyLimits.min}–${caps.ramp.buyLimits.max} ${draft.fiat}. The provider may set its own.`,
              }
            : {})}
        >
          {(control) => (
            <input
              {...control}
              className={`${inputClass} tabular text-lg`}
              inputMode="decimal"
              placeholder="0"
              value={draft.amount}
              onChange={(e) => update({ amount: normalizeAmountInput(e.target.value) })}
            />
          )}
        </Field>
        <Field label={draft.direction === "buy" ? (ru ? "Валюта оплаты" : "Pay with") : ru ? "Валюта выплаты" : "Paid out in"}>
          {(control) => (
            <select {...control} className={inputClass} value={draft.fiat} onChange={(e) => update({ fiat: e.target.value as Fiat })}>
              {FIATS.map((f) => (
                <option key={f}>{f}</option>
              ))}
            </select>
          )}
        </Field>
      </div>

      <div className="mt-4">
        <Field
          label={draft.direction === "buy" ? (ru ? "Адрес кошелька-получателя" : "Receiving wallet address") : ru ? "Адрес для возврата" : "Refund address"}
          hint={
            draft.direction === "buy"
              ? ru
                ? "Проверьте его дважды: криптовалюту, отправленную на неверный адрес, вернуть нельзя."
                : "Double-check it. Crypto sent to a wrong address cannot be recovered."
              : ru
                ? "Если продажа не состоится, провайдер вернёт криптовалюту сюда."
                : "If the sale cannot complete, the provider returns your crypto here."
          }
          error={touched ? errors.wallet : undefined}
        >
          {(control) => (
            <input
              {...control}
              className={`${inputClass} font-mono text-sm`}
              placeholder="0x…"
              autoComplete="off"
              spellCheck={false}
              value={draft.wallet}
              onChange={(e) => update({ wallet: e.target.value })}
            />
          )}
        </Field>
      </div>

      <fieldset className="mt-5">
        <legend className="mb-2 text-sm text-muted">{ru ? "Провайдер" : "Provider"}</legend>
        <div className="grid gap-2 sm:grid-cols-2">
          {(["moonpay", "transak"] as const).map((p) => {
            const on = enabled.includes(p);
            return (
              <label
                key={p}
                className={`flex items-center justify-between gap-3 rounded-control border px-4 py-3 ${chosen === p ? "border-accent/60 bg-surface-raised" : "border-line"} ${on ? "cursor-pointer" : "opacity-60"}`}
              >
                <span className="flex items-center gap-3">
                  <input type="radio" name="ramp-provider" value={p} disabled={!on} checked={chosen === p} onChange={() => setProvider(p)} className="accent-accent" />
                  <span className="font-medium">{PROVIDER_LABEL[p]}</span>
                </span>
                <span className="text-xs text-muted">{caps === null ? (ru ? "Проверяем…" : "Checking…") : on ? (ru ? "Доступен" : "Available") : ru ? "Не подключён" : "Not enabled"}</span>
              </label>
            );
          })}
        </div>
      </fieldset>

      <div className="mt-5 space-y-3">
        {caps !== null && enabled.length === 0 ? (
          <Notice title={ru ? "Оплата картой пока не подключена" : "Card payments are not enabled yet"}>
            {ru
              ? "На этом сервере не подключён ни один платёжный провайдер. Когда он появится, курс и комиссии будет показывать провайдер до оплаты."
              : "No payment provider is connected on this server. When one is, rates and fees come from the provider and are shown before you pay."}
          </Notice>
        ) : null}
        {capabilities.status === "error" ? <Notice tone="danger" title={ru ? "Kavrix недоступен" : "Kavrix is unreachable"}>{describeError(capabilities.error, lang)}</Notice> : null}
        {submit.status === "error" ? <Notice tone="danger" title={ru ? "Не удалось начать оплату" : "Checkout could not start"}>{submit.message}</Notice> : null}
        <Button size="lg" disabled={chosen === null} busy={submit.status === "busy"} onClick={() => void start()}>
          {chosen === null ? (ru ? "Нет доступного провайдера" : "No provider available") : ru ? `Продолжить в ${PROVIDER_LABEL[chosen]}` : `Continue with ${PROVIDER_LABEL[chosen]}`}
        </Button>
        <p className="text-xs text-faint">
          {ru
            ? `${chosen === null ? "Платёжный провайдер" : PROVIDER_LABEL[chosen]} проверяет личность, принимает оплату и отправляет выплаты на своей странице. Kavrix никогда не видит данные карты или банковского счёта. Доступность, лимиты и способы выплат зависят от страны.`
            : `${chosen === null ? "The payment provider" : PROVIDER_LABEL[chosen]} verifies your identity, takes payment and sends payouts on its own page. Kavrix never sees your card or bank details. Availability, limits and payout methods depend on your country.`}
        </p>
      </div>
    </section>
  );
}
