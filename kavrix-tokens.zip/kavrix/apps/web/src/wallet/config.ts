import { createConfig, http } from "wagmi";
import { arbitrum, base, mainnet, polygon } from "wagmi/chains";
import { coinbaseWallet, injected, walletConnect } from "wagmi/connectors";
import type { CreateConnectorFn } from "wagmi";

const env: Partial<ImportMetaEnv> = import.meta.env ?? {};
/** Free project id from dashboard.reown.com. Without it the WalletConnect option is hidden, not broken. */
export const WALLETCONNECT_PROJECT_ID = env.VITE_WALLETCONNECT_PROJECT_ID || undefined;

const origin = typeof window === "undefined" ? "https://localhost" : window.location.origin;

const connectors: CreateConnectorFn[] = [
  // Browser wallets (MetaMask, Rabby, Coinbase extension, …) are discovered via EIP-6963.
  injected({ shimDisconnect: true }),
  coinbaseWallet({ appName: "Kavrix", preference: { options: "all" } }),
];
if (WALLETCONNECT_PROJECT_ID !== undefined) {
  connectors.push(
    walletConnect({
      projectId: WALLETCONNECT_PROJECT_ID,
      showQrModal: true,
      metadata: { name: "Kavrix", description: "Non-custodial token swaps", url: origin, icons: [`${origin}/favicon.svg`] },
    }),
  );
}

/**
 * Reads go through Kavrix's read-only RPC proxy (keys stay server-side, CSP stays 'self').
 * Transactions are signed and broadcast by the wallet itself.
 */
export const wagmiConfig = createConfig({
  chains: [mainnet, base, arbitrum, polygon],
  connectors,
  multiInjectedProviderDiscovery: true,
  transports: {
    [mainnet.id]: http("/api/v1/rpc/1"),
    [base.id]: http("/api/v1/rpc/8453"),
    [arbitrum.id]: http("/api/v1/rpc/42161"),
    [polygon.id]: http("/api/v1/rpc/137"),
  },
});

declare module "wagmi" {
  interface Register {
    config: typeof wagmiConfig;
  }
}
