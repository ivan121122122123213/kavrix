import { useState } from "react";
import { useLang } from "../i18n/core.tsx";
import { useConnect, useConnection, useConnectors, useDisconnect } from "wagmi";
import { CHAINS, isSupportedChainId } from "@kavrix/shared";
import { Dialog } from "../ui/Dialog.tsx";
import { Button } from "../ui/Button.tsx";
import { Notice } from "../ui/Notice.tsx";
import { shortAddress } from "../lib/format.ts";
import { describeWalletError } from "./errors.ts";
import { WALLETCONNECT_PROJECT_ID } from "./config.ts";

export function ConnectDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const ru = useLang() === "ru";
  const connectors = useConnectors();
  const connect = useConnect();
  // The generic "Injected" entry duplicates EIP-6963 discovered wallets when any are present.
  const discovered = connectors.filter((c) => c.type === "injected" && c.id !== "injected");
  const list = connectors.filter((c) => !(c.id === "injected" && discovered.length > 0));

  return (
    <Dialog open={open} onClose={onClose} title={ru ? "Подключить кошелёк" : "Connect a wallet"}>
      <ul className="space-y-2">
        {list.map((c) => (
          <li key={c.uid}>
            <button
              type="button"
              disabled={connect.isPending}
              onClick={() => connect.mutate({ connector: c }, { onSuccess: onClose })}
              className="flex w-full items-center gap-3 rounded-control border border-line px-4 py-3 text-left hover:border-accent/60 disabled:opacity-60"
            >
              {c.icon !== undefined && c.icon.startsWith("data:image/") ? (
                <img src={c.icon} alt="" className="size-7 rounded-md" />
              ) : (
                <span aria-hidden className="size-7 rounded-md bg-surface-raised" />
              )}
              <span className="font-medium">{c.id === "injected" ? (ru ? "Кошелёк в браузере" : "Browser wallet") : c.name}</span>
            </button>
          </li>
        ))}
      </ul>
      {connect.error ? (
        <div className="mt-4">
          <Notice tone="danger">{describeWalletError(connect.error, ru ? "ru" : "en")}</Notice>
        </div>
      ) : null}
      <p className="mt-4 text-xs text-faint">
        {ru ? "Kavrix никогда не просит seed-фразу." : "Kavrix never asks for your seed phrase."}{" "}
        {WALLETCONNECT_PROJECT_ID === undefined
          ? ru
            ? "Мобильные кошельки через WalletConnect на этом сайте не включены."
            : "Mobile wallets via WalletConnect are not enabled on this site."
          : ""}
      </p>
    </Dialog>
  );
}

export function WalletButton() {
  const ru = useLang() === "ru";
  const connection = useConnection();
  const disconnect = useDisconnect();
  const [open, setOpen] = useState(false);
  const [menu, setMenu] = useState(false);

  if (connection.status !== "connected" || connection.address === undefined) {
    return (
      <>
        <Button variant="secondary" onClick={() => setOpen(true)} disabled={connection.status === "connecting" || connection.status === "reconnecting"}>
          {connection.status === "connecting" || connection.status === "reconnecting" ? (ru ? "Подключаем…" : "Connecting…") : ru ? "Подключить кошелёк" : "Connect wallet"}
        </Button>
        <ConnectDialog open={open} onClose={() => setOpen(false)} />
      </>
    );
  }

  const chainName = isSupportedChainId(connection.chainId) ? CHAINS[connection.chainId].name : ru ? "Неподдерживаемая сеть" : "Unsupported network";
  return (
    <div className="relative">
      <button
        type="button"
        aria-expanded={menu}
        onClick={() => setMenu((m) => !m)}
        className="tabular flex h-10 items-center gap-2 rounded-control border border-line-strong bg-surface-raised px-3 text-sm"
      >
        <span aria-hidden className={`size-2 rounded-full ${isSupportedChainId(connection.chainId) ? "bg-accent" : "bg-warning"}`} />
        {shortAddress(connection.address)}
        <span className="sr-only">, {chainName}</span>
      </button>
      {menu ? (
        <div className="absolute right-0 z-50 mt-2 w-56 rounded-control border border-line-strong bg-surface p-2 shadow-widget">
          <p className="px-2 py-1 text-xs text-muted">{chainName}</p>
          <button
            type="button"
            className="w-full rounded-md px-2 py-2 text-left text-sm hover:bg-surface-raised"
            onClick={() => {
              disconnect.mutate();
              setMenu(false);
            }}
          >
            {ru ? "Отключить" : "Disconnect"}
          </button>
        </div>
      ) : null}
    </div>
  );
}
