import { BaseError, UserRejectedRequestError } from "viem";
import type { Lang } from "../i18n/lang.ts";

export function isUserRejection(error: unknown): boolean {
  if (error instanceof BaseError) {
    return error.walk((e) => e instanceof UserRejectedRequestError) instanceof UserRejectedRequestError;
  }
  return typeof error === "object" && error !== null && (error as { code?: unknown }).code === 4001;
}

/** Short, user-facing description of a wallet/RPC failure. Never shows raw RPC payloads. */
const TEXT = {
  en: {
    declined: "You declined the request in your wallet.",
    funds: "Not enough funds to cover the amount and the network fee.",
    chain: "Your wallet is on a different network. Switch networks and try again.",
    reverted: "The transaction would fail on-chain, usually because the price moved. Get a new quote and retry.",
    generic: "The wallet returned an error. Try again.",
  },
  ru: {
    declined: "Вы отклонили запрос в кошельке.",
    funds: "Недостаточно средств на сумму и комиссию сети.",
    chain: "Кошелёк подключён к другой сети. Переключите сеть и повторите.",
    reverted: "Транзакция не пройдёт в блокчейне — обычно из-за сдвига цены. Получите новую котировку и повторите.",
    generic: "Кошелёк вернул ошибку. Попробуйте ещё раз.",
  },
} as const;

export function describeWalletError(error: unknown, lang: Lang = "en"): string {
  const t = TEXT[lang];
  if (isUserRejection(error)) return t.declined;
  if (error instanceof BaseError) {
    const text = `${error.shortMessage} ${error.details ?? ""}`.toLowerCase();
    if (text.includes("insufficient funds")) return t.funds;
    if (text.includes("chain") && text.includes("mismatch")) return t.chain;
    if (text.includes("execution reverted")) return t.reverted;
    // Unrecognised wallet messages come in the wallet's own language; show them rather than hide the cause.
    return error.shortMessage.slice(0, 200);
  }
  return t.generic;
}
