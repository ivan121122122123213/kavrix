import { Loadable, amountLabel, chainName, type TokenIndex } from "./shared.tsx";
import { useAdminGet } from "./useAdmin.ts";
import { arr, big, num, str } from "./api.ts";

interface StatsView {
  swaps: { status: string; count: number }[];
  volume: { chainId: number; token: string; amount: bigint; count: number }[];
  fees: { chainId: number; token: string; amount: bigint }[];
  ramp: { provider: string; status: string; count: number }[];
  daily: { day: string; count: number }[];
}

function parseStats(v: unknown): StatsView {
  return {
    swaps: arr(v, "swapsByStatus").map((r) => ({ status: str(r["status"]), count: num(r["count"]) })),
    volume: arr(v, "confirmedVolume").map((r) => ({ chainId: num(r["chainId"]), token: str(r["token"]), amount: big(r["amount"]), count: num(r["count"]) })),
    fees: arr(v, "feeRevenue").map((r) => ({ chainId: num(r["chainId"]), token: str(r["token"]), amount: big(r["amount"]) })),
    ramp: arr(v, "rampByStatus").map((r) => ({ provider: str(r["provider"]), status: str(r["status"]), count: num(r["count"]) })),
    daily: arr(v, "dailyConfirmed").map((r) => ({ day: str(r["day"]), count: num(r["count"]) })),
  };
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-control border border-line px-4 py-3">
      <dt className="text-xs text-muted">{label}</dt>
      <dd className="tabular mt-1 text-xl font-semibold">{value}</dd>
    </div>
  );
}

export function Overview({ tokens }: { tokens: TokenIndex | null }) {
  const stats = useAdminGet("/stats?days=30", parseStats);
  return (
    <Loadable res={stats} label="Statistics">
      {(s) => {
        const total = s.swaps.reduce((a, b) => a + b.count, 0);
        const confirmed = s.swaps.find((x) => x.status === "confirmed")?.count ?? 0;
        const maxDay = Math.max(1, ...s.daily.map((d) => d.count));
        return (
          <div className="space-y-8">
            <p className="text-sm text-muted">Last 30 days. Amounts are in token units; Kavrix stores no USD prices, so nothing is converted or estimated.</p>
            <dl className="grid gap-3 sm:grid-cols-4">
              <Stat label="Swaps started" value={total} />
              <Stat label="Confirmed" value={confirmed} />
              <Stat label="Reverted / failed" value={(s.swaps.find((x) => x.status === "reverted")?.count ?? 0) + (s.swaps.find((x) => x.status === "failed")?.count ?? 0)} />
              <Stat label="Card orders" value={s.ramp.reduce((a, b) => a + b.count, 0)} />
            </dl>

            <section>
              <h3 className="mb-2 font-medium">Confirmed volume (sold side)</h3>
              {s.volume.length === 0 ? <p className="text-sm text-muted">No confirmed swaps in this period.</p> : (
                <ul className="space-y-1 text-sm">
                  {s.volume.map((v) => (
                    <li key={`${v.chainId}:${v.token}`} className="tabular">
                      {chainName(v.chainId)}: {amountLabel(tokens, v.chainId, v.token, v.amount)} in {v.count} swaps
                    </li>
                  ))}
                </ul>
              )}
            </section>

            <section>
              <h3 className="mb-2 font-medium">Platform fee revenue (confirmed swaps)</h3>
              {s.fees.length === 0 ? <p className="text-sm text-muted">No fees collected in this period.</p> : (
                <ul className="space-y-1 text-sm">
                  {s.fees.map((v) => (
                    <li key={`${v.chainId}:${v.token}`} className="tabular">
                      {chainName(v.chainId)}: {amountLabel(tokens, v.chainId, v.token, v.amount)}
                    </li>
                  ))}
                </ul>
              )}
            </section>

            <section>
              <h3 className="mb-2 font-medium">Confirmed swaps per day</h3>
              {s.daily.length === 0 ? <p className="text-sm text-muted">No data.</p> : (
                <ol className="space-y-1 text-xs">
                  {s.daily.map((d) => (
                    <li key={d.day} className="grid grid-cols-[6rem_1fr_3rem] items-center gap-2">
                      <span className="tabular text-muted">{d.day}</span>
                      <span aria-hidden className="h-2 rounded-full bg-accent/70" style={{ width: `${(d.count / maxDay) * 100}%` }} />
                      <span className="tabular text-right">{d.count}</span>
                    </li>
                  ))}
                </ol>
              )}
            </section>

            <section>
              <h3 className="mb-2 font-medium">Card orders by status</h3>
              {s.ramp.length === 0 ? <p className="text-sm text-muted">No card orders in this period.</p> : (
                <ul className="space-y-1 text-sm">
                  {s.ramp.map((r) => (
                    <li key={`${r.provider}:${r.status}`}>
                      {r.provider} · {r.status}: <span className="tabular">{r.count}</span>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          </div>
        );
      }}
    </Loadable>
  );
}
