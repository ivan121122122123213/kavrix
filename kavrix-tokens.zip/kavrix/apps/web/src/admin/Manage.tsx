import { useState, type FormEvent } from "react";
import { SUPPORTED_CHAIN_IDS, isSupportedChainId } from "@kavrix/shared";
import { describeError } from "../lib/api.ts";
import { shortAddress } from "../lib/format.ts";
import { Button } from "../ui/Button.tsx";
import { Field, inputClass } from "../ui/Field.tsx";
import { Notice } from "../ui/Notice.tsx";
import { Loadable, Table, chainName, td } from "./shared.tsx";
import { useAdminGet } from "./useAdmin.ts";
import { adminFetch, arr, canEdit, num, str, type AdminRole } from "./api.ts";

type Msg = { tone: "info" | "danger"; text: string } | null;

export function TokensPanel({ role, onChanged }: { role: AdminRole; onChanged: () => void }) {
  const tokens = useAdminGet("/tokens", (v) => arr(v, "tokens"));
  const [msg, setMsg] = useState<Msg>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [view, setView] = useState<"all" | "pending" | "live">("pending");
  const [form, setForm] = useState({ chainId: "8453", address: "", symbol: "", name: "", decimals: "18" });

  const toggle = async (chainId: number, address: string, enabled: boolean) => {
    setBusy(`${chainId}:${address}`);
    try {
      await adminFetch("PATCH", `/tokens/${chainId}/${address}`, { enabled });
      setMsg({ tone: "info", text: `${enabled ? "Enabled" : "Disabled"} ${shortAddress(address)} on ${chainName(chainId)}.` });
      tokens.retry();
      onChanged();
    } catch (err) {
      setMsg({ tone: "danger", text: describeError(err) });
    } finally {
      setBusy(null);
    }
  };

  const add = async (e: FormEvent) => {
    e.preventDefault();
    const chainId = Number(form.chainId);
    if (!isSupportedChainId(chainId)) return;
    setBusy("add");
    try {
      await adminFetch("POST", "/tokens", { chainId, address: form.address.trim(), symbol: form.symbol.trim(), name: form.name.trim(), decimals: Number(form.decimals) });
      setMsg({ tone: "info", text: "Token added as disabled. Verify it on the explorer, then enable it." });
      setForm((f) => ({ ...f, address: "", symbol: "", name: "" }));
      tokens.retry();
      onChanged();
    } catch (err) {
      setMsg({ tone: "danger", text: describeError(err) });
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="space-y-6">
      {msg !== null ? <Notice tone={msg.tone}>{msg.text}</Notice> : null}
      <Loadable res={tokens} label="Tokens">
        {(rows) => (
          <>
          <div className="mb-3 flex flex-wrap items-center gap-2 text-sm">
            {(["pending", "live", "all"] as const).map((v) => (
              <button
                key={v}
                type="button"
                aria-pressed={view === v}
                onClick={() => setView(v)}
                className={`rounded-[10px] px-3 py-1.5 ${view === v ? "bg-white/8 text-text" : "text-muted hover:text-text"}`}
              >
                {v === "pending" ? `Needs review (${rows.filter((t) => t["review"] === "pending").length})` : v === "live" ? `Live (${rows.filter((t) => t["enabled"] === true).length})` : `All (${rows.length})`}
              </button>
            ))}
          </div>
          <p className="mb-3 text-xs text-faint">
            Enabling or disabling a token makes it operator-owned: the daily sync will not change it again. Pending tokens were seen in only one
            source or failed an automatic check (see the note).
          </p>
          <Table caption="Listed tokens" head={["Network", "Symbol", "Contract", "Decimals", "Managed by", "Risk", "Status", ""]}>
            {rows
              .filter((t) => (view === "pending" ? t["review"] === "pending" : view === "live" ? t["enabled"] === true : true))
              .map((t) => {
              const chainId = num(t["chainId"]);
              const address = str(t["address"]);
              const enabled = t["enabled"] === true;
              return (
                <tr key={`${chainId}:${address}`}>
                  <td className={td}>{chainName(chainId)}</td>
                  <td className={td}>{str(t["symbol"])}</td>
                  <td className={`${td} font-mono text-xs`}>{address}</td>
                  <td className={`${td} tabular`}>{num(t["decimals"])}</td>
                  <td className={td}>
                    {str(t["review"]) === "manual" ? "Operator" : str(t["review"]) === "auto" ? "Sync (verified)" : "Sync (needs review)"}
                    {Array.isArray(t["sources"]) && t["sources"].length > 0 ? (
                      <span className="block text-xs text-faint">{(t["sources"] as unknown[]).map(str).join(", ")}</span>
                    ) : null}
                    {str(t["note"]) !== "" ? <span className="block max-w-xs text-xs text-warning">{str(t["note"])}</span> : null}
                  </td>
                  <td className={td}>{str(t["risk"]) === "high" ? <span className="text-warning">High</span> : <span className="text-muted">Standard</span>}</td>
                  <td className={td}>{enabled ? <span className="text-accent">Enabled</span> : <span className="text-muted">Disabled</span>}</td>
                  <td className={td}>
                    {canEdit(role, "operator") ? (
                      <Button variant="secondary" busy={busy === `${chainId}:${address}`} onClick={() => void toggle(chainId, address, !enabled)}>
                        {enabled ? "Disable" : "Enable"}
                      </Button>
                    ) : null}
                  </td>
                </tr>
              );
            })}
          </Table>
          </>
        )}
      </Loadable>

      {canEdit(role, "owner") ? (
        <form onSubmit={(e) => void add(e)} className="max-w-2xl space-y-4 rounded-control border border-line p-4">
          <h3 className="font-medium">Add a token</h3>
          <p className="text-sm text-muted">The server reads decimals from the contract and refuses a mismatch. New tokens start disabled.</p>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Network">
              {(c) => (
                <select {...c} className={inputClass} value={form.chainId} onChange={(e) => setForm({ ...form, chainId: e.target.value })}>
                  {SUPPORTED_CHAIN_IDS.map((id) => <option key={id} value={id}>{chainName(id)}</option>)}
                </select>
              )}
            </Field>
            <Field label="Contract address">
              {(c) => <input {...c} className={`${inputClass} font-mono text-sm`} spellCheck={false} value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />}
            </Field>
            <Field label="Symbol">{(c) => <input {...c} className={inputClass} value={form.symbol} onChange={(e) => setForm({ ...form, symbol: e.target.value })} />}</Field>
            <Field label="Name">{(c) => <input {...c} className={inputClass} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />}</Field>
            <Field label="Decimals">
              {(c) => <input {...c} inputMode="numeric" className={inputClass} value={form.decimals} onChange={(e) => setForm({ ...form, decimals: e.target.value.replace(/\D/g, "").slice(0, 2) })} />}
            </Field>
          </div>
          <Button type="submit" busy={busy === "add"} disabled={!/^0x[0-9a-fA-F]{40}$/.test(form.address.trim()) || form.symbol.trim() === "" || form.name.trim() === ""}>
            Add token
          </Button>
        </form>
      ) : null}
    </div>
  );
}

interface SettingView {
  key: string;
  value: unknown;
  version: number;
  updatedAt: string;
}

const LABELS: Record<string, { title: string; help: string }> = {
  "swap.enabled": { title: "Swaps enabled", help: "Kill switch. When off, no quotes are issued and no new swaps can be recorded. Pending swaps are still tracked." },
  "swap.fee_bps_by_chain": { title: "Platform fee by network (bps)", help: "Overrides PLATFORM_FEE_BPS per network. 25 = 0.25%, maximum 300. Requires PLATFORM_FEE_RECIPIENT." },
  "swap.quote_rate_per_minute": { title: "Quote requests per minute per IP", help: "5–600. Keep in mind the aggregator's own limit." },
  "ramp.enabled": { title: "Card providers enabled", help: "Pause a provider without removing its keys." },
  "ramp.buy_limits": { title: "Card purchase limits (fiat per order)", help: "Applied before sending the user to the provider. Providers may apply stricter limits." },
};

function SettingEditor({ s, editable, onSaved }: { s: SettingView; editable: boolean; onSaved: () => void }) {
  const [text, setText] = useState(JSON.stringify(s.value, null, 2));
  const [state, setState] = useState<Msg>(null);
  const [busy, setBusy] = useState(false);
  const meta = LABELS[s.key] ?? { title: s.key, help: "" };

  const save = async (value: unknown) => {
    setBusy(true);
    try {
      await adminFetch("PUT", `/settings/${encodeURIComponent(s.key)}`, { value, version: s.version });
      setState({ tone: "info", text: "Saved and recorded in the audit log." });
      onSaved();
    } catch (err) {
      setState({ tone: "danger", text: describeError(err) });
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="rounded-control border border-line p-4">
      <h3 className="font-medium">{meta.title}</h3>
      <p className="mt-1 text-sm text-muted">{meta.help}</p>
      <p className="mt-1 text-xs text-faint">Version {s.version}, updated {new Date(s.updatedAt).toLocaleString()}</p>
      {typeof s.value === "boolean" ? (
        <div className="mt-3">
          <Button variant={s.value ? "secondary" : "primary"} disabled={!editable} busy={busy} onClick={() => void save(!s.value)}>
            {s.value ? "Turn off" : "Turn on"}
          </Button>
          <span className={`ml-3 text-sm ${s.value ? "text-accent" : "text-warning"}`}>{s.value ? "On" : "Off"}</span>
        </div>
      ) : (
        <div className="mt-3 space-y-2">
          <label className="sr-only" htmlFor={`setting-${s.key}`}>{meta.title} (JSON)</label>
          <textarea
            id={`setting-${s.key}`}
            className={`${inputClass} h-28 py-2 font-mono text-xs`}
            value={text}
            readOnly={!editable}
            spellCheck={false}
            onChange={(e) => setText(e.target.value)}
          />
          {editable ? (
            <Button
              variant="secondary"
              busy={busy}
              onClick={() => {
                try {
                  void save(JSON.parse(text) as unknown);
                } catch {
                  setState({ tone: "danger", text: "Not valid JSON." });
                }
              }}
            >
              Save
            </Button>
          ) : null}
        </div>
      )}
      {state !== null ? <div className="mt-3"><Notice tone={state.tone}>{state.text}</Notice></div> : null}
    </section>
  );
}

export function SettingsPanel({ role }: { role: AdminRole }) {
  const settings = useAdminGet("/settings", (v) =>
    arr(v, "settings").map((r): SettingView => ({ key: str(r["key"]), value: r["value"], version: num(r["version"]), updatedAt: str(r["updatedAt"]) })),
  );
  return (
    <Loadable res={settings} label="Settings">
      {(rows) => (
        <div className="grid gap-4 lg:grid-cols-2">
          {!canEdit(role, "owner") ? <Notice>Only owners can change settings.</Notice> : null}
          {rows.map((s) => (
            <SettingEditor key={`${s.key}:${s.version}`} s={s} editable={canEdit(role, "owner")} onSaved={settings.retry} />
          ))}
        </div>
      )}
    </Loadable>
  );
}
