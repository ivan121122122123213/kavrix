import { ApiError, type Problem } from "../lib/api.ts";

export type AdminRole = "owner" | "operator" | "viewer";
export interface AdminMe {
  readonly email: string;
  readonly role: AdminRole;
  readonly expiresAt: string;
}

/**
 * Same-origin admin calls. The custom header plus SameSite=Strict cookie is the CSRF defence;
 * the session cookie itself is HttpOnly and never visible to scripts.
 */
export async function adminFetch(method: "GET" | "POST" | "PUT" | "PATCH" | "DELETE", path: `/${string}`, body?: unknown, signal?: AbortSignal): Promise<unknown> {
  const init: RequestInit = {
    method,
    credentials: "same-origin",
    headers: { accept: "application/json", "x-kavrix-admin": "1", ...(body === undefined ? {} : { "content-type": "application/json" }) },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    ...(signal === undefined ? {} : { signal }),
  };
  let res: Response;
  try {
    res = await fetch(`/api/admin${path}`, init);
  } catch (err) {
    if (err instanceof DOMException && err.name === "AbortError") throw err;
    throw new ApiError(0, undefined, "The admin API is unreachable.");
  }
  const json: unknown = await res.json().catch(() => undefined);
  if (!res.ok) {
    const p = typeof json === "object" && json !== null && typeof (json as Problem).code === "string" ? (json as Problem) : undefined;
    throw new ApiError(res.status, p);
  }
  return json;
}

export function parseMe(v: unknown): AdminMe {
  const o = (typeof v === "object" && v !== null ? v : {}) as Record<string, unknown>;
  const role = o["role"];
  if (typeof o["email"] !== "string" || (role !== "owner" && role !== "operator" && role !== "viewer") || typeof o["expiresAt"] !== "string") {
    throw new ApiError(502, undefined, "Invalid admin session response");
  }
  return { email: o["email"], role, expiresAt: o["expiresAt"] };
}

/** Narrow helpers for admin payloads: shape-checked, never trusted blindly. */
export function arr(v: unknown, key: string): Record<string, unknown>[] {
  const o = (typeof v === "object" && v !== null ? v : {}) as Record<string, unknown>;
  const a = o[key];
  if (!Array.isArray(a)) throw new ApiError(502, undefined, "Invalid admin response");
  return a.filter((x): x is Record<string, unknown> => typeof x === "object" && x !== null);
}

export const str = (v: unknown): string => (typeof v === "string" ? v : v === null || v === undefined ? "" : String(v));
export const num = (v: unknown): number => (typeof v === "number" && Number.isFinite(v) ? v : 0);
export const big = (v: unknown): bigint => (typeof v === "string" && /^\d{1,78}$/.test(v) ? BigInt(v) : 0n);
export const canEdit = (role: AdminRole, need: AdminRole): boolean => ({ viewer: 0, operator: 1, owner: 2 })[role] >= ({ viewer: 0, operator: 1, owner: 2 })[need];
