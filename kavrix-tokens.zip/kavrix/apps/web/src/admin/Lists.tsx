import { useState, type ReactNode } from "react";
import { SWAP_STATUSES, RAMP_STATUSES, SUPPORTED_CHAIN_IDS, explorerTxUrl, isSupportedChainId } from "@kavrix/shared";
import { shortAddress } from "../lib/format.ts";
import { ExternalLink } from "../ui/ExternalLink.tsx";
import { Button } from "../ui/Button.tsx";
import { inputClass } from "../ui/Field.tsx";
import { Loadable, Table, amountLabel, chainName, td, type TokenIndex } from "./shared.tsx";
import { useAdminGet } from "./useAdmin.ts";
import { arr, big, num, str } from "./api.ts";

type Row = Record<string, unknown>;
const page = (key: string) => (v: unknown) => ({
  rows: arr(v, key),
  next: (() => {
    const n = (v as Record<string, unknown>)["nextCursor"];
    return typeof n === "string" ? n : null;
  })(),
});

function Filters({ children }: { children: ReactNode }) {
  return <div className="mb-4 flex flex-wrap gap-2">{children}</div>;
}

export function SwapsList({ tokens }: { tokens: TokenIndex | null }) {
  const [status, setStatus] = useState("");
  const [chain, setChain] = useState("");
  const [cursors, setCursors] = useState<string[]>([]);
  const q = new URLSearchParams();
  if (status !== "") q.set("status", status);
  if (chain !== "") q.set("chainId", chain);
  const before = cursors.at(-1);
  if (before !== undefined) q.set("before", before);
  const res = useAdminGet(`/swaps?${q.toString()}`, page("swaps"));

  return (
    <div>
      <Filters>
        <select aria-label="Status" className={`${inputClass} w-auto`} value={status} onChange={(e) => { setStatus(e.target.value); setCursors([]); }}>
          <option value="">All statuses</option>
          {SWAP_STATUSES.map((s) => <option key={s}>{s}</option>)}
        </select>
        <select aria-label="Network" className={`${inputClass} w-auto`} value={chain} onChange={(e) => { setChain(e.target.value); setCursors([]); }}>
          <option value="">All networks</option>
          {SUPPORTED_CHAIN_IDS.map((id) => <option key={id} value={id}>{chainName(id)}</option>)}
        </select>
      </Filters>
      <Loadable res={res} label="Swaps">
        {({ rows, next }) => (
          <>
            <Table caption="Swaps" head={["Created", "Network", "Wallet", "Paid", "Received", "Fee", "Status", "Tx"]}>
              {rows.map((r: Row) => {
                const chainId = num(r["chainId"]);
                const hash = str(r["txHash"]);
                const received = r["actualBuyAmount"] === null ? big(r["quotedBuyAmount"]) : big(r["actualBuyAmount"]);
                return (
                  <tr key={str(r["id"])}>
                    <td className={td}>{new Date(str(r["createdAt"])).toLocaleString()}</td>
                    <td className={td}>{chainName(chainId)}</td>
                    <td className={`${td} font-mono text-xs`}>{shortAddress(str(r["taker"]))}</td>
                    <td className={`${td} tabular`}>{amountLabel(tokens, chainId, str(r["sellToken"]), big(r["sellAmount"]))}</td>
                    <td className={`${td} tabular`}>
                      {amountLabel(tokens, chainId, str(r["buyToken"]), received)}
                      {r["actualBuyAmount"] === null ? <span className="text-faint"> (quoted)</span> : null}
                    </td>
                    <td className={`${td} tabular`}>{num(r["platformFeeBps"])} bps</td>
                    <td className={td}>
                      {str(r["status"])}
                      {r["failureCode"] !== null ? <span className="block text-xs text-danger">{str(r["failureCode"])}</span> : null}
                    </td>
                    <td className={td}>
                      {/^0x[0-9a-f]{64}$/.test(hash) && isSupportedChainId(chainId) ? <ExternalLink href={explorerTxUrl(chainId, hash)}>{shortAddress(hash)}</ExternalLink> : "—"}
                    </td>
                  </tr>
                );
              })}
            </Table>
            {rows.length === 0 ? <p className="mt-3 text-sm text-muted">No swaps match.</p> : null}
            <div className="mt-3 flex gap-2">
              {cursors.length > 0 ? <Button variant="secondary" onClick={() => setCursors((c) => c.slice(0, -1))}>Newer</Button> : null}
              {next !== null ? <Button variant="secondary" onClick={() => setCursors((c) => [...c, next])}>Older</Button> : null}
            </div>
          </>
        )}
      </Loadable>
    </div>
  );
}

export function RampList() {
  const [status, setStatus] = useState("");
  const [provider, setProvider] = useState("");
  const [cursors, setCursors] = useState<string[]>([]);
  const q = new URLSearchParams();
  if (status !== "") q.set("status", status);
  if (provider !== "") q.set("provider", provider);
  const before = cursors.at(-1);
  if (before !== undefined) q.set("before", before);
  const res = useAdminGet(`/ramp-orders?${q.toString()}`, page("orders"));

  return (
    <div>
      <Filters>
        <select aria-label="Status" className={`${inputClass} w-auto`} value={status} onChange={(e) => { setStatus(e.target.value); setCursors([]); }}>
          <option value="">All statuses</option>
          {RAMP_STATUSES.map((s) => <option key={s}>{s}</option>)}
        </select>
        <select aria-label="Provider" className={`${inputClass} w-auto`} value={provider} onChange={(e) => { setProvider(e.target.value); setCursors([]); }}>
          <option value="">All providers</option>
          <option value="moonpay">moonpay</option>
          <option value="transak">transak</option>
        </select>
      </Filters>
      <Loadable res={res} label="Card orders">
        {({ rows, next }) => (
          <>
            <Table caption="Card orders" head={["Created", "Provider", "Type", "Network", "Amount", "Wallet", "Status", "Provider id"]}>
              {rows.map((r: Row) => (
                <tr key={str(r["id"])}>
                  <td className={td}>{new Date(str(r["createdAt"])).toLocaleString()}</td>
                  <td className={td}>{str(r["provider"])}</td>
                  <td className={td}>{str(r["direction"])} {str(r["cryptoCurrency"])}</td>
                  <td className={td}>{chainName(num(r["chainId"]))}</td>
                  <td className={`${td} tabular`}>
                    {str(r["direction"]) === "buy" ? `${str(r["fiatAmount"])} ${str(r["fiatCurrency"])}` : `${str(r["cryptoAmount"])} ${str(r["cryptoCurrency"])}`}
                  </td>
                  <td className={`${td} font-mono text-xs`}>{shortAddress(str(r["wallet"]))}</td>
                  <td className={td}>
                    {str(r["status"])}
                    {r["providerStatus"] !== null ? <span className="block text-xs text-faint">{str(r["providerStatus"])}</span> : null}
                  </td>
                  <td className={`${td} font-mono text-xs`}>{str(r["externalOrderId"]) || "—"}</td>
                </tr>
              ))}
            </Table>
            {rows.length === 0 ? <p className="mt-3 text-sm text-muted">No card orders match.</p> : null}
            <div className="mt-3 flex gap-2">
              {cursors.length > 0 ? <Button variant="secondary" onClick={() => setCursors((c) => c.slice(0, -1))}>Newer</Button> : null}
              {next !== null ? <Button variant="secondary" onClick={() => setCursors((c) => [...c, next])}>Older</Button> : null}
            </div>
          </>
        )}
      </Loadable>
    </div>
  );
}
