import { useState, type FormEvent } from "react";
import { Button } from "../ui/Button.tsx";
import { Field, inputClass } from "../ui/Field.tsx";
import { Notice } from "../ui/Notice.tsx";
import { describeError } from "../lib/api.ts";
import { adminFetch, parseMe, type AdminMe } from "./api.ts";

export function AdminLogin({ onSignedIn }: { onSignedIn: (me: AdminMe) => void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [code, setCode] = useState("");
  const [state, setState] = useState<{ status: "idle" | "busy" } | { status: "error"; message: string }>({ status: "idle" });

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setState({ status: "busy" });
    try {
      onSignedIn(parseMe(await adminFetch("POST", "/session", { email: email.trim(), password, code })));
    } catch (err) {
      setState({ status: "error", message: describeError(err) });
    } finally {
      setPassword("");
      setCode("");
    }
  };

  return (
    <form onSubmit={(e) => void submit(e)} className="max-w-sm space-y-4" noValidate>
      <Field label="Email">
        {(c) => <input {...c} type="email" autoComplete="username" className={inputClass} value={email} onChange={(e) => setEmail(e.target.value)} />}
      </Field>
      <Field label="Password">
        {(c) => <input {...c} type="password" autoComplete="current-password" className={inputClass} value={password} onChange={(e) => setPassword(e.target.value)} />}
      </Field>
      <Field label="Authenticator code" hint="6 digits from your authenticator app.">
        {(c) => (
          <input
            {...c}
            inputMode="numeric"
            autoComplete="one-time-code"
            pattern="[0-9]{6}"
            maxLength={6}
            className={`${inputClass} tabular tracking-[0.3em]`}
            value={code}
            onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
          />
        )}
      </Field>
      {state.status === "error" ? <Notice tone="danger" title="Sign-in failed">{state.message}</Notice> : null}
      <Button type="submit" busy={state.status === "busy"} disabled={email === "" || password === "" || code.length !== 6}>
        Sign in
      </Button>
      <p className="text-xs text-faint">Accounts are created on the server with the admin CLI. Repeated failures lock the account for 15 minutes.</p>
    </form>
  );
}
