import { useState } from "react";
import { Button } from "../ui/Button.tsx";
import { Loadable, Table, td } from "./shared.tsx";
import { useAdminGet } from "./useAdmin.ts";
import { arr, num, str } from "./api.ts";

type Obj = Record<string, unknown>;
const obj = (v: unknown): Obj => (typeof v === "object" && v !== null && !Array.isArray(v) ? (v as Obj) : {});

function Dot({ ok }: { ok: boolean }) {
  return <span aria-label={ok ? "OK" : "Problem"} className={`inline-block size-2 rounded-full ${ok ? "bg-accent" : "bg-danger"}`} />;
}

export function HealthPanel() {
  const health = useAdminGet("/health", obj);
  const errors = useAdminGet("/errors", (v) => arr(v, "errors"));
  return (
    <div className="space-y-8">
      <div className="flex justify-end">
        <Button variant="secondary" onClick={() => { health.retry(); errors.retry(); }}>Refresh</Button>
      </div>
      <Loadable res={health} label="Health">
        {(h) => {
          const tracker = obj(h["tracker"]);
          const last = str(tracker["lastTickAt"]);
          const stale = last === "" || Date.now() - Date.parse(last) > 60_000;
          return (
            <dl className="grid gap-4 sm:grid-cols-2">
              <div className="rounded-control border border-line p-4">
                <dt className="font-medium">Database</dt>
                <dd className="mt-1 flex items-center gap-2 text-sm"><Dot ok={h["database"] === "ok"} /> {str(h["database"])}</dd>
              </div>
              <div className="rounded-control border border-line p-4">
                <dt className="font-medium">Swap tracker</dt>
                <dd className="mt-1 space-y-1 text-sm">
                  <span className="flex items-center gap-2"><Dot ok={tracker["enabled"] === true && !stale} /> {tracker["enabled"] === true ? (stale ? "No recent tick" : "Running") : "Disabled in this process"}</span>
                  <span className="block text-muted">Last tick: {last === "" ? "never" : new Date(last).toLocaleTimeString()} · backlog {tracker["backlog"] === null ? "unknown" : num(tracker["backlog"])}</span>
                </dd>
              </div>
              <div className="rounded-control border border-line p-4">
                <dt className="font-medium">Network nodes</dt>
                <dd className="mt-1 space-y-1 text-sm">
                  {Object.entries(obj(h["rpc"])).map(([name, v]) => {
                    const r = obj(v);
                    return (
                      <span key={name} className="flex items-center gap-2">
                        <Dot ok={r["ok"] === true} /> {name}
                        {r["ok"] === true ? <span className="tabular text-muted">block {str(r["block"])} · {num(r["latencyMs"])} ms</span> : <span className="text-danger">unreachable</span>}
                      </span>
                    );
                  })}
                </dd>
              </div>
              <div className="rounded-control border border-line p-4">
                <dt className="font-medium">Providers</dt>
                <dd className="mt-1 space-y-1 text-sm">
                  {Object.entries(obj(h["providers"])).map(([name, v]) => {
                    const p = obj(v);
                    const hook = str(p["lastWebhookAt"]);
                    return (
                      <span key={name} className="flex flex-wrap items-center gap-2">
                        <Dot ok={p["configured"] === true} /> {name}
                        <span className="text-muted">
                          {p["configured"] === true ? "configured" : "not configured"}
                          {"lastWebhookAt" in p ? ` · last webhook ${hook === "" ? "never" : new Date(hook).toLocaleString()}` : ""}
                        </span>
                      </span>
                    );
                  })}
                </dd>
              </div>
              <div className="rounded-control border border-line p-4 sm:col-span-2">
                <dt className="font-medium">Errors in the last hour</dt>
                <dd className="mt-1 text-sm">
                  {Object.keys(obj(h["errorsLastHour"])).length === 0 ? <span className="text-muted">None</span> : (
                    <ul className="tabular">{Object.entries(obj(h["errorsLastHour"])).map(([code, n]) => <li key={code}>{code}: {num(n)}</li>)}</ul>
                  )}
                </dd>
              </div>
            </dl>
          );
        }}
      </Loadable>
      <section>
        <h3 className="mb-2 font-medium">Recent server errors (this process)</h3>
        <Loadable res={errors} label="Errors">
          {(rows) =>
            rows.length === 0 ? <p className="text-sm text-muted">No errors recorded since the last restart.</p> : (
              <Table caption="Recent errors" head={["Time", "Status", "Code", "Route", "Request id"]}>
                {rows.map((e, i) => (
                  <tr key={`${str(e["requestId"])}-${i}`}>
                    <td className={td}>{new Date(str(e["at"])).toLocaleString()}</td>
                    <td className={`${td} tabular`}>{num(e["status"])}</td>
                    <td className={td}>{str(e["code"])}</td>
                    <td className={`${td} font-mono text-xs`}>{str(e["route"])}</td>
                    <td className={`${td} font-mono text-xs`}>{str(e["requestId"])}</td>
                  </tr>
                ))}
              </Table>
            )
          }
        </Loadable>
      </section>
    </div>
  );
}

export function AuditPanel() {
  const [cursors, setCursors] = useState<string[]>([]);
  const before = cursors.at(-1);
  const res = useAdminGet(before === undefined ? "/audit" : `/audit?before=${before}`, (v) => ({
    rows: arr(v, "entries"),
    next: (() => {
      const n = obj(v)["nextCursor"];
      return typeof n === "string" ? n : null;
    })(),
  }));
  return (
    <Loadable res={res} label="Audit log">
      {({ rows, next }) => (
        <>
          <Table caption="Audit log" head={["Time", "Admin", "Action", "Target", "Before", "After", "IP"]}>
            {rows.map((e) => (
              <tr key={str(e["id"])}>
                <td className={td}>{new Date(str(e["createdAt"])).toLocaleString()}</td>
                <td className={td}>{str(e["adminEmail"]) || "system / CLI"}</td>
                <td className={td}>{str(e["action"])}</td>
                <td className={`${td} font-mono text-xs`}>{str(e["target"]) || "—"}</td>
                <td className={`${td} font-mono text-xs`}>{e["before"] === null ? "—" : JSON.stringify(e["before"])}</td>
                <td className={`${td} font-mono text-xs`}>{e["after"] === null ? "—" : JSON.stringify(e["after"])}</td>
                <td className={`${td} font-mono text-xs`}>{str(e["ip"]) || "—"}</td>
              </tr>
            ))}
          </Table>
          <div className="mt-3 flex gap-2">
            {cursors.length > 0 ? <Button variant="secondary" onClick={() => setCursors((c) => c.slice(0, -1))}>Newer</Button> : null}
            {next !== null ? <Button variant="secondary" onClick={() => setCursors((c) => [...c, next])}>Older</Button> : null}
          </div>
        </>
      )}
    </Loadable>
  );
}
