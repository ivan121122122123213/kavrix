import { useResource } from "../lib/resource.ts";
import { adminFetch } from "./api.ts";

/** GET an admin endpoint and parse it; `key` must change to refetch with new inputs. */
export function useAdminGet<T>(path: `/${string}`, parse: (v: unknown) => T, key: string = path) {
  return useResource(async (signal) => parse(await adminFetch("GET", path, undefined, signal)), `admin:${key}`);
}
