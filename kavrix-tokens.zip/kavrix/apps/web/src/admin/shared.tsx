import type { ReactNode } from "react";
import { CHAINS, NATIVE_TOKEN_ADDRESS, isSupportedChainId } from "@kavrix/shared";
import { formatTokenAmount, shortAddress } from "../lib/format.ts";
import { describeError } from "../lib/api.ts";
import { Notice } from "../ui/Notice.tsx";
import { Button } from "../ui/Button.tsx";
import { LoadingRows } from "../ui/Skeleton.tsx";
import type { Resource } from "../lib/resource.ts";
import { arr, num, str } from "./api.ts";

export interface TokenMeta {
  readonly symbol: string;
  readonly decimals: number;
}
export type TokenIndex = ReadonlyMap<string, TokenMeta>;

export function parseTokenIndex(v: unknown): TokenIndex {
  const m = new Map<string, TokenMeta>();
  for (const t of arr(v, "tokens")) m.set(`${num(t["chainId"])}:${str(t["address"]).toLowerCase()}`, { symbol: str(t["symbol"]), decimals: num(t["decimals"]) });
  return m;
}

/** Formats a base-unit amount using the token list; unknown tokens show raw units and the address. */
export function amountLabel(index: TokenIndex | null, chainId: number, address: string, amount: bigint): string {
  if (address === NATIVE_TOKEN_ADDRESS && isSupportedChainId(chainId)) {
    return `${formatTokenAmount(amount, 18)} ${CHAINS[chainId].nativeCurrency.symbol}`;
  }
  const meta = index?.get(`${chainId}:${address.toLowerCase()}`);
  return meta === undefined ? `${amount.toString()} units of ${shortAddress(address)}` : `${formatTokenAmount(amount, meta.decimals)} ${meta.symbol}`;
}

export const chainName = (id: number): string => (isSupportedChainId(id) ? CHAINS[id].name : `Chain ${id}`);

export function Loadable<T>({ res, label, children }: { res: Resource<T> & { retry: () => void }; label: string; children: (data: T) => ReactNode }) {
  if (res.status === "loading") return <LoadingRows label={`Loading ${label}`} rows={3} />;
  if (res.status === "error") {
    return (
      <Notice tone="danger" title={`${label} did not load`} action={<Button variant="secondary" onClick={res.retry}>Retry</Button>}>
        {describeError(res.error)}
      </Notice>
    );
  }
  return <>{children(res.data)}</>;
}

export function Table({ head, children, caption }: { head: readonly string[]; children: ReactNode; caption: string }) {
  return (
    <div className="overflow-x-auto rounded-control border border-line">
      <table className="w-full min-w-[40rem] text-left text-sm">
        <caption className="sr-only">{caption}</caption>
        <thead className="bg-surface text-muted">
          <tr>
            {head.map((h) => (
              <th key={h} scope="col" className="px-3 py-2 font-normal">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-line">{children}</tbody>
      </table>
    </div>
  );
}

export const td = "px-3 py-2 align-top";
