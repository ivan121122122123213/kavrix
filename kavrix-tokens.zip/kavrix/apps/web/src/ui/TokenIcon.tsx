import { useState } from "react";
import type { SupportedChainId } from "@kavrix/shared";

/**
 * Kavrix's own minted-coin icons. They are not the issuers' logos: operators who want official
 * artwork add files from each issuer's brand kit (see public/tokens/README.md) and set `logoUrl`.
 */
const PALETTE: Readonly<Record<string, readonly [string, string, string]>> = {
  // symbol: [light metal, deep metal, glyph]
  ETH: ["#b7b9ff", "#4b4f9e", "Ξ"],
  WETH: ["#c9ccd6", "#4e5464", "Ξ"],
  USDC: ["#5aa8ff", "#0b3f8a", "$"],
  USDT: ["#5fe0b2", "#0b6a4f", "T"],
  DAI: ["#ffd27a", "#9a6410", "D"],
  POL: ["#c7a6ff", "#5b2ca8", "P"],
};

const CHAIN_BADGE: Record<SupportedChainId, string> = {
  1: "#9aa0c8",
  8453: "#2f6bff",
  42161: "#28a0f0",
  137: "#8247e5",
};

function hashHue(address: string): number {
  let h = 0;
  for (const ch of address.toLowerCase()) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return 150 + (h % 90);
}

/** Only same-origin token artwork or https URLs are rendered; anything else falls back to the coin. */
function safeLogo(url: string | null | undefined): string | undefined {
  if (url == null) return undefined;
  if (/^\/tokens\/[a-z0-9-]+\.(svg|png|webp)$/.test(url)) return url;
  return /^https:\/\/[^\s"'<>]+$/.test(url) ? url : undefined;
}

export function TokenIcon({
  symbol,
  address,
  size = 32,
  chainId,
  logoUrl,
}: {
  symbol: string;
  address: string;
  size?: number;
  chainId?: SupportedChainId;
  logoUrl?: string | null;
}) {
  const [failed, setFailed] = useState(false);
  const known = PALETTE[symbol.toUpperCase()];
  const hue = hashHue(address);
  const [a, b, glyph] = known ?? [`hsl(${hue} 70% 68%)`, `hsl(${hue} 65% 26%)`, symbol.slice(0, 1).toUpperCase()];
  const logo = failed ? undefined : safeLogo(logoUrl);
  return (
    <span
      aria-hidden
      className="k-coin"
      style={{ width: size, height: size, fontSize: size * 0.44, ["--coin-a" as string]: a, ["--coin-b" as string]: b }}
    >
      <span>{glyph}</span>
      {logo !== undefined ? <img src={logo} alt="" loading="lazy" decoding="async" referrerPolicy="no-referrer" onError={() => setFailed(true)} /> : null}
      {chainId !== undefined ? <i className="k-coin-badge" style={{ ["--badge" as string]: CHAIN_BADGE[chainId] }} /> : null}
    </span>
  );
}
