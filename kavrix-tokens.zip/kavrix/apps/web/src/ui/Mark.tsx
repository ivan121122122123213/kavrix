import { useId } from "react";

/**
 * The Kavrix mark: two interlocked rings, one per side of a swap. The teal ring passes over the blue one
 * at the top crossing and under it at the bottom, like chain links. Gaps are cut along each ring's own
 * arc so the breaks stay square to the band at every size.
 * `swapped` turns the mark half a revolution so the rings trade places (the flip control).
 */
export const LINK_GEOMETRY = {
  ringA: "M9.0 32 a14.0 14.0 0 1 0 28.0 0 a14.0 14.0 0 1 0 -28.0 0",
  ringB: "M27.0 32 a14.0 14.0 0 1 0 28.0 0 a14.0 14.0 0 1 0 -28.0 0",
  overA: "M28.695 19.211 A14.0 14.0 0 0 1 34.607 24.172",
  overB: "M35.305 44.789 A14.0 14.0 0 0 1 29.393 39.828",
  stroke: 5.0,
  gap: 8.4,
} as const;

export function KavrixMark({
  size = 28,
  swapped = false,
  title,
  className = "",
}: {
  size?: number;
  swapped?: boolean;
  title?: string;
  className?: string;
}) {
  const id = useId().replace(/:/g, "");
  const ref = (n: string) => `url(#${n}-${id})`;
  const G = LINK_GEOMETRY;
  return (
    <svg
      viewBox="0 0 64 64"
      width={size}
      height={size}
      className={`k-mark ${className}`}
      data-swapped={swapped}
      role={title === undefined ? undefined : "img"}
      aria-hidden={title === undefined ? true : undefined}
      aria-label={title}
    >
      <defs>
        <linearGradient id={`a-${id}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#9dfcec" />
          <stop offset=".5" stopColor="#22f2d0" />
          <stop offset="1" stopColor="#0c9c86" />
        </linearGradient>
        <linearGradient id={`b-${id}`} x1="1" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#8fe2ff" />
          <stop offset=".5" stopColor="#00b8ff" />
          <stop offset="1" stopColor="#0566a0" />
        </linearGradient>
        <mask id={`ma-${id}`} maskUnits="userSpaceOnUse" x="0" y="0" width="64" height="64">
          <rect width="64" height="64" fill="#fff" />
          <path d={G.overB} fill="none" stroke="#000" strokeWidth={G.gap} />
        </mask>
        <mask id={`mb-${id}`} maskUnits="userSpaceOnUse" x="0" y="0" width="64" height="64">
          <rect width="64" height="64" fill="#fff" />
          <path d={G.overA} fill="none" stroke="#000" strokeWidth={G.gap} />
        </mask>
      </defs>
      <g className="k-mark-body">
        <path d={G.ringA} fill="none" stroke={ref("a")} strokeWidth={G.stroke} mask={ref("ma")} />
        <path d={G.ringB} fill="none" stroke={ref("b")} strokeWidth={G.stroke} mask={ref("mb")} />
      </g>
    </svg>
  );
}

export function Wordmark() {
  return (
    <span className="flex items-center gap-2.5 text-text">
      <KavrixMark size={30} />
      <span className="k-wordmark">Kavrix</span>
    </span>
  );
}
