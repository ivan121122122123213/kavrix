import { useId, type ReactNode } from "react";

export interface FieldControlProps {
  readonly id: string;
  readonly "aria-describedby": string | undefined;
  readonly "aria-invalid": boolean | undefined;
}

/** Label + control + hint + error, wired with ids so screen readers read them together. */
export function Field({
  label,
  hint,
  error,
  children,
  labelHidden = false,
}: {
  label: string;
  hint?: ReactNode;
  error?: string | undefined;
  labelHidden?: boolean;
  children: (control: FieldControlProps) => ReactNode;
}) {
  const id = useId();
  const hintId = hint !== undefined ? `${id}-hint` : undefined;
  const errorId = error !== undefined ? `${id}-error` : undefined;
  const describedBy = [hintId, errorId].filter(Boolean).join(" ") || undefined;
  return (
    <div>
      <label htmlFor={id} className={labelHidden ? "sr-only" : "mb-1.5 block text-sm text-muted"}>
        {label}
      </label>
      {children({ id, "aria-describedby": describedBy, "aria-invalid": error !== undefined ? true : undefined })}
      {hint !== undefined ? (
        <p id={hintId} className="mt-1.5 text-xs text-faint">
          {hint}
        </p>
      ) : null}
      {error !== undefined ? (
        <p id={errorId} className="mt-1.5 text-xs text-danger">
          {error}
        </p>
      ) : null}
    </div>
  );
}

export const inputClass =
  "h-11 w-full rounded-control border border-line bg-surface-sunken px-3 text-text placeholder:text-faint focus:border-accent/70 focus:outline-none aria-[invalid=true]:border-danger/70";
