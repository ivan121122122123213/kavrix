import { useEffect, useState } from "react";

let played = false;

/**
 * True only for the first mount in this page session. Returning to the home page later shows the
 * finished state instead of replaying the entrance. Safe under StrictMode: the flag flips in an effect.
 */
export function useIntroOnce(): boolean {
  const [intro] = useState(() => !played);
  useEffect(() => {
    played = true;
  }, []);
  return intro;
}
