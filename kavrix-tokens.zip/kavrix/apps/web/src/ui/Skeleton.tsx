/** Placeholder shape. Pass a display class (`block`, `inline-block`) together with the size. */
export function Skeleton({ className = "block" }: { className?: string }) {
  return <span aria-hidden className={`animate-pulse rounded-md bg-surface-raised ${className}`} />;
}

/** Announces loading to assistive tech while showing placeholder shapes. */
export function LoadingRows({ label, rows = 3 }: { label: string; rows?: number }) {
  return (
    <div role="status" aria-label={label} className="space-y-3">
      {Array.from({ length: rows }, (_, i) => (
        <Skeleton key={i} className="block h-12 w-full" />
      ))}
    </div>
  );
}
