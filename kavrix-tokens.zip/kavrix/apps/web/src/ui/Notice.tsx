import type { ReactNode } from "react";

type Tone = "info" | "warning" | "danger";

const TONES: Record<Tone, string> = {
  info: "border-line-strong text-muted",
  warning: "border-warning/40 text-warning",
  danger: "border-danger/40 text-danger",
};

/** Inline message. Danger notices are announced immediately; others politely. */
export function Notice({ tone = "info", title, children, action }: { tone?: Tone; title?: string; children?: ReactNode; action?: ReactNode }) {
  return (
    <div role={tone === "danger" ? "alert" : "status"} className={`rounded-control border bg-surface-sunken px-4 py-3 text-sm ${TONES[tone]}`}>
      {title !== undefined ? <p className="font-medium text-text">{title}</p> : null}
      {children !== undefined ? <div className={title !== undefined ? "mt-1" : ""}>{children}</div> : null}
      {action !== undefined ? <div className="mt-3">{action}</div> : null}
    </div>
  );
}
