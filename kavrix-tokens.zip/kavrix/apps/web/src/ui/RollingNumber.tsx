/**
 * Odometer-style number: each digit rolls to its new value. Columns are keyed from the right so
 * units stay aligned while the integer part grows. Screen readers get the plain value.
 */
export function RollingNumber({ value, className = "" }: { value: string; className?: string }) {
  const chars = [...value];
  return (
    <span className={`k-num ${className}`} aria-label={value} role="text">
      <span aria-hidden className="inline-flex">
        {chars.map((ch, i) => {
          const key = chars.length - i;
          if (!/\d/.test(ch)) {
            return (
              <span key={`s${key}`} className="k-roll">
                <span>{ch}</span>
              </span>
            );
          }
          const d = Number(ch);
          return (
            <span key={`d${key}`} className="k-roll">
              <span className="k-roll-col" style={{ transform: `translateY(-${d * 1.1}em)` }}>
                {"0123456789".split("").map((n) => (
                  <span key={n}>{n}</span>
                ))}
              </span>
            </span>
          );
        })}
      </span>
    </span>
  );
}
