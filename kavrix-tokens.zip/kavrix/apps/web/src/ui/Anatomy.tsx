import { useEffect, useRef, useState } from "react";
import { Link } from "react-router";
import { CHAINS } from "@kavrix/shared";
import { shortAddress } from "../lib/format.ts";
import { useLang } from "../i18n/core.tsx";
import type { L10n } from "../i18n/lang.ts";

const ROUTER = shortAddress(CHAINS[1].kyberRouter);

const CHECKS: L10n<readonly { title: string; detail: string; value: string }[]> = {
  en: [
    { title: "Contract", detail: "The published KyberSwap router, nothing else", value: ROUTER },
    { title: "Recipient", detail: "Output goes to the wallet that signs", value: "Your wallet" },
    { title: "Minimum received", detail: "Decoded from the transaction and matched to your tolerance", value: "Enforced on-chain" },
    { title: "Fee receivers", detail: "Only Kavrix's own address, and only if a fee is set", value: "Kavrix only" },
    { title: "Approval", detail: "Exactly the amount you swap, never unlimited", value: "Exact" },
  ],
  ru: [
    { title: "Контракт", detail: "Только опубликованный роутер KyberSwap, никакой другой", value: ROUTER },
    { title: "Получатель", detail: "Результат обмена уходит на кошелёк, который подписывает", value: "Ваш кошелёк" },
    { title: "Минимум к получению", detail: "Расшифрован из транзакции и сверен с вашим допуском", value: "Гарантирован в блокчейне" },
    { title: "Получатели комиссии", detail: "Только адрес Kavrix — и только если комиссия включена", value: "Только Kavrix" },
    { title: "Разрешение", detail: "Ровно на сумму обмена, никогда не безлимитное", value: "Точное" },
  ],
};

/**
 * What Kavrix verifies before a wallet sees a transaction. The checks light up one by one the first
 * time the card scrolls into view: the page's single scroll-triggered moment.
 */
export function Anatomy() {
  const lang = useLang();
  const ru = lang === "ru";
  // Both languages list the same five checks, so the reveal count does not depend on the language.
  const checks = CHECKS[lang];
  const card = useRef<HTMLDivElement>(null);
  const [lit, setLit] = useState(0);

  useEffect(() => {
    const el = card.current;
    if (el === null) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setLit(CHECKS.en.length);
      return;
    }
    const timers: number[] = [];
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry?.isIntersecting !== true) return;
        io.disconnect();
        CHECKS.en.forEach((_, i) => timers.push(window.setTimeout(() => setLit(i + 1), 250 + i * 220)));
      },
      { threshold: 0.45 },
    );
    io.observe(el);
    return () => {
      io.disconnect();
      timers.forEach(clearTimeout);
    };
  }, []);

  return (
    <section aria-labelledby="anatomy-title" className="mx-auto mt-32 grid max-w-6xl items-start gap-12 sm:mt-44 lg:grid-cols-[minmax(0,1fr)_32rem] lg:gap-20">
      <div>
        <h2 id="anatomy-title" className="k-display max-w-[16ch] text-[clamp(2rem,1.2rem_+_2vw,3.1rem)]">
          {ru ? "Проверено до того, как увидит кошелёк." : "Checked before your wallet sees it."}
        </h2>
        <p className="mt-5 max-w-[46ch] leading-relaxed text-muted">
          {ru
            ? "Агрегаторы возвращают сырые данные транзакции. Kavrix расшифровывает их на сервере и ещё раз в вашем браузере и отклоняет всё, что не совпадает с вашим запросом. Если не прошла хотя бы одна проверка, в кошелёк ничего не попадёт."
            : "Aggregators return raw transaction data. Kavrix decodes it on the server and again in your browser, and refuses anything that does not match what you asked for. If a single check fails, nothing reaches your wallet."}
        </p>
        <p className="mt-4 flex flex-wrap gap-x-5 gap-y-2 text-sm">
          <Link className="text-accent hover:underline" to="/security">
            {ru ? "Как Kavrix вас защищает" : "How Kavrix protects you"}
          </Link>
          <Link className="text-accent hover:underline" to="/fees">
            {ru ? "Как устроены комиссии" : "How fees work"}
          </Link>
        </p>
      </div>
      <div ref={card} className="k-glass px-6 py-2">
        <ul>
          {checks.map((c, i) => (
            <li key={c.title} className="k-check" data-on={i < lit}>
              <span className="k-check-dot">
                <svg viewBox="0 0 12 12" fill="none" stroke="var(--k-teal)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                  <path d="M2.5 6.3 L5 8.6 L9.6 3.6" />
                </svg>
              </span>
              <span>
                <span className="block font-medium">{c.title}</span>
                <span className="mt-0.5 block text-sm text-muted">{c.detail}</span>
              </span>
              <span className="k-check-value k-num">{c.value}</span>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
