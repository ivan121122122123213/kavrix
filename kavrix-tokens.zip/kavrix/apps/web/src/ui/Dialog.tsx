import { useEffect, useId, useRef, type ReactNode } from "react";
import { useLang } from "../i18n/core.tsx";

/**
 * Native modal <dialog>: focus trapping, Escape and inert background come from the browser.
 * `onClose` fires for Escape, backdrop click and the close button.
 */
export function Dialog({ open, onClose, title, children }: { open: boolean; onClose: () => void; title: string; children: ReactNode }) {
  const ref = useRef<HTMLDialogElement>(null);
  const titleId = useId();

  useEffect(() => {
    const dialog = ref.current;
    if (dialog === null) return;
    if (open && !dialog.open) dialog.showModal();
    if (!open && dialog.open) dialog.close();
  }, [open]);

  return (
    <dialog
      ref={ref}
      aria-labelledby={titleId}
      onClose={onClose}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      className="k-dialog m-auto w-[min(28rem,calc(100vw_-_2rem))] border-0 p-0 text-text"
    >
      <div className="relative z-10 flex items-center justify-between border-b border-line px-5 py-4">
        <h2 id={titleId} className="text-lg font-semibold">
          {title}
        </h2>
        <button type="button" onClick={onClose} className="rounded-md p-1 text-muted hover:text-text" aria-label={useLang() === "ru" ? "Закрыть" : "Close"}>
          <svg aria-hidden viewBox="0 0 20 20" className="size-5" fill="none" stroke="currentColor" strokeWidth="1.8">
            <path d="M5 5l10 10M15 5L5 15" strokeLinecap="round" />
          </svg>
        </button>
      </div>
      {open ? <div className="relative z-10 p-5">{children}</div> : null}
    </dialog>
  );
}
