import type { ReactNode } from "react";
import { useLang } from "../i18n/core.tsx";

export function ExternalLink({ href, children, className = "" }: { href: string; children: ReactNode; className?: string }) {
  return (
    <a href={href} target="_blank" rel="noopener noreferrer" className={`text-accent underline underline-offset-3 hover:text-text ${className}`}>
      {children}
      <span className="sr-only">{useLang() === "ru" ? " (откроется в новой вкладке)" : " (opens in a new tab)"}</span>
    </a>
  );
}
