import type { ButtonHTMLAttributes, ReactNode } from "react";

type Variant = "primary" | "secondary" | "ghost";
type Size = "md" | "lg";

const SIZES: Record<Size, string> = {
  md: "h-10 px-4 text-sm",
  lg: "h-14 px-5 text-lg w-full",
};

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  busy?: boolean;
  children: ReactNode;
}

export function Button({ variant = "primary", size = "md", busy = false, className = "", children, disabled, ...rest }: ButtonProps) {
  return (
    <button
      type="button"
      {...rest}
      disabled={disabled === true || busy}
      aria-busy={busy || undefined}
      className={`k-btn k-btn--${variant} ${SIZES[size]} ${className}`}
    >
      {busy ? <span aria-hidden className="relative z-10 size-4 animate-spin rounded-full border-2 border-current border-t-transparent" /> : null}
      <span className="relative z-10">{children}</span>
    </button>
  );
}
