import { useEffect, useRef } from "react";
import { createLinkField, type LinkField as Field } from "../design/link.ts";

/**
 * Two interlocked rings of light behind the swap widget. Quoting speeds up and brightens the flow;
 * the pointer tilts the rings slightly. Listens on the parent element so the page needs no wiring.
 */
export function LinkField({ busy, intro }: { busy: boolean; intro: boolean }) {
  const canvas = useRef<HTMLCanvasElement>(null);
  const field = useRef<Field | null>(null);

  useEffect(() => {
    const el = canvas.current;
    const host = el?.parentElement;
    if (el == null || host == null) return;
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const f = createLinkField(el, { reducedMotion });
    field.current = f;
    const onMove = (e: PointerEvent) => {
      if (e.pointerType === "touch") return;
      const r = host.getBoundingClientRect();
      f.tilt(((e.clientX - r.left) / r.width) * 2 - 1, ((e.clientY - r.top) / r.height) * 2 - 1);
    };
    const onLeave = () => f.tilt(null, null);
    host.addEventListener("pointermove", onMove);
    host.addEventListener("pointerleave", onLeave);
    return () => {
      host.removeEventListener("pointermove", onMove);
      host.removeEventListener("pointerleave", onLeave);
      f.destroy();
      field.current = null;
    };
  }, []);

  useEffect(() => {
    field.current?.update({ activity: busy ? 1 : 0.35 });
  }, [busy]);

  return (
    <>
      <div aria-hidden className={`k-link-glow ${intro ? "k-fade-in" : ""}`} />
      <canvas ref={canvas} aria-hidden className={`k-link-canvas ${intro ? "k-fade-in" : ""}`} />
    </>
  );
}
