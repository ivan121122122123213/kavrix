/** Framework-free language primitives (importable from Node scripts and tests). */

export type Lang = "en" | "ru";
export const LANGS: readonly Lang[] = ["ru", "en"];
/** A value per language. TypeScript rejects a missing translation. */
export type L10n<T = string> = Readonly<Record<Lang, T>>;

export const STORAGE_KEY = "kavrix.lang";
// Typed locally so this module also loads in Node scripts (prerender) without Vite types.
const env: { readonly VITE_DEFAULT_LANG?: string } = (import.meta as { env?: { readonly VITE_DEFAULT_LANG?: string } }).env ?? {};

/** Build-time default (prerendered <head>, visitors whose browser prefers neither language). */
export const DEFAULT_LANG: Lang = env.VITE_DEFAULT_LANG === "en" ? "en" : "ru";

export function isLang(v: unknown): v is Lang {
  return v === "en" || v === "ru";
}

/** Saved choice, then the browser's preference, then the site default. */
export function detectLang(): Lang {
  if (typeof window === "undefined") return DEFAULT_LANG;
  try {
    const saved = window.localStorage.getItem(STORAGE_KEY);
    if (isLang(saved)) return saved;
  } catch {
    // Storage can be unavailable (private mode); fall through to detection.
  }
  for (const l of navigator.languages ?? [navigator.language]) {
    const base = l.toLowerCase().split("-")[0];
    if (base === "ru" || base === "uk" || base === "be" || base === "kk") return "ru";
    if (base === "en") return "en";
  }
  return DEFAULT_LANG;
}

/** Locale for Intl APIs (dates, grouping). */
export function locale(lang: Lang): string {
  return lang === "ru" ? "ru-RU" : "en-US";
}

/** Russian plural form: 1 подтверждение, 2 подтверждения, 5 подтверждений. */
export function ruPlural(n: number, one: string, few: string, many: string): string {
  const m10 = n % 10;
  const m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return one;
  if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return few;
  return many;
}
