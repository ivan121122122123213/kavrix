import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { DEFAULT_LANG, STORAGE_KEY, detectLang, type Lang } from "./lang.ts";

export * from "./lang.ts";

interface I18nValue {
  readonly lang: Lang;
  readonly setLang: (lang: Lang) => void;
}

const I18nContext = createContext<I18nValue>({ lang: DEFAULT_LANG, setLang: () => undefined });

export function I18nProvider({ children, initial }: { children: ReactNode; initial?: Lang }) {
  const [lang, setLangState] = useState<Lang>(() => initial ?? detectLang());
  const setLang = useCallback((next: Lang) => {
    setLangState(next);
    try {
      window.localStorage.setItem(STORAGE_KEY, next);
    } catch {
      // Not persisting is acceptable; the choice still applies to this visit.
    }
  }, []);
  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);
  const value = useMemo(() => ({ lang, setLang }), [lang, setLang]);
  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n(): I18nValue {
  return useContext(I18nContext);
}

export function useLang(): Lang {
  return useContext(I18nContext).lang;
}

