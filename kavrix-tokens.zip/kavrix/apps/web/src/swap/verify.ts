import { CHAINS, NATIVE_TOKEN_ADDRESS, type SupportedChainId } from "@kavrix/shared";
import type { FirmQuoteView } from "./quote.ts";

/** Contracts a swap transaction may call, per provider. Mirrors the server-side allowlist. */
export function allowedTargets(chainId: SupportedChainId, provider: FirmQuoteView["provider"]): `0x${string}` {
  return provider === "kyberswap" ? CHAINS[chainId].kyberRouter : CHAINS[chainId].zeroExAllowanceHolder;
}

export type VerifyFailure = "expired" | "wrong_wallet" | "wrong_target" | "wrong_value" | "wrong_spender";

/** Last check in the browser before anything reaches the wallet. Defence in depth over the server checks. */
export function verifyFirmQuote(quote: FirmQuoteView, account: string, nowMs: number, marginMs = 3_000): VerifyFailure | undefined {
  if (quote.expiresAt - nowMs < marginMs) return "expired";
  if (quote.taker !== account.toLowerCase()) return "wrong_wallet";
  const target = allowedTargets(quote.chainId, quote.provider);
  if (quote.tx.to !== target) return "wrong_target";
  const native = quote.sellToken === NATIVE_TOKEN_ADDRESS;
  if (native ? quote.tx.value !== quote.sellAmount : quote.tx.value !== 0n) return "wrong_value";
  if (native ? quote.spender !== null : quote.spender !== target) return "wrong_spender";
  return undefined;
}

export const VERIFY_MESSAGES_RU: Record<VerifyFailure, string> = {
  expired: "Котировка устарела. Получаем новую.",
  wrong_wallet: "Котировка составлена для другого кошелька. Получаем новую.",
  wrong_target: "Котировка ведёт на неожиданный контракт и заблокирована.",
  wrong_value: "Сумма платежа в котировке не совпадает — она заблокирована.",
  wrong_spender: "Котировка просит разрешение для неожиданного контракта и заблокирована.",
};

export const VERIFY_MESSAGES: Record<VerifyFailure, string> = {
  expired: "The quote expired. A fresh quote is being fetched.",
  wrong_wallet: "The quote was made for a different wallet. Fetching a new one.",
  wrong_target: "The quote targets an unexpected contract and was blocked.",
  wrong_value: "The quote's payment amount does not match and was blocked.",
  wrong_spender: "The quote asks to approve an unexpected contract and was blocked.",
};
