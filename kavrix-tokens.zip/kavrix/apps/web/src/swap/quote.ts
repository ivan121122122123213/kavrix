import { isSupportedChainId, type SupportedChainId } from "@kavrix/shared";
import { ApiError } from "../lib/api.ts";

export type ProviderId = "kyberswap" | "0x";

/** Quote as the browser sees it. Built only from a server-validated provider response. */
export interface QuoteView {
  readonly provider: ProviderId;
  readonly chainId: SupportedChainId;
  readonly sellToken: `0x${string}`;
  readonly buyToken: `0x${string}`;
  readonly sellAmount: bigint;
  readonly buyAmount: bigint;
  readonly minBuyAmount: bigint;
  readonly platformFee: { readonly bps: number; readonly amount: bigint; readonly token: "sell" | "buy" };
  /** Explicit provider fee in the buy token; null when the provider charges none. */
  readonly providerFee: bigint | null;
  readonly networkFeeWei: bigint | null;
  readonly route: readonly { readonly source: string; readonly proportionBps: number }[];
  /** Provider-reported USD values (display and warnings only); null when unknown. */
  readonly valueUsd: { readonly sell: number; readonly buy: number } | null;
  readonly expiresAt: number;
}

export interface FirmQuoteView extends QuoteView {
  /** Server-signed terms; presented when the swap is recorded right before signing. */
  readonly quoteToken: string;
  readonly taker: `0x${string}`;
  readonly spender: `0x${string}` | null;
  readonly tx: { readonly to: `0x${string}`; readonly data: `0x${string}`; readonly value: bigint };
}

export type AnyQuote = (QuoteView & { readonly firm: false }) | (FirmQuoteView & { readonly firm: true });

/** Buy-token base units received per one whole sell token, rounded down. */
export function unitRate(quote: Pick<QuoteView, "sellAmount" | "buyAmount">, sellDecimals: number): bigint {
  if (quote.sellAmount <= 0n) return 0n;
  return (quote.buyAmount * 10n ** BigInt(sellDecimals)) / quote.sellAmount;
}

type J = Record<string, unknown>;
const ADDR = /^0x[0-9a-fA-F]{40}$/;
const UINT = /^\d{1,78}$/;

function bad(): never {
  throw new ApiError(502, undefined, "The server returned an invalid quote");
}
function obj(v: unknown): J {
  return typeof v === "object" && v !== null && !Array.isArray(v) ? (v as J) : bad();
}
function uint(v: unknown): bigint {
  return typeof v === "string" && UINT.test(v) ? BigInt(v) : bad();
}
function addr(v: unknown): `0x${string}` {
  return typeof v === "string" && ADDR.test(v) ? (v.toLowerCase() as `0x${string}`) : bad();
}

/** Strict guard for POST /v1/swap/quote; rejects anything not matching the request it answers. */
export function parseQuote(body: unknown, expect: { chainId: number; sellToken: string; buyToken: string; sellAmount: bigint }): AnyQuote {
  const o = obj(body);
  const chainId = o["chainId"];
  const provider = o["provider"];
  if (!isSupportedChainId(chainId) || chainId !== expect.chainId) bad();
  if (provider !== "kyberswap" && provider !== "0x") bad();
  const fee = obj(o["platformFee"]);
  const feeBps = fee["bps"];
  if (typeof feeBps !== "number" || !Number.isInteger(feeBps) || feeBps < 0 || feeBps > 300) bad();
  if (fee["token"] !== "sell" && fee["token"] !== "buy") bad();
  const routeRaw = o["route"];
  if (!Array.isArray(routeRaw) || routeRaw.length > 32) bad();
  const route = routeRaw.map((r) => {
    const leg = obj(r);
    const source = leg["source"];
    const proportionBps = leg["proportionBps"];
    if (typeof source !== "string" || source.length > 128 || typeof proportionBps !== "number" || proportionBps < 0 || proportionBps > 10_000) bad();
    return { source, proportionBps };
  });
  const usdRaw = o["valueUsd"];
  let valueUsd: QuoteView["valueUsd"] = null;
  if (usdRaw !== null && usdRaw !== undefined) {
    const u = obj(usdRaw);
    const s = u["sell"];
    const b = u["buy"];
    const ok = (n: unknown): n is number => typeof n === "number" && Number.isFinite(n) && n >= 0 && n < 1e13;
    if (!ok(s) || !ok(b)) bad();
    valueUsd = { sell: s, buy: b };
  }
  const expiresAt = o["expiresAt"];
  if (typeof expiresAt !== "number" || !Number.isFinite(expiresAt)) bad();

  const base: QuoteView = {
    provider,
    chainId,
    sellToken: addr(o["sellToken"]),
    buyToken: addr(o["buyToken"]),
    sellAmount: uint(o["sellAmount"]),
    buyAmount: uint(o["buyAmount"]),
    minBuyAmount: uint(o["minBuyAmount"]),
    platformFee: { bps: feeBps, amount: uint(fee["amount"]), token: fee["token"] },
    providerFee: o["providerFee"] === null ? null : uint(o["providerFee"]),
    networkFeeWei: o["networkFeeWei"] === null ? null : uint(o["networkFeeWei"]),
    route,
    valueUsd,
    expiresAt,
  };
  if (
    base.sellToken !== expect.sellToken.toLowerCase() ||
    base.buyToken !== expect.buyToken.toLowerCase() ||
    base.sellAmount !== expect.sellAmount ||
    base.buyAmount === 0n ||
    base.minBuyAmount === 0n ||
    base.minBuyAmount > base.buyAmount
  ) {
    bad();
  }
  if (o["firm"] !== true) return { ...base, firm: false };
  const tx = obj(o["tx"]);
  const data = tx["data"];
  if (typeof data !== "string" || !/^0x([0-9a-fA-F]{2})+$/.test(data)) bad();
  const quoteToken = o["quoteToken"];
  if (typeof quoteToken !== "string" || !/^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]{43}$/.test(quoteToken) || quoteToken.length > 8192) bad();
  return {
    ...base,
    firm: true,
    quoteToken,
    taker: addr(o["taker"]),
    spender: o["spender"] === null ? null : addr(o["spender"]),
    tx: { to: addr(tx["to"]), data: data as `0x${string}`, value: uint(tx["value"]) },
  };
}
