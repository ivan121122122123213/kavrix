import { useEffect, useState, type ReactNode } from "react";
import type { Lang } from "../i18n/lang.ts";
import type { TokenOption } from "../lib/api.ts";
import { formatBps, formatTokenAmount } from "../lib/format.ts";
import { unitRate, type QuoteView } from "./quote.ts";
import { RouteRail } from "./RouteRail.tsx";
import { IMPACT_CONFIRM_BPS, IMPACT_WARN_BPS, priceImpactBps } from "./impact.ts";

const PROVIDER_LABEL: Record<QuoteView["provider"], string> = { kyberswap: "KyberSwap", "0x": "0x" };

function useSecondsLeft(expiresAt: number): number {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);
  return Math.max(0, Math.ceil((expiresAt - now) / 1000));
}

function Row({ term, children }: { term: string; children: ReactNode }) {
  return (
    <div className="flex items-baseline justify-between gap-4 py-1.5">
      <dt className="text-muted">{term}</dt>
      <dd className="tabular text-right text-text">{children}</dd>
    </div>
  );
}

/** Countdown ring: drains as the quote ages, so freshness is visible at a glance. */
function FreshnessRing({ secondsLeft, ttlSeconds }: { secondsLeft: number; ttlSeconds: number }) {
  const r = 6;
  const c = 2 * Math.PI * r;
  const ratio = ttlSeconds > 0 ? Math.min(1, secondsLeft / ttlSeconds) : 0;
  return (
    <svg className="k-ring shrink-0" width="16" height="16" viewBox="0 0 16 16" aria-hidden>
      <defs>
        <linearGradient id="k-seam-grad">
          <stop offset="0" stopColor="#22f2d0" />
          <stop offset="1" stopColor="#00b8ff" />
        </linearGradient>
      </defs>
      <circle className="k-ring-track" cx="8" cy="8" r={r} />
      <circle className="k-ring-value" cx="8" cy="8" r={r} strokeDasharray={c} strokeDashoffset={c * (1 - ratio)} />
    </svg>
  );
}

const Q_TEXT = {
  en: {
    details: "Quote details",
    rate: "Rate",
    impact: "Price impact",
    unavailable: "Unavailable",
    minimum: "Minimum received",
    kavrixFee: (bps: string) => `Kavrix fee (${bps})`,
    providerFee: (p: string) => `${p} fee`,
    none: "None",
    networkFee: "Network fee (estimate)",
    byWallet: "Shown by your wallet",
    indicative: (p: string) => `Indicative price from ${p}. Connect a wallet for an executable quote.`,
    validFor: (p: string, s: number) => `Quote from ${p}, valid for ${s}s.`,
    expired: "Quote expired. A new quote is needed before you can swap.",
    surplus: " If the price moves in your favour after you sign, KyberSwap keeps the difference; you always receive at least the minimum.",
  },
  ru: {
    details: "Детали котировки",
    rate: "Курс",
    impact: "Потеря цены",
    unavailable: "Нет данных",
    minimum: "Минимум к получению",
    kavrixFee: (bps: string) => `Комиссия Kavrix (${bps})`,
    providerFee: (p: string) => `Комиссия ${p}`,
    none: "Нет",
    networkFee: "Комиссия сети (оценка)",
    byWallet: "Покажет кошелёк",
    indicative: (p: string) => `Ориентировочная цена от ${p}. Подключите кошелёк, чтобы получить исполнимую котировку.`,
    validFor: (p: string, s: number) => `Котировка от ${p}, действует ещё ${s} с.`,
    expired: "Котировка устарела. Чтобы обменять, нужна новая.",
    surplus: " Если после подписи цена сдвинется в вашу пользу, разницу оставляет KyberSwap; вы в любом случае получите не меньше минимума.",
  },
} as const;

export function QuoteSummary({
  lang = "en",
  quote,
  sell,
  buy,
  nativeSymbol,
  firm = true,
  refreshing = false,
  ttlSeconds = 30,
}: {
  quote: QuoteView;
  sell: TokenOption;
  buy: TokenOption;
  nativeSymbol: string;
  firm?: boolean;
  refreshing?: boolean;
  ttlSeconds?: number;
  lang?: Lang;
}) {
  const t = Q_TEXT[lang];
  const secondsLeft = useSecondsLeft(quote.expiresAt);
  const rate = unitRate(quote, sell.decimals);
  const feeToken = quote.platformFee.token === "sell" ? sell : buy;
  return (
    <section aria-label={t.details} className="space-y-4">
      <dl className="divide-y divide-line border-y border-line text-sm">
        <Row term={t.rate}>
          1 {sell.symbol} = {formatTokenAmount(rate, buy.decimals)} {buy.symbol}
        </Row>
        <Row term={t.impact}>
          {(() => {
            const bps = priceImpactBps(quote);
            if (bps === null) return <span className="text-faint">{t.unavailable}</span>;
            const tone = bps >= IMPACT_CONFIRM_BPS ? "text-danger" : bps >= IMPACT_WARN_BPS ? "text-warning" : "";
            return <span className={tone}>{bps < 1 ? "< 0.01%" : `${(bps / 100).toFixed(2)}%`}</span>;
          })()}
        </Row>
        <Row term={t.minimum}>
          {formatTokenAmount(quote.minBuyAmount, buy.decimals)} {buy.symbol}
        </Row>
        <Row term={t.kavrixFee(formatBps(quote.platformFee.bps))}>
          {quote.platformFee.amount === 0n ? t.none : `${formatTokenAmount(quote.platformFee.amount, feeToken.decimals)} ${feeToken.symbol}`}
        </Row>
        <Row term={t.providerFee(PROVIDER_LABEL[quote.provider])}>
          {quote.providerFee === null || quote.providerFee === 0n ? t.none : `${formatTokenAmount(quote.providerFee, buy.decimals)} ${buy.symbol}`}
        </Row>
        <Row term={t.networkFee}>
          {quote.networkFeeWei === null ? t.byWallet : `${formatTokenAmount(quote.networkFeeWei, 18)} ${nativeSymbol}`}
        </Row>
      </dl>
      <RouteRail route={quote.route} busy={refreshing} />
      <p className="flex items-start gap-2 text-xs text-faint" aria-live="polite">
        {firm && secondsLeft > 0 ? <FreshnessRing secondsLeft={secondsLeft} ttlSeconds={ttlSeconds} /> : null}
        <span>
        {!firm
          ? t.indicative(PROVIDER_LABEL[quote.provider])
          : secondsLeft > 0
            ? t.validFor(PROVIDER_LABEL[quote.provider], secondsLeft)
            : t.expired}
        {quote.provider === "kyberswap" ? t.surplus : ""}
        </span>
      </p>
    </section>
  );
}
