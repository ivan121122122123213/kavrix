import type { TokenOption } from "../lib/api.ts";

/** Rows rendered without a search: enough to browse, few enough to stay instant on a phone. */
export const MAX_ROWS = 80;
const POPULAR = ["USDC", "USDT", "WETH", "WBTC", "CBBTC", "DAI"];

/**
 * Search by symbol, name or exact contract address. Only listed tokens can match.
 * Order: exact symbol, then symbol prefix, then name match; ties keep the server's prominence order.
 */
export function filterTokens(tokens: readonly TokenOption[], query: string): TokenOption[] {
  const q = query.trim().toLowerCase();
  if (q === "") return [...tokens];
  if (/^0x[0-9a-f]{40}$/.test(q)) return tokens.filter((t) => t.address === q);
  const score = (t: TokenOption): number => {
    const sym = t.symbol.toLowerCase();
    if (sym === q) return 0;
    if (sym.startsWith(q)) return 1;
    if (t.name.toLowerCase().includes(q)) return 2;
    return -1;
  };
  return tokens
    .map((t, i) => ({ t, i, s: score(t) }))
    .filter((x) => x.s >= 0)
    .sort((a, b) => a.s - b.s || a.i - b.i)
    .map((x) => x.t);
}

/** Quick picks: the native coin plus the usual majors that exist on this network (standard risk only). */
export function popularTokens(tokens: readonly TokenOption[]): TokenOption[] {
  const native = tokens.filter((t) => t.native);
  const majors = POPULAR.map((sym) => tokens.find((t) => !t.native && t.risk === "standard" && t.symbol.toUpperCase() === sym)).filter(
    (t): t is TokenOption => t !== undefined,
  );
  return [...native, ...majors].slice(0, 6);
}

export function visibleRows(list: readonly TokenOption[]): { rows: TokenOption[]; hidden: number } {
  return { rows: list.slice(0, MAX_ROWS), hidden: Math.max(0, list.length - MAX_ROWS) };
}
