import type { QuoteView } from "./quote.ts";

const SEGMENT_FILLS = [
  "linear-gradient(90deg, #22f2d0, #4fe6e0)",
  "linear-gradient(90deg, #22c7ff, #00b8ff)",
  "linear-gradient(90deg, #6f8bff, #4a6cff)",
  "linear-gradient(90deg, #8c7bff, #6b5cff)",
];

/**
 * Signature element: the liquidity path drawn as one bar split by real fill proportions.
 * While a new quote is loading, light runs along it. No decorative placeholder route is ever drawn.
 */
export function RouteRail({ route, busy = false }: { route: QuoteView["route"]; busy?: boolean }) {
  const total = route.reduce((sum, r) => sum + r.proportionBps, 0);
  if (route.length === 0 || total <= 0) return null;
  let offset = 0;
  return (
    <figure>
      <div className="k-rail" data-busy={busy} aria-hidden>
        {route.map((r, i) => {
          const width = (r.proportionBps / total) * 100;
          const left = offset;
          offset += width;
          return (
            <span
              key={`${r.source}-${i}`}
              className="k-rail-seg"
              style={{ left: `calc(${left}% + ${i === 0 ? 0 : 2}px)`, width: `calc(${width}% - ${i === 0 ? 0 : 2}px)`, background: SEGMENT_FILLS[i % SEGMENT_FILLS.length] }}
            />
          );
        })}
      </div>
      <figcaption className="mt-2 flex flex-wrap gap-x-3 gap-y-1 text-xs text-faint">
        {route.map((r, i) => (
          <span key={`${r.source}-${i}`} className="tabular">
            {r.source} {((r.proportionBps / total) * 100).toFixed(1).replace(/\.0$/, "")}%
          </span>
        ))}
      </figcaption>
    </figure>
  );
}
