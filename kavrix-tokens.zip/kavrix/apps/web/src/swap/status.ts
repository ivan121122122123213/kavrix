import { SWAP_STATUSES, isSupportedChainId, type SupportedChainId, type SwapStatus } from "@kavrix/shared";
import type { Lang } from "../i18n/lang.ts";

export interface TokenRef {
  readonly address: `0x${string}`;
  readonly symbol: string | null;
  readonly decimals: number | null;
}

export interface SwapStatusView {
  readonly id: string;
  readonly status: SwapStatus;
  readonly chainId: SupportedChainId;
  readonly sell: TokenRef;
  readonly buy: TokenRef;
  readonly sellAmount: bigint;
  readonly quotedBuyAmount: bigint;
  readonly minBuyAmount: bigint;
  readonly actualBuyAmount: bigint | null;
  readonly txHash: `0x${string}` | null;
  readonly confirmations: number | null;
  readonly requiredConfirmations: number;
  readonly failureCode: string | null;
  readonly createdAt: string;
  readonly updatedAt: string;
}

export const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function fail(): never {
  throw new Error("Invalid swap status response");
}
type J = Record<string, unknown>;
const o = (v: unknown): J => (typeof v === "object" && v !== null && !Array.isArray(v) ? (v as J) : fail());
const big = (v: unknown): bigint => (typeof v === "string" && /^\d{1,78}$/.test(v) ? BigInt(v) : fail());
const optBig = (v: unknown): bigint | null => (v === null ? null : big(v));
const str = (v: unknown): string => (typeof v === "string" && v.length <= 64 ? v : fail());
const optInt = (v: unknown): number | null => (v === null ? null : typeof v === "number" && Number.isInteger(v) && v >= 0 ? v : fail());

function token(v: unknown): TokenRef {
  const t = o(v);
  const address = t["address"];
  const symbol = t["symbol"];
  const decimals = t["decimals"];
  if (typeof address !== "string" || !/^0x[0-9a-f]{40}$/.test(address)) fail();
  if (!(symbol === null || (typeof symbol === "string" && symbol.length <= 16))) fail();
  if (!(decimals === null || (typeof decimals === "number" && Number.isInteger(decimals) && decimals >= 0 && decimals <= 36))) fail();
  return { address: address as `0x${string}`, symbol, decimals };
}

export function parseSwapStatus(body: unknown, expectedId?: string): SwapStatusView {
  const b = o(body);
  const id = b["id"];
  const status = b["status"];
  const chainId = b["chainId"];
  const txHash = b["txHash"];
  if (typeof id !== "string" || !UUID_RE.test(id) || (expectedId !== undefined && id !== expectedId)) fail();
  if (typeof status !== "string" || !(SWAP_STATUSES as readonly string[]).includes(status)) fail();
  if (!isSupportedChainId(chainId)) fail();
  if (!(txHash === null || (typeof txHash === "string" && /^0x[0-9a-f]{64}$/.test(txHash)))) fail();
  const required = b["requiredConfirmations"];
  if (typeof required !== "number" || !Number.isInteger(required) || required < 1) fail();
  const failureCode = b["failureCode"];
  if (!(failureCode === null || (typeof failureCode === "string" && /^[A-Z0-9_]{2,64}$/.test(failureCode)))) fail();
  return {
    id,
    status: status as SwapStatus,
    chainId,
    sell: token(b["sell"]),
    buy: token(b["buy"]),
    sellAmount: big(b["sellAmount"]),
    quotedBuyAmount: big(b["quotedBuyAmount"]),
    minBuyAmount: big(b["minBuyAmount"]),
    actualBuyAmount: optBig(b["actualBuyAmount"]),
    txHash: txHash as `0x${string}` | null,
    confirmations: optInt(b["confirmations"]),
    requiredConfirmations: required,
    failureCode,
    createdAt: str(b["createdAt"]),
    updatedAt: str(b["updatedAt"]),
  };
}

export function parseSwapList(body: unknown): { swaps: SwapStatusView[]; nextCursor: string | null } {
  const b = o(body);
  const swaps = b["swaps"];
  const next = b["nextCursor"];
  if (!Array.isArray(swaps) || swaps.length > 50 || !(next === null || (typeof next === "string" && next.length <= 128))) fail();
  return { swaps: swaps.map((s) => parseSwapStatus(s)), nextCursor: next };
}

export type StepState = "done" | "current" | "todo" | "failed";

export interface Step {
  readonly label: string;
  readonly state: StepState;
}

const COPY_RU: Record<SwapStatus, { title: string; body: string }> = {
  quoted: { title: "Ждём вашей подписи", body: "Ничего ещё не отправлено." },
  awaiting_approval: { title: "Ждём разрешения на токен", body: "Разрешите в кошельке ровно сумму обмена, чтобы продолжить." },
  submitted: { title: "Отправлено, ещё не окончательно", body: "Транзакция ждёт подтверждения сетью." },
  confirmed: { title: "Обмен подтверждён", body: "Сеть подтвердила обмен. Он окончательный." },
  reverted: { title: "Обмен не прошёл в блокчейне", body: "Транзакция попала в блок, но откатилась — обычно потому, что сдвинулась цена. Токены остались в кошельке, комиссия сети потрачена." },
  dropped: { title: "Сеть давно не видит транзакцию", body: "Она ещё может попасть в блок. Проверьте кошелёк и не отправляйте этот же обмен повторно, пока статус не прояснится." },
  rejected: { title: "Отклонено в кошельке", body: "Транзакция не отправлялась." },
  expired: { title: "Котировка устарела", body: "Котировку не подписали вовремя. Начните обмен заново." },
  failed: { title: "Не удалось проверить", body: "Транзакция, указанная для этого обмена, не совпадает с подготовленной Kavrix, поэтому не засчитана." },
};

const COPY: Record<SwapStatus, { title: string; body: string }> = {
  quoted: { title: "Waiting for your signature", body: "Nothing has been sent yet." },
  awaiting_approval: { title: "Waiting for token approval", body: "Approve the exact amount in your wallet to continue." },
  submitted: { title: "Submitted, not final", body: "Your transaction is waiting to be confirmed by the network." },
  confirmed: { title: "Swap confirmed", body: "The network confirmed the swap. It is final." },
  reverted: { title: "Swap failed on-chain", body: "The transaction was mined but reverted, usually because the price moved. Your tokens stayed in your wallet; the network fee was spent." },
  dropped: { title: "Not seen by the network for a while", body: "The transaction may still be mined. Check your wallet; do not resend the same swap until this resolves." },
  rejected: { title: "Declined in your wallet", body: "No transaction was sent." },
  expired: { title: "Quote expired", body: "The quote timed out before it was signed. Start a new swap." },
  failed: { title: "Could not be verified", body: "The transaction reported for this swap is not the one Kavrix prepared, so it is not counted as this swap." },
};

export function statusCopy(status: SwapStatus, lang: Lang = "en") {
  return (lang === "ru" ? COPY_RU : COPY)[status];
}

const STEP_LABELS: Record<Lang, readonly [string, string, string]> = {
  en: ["Quote", "Submitted", "Confirmed"],
  ru: ["Котировка", "Отправлено", "Подтверждено"],
};

const STEPS: Record<SwapStatus, readonly [StepState, StepState, StepState]> = {
  quoted: ["current", "todo", "todo"],
  awaiting_approval: ["current", "todo", "todo"],
  rejected: ["done", "failed", "todo"],
  expired: ["done", "failed", "todo"],
  failed: ["done", "failed", "todo"],
  submitted: ["done", "current", "todo"],
  dropped: ["done", "current", "todo"],
  reverted: ["done", "done", "failed"],
  confirmed: ["done", "done", "done"],
};

/** Three-step progress; failure states mark where the flow stopped. */
export function stepsFor(status: SwapStatus, lang: Lang = "en"): readonly Step[] {
  return STEP_LABELS[lang].map((label, i) => ({ label, state: STEPS[status][i] ?? "todo" }));
}

export const STATUS_LABEL_RU: Record<SwapStatus, string> = {
  quoted: "Не отправлено",
  awaiting_approval: "Разрешение",
  submitted: "В обработке",
  confirmed: "Подтверждено",
  reverted: "Не прошло",
  dropped: "Пока не найдено",
  rejected: "Отклонено",
  expired: "Устарело",
  failed: "Не проверено",
};

export const STATUS_LABEL: Record<SwapStatus, string> = {
  quoted: "Not sent",
  awaiting_approval: "Approving",
  submitted: "Pending",
  confirmed: "Confirmed",
  reverted: "Failed on-chain",
  dropped: "Not found yet",
  rejected: "Declined",
  expired: "Expired",
  failed: "Unverified",
};
