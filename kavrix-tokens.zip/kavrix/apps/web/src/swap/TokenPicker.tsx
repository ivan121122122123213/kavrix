import { useMemo, useState } from "react";
import { useLang } from "../i18n/core.tsx";
import type { Resource } from "../lib/resource.ts";
import { describeError, type TokenOption } from "../lib/api.ts";
import { shortAddress } from "../lib/format.ts";
import { Dialog } from "../ui/Dialog.tsx";
import { LoadingRows } from "../ui/Skeleton.tsx";
import { Notice } from "../ui/Notice.tsx";
import { TokenIcon } from "../ui/TokenIcon.tsx";
import { Button } from "../ui/Button.tsx";
import { inputClass } from "../ui/Field.tsx";
import { filterTokens, popularTokens, visibleRows } from "./tokens.ts";

export function TokenPicker({
  open,
  onClose,
  onPick,
  tokens,
  selected,
  title,
}: {
  open: boolean;
  onClose: () => void;
  onPick: (token: TokenOption) => void;
  tokens: Resource<TokenOption[]> & { retry: () => void };
  selected: TokenOption | null;
  title: string;
}) {
  const ru = useLang() === "ru";
  const [query, setQuery] = useState("");
  const list = useMemo(() => (tokens.status === "ready" ? filterTokens(tokens.data, query) : []), [tokens, query]);
  const popular = useMemo(() => (tokens.status === "ready" ? popularTokens(tokens.data) : []), [tokens]);
  const { rows, hidden } = visibleRows(list);
  const pick = (token: TokenOption) => {
    onPick(token);
    setQuery("");
  };

  return (
    <Dialog
      open={open}
      onClose={() => {
        setQuery("");
        onClose();
      }}
      title={title}
    >
      <label className="sr-only" htmlFor="token-search">
        {ru ? "Поиск по названию, тикеру или адресу контракта" : "Search by name, symbol or contract address"}
      </label>
      <input
        id="token-search"
        autoFocus
        className={inputClass}
        placeholder={ru ? "Название, тикер или адрес" : "Search name, symbol or paste address"}
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        autoComplete="off"
        spellCheck={false}
      />
      {query.trim() === "" && popular.length > 0 ? (
        <div className="mt-3 flex flex-wrap gap-2" role="group" aria-label={ru ? "Популярные токены" : "Popular tokens"}>
          {popular.map((t) => (
            <button
              key={t.address}
              type="button"
              onClick={() => pick(t)}
              aria-pressed={selected?.address === t.address}
              className="k-chip h-9 pr-3 text-sm"
            >
              <TokenIcon symbol={t.symbol} address={t.address} logoUrl={t.logoUrl} size={24} />
              {t.symbol}
            </button>
          ))}
        </div>
      ) : null}
      <div className="mt-4 max-h-[50vh] overflow-y-auto overscroll-contain">
        {tokens.status === "loading" ? <LoadingRows label={ru ? "Загружаем токены" : "Loading tokens"} /> : null}
        {tokens.status === "error" ? (
          <Notice tone="danger" title={ru ? "Список токенов не загрузился" : "Token list did not load"} action={<Button variant="secondary" onClick={tokens.retry}>{ru ? "Повторить" : "Retry"}</Button>}>
            {describeError(tokens.error, ru ? "ru" : "en")}
          </Notice>
        ) : null}
        {tokens.status === "ready" && list.length === 0 ? (
          <p className="py-6 text-center text-sm text-muted">
            {query.trim() === ""
              ? ru ? "В этой сети пока нет включённых токенов." : "No tokens are enabled on this network yet."
              : ru ? "Совпадений нет. Kavrix показывает только проверенные токены." : "No listed token matches. Kavrix only lists tokens it has verified."}
          </p>
        ) : null}
        <ul className="space-y-1">
          {rows.map((token) => {
            const isSelected = selected !== null && selected.address === token.address;
            return (
              <li key={token.address}>
                <button
                  type="button"
                  onClick={() => pick(token)}
                  aria-current={isSelected || undefined}
                  className="k-row flex w-full items-center gap-3 px-3 py-2.5 text-left"
                >
                  <TokenIcon symbol={token.symbol} address={token.address} logoUrl={token.logoUrl} size={36} />
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-2 font-medium">
                      {token.symbol}
                      {token.risk === "high" ? (
                        <span className="rounded-full px-1.5 py-px text-[0.65rem] font-medium uppercase tracking-wide text-warning shadow-[inset_0_0_0_1px_rgb(242_196_107/0.4)]">
                          {ru ? "риск" : "risk"}
                        </span>
                      ) : null}
                    </span>
                    <span className="block truncate text-xs text-muted">{token.name}</span>
                  </span>
                  <span className="text-xs text-faint">{token.native ? (ru ? "Нативная" : "Native") : shortAddress(token.address)}</span>
                </button>
              </li>
            );
          })}
        </ul>
        {hidden > 0 ? (
          <p className="py-3 text-center text-xs text-faint">
            {ru ? `Ещё ${hidden} — уточните поиск` : `${hidden} more — refine your search`}
          </p>
        ) : null}
      </div>
    </Dialog>
  );
}
