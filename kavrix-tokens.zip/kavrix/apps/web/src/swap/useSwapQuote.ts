import { useCallback, useEffect, useRef, useState } from "react";
import type { SupportedChainId } from "@kavrix/shared";
import { apiPost } from "../lib/api.ts";
import { parseQuote, type AnyQuote } from "./quote.ts";

export type QuoteState =
  | { readonly status: "idle" }
  /**
   * `refreshing` = re-quoting the same inputs in the background; the previous quote stays valid and
   * actionable until it expires, so the UI must not flicker into a loading state.
   */
  | { readonly status: "loading"; readonly previous: AnyQuote | null; readonly refreshing: boolean }
  | { readonly status: "ready"; readonly quote: AnyQuote }
  | { readonly status: "error"; readonly error: unknown };

export interface QuoteInput {
  readonly chainId: SupportedChainId;
  readonly sellToken: `0x${string}` | null;
  readonly buyToken: `0x${string}` | null;
  readonly sellAmount: bigint | null;
  readonly slippageBps: number;
  readonly taker: `0x${string}` | undefined;
  /** False while quotes are disabled server-side or a transaction is in flight. */
  readonly enabled: boolean;
}

const DEBOUNCE_MS = 400;
/** KyberSwap advises re-fetching routes older than ~10 s; refresh a little before the server TTL. */
const REFRESH_EARLY_MS = 5_000;

export function useSwapQuote(input: QuoteInput): QuoteState & { refresh: () => void } {
  const [state, setState] = useState<QuoteState>({ status: "idle" });
  const [nonce, setNonce] = useState(0);
  const lastQuote = useRef<AnyQuote | null>(null);
  const lastKey = useRef<string | null>(null);
  const { chainId, sellToken, buyToken, sellAmount, slippageBps, taker, enabled } = input;
  const key = `${chainId}:${sellToken}:${buyToken}:${sellAmount}:${slippageBps}:${taker ?? "-"}`;

  useEffect(() => {
    if (!enabled || sellToken === null || buyToken === null || sellAmount === null || sellAmount <= 0n) {
      lastQuote.current = null;
      lastKey.current = null;
      setState({ status: "idle" });
      return;
    }
    const controller = new AbortController();
    const refreshing = lastQuote.current !== null && lastKey.current === key && lastQuote.current.expiresAt > Date.now() + 2_000;
    setState({ status: "loading", previous: lastQuote.current, refreshing });
    const timer = setTimeout(() => {
      apiPost(
        "/v1/swap/quote",
        { chainId, sellToken, buyToken, sellAmount: sellAmount.toString(), slippageBps, ...(taker === undefined ? {} : { taker }) },
        controller.signal,
      ).then(
        (body) => {
          if (controller.signal.aborted) return;
          try {
            const quote = parseQuote(body, { chainId, sellToken, buyToken, sellAmount });
            lastQuote.current = quote;
            lastKey.current = key;
            setState({ status: "ready", quote });
          } catch (error) {
            setState({ status: "error", error });
          }
        },
        (error: unknown) => {
          if (!controller.signal.aborted) setState({ status: "error", error });
        },
      );
    }, DEBOUNCE_MS);
    return () => {
      controller.abort();
      clearTimeout(timer);
    };
    // `key` captures every input; `nonce` forces a refresh.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, enabled, nonce]);

  // Re-quote shortly before expiry so the displayed price never goes stale silently.
  const expiresAt = state.status === "ready" ? state.quote.expiresAt : null;
  useEffect(() => {
    if (expiresAt === null || !enabled) return;
    const timer = setTimeout(() => setNonce((n) => n + 1), Math.max(1_000, expiresAt - Date.now() - REFRESH_EARLY_MS));
    return () => clearTimeout(timer);
  }, [expiresAt, enabled]);

  const refresh = useCallback(() => setNonce((n) => n + 1), []);
  return { ...state, refresh };
}
