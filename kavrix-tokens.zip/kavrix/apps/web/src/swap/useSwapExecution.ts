import { useCallback, useRef, useState } from "react";
import { erc20Abi } from "viem";
import { useConfig } from "wagmi";
import { getBalance, readContract, sendTransaction, switchChain, waitForTransactionReceipt, writeContract } from "wagmi/actions";
import { CHAINS } from "@kavrix/shared";
import { describeWalletError, isUserRejection } from "../wallet/errors.ts";
import { createSwap, reportRejected, reportSubmitted } from "../lib/swaps.ts";
import { describeError } from "../lib/api.ts";
import type { FirmQuoteView } from "./quote.ts";
import { VERIFY_MESSAGES, VERIFY_MESSAGES_RU, verifyFirmQuote } from "./verify.ts";
import { SWAP_TEXT } from "./text.ts";
import type { Lang } from "../i18n/lang.ts";

export type ExecState =
  | { readonly step: "idle" }
  | { readonly step: "switching" }
  | { readonly step: "approve_sign" }
  | { readonly step: "approve_pending"; readonly hash: `0x${string}` }
  | { readonly step: "approved" }
  | { readonly step: "swap_sign"; readonly operationId: string }
  | { readonly step: "swap_pending"; readonly hash: `0x${string}`; readonly included: boolean; readonly operationId: string }
  | { readonly step: "confirmed"; readonly hash: `0x${string}`; readonly blockNumber: bigint; readonly operationId: string }
  | { readonly step: "reverted"; readonly hash: `0x${string}`; readonly operationId: string }
  | { readonly step: "rejected" }
  | { readonly step: "failed"; readonly message: string; readonly requote: boolean };

export function isBusy(state: ExecState): boolean {
  return state.step === "switching" || state.step === "approve_sign" || state.step === "approve_pending" || state.step === "swap_sign" || state.step === "swap_pending";
}

/**
 * Drives approval and swap through the user's wallet. A ref guard makes double clicks harmless,
 * and nothing is reported as done until a receipt with the chain's confirmation depth arrives.
 */
export function useSwapExecution(lang: Lang = "en") {
  // Read through a ref so callbacks created earlier still speak the current language.
  const langRef = useRef(lang);
  langRef.current = lang;
  const text = () => SWAP_TEXT[langRef.current];
  const verifyMessages = () => (langRef.current === "ru" ? VERIFY_MESSAGES_RU : VERIFY_MESSAGES);
  const config = useConfig();
  const [state, setState] = useState<ExecState>({ step: "idle" });
  const inFlight = useRef(false);

  const guard = useCallback(async (work: () => Promise<void>) => {
    if (inFlight.current) return;
    inFlight.current = true;
    try {
      await work();
    } catch (error) {
      setState(isUserRejection(error) ? { step: "rejected" } : { step: "failed", message: describeWalletError(error, langRef.current), requote: false });
    } finally {
      inFlight.current = false;
    }
  }, []);

  const ensureChain = useCallback(
    async (quote: FirmQuoteView, walletChainId: number | undefined) => {
      if (walletChainId === quote.chainId) return;
      setState({ step: "switching" });
      await switchChain(config, { chainId: quote.chainId });
    },
    [config],
  );

  /** Approves exactly `sellAmount` to the quoted spender (resetting a partial allowance to 0 first). */
  const approve = useCallback(
    (quote: FirmQuoteView, account: `0x${string}`, walletChainId: number | undefined, onDone: () => void) =>
      guard(async () => {
        const failure = verifyFirmQuote(quote, account, Date.now(), 0);
        if (failure !== undefined && failure !== "expired") {
          setState({ step: "failed", message: verifyMessages()[failure], requote: true });
          return;
        }
        if (quote.spender === null) return;
        await ensureChain(quote, walletChainId);
        const current = await readContract(config, {
          chainId: quote.chainId,
          address: quote.sellToken,
          abi: erc20Abi,
          functionName: "allowance",
          args: [account, quote.spender],
        });
        const steps: bigint[] = current > 0n && current < quote.sellAmount ? [0n, quote.sellAmount] : [quote.sellAmount];
        for (const amount of steps) {
          setState({ step: "approve_sign" });
          const hash = await writeContract(config, {
            chainId: quote.chainId,
            address: quote.sellToken,
            abi: erc20Abi,
            functionName: "approve",
            args: [quote.spender, amount],
          });
          setState({ step: "approve_pending", hash });
          const receipt = await waitForTransactionReceipt(config, { chainId: quote.chainId, hash });
          if (receipt.status !== "success") {
            setState({ step: "failed", message: text().approvalFailed, requote: false });
            return;
          }
        }
        setState({ step: "approved" });
        onDone();
      }),
    [config, ensureChain, guard],
  );

  const swap = useCallback(
    (quote: FirmQuoteView, account: `0x${string}`, walletChainId: number | undefined) =>
      guard(async () => {
        const failure = verifyFirmQuote(quote, account, Date.now());
        if (failure !== undefined) {
          setState({ step: "failed", message: verifyMessages()[failure], requote: true });
          return;
        }
        await ensureChain(quote, walletChainId);

        const balance =
          quote.spender === null
            ? (await getBalance(config, { chainId: quote.chainId, address: account })).value
            : await readContract(config, { chainId: quote.chainId, address: quote.sellToken, abi: erc20Abi, functionName: "balanceOf", args: [account] });
        if (balance < quote.sellAmount) {
          setState({ step: "failed", message: text().balanceLow, requote: false });
          return;
        }

        // Record the swap before the wallet sees it. If Kavrix cannot record it, nothing is sent.
        let operationId: string;
        try {
          operationId = await createSwap(quote.quoteToken, crypto.randomUUID());
        } catch (err) {
          setState({ step: "failed", message: text().recordFailed(describeError(err, langRef.current)), requote: false });
          return;
        }

        setState({ step: "swap_sign", operationId });
        let hash: `0x${string}`;
        try {
          hash = await sendTransaction(config, { chainId: quote.chainId, to: quote.tx.to, data: quote.tx.data, value: quote.tx.value });
        } catch (err) {
          if (isUserRejection(err)) reportRejected(operationId);
          throw err;
        }
        setState({ step: "swap_pending", hash, included: false, operationId });
        void reportSubmitted(operationId, hash);

        const included = await waitForTransactionReceipt(config, { chainId: quote.chainId, hash });
        if (included.status !== "success") {
          setState({ step: "reverted", hash, operationId });
          return;
        }
        setState({ step: "swap_pending", hash, included: true, operationId });
        const final = await waitForTransactionReceipt(config, { chainId: quote.chainId, hash, confirmations: CHAINS[quote.chainId].confirmations });
        setState(final.status === "success" ? { step: "confirmed", hash, blockNumber: final.blockNumber, operationId } : { step: "reverted", hash, operationId });
      }),
    [config, ensureChain, guard],
  );

  const switchNetwork = useCallback(
    (chainId: FirmQuoteView["chainId"]) =>
      guard(async () => {
        setState({ step: "switching" });
        await switchChain(config, { chainId });
        setState({ step: "idle" });
      }),
    [config, guard],
  );

  const reset = useCallback(() => {
    if (!inFlight.current) setState({ step: "idle" });
  }, []);

  return { state, approve, swap, switchNetwork, reset };
}
