import type { QuoteView } from "./quote.ts";

/** Above this the user is warned; above the hard level they must confirm explicitly. */
export const IMPACT_WARN_BPS = 100;
export const IMPACT_CONFIRM_BPS = 500;
/** Below this USD size the provider's rounded figures are too coarse to judge impact. */
const MIN_USD = 1;

/**
 * Value lost between what is sold and what is bought, from the provider's USD figures, in basis points.
 * Kavrix's own fee is excluded (it is shown separately). null when the figures are missing or too small.
 */
export function priceImpactBps(q: Pick<QuoteView, "valueUsd" | "platformFee">): number | null {
  if (q.valueUsd === null || q.valueUsd.sell < MIN_USD) return null;
  const feeShare = q.platformFee.token === "sell" ? q.platformFee.bps / 10_000 : 0;
  const effectiveIn = q.valueUsd.sell * (1 - feeShare);
  if (effectiveIn <= 0) return null;
  const loss = (effectiveIn - q.valueUsd.buy) / effectiveIn;
  return Math.max(0, Math.round(loss * 10_000));
}

export function formatUsd(value: number): string {
  if (value < 0.01) return "< $0.01";
  return `$${value.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}
