import { useEffect, useReducer, useRef, useState, type PointerEvent } from "react";
import { Link } from "react-router";
import { erc20Abi } from "viem";
import { useBalance, useConnection, useReadContract } from "wagmi";
import { CHAINS, SUPPORTED_CHAIN_IDS, explorerTxUrl, isSupportedChainId, type SupportedChainId } from "@kavrix/shared";
import { describeError, feeBpsFor, type Capabilities, type TokenOption } from "../lib/api.ts";
import { useTokens } from "../lib/data.ts";
import { formatBps, formatTokenAmount, normalizeAmountInput } from "../lib/format.ts";
import type { Resource } from "../lib/resource.ts";
import { Button } from "../ui/Button.tsx";
import { ExternalLink } from "../ui/ExternalLink.tsx";
import { Notice } from "../ui/Notice.tsx";
import { TokenIcon } from "../ui/TokenIcon.tsx";
import { KavrixMark } from "../ui/Mark.tsx";
import { useLang } from "../i18n/core.tsx";
import { SWAP_TEXT, type SwapText } from "./text.ts";
import { RollingNumber } from "../ui/RollingNumber.tsx";
import { ConnectDialog } from "../wallet/WalletButton.tsx";
import { QuoteSummary } from "./QuoteSummary.tsx";
import { SlippageSettings } from "./SlippageSettings.tsx";
import { TokenPicker } from "./TokenPicker.tsx";
import { checkAmount, initialSwapState, maxSpendable, slippageWarning, swapCta, swapReducer } from "./state.ts";
import { IMPACT_CONFIRM_BPS, IMPACT_WARN_BPS, formatUsd, priceImpactBps } from "./impact.ts";
import { formatUnits } from "@kavrix/shared";
import { isBusy, useSwapExecution, type ExecState } from "./useSwapExecution.ts";
import { useSwapQuote } from "./useSwapQuote.ts";

const CHAIN_LABEL: Record<SupportedChainId, string> = { 1: "Ethereum", 8453: "Base", 42161: "Arbitrum", 137: "Polygon" };

function TokenButton({ token, onClick, label, disabled, selectLabel }: { token: TokenOption | null; onClick: () => void; label: string; disabled: boolean; selectLabel: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      aria-label={token === null ? label : `${label}: ${token.symbol}`}
      className="k-chip shrink-0 text-base disabled:opacity-60"
    >
      {token === null ? <span className="pl-2 text-muted">{selectLabel}</span> : <TokenIcon symbol={token.symbol} address={token.address} logoUrl={token.logoUrl} chainId={token.chainId} size={32} />}
      {token !== null ? token.symbol : null}
      <svg aria-hidden viewBox="0 0 20 20" className="size-4 text-muted" fill="none" stroke="currentColor" strokeWidth="1.8">
        <path d="M5 8l5 5 5-5" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </button>
  );
}

function ExecNotice({ exec, chainId, onDismiss, t }: { exec: ExecState; chainId: SupportedChainId; onDismiss: () => void; t: SwapText }) {
  const link = (hash: `0x${string}`) => <ExternalLink href={explorerTxUrl(chainId, hash)}>{t.viewOnExplorer}</ExternalLink>;
  const status = "operationId" in exec ? (
    <>
      {" · "}
      <Link className="text-accent underline underline-offset-3" to={`/tx/${exec.operationId}`}>
        {t.statusPage}
      </Link>
    </>
  ) : null;
  switch (exec.step) {
    case "approve_pending":
      return <Notice title={t.approvalSubmitted}>{t.approvalWaiting} {link(exec.hash)}</Notice>;
    case "approved":
      return <Notice title={t.approvalConfirmed}>{t.approvalConfirmedBody}</Notice>;
    case "swap_pending":
      return (
        <Notice title={exec.included ? t.includedTitle : t.submittedTitle}>
          {exec.included
            ? t.waitingConfirmations(CHAINS[chainId].confirmations)
            : t.waitingInclusion}{" "}
          {link(exec.hash)}
          {status}
        </Notice>
      );
    case "confirmed":
      return (
        <Notice title={t.confirmedTitle} action={<Button variant="secondary" onClick={onDismiss}>{t.newSwap}</Button>}>
          {t.finalOn(CHAINS[chainId].name)} {link(exec.hash)}
          {status}
        </Notice>
      );
    case "reverted":
      return (
        <Notice tone="danger" title={t.revertedTitle} action={<Button variant="secondary" onClick={onDismiss}>{t.tryAgain}</Button>}>
          {t.revertedBody} {link(exec.hash)}
          {status}
        </Notice>
      );
    case "rejected":
      return <Notice title={t.declinedTitle}>{t.declinedBody}</Notice>;
    case "failed":
      return <Notice tone="danger" title={t.notSentTitle}>{exec.message}</Notice>;
    default:
      return null;
  }
}

export interface SwapActivity {
  readonly busy: boolean;
  /** Route legs (bps) of the quote on screen; empty when there is none. */
  readonly route: readonly number[];
}

export interface SwapWidgetProps {
  readonly capabilities: Resource<Capabilities>;
  /** Lets the page animate around the widget (the liquidity field) from real quote state. */
  readonly onActivity?: (activity: SwapActivity) => void;
  /** Play the entrance animation (first visit only). */
  readonly intro?: boolean;
}

export function SwapWidget({ capabilities, onActivity, intro = false }: SwapWidgetProps) {
  const lang = useLang();
  const t = SWAP_TEXT[lang];
  const [state, dispatch] = useReducer(swapReducer, initialSwapState(8453));
  const [picker, setPicker] = useState<"sell" | "buy" | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [connectOpen, setConnectOpen] = useState(false);
  const [flipped, setFlipped] = useState(false);
  const shell = useRef<HTMLElement>(null);

  // Rim spotlight follows the pointer; written straight to CSS variables to avoid re-renders.
  const onPointerMove = (e: PointerEvent<HTMLElement>) => {
    const el = shell.current;
    if (el === null || e.pointerType === "touch") return;
    const r = el.getBoundingClientRect();
    el.style.setProperty("--mx", `${e.clientX - r.left}px`);
    el.style.setProperty("--my", `${e.clientY - r.top}px`);
    el.style.setProperty("--spot", "1");
  };
  const onPointerLeave = () => shell.current?.style.setProperty("--spot", "0");
  const tokens = useTokens(state.chainId);
  const connection = useConnection();
  const exec = useSwapExecution(lang);

  const loadedTokens = tokens.status === "ready" ? tokens.data : null;
  useEffect(() => {
    if (loadedTokens !== null) dispatch({ type: "defaults", tokens: loadedTokens });
  }, [loadedTokens]);

  const account = connection.status === "connected" ? connection.address : undefined;
  const busy = isBusy(exec.state);
  const amount = checkAmount(state.amount, state.sell, lang);
  const caps = capabilities.status === "ready" ? capabilities.data : null;
  const quotesEnabled = caps?.swap.quotes === true;
  const chain = CHAINS[state.chainId];
  const wrongChain = account !== undefined && connection.chainId !== state.chainId;

  const quote = useSwapQuote({
    chainId: state.chainId,
    sellToken: state.sell?.address ?? null,
    buyToken: state.buy?.address ?? null,
    sellAmount: amount.kind === "ok" ? amount.value : null,
    slippageBps: state.slippageBps,
    taker: account?.toLowerCase() as `0x${string}` | undefined,
    enabled: quotesEnabled && !busy,
  });
  const shown = quote.status === "ready" ? quote.quote : quote.status === "loading" ? quote.previous : null;
  const routeKey = shown === null ? "" : shown.route.map((r) => r.proportionBps).join(",");
  // A background refresh keeps the previous quote on screen and actionable: no dimming, no disabled button.
  const refreshing = quote.status === "loading" && quote.refreshing;
  const quoting = quote.status === "loading" && !refreshing;
  useEffect(() => {
    onActivity?.({ busy: quoting, route: routeKey === "" ? [] : routeKey.split(",").map(Number) });
  }, [quoting, routeKey, onActivity]);
  const firm = shown !== null && shown.firm ? shown : null;

  const sellIsNative = state.sell?.native === true;
  const nativeBalance = useBalance({ address: account, chainId: state.chainId, query: { enabled: account !== undefined && sellIsNative } });
  const tokenBalance = useReadContract({
    address: state.sell?.address,
    abi: erc20Abi,
    functionName: "balanceOf",
    args: account === undefined ? undefined : [account],
    chainId: state.chainId,
    query: { enabled: account !== undefined && state.sell !== null && !sellIsNative },
  });
  const allowance = useReadContract({
    address: state.sell?.address,
    abi: erc20Abi,
    functionName: "allowance",
    args: account === undefined || firm?.spender == null ? undefined : [account, firm.spender],
    chainId: state.chainId,
    query: { enabled: account !== undefined && firm !== null && firm.spender !== null },
  });
  const balance = sellIsNative ? nativeBalance.data?.value : tokenBalance.data;

  const expired = firm !== null && firm.expiresAt <= Date.now();
  const impact = shown === null ? null : priceImpactBps(shown);
  const [impactAccepted, setImpactAccepted] = useState(false);
  const impactKey = firm === null ? "" : firm.tx.data;
  useEffect(() => setImpactAccepted(false), [impactKey]);
  const cta = swapCta({
    capabilities: capabilities.status,
    quotesEnabled,
    state,
    amount,
    wallet: account === undefined ? "disconnected" : "connected",
    wrongChain,
    chainName: chain.name,
    quote:
      quote.status === "idle"
        ? "idle"
        : quote.status === "error"
          ? "error"
          : quoting || shown === null
            ? "loading"
            : expired
              ? "expired"
              : shown.firm
                ? "firm"
                : "indicative",
    balance,
    allowance: firm === null ? undefined : firm.spender === null ? null : allowance.data,
    exec: exec.state.step,
    impactBps: impact,
    impactAccepted,
  }, lang);

  const onAction = () => {
    if (account === undefined && cta.action === "connect") {
      setConnectOpen(true);
      return;
    }
    if (cta.action === "refresh") quote.refresh();
    if (cta.action === "switch") {
      void exec.switchNetwork(state.chainId);
      return;
    }
    if (account === undefined || firm === null) return;
    if (cta.action === "approve") {
      void exec.approve(firm, account, connection.chainId, () => {
        void allowance.refetch();
        quote.refresh();
      });
    }
    if (cta.action === "swap") {
      void exec.swap(firm, account, connection.chainId).then(() => {
        void nativeBalance.refetch();
        void tokenBalance.refetch();
      });
    }
  };

  // A failed pre-sign check means the quote is unusable: fetch a new one automatically.
  const { refresh } = quote;
  useEffect(() => {
    if (exec.state.step === "failed" && exec.state.requote) refresh();
  }, [exec.state, refresh]);

  const slippageNote = slippageWarning(state.slippageBps, lang);
  const outputText =
    shown !== null && state.buy !== null ? formatTokenAmount(shown.buyAmount, state.buy.decimals) : quote.status === "loading" ? "…" : "—";

  return (
    <section
      ref={shell}
      aria-labelledby="swap-title"
      data-spot
      onPointerMove={onPointerMove}
      onPointerLeave={onPointerLeave}
      className={`k-glass k-seam-corner p-4 sm:p-5 ${intro ? "k-rise" : ""}`}
    >
      <div className="relative z-10 flex items-center justify-between gap-3">
        <h2 id="swap-title" className="text-lg font-semibold tracking-tight">
          {t.title}
        </h2>
        <div className="flex items-center gap-1.5">
        <label htmlFor="swap-chain" className="sr-only">
          {t.network}
        </label>
        <select
          id="swap-chain"
          value={state.chainId}
          disabled={busy}
          onChange={(e) => {
            const id = Number(e.target.value);
            if (isSupportedChainId(id)) dispatch({ type: "chain", chainId: id });
          }}
          className="h-9 cursor-pointer rounded-[10px] bg-surface-sunken px-3 text-sm text-text shadow-[inset_0_0_0_1px_var(--k-line)] hover:shadow-[inset_0_0_0_1px_var(--k-line-strong)]"
        >
          {SUPPORTED_CHAIN_IDS.map((id) => (
            <option key={id} value={id}>
              {CHAIN_LABEL[id]}
            </option>
          ))}
        </select>
        <button
          type="button"
          onClick={() => setSettingsOpen(true)}
          disabled={busy}
          className="k-btn k-btn--ghost tabular h-9 px-2.5 text-sm"
          aria-label={t.slippageAria(formatBps(state.slippageBps))}
        >
          <span className="relative z-10">{formatBps(state.slippageBps)}</span>
        </button>
        </div>
      </div>

      <div className="relative z-10 mt-4 space-y-1.5">
        <div className="k-field p-4">
          <div className="flex items-baseline justify-between gap-2">
            <label htmlFor="swap-amount" className="k-label">
              {t.youPay}
            </label>
            {balance !== undefined && state.sell !== null ? (
              <span className="flex items-center gap-2 text-xs text-faint">
                <span className="tabular">
                  {t.balance} {formatTokenAmount(balance, state.sell.decimals)} {state.sell.symbol}
                </span>
                {(() => {
                  const max = maxSpendable(balance, state.sell.native, state.chainId, shown?.networkFeeWei ?? null);
                  return (
                    <button
                      type="button"
                      disabled={busy || max === 0n}
                      title={state.sell.native ? t.maxHint : undefined}
                      onClick={() => {
                        exec.reset();
                        if (state.sell !== null) dispatch({ type: "amount", amount: formatUnits(max, state.sell.decimals) });
                      }}
                      className="rounded-md px-1.5 py-0.5 font-medium text-accent hover:bg-accent/10 disabled:text-faint disabled:hover:bg-transparent"
                    >
                      {t.max}
                    </button>
                  );
                })()}
              </span>
            ) : null}
          </div>
          <div className="mt-2 flex items-center gap-3">
            <input
              id="swap-amount"
              inputMode="decimal"
              autoComplete="off"
              placeholder="0"
              disabled={busy}
              value={state.amount}
              onChange={(e) => {
                exec.reset();
                dispatch({ type: "amount", amount: normalizeAmountInput(e.target.value) });
              }}
              aria-invalid={amount.kind === "invalid" || undefined}
              aria-describedby={amount.kind === "invalid" ? "swap-amount-error" : undefined}
              className="k-amount k-num min-w-0 flex-1 bg-transparent text-text placeholder:text-faint focus:outline-none"
            />
            <TokenButton token={state.sell} onClick={() => setPicker("sell")} label={t.tokenToPay} disabled={busy} selectLabel={t.select} />
          </div>
          {amount.kind !== "invalid" && shown?.valueUsd != null ? (
            <p className="k-num mt-1.5 text-xs text-faint">≈ {formatUsd(shown.valueUsd.sell)}</p>
          ) : null}
          {amount.kind === "invalid" ? (
            <p id="swap-amount-error" className="mt-2 text-xs text-danger">
              {amount.message}
            </p>
          ) : null}
        </div>

        {/* The seam between what you pay and what you receive; light runs along it while quoting. */}
        <div className="relative z-10 -my-4 flex justify-center">
          <span aria-hidden className="k-link" data-busy={quote.status === "loading"} />
          <button
            type="button"
            onClick={() => {
              setFlipped((f) => !f);
              dispatch({ type: "flip" });
            }}
            disabled={busy}
            aria-label={t.flipAria}
            className="k-flip relative"
          >
            <KavrixMark size={22} swapped={flipped} />
          </button>
        </div>

        <div className="k-field p-4">
          <span id="swap-receive-label" className="k-label">
            {t.youReceive}
          </span>
          <div className="mt-2 flex items-center gap-3">
            <output
              aria-labelledby="swap-receive-label"
              aria-busy={quote.status === "loading"}
              className={`k-amount min-w-0 flex-1 truncate transition-opacity duration-300 ${shown !== null ? "text-text" : "text-faint"} ${quoting ? "opacity-55" : ""}`}
            >
              {shown !== null ? (
                <>
                  <RollingNumber value={outputText.split(".")[0] ?? outputText} />
                  {outputText.includes(".") ? <RollingNumber className="k-frac" value={`.${outputText.split(".")[1] ?? ""}`} /> : null}
                </>
              ) : (
                <span className="k-num">{outputText}</span>
              )}
            </output>
            <TokenButton token={state.buy} onClick={() => setPicker("buy")} label={t.tokenToReceive} disabled={busy} selectLabel={t.select} />
          </div>
          {shown?.valueUsd != null ? (
            <p className="k-num mt-1.5 text-xs text-faint">
              ≈ {formatUsd(shown.valueUsd.buy)}
              {impact !== null && impact >= IMPACT_WARN_BPS ? (
                <span className={impact >= IMPACT_CONFIRM_BPS ? "text-danger" : "text-warning"}> (−{(impact / 100).toFixed(2)}%)</span>
              ) : null}
            </p>
          ) : null}
        </div>
      </div>

      <div className="relative z-10 mt-4 space-y-3">
        {capabilities.status === "error" ? (
          <Notice tone="danger" title={t.unreachableTitle}>
            {t.unreachableBody}
          </Notice>
        ) : null}
        {caps !== null && caps.swap.paused ? (
          <Notice tone="warning" title={t.pausedTitle}>
            {t.pausedBody}
          </Notice>
        ) : null}
        {caps !== null && !caps.swap.quotes && !caps.swap.paused ? (
          <Notice title={t.noQuotesTitle}>
            {t.noQuotesBody}
          </Notice>
        ) : null}
        {tokens.status === "error" ? (
          <Notice tone="danger" title={t.tokensFailed(chain.name)} action={<Button variant="secondary" onClick={tokens.retry}>{t.retry}</Button>} />
        ) : null}
        {quote.status === "error" ? (
          <Notice tone="danger" title={t.noQuote} action={<Button variant="secondary" onClick={quote.refresh}>{t.retry}</Button>}>
            {describeError(quote.error, lang)}
          </Notice>
        ) : null}
        {(() => {
          // Warn about whichever side is long-tail; once per pair, before anything is signed.
          const risky = [state.sell, state.buy].find((tk) => tk !== null && tk.risk === "high");
          return risky != null ? (
            <Notice tone="warning" title={t.highRiskTitle(risky.symbol)}>
              {t.highRiskBody}
            </Notice>
          ) : null;
        })()}
        {slippageNote !== undefined ? <p className="text-xs text-warning">{slippageNote}</p> : null}
        {impact !== null && impact >= IMPACT_WARN_BPS && impact < IMPACT_CONFIRM_BPS ? (
          <p className="text-xs text-warning">
            {t.impactWarn((impact / 100).toFixed(2))}
          </p>
        ) : null}
        {impact !== null && impact >= IMPACT_CONFIRM_BPS && firm !== null ? (
          <Notice tone="danger" title={t.impactSevereTitle((impact / 100).toFixed(1))}>
            <span className="block">{t.impactSevereBody}</span>
            <label className="mt-2 flex cursor-pointer items-center gap-2">
              <input type="checkbox" className="accent-danger size-4" checked={impactAccepted} onChange={(e) => setImpactAccepted(e.target.checked)} />
              <span>{t.impactAccept}</span>
            </label>
          </Notice>
        ) : null}
        {shown !== null && state.sell !== null && state.buy !== null ? (
          <QuoteSummary lang={lang} quote={shown} sell={state.sell} buy={state.buy} nativeSymbol={chain.nativeCurrency.symbol} firm={shown.firm} refreshing={quote.status === "loading"} ttlSeconds={caps?.swap.quoteTtlSeconds ?? 30} />
        ) : null}
        <ExecNotice t={t} exec={exec.state} chainId={state.chainId} onDismiss={() => {
          exec.reset();
          dispatch({ type: "amount", amount: "" });
        }} />
        <Button size="lg" disabled={cta.disabled} busy={busy} onClick={onAction}>
          {cta.label}
        </Button>
        {caps !== null ? (
          <p className="text-center text-xs text-faint">
            {feeBpsFor(caps, state.chainId) === 0
              ? t.noFee(chain.name)
              : t.fee(chain.name, formatBps(feeBpsFor(caps, state.chainId)))}
          </p>
        ) : null}
      </div>

      <TokenPicker
        open={picker !== null}
        title={picker === "buy" ? t.youReceive : t.youPay}
        tokens={tokens}
        selected={picker === "buy" ? state.buy : state.sell}
        onClose={() => setPicker(null)}
        onPick={(token) => {
          if (picker !== null) dispatch({ type: "pick", side: picker, token });
          setPicker(null);
        }}
      />
      {settingsOpen ? (
        <SlippageSettings open bps={state.slippageBps} onClose={() => setSettingsOpen(false)} onSave={(bps) => dispatch({ type: "slippage", bps })} />
      ) : null}
      <ConnectDialog open={connectOpen} onClose={() => setConnectOpen(false)} />
    </section>
  );
}
