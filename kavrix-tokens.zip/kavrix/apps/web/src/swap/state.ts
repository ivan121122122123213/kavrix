import { IMPACT_CONFIRM_BPS } from "./impact.ts";
import type { Lang } from "../i18n/lang.ts";
import { AmountError, parseUnits, sameAddress, type SupportedChainId } from "@kavrix/shared";
import type { TokenOption } from "../lib/api.ts";

export const DEFAULT_SLIPPAGE_BPS = 50;
/** KyberSwap caps slippage at 20%; Kavrix uses the same ceiling for every provider. */
export const MAX_SLIPPAGE_BPS = 2000;

export interface SwapState {
  readonly chainId: SupportedChainId;
  readonly sell: TokenOption | null;
  readonly buy: TokenOption | null;
  readonly amount: string;
  readonly slippageBps: number;
}

export type SwapAction =
  | { readonly type: "chain"; readonly chainId: SupportedChainId }
  | { readonly type: "pick"; readonly side: "sell" | "buy"; readonly token: TokenOption }
  | { readonly type: "defaults"; readonly tokens: readonly TokenOption[] }
  | { readonly type: "flip" }
  | { readonly type: "amount"; readonly amount: string }
  | { readonly type: "slippage"; readonly bps: number };

export function initialSwapState(chainId: SupportedChainId): SwapState {
  return { chainId, sell: null, buy: null, amount: "", slippageBps: DEFAULT_SLIPPAGE_BPS };
}

export function swapReducer(state: SwapState, action: SwapAction): SwapState {
  switch (action.type) {
    case "chain":
      return action.chainId === state.chainId ? state : { ...state, chainId: action.chainId, sell: null, buy: null };
    case "defaults": {
      if (state.sell !== null || state.buy !== null) return state;
      const tokens = action.tokens.filter((t) => t.chainId === state.chainId);
      const sell = tokens.find((t) => t.native) ?? tokens[0] ?? null;
      const buy = tokens.find((t) => t.symbol === "USDC" && t !== sell) ?? tokens.find((t) => t !== sell) ?? null;
      return { ...state, sell, buy };
    }
    case "pick": {
      if (action.token.chainId !== state.chainId) return state;
      const other = action.side === "sell" ? state.buy : state.sell;
      // Picking the token already on the other side swaps the pair instead of creating A→A.
      if (other !== null && sameAddress(other.address, action.token.address)) {
        return { ...state, sell: state.buy, buy: state.sell };
      }
      return action.side === "sell" ? { ...state, sell: action.token } : { ...state, buy: action.token };
    }
    case "flip":
      return { ...state, sell: state.buy, buy: state.sell, amount: "" };
    case "amount":
      return { ...state, amount: action.amount };
    case "slippage":
      return Number.isInteger(action.bps) && action.bps >= 0 && action.bps <= MAX_SLIPPAGE_BPS
        ? { ...state, slippageBps: action.bps }
        : state;
  }
}

export type AmountCheck =
  | { readonly kind: "empty" }
  | { readonly kind: "invalid"; readonly message: string }
  | { readonly kind: "ok"; readonly value: bigint };

const AMOUNT_TEXT = {
  en: {
    selectToken: "Select a token first.",
    positive: "Enter an amount greater than 0.",
    decimals: (symbol: string, d: number) => `${symbol} supports up to ${d} decimal places.`,
    number: "Enter a number like 0.5",
  },
  ru: {
    selectToken: "Сначала выберите токен.",
    positive: "Введите сумму больше нуля.",
    decimals: (symbol: string, d: number) => `У ${symbol} не больше ${d} знаков после запятой.`,
    number: "Введите число, например 0.5",
  },
} as const;

export function checkAmount(amount: string, token: TokenOption | null, lang: Lang = "en"): AmountCheck {
  const t = AMOUNT_TEXT[lang];
  if (amount.trim() === "") return { kind: "empty" };
  if (token === null) return { kind: "invalid", message: t.selectToken };
  try {
    const value = parseUnits(amount, token.decimals);
    return value === 0n ? { kind: "invalid", message: t.positive } : { kind: "ok", value };
  } catch (err) {
    if (err instanceof AmountError && /decimal places/.test(err.message)) {
      return { kind: "invalid", message: t.decimals(token.symbol, token.decimals) };
    }
    return { kind: "invalid", message: t.number };
  }
}

export type WalletStatus = "disconnected" | "connected";
export type ExecStep =
  | "idle" | "switching" | "approve_sign" | "approve_pending" | "approved"
  | "swap_sign" | "swap_pending" | "confirmed" | "reverted" | "rejected" | "failed";
export type CtaAction = "none" | "connect" | "switch" | "approve" | "swap" | "refresh";

/**
 * Native coin left untouched by "Max" so the swap itself can pay for gas.
 * At least 3x the quoted network fee, never less than a per-network floor.
 */
export const GAS_RESERVE_WEI: Record<SupportedChainId, bigint> = {
  1: 4_000_000_000_000_000n, // 0.004 ETH
  8453: 300_000_000_000_000n, // 0.0003 ETH
  42161: 300_000_000_000_000n, // 0.0003 ETH
  137: 200_000_000_000_000_000n, // 0.2 POL
};

export function maxSpendable(balance: bigint, native: boolean, chainId: SupportedChainId, networkFeeWei: bigint | null): bigint {
  if (!native) return balance;
  const fromQuote = (networkFeeWei ?? 0n) * 3n;
  const reserve = fromQuote > GAS_RESERVE_WEI[chainId] ? fromQuote : GAS_RESERVE_WEI[chainId];
  return balance > reserve ? balance - reserve : 0n;
}

export interface CtaInput {
  readonly capabilities: "loading" | "error" | "ready";
  readonly quotesEnabled: boolean;
  readonly state: SwapState;
  readonly amount: AmountCheck;
  readonly wallet: WalletStatus;
  readonly wrongChain?: boolean;
  readonly chainName?: string;
  readonly quote?: "idle" | "loading" | "error" | "indicative" | "firm" | "expired";
  /** Wallet balance of the sell token, when known. */
  readonly balance?: bigint | undefined;
  /** Current allowance to the quoted spender; `null` when no approval is needed (native coin). */
  readonly allowance?: bigint | null | undefined;
  readonly exec?: ExecStep;
  /** Price impact of the firm quote in bps; null when unknown. */
  readonly impactBps?: number | null;
  /** The user ticked "I understand" for a high-impact trade. */
  readonly impactAccepted?: boolean;
}

export interface Cta {
  readonly label: string;
  readonly disabled: boolean;
  readonly action: CtaAction;
}

const CTA_TEXT = {
  en: {
    busy: {
      switching: "Switch network in your wallet…",
      approve_sign: "Confirm approval in your wallet…",
      approve_pending: "Approving…",
      swap_sign: "Confirm swap in your wallet…",
      swap_pending: "Swapping…",
    } as Partial<Record<ExecStep, string>>,
    unreachable: "Kavrix is unreachable",
    loading: "Loading…",
    selectToken: "Select a token",
    enterAmount: "Enter an amount",
    checkAmount: "Check the amount",
    quotesUnavailable: "Quotes unavailable",
    connect: "Connect wallet",
    switchTo: (chain: string | undefined) => `Switch to ${chain ?? "the selected network"}`,
    insufficient: (symbol: string) => `Insufficient ${symbol} balance`,
    refresh: "Refresh quote",
    gettingQuote: "Getting a quote…",
    checkingAllowance: "Checking allowance…",
    approve: (symbol: string) => `Approve ${symbol}`,
    confirmImpact: "Confirm the price impact",
    swapAnyway: "Swap anyway",
    swap: "Swap",
  },
  ru: {
    busy: {
      switching: "Смените сеть в кошельке…",
      approve_sign: "Подтвердите разрешение в кошельке…",
      approve_pending: "Выдаём разрешение…",
      swap_sign: "Подтвердите обмен в кошельке…",
      swap_pending: "Обмениваем…",
    } as Partial<Record<ExecStep, string>>,
    unreachable: "Kavrix недоступен",
    loading: "Загрузка…",
    selectToken: "Выберите токен",
    enterAmount: "Введите сумму",
    checkAmount: "Проверьте сумму",
    quotesUnavailable: "Котировки недоступны",
    connect: "Подключить кошелёк",
    switchTo: (chain: string | undefined) => `Переключиться на ${chain ?? "выбранную сеть"}`,
    insufficient: (symbol: string) => `Недостаточно ${symbol}`,
    refresh: "Обновить котировку",
    gettingQuote: "Получаем котировку…",
    checkingAllowance: "Проверяем разрешение…",
    approve: (symbol: string) => `Разрешить ${symbol}`,
    confirmImpact: "Подтвердите потерю цены",
    swapAnyway: "Всё равно обменять",
    swap: "Обменять",
  },
} as const;

const off = (label: string): Cta => ({ label, disabled: true, action: "none" });

/** One primary action whose label always says what is missing or what happens next. */
export function swapCta(i: CtaInput, lang: Lang = "en"): Cta {
  const t = CTA_TEXT[lang];
  if (i.capabilities === "error") return off(t.unreachable);
  if (i.capabilities === "loading") return off(t.loading);
  if (i.state.sell === null || i.state.buy === null) return off(t.selectToken);
  if (i.amount.kind === "empty") return off(t.enterAmount);
  if (i.amount.kind === "invalid") return off(t.checkAmount);
  if (!i.quotesEnabled) return off(t.quotesUnavailable);
  const busy = i.exec !== undefined ? t.busy[i.exec] : undefined;
  if (busy !== undefined) return off(busy);
  if (i.wallet === "disconnected") return { label: t.connect, disabled: false, action: "connect" };
  if (i.wrongChain === true) return { label: t.switchTo(i.chainName), disabled: false, action: "switch" };
  if (i.balance !== undefined && i.balance < i.amount.value) return off(t.insufficient(i.state.sell.symbol));
  if (i.quote === "expired") return { label: t.refresh, disabled: false, action: "refresh" };
  if (i.quote === "loading" || i.quote === undefined || i.quote === "idle") return off(t.gettingQuote);
  if (i.quote !== "firm") return off(t.quotesUnavailable);
  if (i.allowance === undefined) return off(t.checkingAllowance);
  if (i.allowance !== null && i.allowance < i.amount.value) return { label: t.approve(i.state.sell.symbol), disabled: false, action: "approve" };
  const severe = (i.impactBps ?? 0) >= IMPACT_CONFIRM_BPS;
  if (severe && i.impactAccepted !== true) return off(t.confirmImpact);
  return { label: severe ? t.swapAnyway : t.swap, disabled: false, action: "swap" };
}

export function slippageWarning(bps: number, lang: Lang = "en"): string | undefined {
  const ru = lang === "ru";
  if (bps < 5) return ru ? "Очень низкий допуск: если цена сдвинется, обмен, скорее всего, не пройдёт." : "Very low tolerance: the swap will likely fail if the price moves.";
  if (bps > 100)
    return ru
      ? "Высокий допуск: вы можете получить заметно меньше, а сделку проще атаковать опережением."
      : "High tolerance: you may receive noticeably less, and the trade is easier to front-run.";
  return undefined;
}

/** "0.3" -> 30 bps. Up to two decimals, within (0, MAX_SLIPPAGE_BPS]. */
export function parseSlippagePercent(input: string): number | undefined {
  if (!/^\d{1,2}(\.\d{1,2})?$/.test(input)) return undefined;
  const bps = Math.round(Number(input) * 100);
  return bps >= 1 && bps <= MAX_SLIPPAGE_BPS ? bps : undefined;
}
