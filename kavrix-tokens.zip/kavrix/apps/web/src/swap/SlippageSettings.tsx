import { useState } from "react";
import { useLang } from "../i18n/core.tsx";
import { Dialog } from "../ui/Dialog.tsx";
import { Field, inputClass } from "../ui/Field.tsx";
import { Segmented } from "../ui/Segmented.tsx";
import { Button } from "../ui/Button.tsx";
import { formatBps, normalizeAmountInput } from "../lib/format.ts";
import { MAX_SLIPPAGE_BPS, parseSlippagePercent, slippageWarning } from "./state.ts";

const presets = (custom: string) => [
  { value: "10", label: "0.1%" },
  { value: "50", label: "0.5%" },
  { value: "100", label: "1%" },
  { value: "custom", label: custom },
] as const;
type Preset = ReturnType<typeof presets>[number]["value"];

export function SlippageSettings({ open, onClose, bps, onSave }: { open: boolean; onClose: () => void; bps: number; onSave: (bps: number) => void }) {
  const isPreset = PRESETS.some((p) => p.value === String(bps));
  const [preset, setPreset] = useState<Preset>(isPreset ? (String(bps) as Preset) : "custom");
  const [custom, setCustom] = useState(isPreset ? "" : String(bps / 100));

  const draft = preset === "custom" ? parseSlippagePercent(custom) : Number(preset);
  const lang = useLang();
  const ru = lang === "ru";
  const PRESETS = presets(ru ? "Своё" : "Custom");
  const customError =
    preset === "custom" && custom !== "" && draft === undefined
      ? ru
        ? `Введите значение от 0.01% до ${MAX_SLIPPAGE_BPS / 100}%.`
        : `Enter a value between 0.01% and ${MAX_SLIPPAGE_BPS / 100}%.`
      : undefined;
  const warning = draft === undefined ? undefined : slippageWarning(draft, lang);

  return (
    <Dialog open={open} onClose={onClose} title={ru ? "Допустимое проскальзывание" : "Slippage tolerance"}>
      <p className="text-sm text-muted">
        {ru
          ? "Если до попадания транзакции в блок цена сдвинется против вас сильнее этого значения, обмен откатится, а токены останутся у вас. Комиссию сети при этом придётся заплатить."
          : "If the price moves against you by more than this before your transaction is mined, the swap reverts and you keep your tokens. You still pay the network fee."}
      </p>
      <div className="mt-4">
        <Segmented label={ru ? "Готовые значения" : "Slippage preset"} options={PRESETS} value={preset} onChange={setPreset} />
      </div>
      {preset === "custom" ? (
        <div className="mt-4">
          <Field label={ru ? "Своё значение, %" : "Custom tolerance, %"} error={customError}>
            {(control) => (
              <input
                {...control}
                className={inputClass}
                inputMode="decimal"
                placeholder="0.3"
                value={custom}
                onChange={(e) => setCustom(normalizeAmountInput(e.target.value))}
              />
            )}
          </Field>
        </div>
      ) : null}
      {warning !== undefined ? <p className="mt-4 text-sm text-warning">{warning}</p> : null}
      <div className="mt-6 flex justify-end gap-2">
        <Button variant="ghost" onClick={onClose}>
          {ru ? "Отмена" : "Cancel"}
        </Button>
        <Button
          disabled={draft === undefined}
          onClick={() => {
            if (draft === undefined) return;
            onSave(draft);
            onClose();
          }}
        >
          {draft === undefined ? (ru ? "Сохранить" : "Save") : ru ? `Применить ${formatBps(draft)}` : `Use ${formatBps(draft)}`}
        </Button>
      </div>
    </Dialog>
  );
}
