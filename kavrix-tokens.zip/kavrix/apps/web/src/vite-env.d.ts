/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_SITE_ORIGIN?: string;
  readonly VITE_LEGAL_ENTITY?: string;
  readonly VITE_SUPPORT_EMAIL?: string;
  readonly VITE_WALLETCONNECT_PROJECT_ID?: string;
  /** "ru" (default) or "en": prerendered <head> and fallback language. */
  readonly VITE_DEFAULT_LANG?: string;
}
