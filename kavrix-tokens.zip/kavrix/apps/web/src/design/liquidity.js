/**
 * Liquidity field: light flowing from the teal half of the crystal, through the swap widget (the seam),
 * into the blue half. It reacts to the swap: dim at rest, brighter while quoting, and split into the
 * real route proportions once a quote arrives. Framework-free so it can be rendered anywhere.
 */
const TEAL = [34, 242, 208];
const BLUE = [0, 184, 255];
const SAMPLES = 10;
function mix(a, b, t) {
    return `${Math.round(a[0] + (b[0] - a[0]) * t)},${Math.round(a[1] + (b[1] - a[1]) * t)},${Math.round(a[2] + (b[2] - a[2]) * t)}`;
}
/** Point on a cubic Bézier from the left edge, through the seam, to the right edge. */
function point(s, t, w, h) {
    const x0 = 0;
    const x3 = w;
    const y0 = s.y0 * h;
    const y3 = s.y1 * h;
    // Control points pull every stream towards the seam at the centre.
    const x1 = w * 0.42;
    const x2 = w * 0.58;
    const y1 = h * (0.5 + s.bend);
    const y2 = h * (0.5 - s.bend * 0.6);
    const u = 1 - t;
    return [
        u * u * u * x0 + 3 * u * u * t * x1 + 3 * u * t * t * x2 + t * t * t * x3,
        u * u * u * y0 + 3 * u * u * t * y1 + 3 * u * t * t * y2 + t * t * t * y3,
    ];
}
/** Deterministic PRNG so the composition is identical on every load. */
function rng(seed) {
    let s = seed >>> 0;
    return () => {
        s = (s * 1664525 + 1013904223) >>> 0;
        return s / 4294967296;
    };
}
function buildStreams(route, count) {
    const r = rng(7);
    const legs = route.length > 0 ? route : [10_000];
    const total = legs.reduce((a, b) => a + b, 0) || 1;
    const streams = [];
    let leg = 0;
    let acc = legs[0] ?? total;
    for (let i = 0; i < count; i++) {
        const share = (i + 0.5) / count;
        while (share * total > acc && leg < legs.length - 1) {
            leg++;
            acc += legs[leg] ?? 0;
        }
        // Each route leg gets its own band so proportions are visible as separate bundles.
        const band = legs.length > 1 ? (leg / (legs.length - 1) - 0.5) * 0.18 : 0;
        streams.push({
            y0: 0.16 + r() * 0.68,
            y1: 0.16 + r() * 0.68,
            bend: band + (r() - 0.5) * 0.08,
            leg,
            speed: 0.035 + r() * 0.05,
            phase: r(),
            width: 0.6 + r() * 1.1,
        });
    }
    return streams;
}
export function createLiquidityField(canvas, opts) {
    const ctx = canvas.getContext("2d");
    if (ctx === null)
        return { update() { }, destroy() { } };
    const g = ctx;
    let w = 0;
    let h = 0;
    let streams = buildStreams([], 46);
    let routeKey = "";
    let target = { activity: 0, route: [] };
    let activity = 0;
    let raf = 0;
    let last = performance.now();
    let visible = true;
    const resize = () => {
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        const rect = canvas.getBoundingClientRect();
        w = rect.width;
        h = rect.height;
        canvas.width = Math.max(1, Math.round(w * dpr));
        canvas.height = Math.max(1, Math.round(h * dpr));
        g.setTransform(dpr, 0, 0, dpr, 0, 0);
        if (opts.reducedMotion)
            draw(0);
    };
    function draw(dt) {
        activity += (target.activity - activity) * Math.min(1, dt * 3);
        g.clearRect(0, 0, w, h);
        g.globalCompositeOperation = "lighter";
        // Faint guide curves: the structure stays legible even when the light is dim.
        for (const s of streams) {
            g.beginPath();
            for (let i = 0; i <= 24; i++) {
                const [x, y] = point(s, i / 24, w, h);
                if (i === 0)
                    g.moveTo(x, y);
                else
                    g.lineTo(x, y);
            }
            const grad = g.createLinearGradient(0, 0, w, 0);
            grad.addColorStop(0, `rgba(${mix(TEAL, TEAL, 0)},0)`);
            grad.addColorStop(0.3, `rgba(${mix(TEAL, BLUE, 0.3)},${0.035 + activity * 0.03})`);
            grad.addColorStop(0.7, `rgba(${mix(TEAL, BLUE, 0.7)},${0.035 + activity * 0.03})`);
            grad.addColorStop(1, `rgba(${mix(BLUE, BLUE, 1)},0)`);
            g.strokeStyle = grad;
            g.lineWidth = 0.6;
            g.stroke();
        }
        // Moving light: a short comet per stream, faster and brighter while quoting.
        const speedUp = 1 + activity * 2.2;
        for (const s of streams) {
            if (!opts.reducedMotion)
                s.phase = (s.phase + dt * s.speed * speedUp) % 1;
            const head = s.phase;
            const len = 0.07 + activity * 0.05;
            let prev = null;
            for (let i = 0; i <= SAMPLES; i++) {
                const t = head - len * (1 - i / SAMPLES);
                if (t < 0 || t > 1) {
                    prev = null;
                    continue;
                }
                const p = point(s, t, w, h);
                if (prev !== null) {
                    // Fade in at the outer edges so streams emerge from the crystal rather than the canvas edge.
                    const edge = Math.min(1, t * 5, (1 - t) * 5);
                    const alpha = (i / SAMPLES) * edge * (0.22 + activity * 0.55);
                    g.strokeStyle = `rgba(${mix(TEAL, BLUE, t)},${alpha.toFixed(3)})`;
                    g.lineWidth = s.width * (0.8 + activity * 0.6);
                    g.beginPath();
                    g.moveTo(prev[0], prev[1]);
                    g.lineTo(p[0], p[1]);
                    g.stroke();
                }
                prev = p;
            }
        }
        g.globalCompositeOperation = "source-over";
    }
    const frame = (now) => {
        const dt = Math.min(0.05, (now - last) / 1000);
        last = now;
        draw(dt);
        raf = requestAnimationFrame(frame);
    };
    const start = () => {
        if (opts.reducedMotion || raf !== 0 || !visible || document.hidden)
            return;
        last = performance.now();
        raf = requestAnimationFrame(frame);
    };
    const stop = () => {
        cancelAnimationFrame(raf);
        raf = 0;
    };
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);
    const io = new IntersectionObserver(([entry]) => {
        visible = entry?.isIntersecting ?? true;
        if (visible)
            start();
        else
            stop();
    });
    io.observe(canvas);
    const onVisibility = () => (document.hidden ? stop() : start());
    document.addEventListener("visibilitychange", onVisibility);
    resize();
    start();
    return {
        update(state) {
            target = state;
            const key = state.route.join(",");
            if (key !== routeKey) {
                routeKey = key;
                const phases = streams.map((s) => s.phase);
                streams = buildStreams(state.route, 46);
                streams.forEach((s, i) => (s.phase = phases[i] ?? s.phase));
            }
            if (opts.reducedMotion)
                draw(0);
        },
        destroy() {
            stop();
            ro.disconnect();
            io.disconnect();
            document.removeEventListener("visibilitychange", onVisibility);
        },
    };
}
