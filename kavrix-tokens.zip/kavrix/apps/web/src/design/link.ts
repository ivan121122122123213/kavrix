/**
 * The Kavrix link: two interlocked rings of light, one per side of a swap, rendered as particles in 3D.
 * The swap widget sits where the rings interlock. Activity (quoting) speeds the flow and brightens it.
 * Framework-free; one canvas, additive blending. The frame loop allocates nothing: colour is set once
 * per ring and per-particle brightness goes through globalAlpha, so there are no GC pauses mid-animation.
 */

export interface LinkState {
  /** 0 = idle, 1 = quoting. Eased internally. */
  readonly activity: number;
}

export interface LinkField {
  update(state: LinkState): void;
  /** Pointer position in -1..1 for a gentle tilt; null to recentre. */
  tilt(x: number | null, y: number | null): void;
  destroy(): void;
}

/** Particles per ring; touch devices get fewer to keep 60 fps on phones. */
const PER_RING_DESKTOP = 2200;
const PER_RING_TOUCH = 1100;
const MAJOR = 1;
const MINOR = 0.09;
const OFFSET = 0.56;

/** Deterministic PRNG: the composition is identical on every load. */
function rng(seed: number): () => number {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

interface Particles {
  /** Angle along the ring. */
  u: Float32Array;
  /** Angle around the tube. */
  v: Float32Array;
  speed: Float32Array;
  size: Float32Array;
}

function makeParticles(seed: number, n: number): Particles {
  const r = rng(seed);
  const p: Particles = { u: new Float32Array(n), v: new Float32Array(n), speed: new Float32Array(n), size: new Float32Array(n) };
  for (let i = 0; i < n; i++) {
    p.u[i] = r() * Math.PI * 2;
    // Bias towards the tube's centre line so each ring reads as a crisp band with a soft halo.
    p.v[i] = r() * Math.PI * 2;
    p.speed[i] = 0.05 + r() * 0.09;
    p.size[i] = r() < 0.06 ? 2.2 : 0.7 + r() * 0.9;
  }
  return p;
}

export function createLinkField(canvas: HTMLCanvasElement, opts: { reducedMotion: boolean }): LinkField {
  const ctx = canvas.getContext("2d");
  if (ctx === null) return { update() {}, tilt() {}, destroy() {} };
  const g = ctx;
  const PER_RING = window.matchMedia("(pointer: coarse)").matches ? PER_RING_TOUCH : PER_RING_DESKTOP;
  const a = makeParticles(11, PER_RING);
  const b = makeParticles(29, PER_RING);
  const tubeA = new Float32Array(PER_RING);
  const tubeB = new Float32Array(PER_RING);
  {
    const r = rng(5);
    for (let i = 0; i < PER_RING; i++) {
      tubeA[i] = Math.pow(r(), 1.8);
      tubeB[i] = Math.pow(r(), 1.8);
    }
  }

  let w = 0;
  let h = 0;
  let dpr = 1;
  let activity = 0;
  let target = 0;
  let spin = 0.6;
  let tiltX = 0;
  let tiltY = 0;
  let tiltTX = 0;
  let tiltTY = 0;
  let raf = 0;
  let last = performance.now();
  let visible = true;

  const resize = () => {
    const rect = canvas.getBoundingClientRect();
    // Cap the backing store at ~2.2 MP: points of light gain nothing from more pixels.
    dpr = Math.min(window.devicePixelRatio || 1, 2, Math.sqrt(2_200_000 / Math.max(1, rect.width * rect.height)));
    const pw = Math.max(1, Math.round(rect.width * dpr));
    const ph = Math.max(1, Math.round(rect.height * dpr));
    if (pw === canvas.width && ph === canvas.height) return;
    w = rect.width;
    h = rect.height;
    canvas.width = pw;
    canvas.height = ph;
    draw(0);
  };

  // Per-frame projection buffers, allocated once.
  const BUCKETS = 10;
  /** Soft fade towards the canvas edge, computed per point (a CSS mask on an animated canvas costs a full recomposite every frame). */
  const edgeFade = (px: number, py: number) => {
    const nx = (px - w / 2) / (w / 2);
    const ny = (py - h / 2) / (h / 2);
    return Math.min(1, Math.max(0, (1 - Math.sqrt(nx * nx + ny * ny)) / 0.28));
  };
  const sx = new Float32Array(PER_RING);
  const sy = new Float32Array(PER_RING);
  const ss = new Float32Array(PER_RING);
  const sb = new Uint8Array(PER_RING);

  /**
   * Projects one ring and draws it in BUCKETS batched fills (one path per brightness level),
   * instead of one draw call per particle.
   */
  function ring(p: Particles, tube: Float32Array, side: -1 | 1, dt: number, cy: number, syaw: number, cx2: number, sx2: number, scale: number, speedUp: number) {
    const cx = w / 2;
    const cyScreen = h / 2;
    for (let i = 0; i < PER_RING; i++) {
      if (!opts.reducedMotion) p.u[i] = (p.u[i]! + dt * p.speed[i]! * speedUp) % (Math.PI * 2);
      const u = p.u[i]!;
      const v = p.v[i]!;
      const rr = MAJOR + MINOR * tube[i]! * Math.cos(v);
      const off = MINOR * tube[i]! * Math.sin(v);
      // Ring A lies in the XY plane, ring B in the XZ plane: they interlock like chain links.
      let x: number;
      let y: number;
      let z: number;
      if (side < 0) {
        x = -OFFSET + rr * Math.cos(u);
        y = rr * Math.sin(u);
        z = off;
      } else {
        x = OFFSET + rr * Math.cos(u);
        y = off;
        z = rr * Math.sin(u);
      }
      const x1 = x * cy + z * syaw;
      const z1 = -x * syaw + z * cy;
      const y2 = y * cx2 - z1 * sx2;
      const z2 = y * sx2 + z1 * cx2;
      const persp = 4.2 / (4.2 - z2);
      const depth = Math.min(1, Math.max(0, (z2 + 1.7) / 3.4));
      const size = p.size[i]! * (0.8 + depth * 0.9) * (1 + activity * 0.25);
      const px = cx + x1 * scale * persp;
      const py = cyScreen + y2 * scale * persp;
      const brightness = ((0.16 + depth * 0.74) / 0.9) * edgeFade(px, py);
      sx[i] = px - size / 2;
      sy[i] = py - size / 2;
      ss[i] = size;
      // Bucket 255 = invisible, skipped entirely.
      sb[i] = brightness <= 0.02 ? 255 : Math.min(BUCKETS - 1, Math.floor(brightness * BUCKETS));
    }
    g.fillStyle = side < 0 ? "rgb(34,242,208)" : "rgb(0,184,255)";
    for (let k = 0; k < BUCKETS; k++) {
      g.globalAlpha = ((k + 0.5) / BUCKETS) * 0.9 * (0.62 + activity * 0.38);
      g.beginPath();
      for (let i = 0; i < PER_RING; i++) if (sb[i] === k) g.rect(sx[i]!, sy[i]!, ss[i]!, ss[i]!);
      g.fill();
    }
  }

  /** Thin luminous centre line of a ring; segments are batched into a few depth bands. */
  function spine(side: -1 | 1, cy: number, syaw: number, cx2: number, sx2: number, scale: number) {
    const cx = w / 2;
    const cyScreen = h / 2;
    const steps = 120;
    const bands = 4;
    g.strokeStyle = side < 0 ? "rgb(34,242,208)" : "rgb(0,184,255)";
    for (let k = 0; k < bands; k++) {
      const level = (k + 0.5) / bands;
      g.globalAlpha = level * 0.5 * (0.7 + activity * 0.3);
      g.lineWidth = 0.6 + level * 1.1;
      g.beginPath();
      let px0 = 0;
      let py0 = 0;
      for (let i = 0; i <= steps; i++) {
        const u = (i / steps) * Math.PI * 2;
        const x = side < 0 ? -OFFSET + MAJOR * Math.cos(u) : OFFSET + MAJOR * Math.cos(u);
        const y = side < 0 ? MAJOR * Math.sin(u) : 0;
        const z = side < 0 ? 0 : MAJOR * Math.sin(u);
        const x1 = x * cy + z * syaw;
        const z1 = -x * syaw + z * cy;
        const y2 = y * cx2 - z1 * sx2;
        const z2 = y * sx2 + z1 * cx2;
        const persp = 4.2 / (4.2 - z2);
        const px = cx + x1 * scale * persp;
        const py = cyScreen + y2 * scale * persp;
        const depth = Math.min(1, Math.max(0, (z2 + 1.7) / 3.4));
        const level = ((0.1 + depth * 0.4) / 0.5) * edgeFade(px, py);
        const band = level <= 0.02 ? -1 : Math.min(bands - 1, Math.floor(level * bands));
        if (i > 0 && band === k) {
          g.moveTo(px0, py0);
          g.lineTo(px, py);
        }
        px0 = px;
        py0 = py;
      }
      g.stroke();
    }
  }

  function draw(dt: number) {
    activity += (target - activity) * Math.min(1, dt * 2.5);
    tiltX += (tiltTX - tiltX) * Math.min(1, dt * 2);
    tiltY += (tiltTY - tiltY) * Math.min(1, dt * 2);
    if (!opts.reducedMotion) spin += dt * (0.07 + activity * 0.12);
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, w, h);
    g.globalCompositeOperation = "lighter";
    const yaw = Math.sin(spin) * 0.55 + tiltX * 0.25;
    const pitch = 0.42 + tiltY * 0.18;
    const scale = Math.min(w * 0.31, h * 0.46);
    const speedUp = 1 + activity * 2.6;
    spine(-1, Math.cos(yaw), Math.sin(yaw), Math.cos(pitch), Math.sin(pitch), scale);
    spine(1, Math.cos(yaw), Math.sin(yaw), Math.cos(pitch), Math.sin(pitch), scale);
    ring(a, tubeA, -1, dt, Math.cos(yaw), Math.sin(yaw), Math.cos(pitch), Math.sin(pitch), scale, speedUp);
    ring(b, tubeB, 1, dt, Math.cos(yaw), Math.sin(yaw), Math.cos(pitch), Math.sin(pitch), scale, speedUp);
    g.globalAlpha = 1;
    g.globalCompositeOperation = "source-over";
  }

  const frame = (now: number) => {
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    draw(dt);
    raf = requestAnimationFrame(frame);
  };
  const start = () => {
    if (opts.reducedMotion || raf !== 0 || !visible || document.hidden) return;
    last = performance.now();
    raf = requestAnimationFrame(frame);
  };
  const stop = () => {
    cancelAnimationFrame(raf);
    raf = 0;
  };

  const ro = new ResizeObserver(resize);
  ro.observe(canvas);
  const io = new IntersectionObserver(([e]) => {
    visible = e?.isIntersecting ?? true;
    if (visible) start();
    else stop();
  });
  io.observe(canvas);
  const onVis = () => (document.hidden ? stop() : start());
  document.addEventListener("visibilitychange", onVis);
  resize();
  start();

  return {
    update(state) {
      target = Math.max(0, Math.min(1, state.activity));
      if (opts.reducedMotion) draw(0.5);
    },
    tilt(x, y) {
      tiltTX = x ?? 0;
      tiltTY = y ?? 0;
    },
    destroy() {
      stop();
      ro.disconnect();
      io.disconnect();
      document.removeEventListener("visibilitychange", onVis);
    },
  };
}
