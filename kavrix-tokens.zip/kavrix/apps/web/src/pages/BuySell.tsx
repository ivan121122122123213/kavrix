import { useCapabilities } from "../lib/data.ts";
import { Page } from "../layout/Page.tsx";
import { RampPanel } from "../ramp/RampPanel.tsx";
import { useLang } from "../i18n/core.tsx";

export default function BuySell() {
  const capabilities = useCapabilities();
  const ru = useLang() === "ru";
  return (
    <Page
      path="/buy-sell"
      lead={
        ru
          ? "Оплатите картой или банковским переводом либо продайте криптовалюту с выплатой. Оплату и проверку личности проводит лицензированный провайдер."
          : "Pay with a card or bank transfer, or sell crypto for a payout. A licensed provider handles payment and identity checks."
      }
    >
      <div className="grid items-start gap-10 lg:grid-cols-[28rem_minmax(0,1fr)]">
        <RampPanel capabilities={capabilities} />
        {ru ? (
          <div className="prose-kavrix">
            <h2>Перед началом</h2>
            <ul>
              <li>Провайдер попросит подтвердить личность. Требования зависят от страны и суммы.</li>
              <li>Курс и комиссия провайдера видны на его странице оплаты до платежа. Kavrix не добавляет скрытую наценку.</li>
              <li>Продажа криптовалюты и выплаты на карту доступны не во всех странах. Провайдер покажет, что доступно вам.</li>
              <li>Kavrix никогда не получает номер карты или банковские реквизиты — они передаются напрямую провайдеру.</li>
            </ul>
            <h2>После оплаты</h2>
            <p>Статус заказа приходит от провайдера. Следить за ним можно на странице истории; Kavrix никогда не отмечает заказ выполненным сам.</p>
          </div>
        ) : (
          <div className="prose-kavrix">
            <h2>Before you start</h2>
            <ul>
              <li>The provider will ask you to verify your identity. Requirements depend on your country and the amount.</li>
              <li>The rate and the provider's fee are shown in the provider's checkout before you pay. Kavrix does not add a hidden margin.</li>
              <li>Selling crypto and payouts to cards are not available in every country. The provider tells you what applies to you.</li>
              <li>Kavrix never receives your card number or bank details; they go directly to the provider.</li>
            </ul>
            <h2>After you pay</h2>
            <p>Order status comes from the provider. You can follow it on the history page; Kavrix never marks an order complete on its own.</p>
          </div>
        )}
      </div>
    </Page>
  );
}
