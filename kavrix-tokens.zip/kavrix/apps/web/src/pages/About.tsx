import { Page, operator } from "../layout/Page.tsx";
import { useLang } from "../i18n/core.tsx";

export default function About() {
  const ru = useLang() === "ru";
  return (
    <Page path="/about">
      {ru ? (
        <div className="prose-kavrix">
          <p>
            Kavrix — интерфейс для обмена токенов в сетях Ethereum, Base, Arbitrum и Polygon прямо из вашего кошелька и вход к
            лицензированным провайдерам для покупки и продажи криптовалюты за обычные деньги.
          </p>
          <p>
            Оператор Kavrix — <strong>{operator("ru")}</strong>. Обмены исполняют смарт-контракты агрегатора KyberSwap; оплату картой и
            выплаты проводят платёжные провайдеры, указанные при оформлении. Kavrix не принимает средства пользователей на хранение.
          </p>
          <p>
            Мы построили Kavrix вокруг одного правила: до того как что-то подписать, вы должны точно знать, сколько стоит обмен и
            что вы получите, и ничего не должно считаться сделанным, пока это не сделано в блокчейне.
          </p>
        </div>
      ) : (
        <div className="prose-kavrix">
          <p>
            Kavrix is an interface for swapping tokens on Ethereum, Base, Arbitrum and Polygon from your own wallet, and a gateway to
            licensed providers for buying and selling crypto with fiat money.
          </p>
          <p>
            Kavrix is operated by <strong>{operator()}</strong>. Swaps are executed by the KyberSwap aggregator's smart contracts; card
            payments and payouts are handled by the payment providers shown at checkout. Kavrix does not take custody of user funds.
          </p>
          <p>
            We built Kavrix around one rule: you should know exactly what a swap will cost and what you will receive before you sign
            anything, and nothing should be reported as done until it is done on-chain.
          </p>
        </div>
      )}
    </Page>
  );
}
