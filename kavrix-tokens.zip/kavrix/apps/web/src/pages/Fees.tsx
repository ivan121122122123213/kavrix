import { Link } from "react-router";
import { CHAINS, SUPPORTED_CHAIN_IDS, applyBps } from "@kavrix/shared";
import { feeBpsFor } from "../lib/api.ts";
import { useCapabilities } from "../lib/data.ts";
import { formatBps, formatTokenAmount } from "../lib/format.ts";
import { Page } from "../layout/Page.tsx";
import { Skeleton } from "../ui/Skeleton.tsx";
import { useLang } from "../i18n/core.tsx";

export default function Fees() {
  const capabilities = useCapabilities();
  const ru = useLang() === "ru";
  const bps = capabilities.status === "ready" ? capabilities.data.swap.platformFeeBps : null;
  const exampleOut = 1_000_000_000n; // 1,000 USDC paid, in base units, for the worked example only
  return (
    <Page
      path="/fees"
      lead={ru ? "У обмена до трёх видов затрат. Каждая видна до подписи, ни одна не спрятана в курс." : "A swap involves up to three costs. Each is shown before you sign, and none is folded into the rate."}
    >
      <div className="prose-kavrix">
        <h2>{ru ? "Комиссия Kavrix" : "Kavrix fee"}</h2>
        <p>
          {ru ? "Текущая ставка:" : "Current rate:"}{" "}
          {bps === null ? (
            capabilities.status === "error" ? <strong>{ru ? "сейчас недоступна" : "unavailable right now"}</strong> : <Skeleton className="inline-block h-4 w-12 align-middle" />
          ) : (
            <strong className="tabular">{bps === 0 ? (ru ? "0% (без комиссии Kavrix)" : "0% (no Kavrix fee)") : formatBps(bps)}</strong>
          )}
          {capabilities.status === "ready" ? (
            <>
              {" "}
              {ru ? "по сетям:" : "by network:"}{" "}
              {SUPPORTED_CHAIN_IDS.map((id, i) => (
                <span key={id} className="tabular">
                  {i > 0 ? ", " : ""}
                  {CHAINS[id].name} {formatBps(feeBpsFor(capabilities.data, id))}
                </span>
              ))}
            </>
          ) : null}
          {ru
            ? ". Это процент от суммы, которую вы отдаёте; его удерживает контракт обмена в той же транзакции. Точная сумма — отдельной строкой в котировке, а сумма к получению уже посчитана после неё."
            : ". It is a percentage of the amount you pay, taken by the swap contract in the same transaction. The quote shows the exact amount on its own line, and the amount you receive is already calculated after it."}
        </p>
        <h2>{ru ? "Агрегатор" : "Aggregator"}</h2>
        <p>
          {ru
            ? "Маршруты строит агрегатор KyberSwap. За обмены через Kavrix он не берёт явной комиссии. По его опубликованным условиям ему достаются две вещи: излишек сверх котировки, если цена между котировкой и исполнением сдвинулась в вашу пользу, и «пыль», если пул исполнил заявку не полностью. Ни то ни другое не может уменьшить сумму ниже минимума, показанного до подписи."
            : "Routes come from the KyberSwap aggregator, which charges no explicit fee on swaps made through Kavrix. Two things go to KyberSwap under its published terms: if the price moves in your favour between quote and execution, the surplus above the quoted amount, and any dust left over when a pool fills an order only partially. Neither can reduce what you receive below the minimum shown before you sign."}
        </p>
        <h2>{ru ? "Комиссия сети (газ)" : "Network fee (gas)"}</h2>
        <p>
          {ru
            ? "Платится сети в её нативной монете (ETH в Ethereum, Base и Arbitrum; POL в Polygon), а не Kavrix. Котировка показывает оценку, окончательную сумму кошелёк покажет до подписи. Если обмен откатится, комиссия сети всё равно будет потрачена."
            : "Paid to the network in its native coin (ETH on Ethereum, Base and Arbitrum; POL on Polygon), not to Kavrix. The quote shows an estimate; your wallet shows the final value before you sign. If a swap reverts, the network fee is still spent."}
        </p>
        <h2>{ru ? "Покупка и продажа картой" : "Card purchases and sales"}</h2>
        <p>
          {ru
            ? "Платёжный провайдер сам устанавливает комиссии и курс и показывает их на своей странице оплаты. Kavrix может получать от провайдера партнёрское вознаграждение по договору; на показанную вам цену это никогда не влияет."
            : "The payment provider sets its own fees and rate and shows them in its checkout. Kavrix may receive a referral share from the provider under its partner agreement; this never changes the price you are shown."}
        </p>
        <h2>{ru ? "Пример расчёта" : "Worked example"}</h2>
        {bps === null ? (
          <p>{ru ? "Пример появится, когда загрузится текущая ставка." : "The example appears once the current fee rate has loaded."}</p>
        ) : (
          ru ? (
            <p>
              Обмен на <strong className="tabular">1,000 USDC</strong> при комиссии Kavrix {formatBps(bps)} отправляет Kavrix{" "}
              <strong className="tabular">{formatTokenAmount(applyBps(exampleOut, bps), 6)} USDC</strong>, а оставшиеся{" "}
              <strong className="tabular">{formatTokenAmount(exampleOut - applyBps(exampleOut, bps), 6)} USDC</strong> идут в обмен.
              Комиссия округляется вниз, поэтому с вас никогда не возьмут больше заявленной ставки. Это пример, а не котировка.
            </p>
          ) : (
            <p>
              A swap paying <strong className="tabular">1,000 USDC</strong> at a Kavrix fee of {formatBps(bps)} sends{" "}
              <strong className="tabular">{formatTokenAmount(applyBps(exampleOut, bps), 6)} USDC</strong> to Kavrix and swaps the remaining{" "}
              <strong className="tabular">{formatTokenAmount(exampleOut - applyBps(exampleOut, bps), 6)} USDC</strong>. Fees are rounded
              down, so you are never charged more than the stated rate. This is an illustration, not a quote.
            </p>
          )
        )}
        <p>
          <Link to="/">{ru ? "Получить живую котировку" : "Get a live quote"}</Link>
        </p>
      </div>
    </Page>
  );
}
