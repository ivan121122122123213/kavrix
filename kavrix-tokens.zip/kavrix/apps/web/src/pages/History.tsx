import { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router";
import { useConnection } from "wagmi";
import { CHAINS } from "@kavrix/shared";
import { Page } from "../layout/Page.tsx";
import { Notice } from "../ui/Notice.tsx";
import { Button } from "../ui/Button.tsx";
import { LoadingRows } from "../ui/Skeleton.tsx";
import { describeError } from "../lib/api.ts";
import { fetchHistory } from "../lib/swaps.ts";
import { formatTokenAmount } from "../lib/format.ts";
import { STATUS_LABEL, STATUS_LABEL_RU, type SwapStatusView, type TokenRef } from "../swap/status.ts";
import { useLang } from "../i18n/core.tsx";
import { locale } from "../i18n/lang.ts";
import { ConnectDialog } from "../wallet/WalletButton.tsx";
import { RAMP_STATUS_LABEL, RAMP_STATUS_LABEL_RU, fetchRampOrder, fetchRampOrders, type RampOrderView } from "../lib/ramp.ts";
import { useResource } from "../lib/resource.ts";

const PROVIDER: Record<RampOrderView["provider"], string> = { moonpay: "MoonPay", transak: "Transak" };

function orderLine(o: RampOrderView, ru: boolean): string {
  const verb = o.direction === "buy" ? (ru ? "Покупка" : "Buy") : ru ? "Продажа" : "Sell";
  const amount = o.direction === "buy" ? `${o.fiatAmount ?? "?"} ${o.fiatCurrency}` : `${o.cryptoAmount ?? "?"} ${o.cryptoCurrency}`;
  return `${verb} ${o.cryptoCurrency} · ${amount}`;
}

/** Shown after a provider redirects back; the status comes from verified provider webhooks only. */
function ReturningOrder({ id }: { id: string }) {
  const ru = useLang() === "ru";
  const order = useResource((signal) => fetchRampOrder(id, signal), `ramp:${id}`);
  const { retry } = order;
  const pending = order.status === "ready" && (order.data.status === "created" || order.data.status === "pending");
  useEffect(() => {
    if (!pending) return;
    const t = setInterval(retry, 5_000);
    return () => clearInterval(t);
  }, [pending, retry]);
  if (order.status !== "ready") return null;
  const o = order.data;
  return (
    <div className="mb-6">
      <Notice title={ru ? `Заказ ${PROVIDER[o.provider]}: ${RAMP_STATUS_LABEL_RU[o.status]}` : `${PROVIDER[o.provider]} order: ${RAMP_STATUS_LABEL[o.status]}`}>
        {o.status === "created"
          ? ru
            ? `Ждём, пока ${PROVIDER[o.provider]} подтвердит заказ. Страница обновляется сама.`
            : `Waiting for ${PROVIDER[o.provider]} to confirm the order. This page updates on its own.`
          : o.status === "pending"
            ? ru
              ? `${PROVIDER[o.provider]} обрабатывает заказ. Обычно это занимает минуты, иногда несколько часов.`
              : `${PROVIDER[o.provider]} is processing the order. Card orders usually take minutes, sometimes a few hours.`
            : ru
              ? `Окончательный статус от ${PROVIDER[o.provider]}.`
              : `Final status reported by ${PROVIDER[o.provider]}.`}
      </Notice>
    </div>
  );
}

function amount(value: bigint | null, token: TokenRef): string {
  if (value === null) return "—";
  return token.decimals === null ? value.toString() : `${formatTokenAmount(value, token.decimals)} ${token.symbol ?? ""}`.trim();
}

const TONE: Record<SwapStatusView["status"], string> = {
  confirmed: "text-accent",
  submitted: "text-accent-2",
  dropped: "text-warning",
  reverted: "text-danger",
  failed: "text-danger",
  quoted: "text-muted",
  awaiting_approval: "text-muted",
  rejected: "text-muted",
  expired: "text-muted",
};

type State =
  | { status: "loading" }
  | { status: "error"; error: unknown }
  | { status: "ready"; swaps: SwapStatusView[]; next: string | null; loadingMore: boolean };

export default function History() {
  const lang = useLang();
  const ru = lang === "ru";
  const when = (iso: string) => new Date(iso).toLocaleString(locale(lang));
  const [params] = useSearchParams();
  const returning = params.get("order");
  const connection = useConnection();
  const wallet = connection.status === "connected" ? connection.address?.toLowerCase() : undefined;
  const [state, setState] = useState<State>({ status: "loading" });
  const [connectOpen, setConnectOpen] = useState(false);
  const [attempt, setAttempt] = useState(0);
  const orders = useResource(
    (signal) => (wallet === undefined ? Promise.resolve<RampOrderView[]>([]) : fetchRampOrders(wallet, signal)),
    `ramp-orders:${wallet ?? "-"}:${attempt}`,
  );

  useEffect(() => {
    if (wallet === undefined) return;
    const controller = new AbortController();
    setState({ status: "loading" });
    fetchHistory(wallet, null, controller.signal).then(
      (r) => setState({ status: "ready", swaps: r.swaps, next: r.nextCursor, loadingMore: false }),
      (error: unknown) => {
        if (!controller.signal.aborted) setState({ status: "error", error });
      },
    );
    return () => controller.abort();
  }, [wallet, attempt]);

  const loadMore = () => {
    if (state.status !== "ready" || state.next === null || wallet === undefined) return;
    setState({ ...state, loadingMore: true });
    fetchHistory(wallet, state.next).then(
      (r) => setState({ status: "ready", swaps: [...state.swaps, ...r.swaps], next: r.nextCursor, loadingMore: false }),
      (error: unknown) => setState({ status: "error", error }),
    );
  };

  return (
    <Page
      path="/history"
      lead={
        ru
          ? "Обмены и заказы по карте для вашего кошелька. Статус обмена берётся из блокчейна, статус заказа — от платёжного провайдера."
          : "Swaps and card orders for your wallet. Swap status comes from the blockchain, card order status from the payment provider."
      }
    >
      <div className="max-w-3xl">
        {returning !== null && /^[0-9a-f-]{36}$/i.test(returning) ? <ReturningOrder id={returning} /> : null}
        <h2 className="mb-3 text-lg font-semibold">{ru ? "Обмены" : "Swaps"}</h2>
        {wallet === undefined ? (
          <Notice
            title={ru ? "Подключите кошелёк, чтобы увидеть историю" : "Connect a wallet to see its history"}
            action={<Button variant="secondary" onClick={() => setConnectOpen(true)}>{ru ? "Подключить кошелёк" : "Connect wallet"}</Button>}
          >
            {ru ? "История ведётся по адресу кошелька. Показаны только обмены, дошедшие до сети." : "History is listed per wallet address. Only swaps that reached the network are shown."}
          </Notice>
        ) : null}
        {wallet !== undefined && state.status === "loading" ? <LoadingRows label={ru ? "Загружаем историю" : "Loading history"} rows={4} /> : null}
        {wallet !== undefined && state.status === "error" ? (
          <Notice tone="danger" title={ru ? "История не загрузилась" : "History did not load"} action={<Button variant="secondary" onClick={() => setAttempt((n) => n + 1)}>{ru ? "Повторить" : "Retry"}</Button>}>
            {describeError(state.error, lang)}
          </Notice>
        ) : null}
        {wallet !== undefined && state.status === "ready" && state.swaps.length === 0 ? (
          <Notice title={ru ? "Обменов пока нет" : "No swaps yet"}>
            {ru ? "Здесь появятся обмены, отправленные с этого кошелька. " : "Swaps you send from this wallet will appear here. "}
            <Link className="text-accent" to="/">{ru ? "Сделать обмен" : "Make a swap"}</Link>
          </Notice>
        ) : null}
        {wallet !== undefined && state.status === "ready" && state.swaps.length > 0 ? (
          <>
            <ul className="divide-y divide-line rounded-control border border-line">
              {state.swaps.map((s) => (
                <li key={s.id}>
                  <Link to={`/tx/${s.id}`} className="grid gap-1 px-4 py-3 hover:bg-surface sm:grid-cols-[1fr_auto] sm:items-center">
                    <span className="tabular">
                      {amount(s.sellAmount, s.sell)} <span className="text-muted">→</span>{" "}
                      {amount(s.actualBuyAmount ?? s.quotedBuyAmount, s.buy)}
                      {s.actualBuyAmount === null && s.status === "confirmed" ? <span className="text-xs text-faint"> {ru ? "(по котировке)" : "(quoted)"}</span> : null}
                    </span>
                    <span className="flex gap-3 text-xs">
                      <span className="text-muted">{CHAINS[s.chainId].name}</span>
                      <span className="text-muted">{when(s.createdAt)}</span>
                      <span className={TONE[s.status]}>{(ru ? STATUS_LABEL_RU : STATUS_LABEL)[s.status]}</span>
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
            {state.next !== null ? (
              <div className="mt-4">
                <Button variant="secondary" busy={state.loadingMore} onClick={loadMore}>
                  {ru ? "Показать ещё" : "Load more"}
                </Button>
              </div>
            ) : null}
          </>
        ) : null}
        {wallet !== undefined ? (
          <section aria-labelledby="orders-title" className="mt-10">
            <h2 id="orders-title" className="mb-3 text-lg font-semibold">
              {ru ? "Заказы по карте" : "Card orders"}
            </h2>
            {orders.status === "loading" ? <LoadingRows label={ru ? "Загружаем заказы" : "Loading card orders"} rows={2} /> : null}
            {orders.status === "error" ? <Notice tone="danger" title={ru ? "Заказы не загрузились" : "Card orders did not load"}>{describeError(orders.error, lang)}</Notice> : null}
            {orders.status === "ready" && orders.data.length === 0 ? (
              <p className="text-sm text-muted">{ru ? "У этого кошелька нет заказов по карте." : "No card orders for this wallet."}</p>
            ) : null}
            {orders.status === "ready" && orders.data.length > 0 ? (
              <ul className="divide-y divide-line rounded-control border border-line">
                {orders.data.map((o) => (
                  <li key={o.id} className="grid gap-1 px-4 py-3 sm:grid-cols-[1fr_auto] sm:items-center">
                    <span className="tabular">{orderLine(o, ru)}</span>
                    <span className="flex gap-3 text-xs text-muted">
                      <span>{PROVIDER[o.provider]}</span>
                      <span>{CHAINS[o.chainId].name}</span>
                      <span>{when(o.createdAt)}</span>
                      <span className={o.status === "completed" ? "text-accent" : o.status === "pending" || o.status === "created" ? "text-accent-2" : "text-muted"}>
                        {(ru ? RAMP_STATUS_LABEL_RU : RAMP_STATUS_LABEL)[o.status]}
                      </span>
                    </span>
                  </li>
                ))}
              </ul>
            ) : null}
          </section>
        ) : null}
      </div>
      <ConnectDialog open={connectOpen} onClose={() => setConnectOpen(false)} />
    </Page>
  );
}
