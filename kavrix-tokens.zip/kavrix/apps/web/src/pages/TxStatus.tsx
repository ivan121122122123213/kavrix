import { useEffect, type ReactNode } from "react";
import { useLang } from "../i18n/core.tsx";
import { locale, type Lang } from "../i18n/lang.ts";
import { Link, useParams } from "react-router";
import { CHAINS, explorerTxUrl, isTerminalSwapStatus } from "@kavrix/shared";
import { ApiError, describeError } from "../lib/api.ts";
import { fetchSwap } from "../lib/swaps.ts";
import { useResource } from "../lib/resource.ts";
import { formatTokenAmount } from "../lib/format.ts";
import { Page } from "../layout/Page.tsx";
import { Notice } from "../ui/Notice.tsx";
import { Button } from "../ui/Button.tsx";
import { LoadingRows } from "../ui/Skeleton.tsx";
import { ExternalLink } from "../ui/ExternalLink.tsx";
import { UUID_RE, statusCopy, stepsFor, type SwapStatusView, type TokenRef } from "../swap/status.ts";

const POLL_MS = 5_000;
const STEP_STATE_RU = { done: "выполнено", current: "идёт", todo: "впереди", failed: "не удалось" } as const;

function Timeline({ status, lang }: { status: SwapStatusView["status"]; lang: Lang }) {
  const steps = stepsFor(status, lang);
  return (
    <ol className="flex gap-2" aria-label={lang === "ru" ? "Ход операции" : "Progress"}>
      {steps.map((s) => (
        <li key={s.label} className="flex-1">
          <span
            aria-hidden
            className={`block h-1 rounded-full ${
              s.state === "done" ? "bg-accent" : s.state === "current" ? "animate-pulse bg-accent-2" : s.state === "failed" ? "bg-danger" : "bg-line"
            }`}
          />
          <span className={`mt-2 block text-xs ${s.state === "todo" ? "text-faint" : "text-muted"}`}>
            {s.label}
            <span className="sr-only">: {lang === "ru" ? STEP_STATE_RU[s.state] : s.state}</span>
          </span>
        </li>
      ))}
    </ol>
  );
}

function Amount({ value, token }: { value: bigint; token: TokenRef }) {
  return (
    <span className="tabular">
      {token.decimals === null ? value.toString() : formatTokenAmount(value, token.decimals)} {token.symbol ?? token.address}
    </span>
  );
}

function Row({ term, children }: { term: string; children: ReactNode }) {
  return (
    <div className="flex justify-between gap-4 py-2">
      <dt className="text-muted">{term}</dt>
      <dd className="min-w-0 text-right">{children}</dd>
    </div>
  );
}

export default function TxStatus() {
  const { id = "" } = useParams();
  const lang = useLang();
  const ru = lang === "ru";
  const validId = UUID_RE.test(id);
  const swap = useResource<SwapStatusView>(async (signal) => {
    if (!validId) throw new ApiError(404, undefined);
    return fetchSwap(id, signal);
  }, `swap:${id}`);

  const pending = swap.status === "ready" && !isTerminalSwapStatus(swap.data.status);
  const { retry } = swap;
  useEffect(() => {
    if (!pending) return;
    const timer = setInterval(retry, POLL_MS);
    return () => clearInterval(timer);
  }, [pending, retry]);

  return (
    <Page path="/tx/:id" heading={ru ? "Статус обмена" : "Swap status"}>
      <div className="max-w-xl">
        {swap.status === "loading" ? <LoadingRows label={ru ? "Загружаем статус" : "Loading swap status"} rows={2} /> : null}
        {swap.status === "error" ? (
          swap.error instanceof ApiError && swap.error.status === 404 ? (
            <Notice title={ru ? "Обмена с таким номером нет" : "No swap with this id"}>
              {ru ? "Проверьте ссылку. " : "Check the link. "}
              <Link className="text-accent" to="/">{ru ? "Начать обмен" : "Start a swap"}</Link>
            </Notice>
          ) : (
            <Notice tone="danger" title={ru ? "Статус не загрузился" : "Status did not load"} action={<Button variant="secondary" onClick={swap.retry}>{ru ? "Повторить" : "Retry"}</Button>}>
              {describeError(swap.error)}
            </Notice>
          )
        ) : null}
        {swap.status === "ready" ? (
          <section aria-live="polite" className="space-y-6">
            <Timeline status={swap.data.status} lang={lang} />
            <div>
              <h2 className="text-xl font-semibold">{statusCopy(swap.data.status, lang).title}</h2>
              <p className="mt-2 text-muted">{statusCopy(swap.data.status, lang).body}</p>
              {swap.data.status === "submitted" && swap.data.confirmations !== null ? (
                <p className="tabular mt-2 text-sm text-muted">
                  {ru
                    ? `${swap.data.confirmations} из ${swap.data.requiredConfirmations} подтверждений`
                    : `${swap.data.confirmations} of ${swap.data.requiredConfirmations} confirmations`}
                </p>
              ) : null}
            </div>
            <dl className="divide-y divide-line text-sm">
              <Row term={ru ? "Вы отдали" : "You paid"}>
                <Amount value={swap.data.sellAmount} token={swap.data.sell} />
              </Row>
              {swap.data.actualBuyAmount !== null ? (
                <Row term={ru ? "Вы получили" : "You received"}>
                  <Amount value={swap.data.actualBuyAmount} token={swap.data.buy} />
                </Row>
              ) : (
                <Row term={swap.data.status === "confirmed" ? (ru ? "По котировке" : "Quoted output") : ru ? "Ожидается" : "Expected"}>
                  <Amount value={swap.data.quotedBuyAmount} token={swap.data.buy} />
                </Row>
              )}
              <Row term={ru ? "Гарантированный минимум" : "Guaranteed minimum"}>
                <Amount value={swap.data.minBuyAmount} token={swap.data.buy} />
              </Row>
              <Row term={ru ? "Сеть" : "Network"}>{CHAINS[swap.data.chainId].name}</Row>
              {swap.data.txHash !== null ? (
                <Row term={ru ? "Транзакция" : "Transaction"}>
                  <ExternalLink href={explorerTxUrl(swap.data.chainId, swap.data.txHash)} className="block truncate font-mono text-xs">
                    {swap.data.txHash}
                  </ExternalLink>
                </Row>
              ) : null}
              <Row term={ru ? "Создано" : "Created"}>{new Date(swap.data.createdAt).toLocaleString(locale(lang))}</Row>
            </dl>
            {pending ? <p className="text-xs text-faint">{ru ? "Страница обновляется сама." : "This page refreshes on its own."}</p> : null}
          </section>
        ) : null}
      </div>
    </Page>
  );
}
