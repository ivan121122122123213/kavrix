import { Link } from "react-router";
import { useLang } from "../i18n/core.tsx";

export default function NotFound() {
  const ru = useLang() === "ru";
  return (
    <section className="max-w-xl">
      <title>{ru ? "Страница не найдена · Kavrix" : "Page not found · Kavrix"}</title>
      <meta name="robots" content="noindex" />
      <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">{ru ? "Страница не найдена" : "Page not found"}</h1>
      <p className="mt-3 text-muted">{ru ? "Возможно, в адресе опечатка или страница переехала." : "The address may be mistyped, or the page has moved."}</p>
      <Link to="/" className="k-btn k-btn--primary mt-6 h-10 px-4">
        <span className="relative z-10">{ru ? "К обмену" : "Go to swap"}</span>
      </Link>
    </section>
  );
}
