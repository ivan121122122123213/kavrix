import { useState } from "react";
import { useLang } from "../i18n/core.tsx";
import { ruPlural } from "../i18n/lang.ts";
import { CHAINS, SUPPORTED_CHAIN_IDS, type SupportedChainId } from "@kavrix/shared";
import { useTokens } from "../lib/data.ts";
import { describeError } from "../lib/api.ts";
import { Page } from "../layout/Page.tsx";
import { Segmented } from "../ui/Segmented.tsx";
import { LoadingRows } from "../ui/Skeleton.tsx";
import { Notice } from "../ui/Notice.tsx";
import { Button } from "../ui/Button.tsx";
import { TokenIcon } from "../ui/TokenIcon.tsx";
import { ExternalLink } from "../ui/ExternalLink.tsx";

const SHORT: Record<SupportedChainId, string> = { 1: "Ethereum", 8453: "Base", 42161: "Arbitrum", 137: "Polygon" };

export default function Networks() {
  const [chainId, setChainId] = useState<SupportedChainId>(1);
  const tokens = useTokens(chainId);
  const lang = useLang();
  const ru = lang === "ru";
  const chain = CHAINS[chainId];
  return (
    <Page
      path="/networks"
      lead={
        ru
          ? "Kavrix показывает только токены, контракты которых он проверил. Перед обменом сверьте адрес в кошельке с адресом ниже."
          : "Kavrix lists a small set of tokens whose contracts it has checked. Compare the address in your wallet with the one below before you swap."
      }
    >
      <Segmented
        label={ru ? "Сеть" : "Network"}
        options={SUPPORTED_CHAIN_IDS.map((id) => ({ value: String(id) as `${SupportedChainId}`, label: SHORT[id] }))}
        value={String(chainId) as `${SupportedChainId}`}
        onChange={(v) => setChainId(Number(v) as SupportedChainId)}
      />
      <p className="mt-4 text-sm text-muted">
        {ru
          ? `${chain.name}: нативная монета ${chain.nativeCurrency.symbol}, окончательность после ${chain.confirmations} ${ruPlural(chain.confirmations, "подтверждения", "подтверждений", "подтверждений")} блока.`
          : `${chain.name}: native coin ${chain.nativeCurrency.symbol}, final after ${chain.confirmations} block confirmations.`}{" "}
        <ExternalLink href={chain.explorerUrl}>{ru ? "Обозреватель блоков" : "Block explorer"}</ExternalLink>
      </p>
      <div className="mt-6 max-w-3xl">
        {tokens.status === "loading" ? <LoadingRows label={ru ? "Загружаем токены" : "Loading tokens"} rows={4} /> : null}
        {tokens.status === "error" ? (
          <Notice tone="danger" title={ru ? "Список токенов не загрузился" : "Token list did not load"} action={<Button variant="secondary" onClick={tokens.retry}>{ru ? "Повторить" : "Retry"}</Button>}>
            {describeError(tokens.error, lang)}
          </Notice>
        ) : null}
        {tokens.status === "ready" ? (
          <div className="overflow-x-auto rounded-control border border-line">
            <table className="w-full min-w-[34rem] text-left text-sm">
              <caption className="sr-only">{ru ? `Токены в сети ${chain.name}` : `Tokens supported on ${chain.name}`}</caption>
              <thead className="bg-surface text-muted">
                <tr>
                  <th scope="col" className="px-4 py-3 font-normal">{ru ? "Токен" : "Token"}</th>
                  <th scope="col" className="px-4 py-3 font-normal">{ru ? "Контракт" : "Contract"}</th>
                  <th scope="col" className="px-4 py-3 text-right font-normal">{ru ? "Знаков" : "Decimals"}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {tokens.data.map((t) => (
                  <tr key={t.address}>
                    <th scope="row" className="px-4 py-3 font-normal">
                      <span className="flex items-center gap-3">
                        <TokenIcon symbol={t.symbol} address={t.address} logoUrl={t.logoUrl} chainId={chainId} size={28} />
                        <span>
                          <span className="block font-medium text-text">{t.symbol}</span>
                          <span className="block text-xs text-muted">{t.name}</span>
                        </span>
                      </span>
                    </th>
                    <td className="px-4 py-3">
                      {t.native ? (
                        <span className="text-muted">{ru ? "Нативная монета, без контракта" : "Native coin, no contract"}</span>
                      ) : (
                        <ExternalLink href={`${chain.explorerUrl}/token/${t.address}`} className="break-all font-mono text-xs">
                          {t.address}
                        </ExternalLink>
                      )}
                    </td>
                    <td className="tabular px-4 py-3 text-right text-muted">{t.decimals}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : null}
      </div>
    </Page>
  );
}
