import { useCallback, useState } from "react";
import { Link, useLocation } from "react-router";
import { CHAINS, SUPPORTED_CHAIN_IDS } from "@kavrix/shared";
import { useCapabilities } from "../lib/data.ts";
import { Seo } from "../layout/Seo.tsx";
import { routeFor } from "../layout/Page.tsx";
import { SwapWidget, type SwapActivity } from "../swap/SwapWidget.tsx";
import { LinkField } from "../ui/LinkField.tsx";
import { Anatomy } from "../ui/Anatomy.tsx";
import { useIntroOnce } from "../ui/intro.ts";
import { useLang } from "../i18n/core.tsx";
import { ruPlural } from "../i18n/lang.ts";

export default function Home() {
  const capabilities = useCapabilities();
  const { pathname } = useLocation();
  const [activity, setActivity] = useState<SwapActivity>({ busy: false, route: [] });
  const intro = useIntroOnce();
  const ru = useLang() === "ru";
  const onActivity = useCallback((a: SwapActivity) => setActivity(a), []);

  return (
    <>
      <Seo route={routeFor("/")} pathname={pathname} />

      <section aria-labelledby="hero-title" className="pt-4 text-center sm:pt-10">
        <h1 id="hero-title" className="k-display mx-auto max-w-[17ch] text-[clamp(2.6rem,1.2rem_+_3.6vw,4.9rem)]">
          {ru ? "Обменивайте токены, не отдавая их никому." : "Swap tokens without handing them over."}
        </h1>
        <p className="mx-auto mt-5 max-w-[52ch] text-lg leading-relaxed text-muted">
          {ru
            ? "Kavrix находит маршрут через ликвидность в сетях Ethereum, Base, Arbitrum и Polygon. Курс, все комиссии и минимум к получению вы видите до подписи."
            : "Kavrix finds a route through on-chain liquidity on Ethereum, Base, Arbitrum and Polygon. You see the rate, every fee and the minimum you will receive before you sign."}
        </p>

        {/* The widget sits where the two rings interlock: the point of exchange. */}
        <div className="relative isolate mx-auto mt-12 w-full max-w-[460px] text-left sm:mt-16">
          <LinkField busy={activity.busy} intro={intro} />
          <SwapWidget capabilities={capabilities} onActivity={onActivity} intro={intro} />
        </div>
      </section>

      <Anatomy />

      <section aria-labelledby="networks-title" className="mx-auto mt-32 max-w-6xl border-t border-line pt-14">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <h2 id="networks-title" className="k-display text-2xl sm:text-3xl">
              {ru ? "Четыре сети, один интерфейс." : "Four networks, one interface."}
            </h2>
            <p className="mt-3 max-w-[48ch] text-muted">
              {ru
                ? "В каждой сети работают одни и те же проверки. Адреса контрактов токенов опубликованы, чтобы вы могли сверить их с кошельком."
                : "The same checks run on every network. Token contracts are listed so you can compare them with your wallet."}
            </p>
          </div>
          <Link className="text-sm text-accent hover:underline" to="/networks">
            {ru ? "Токены и адреса контрактов" : "Supported tokens and addresses"}
          </Link>
        </div>
        <ul className="mt-10 grid gap-px overflow-hidden rounded-panel bg-line sm:grid-cols-4">
          {SUPPORTED_CHAIN_IDS.map((id) => (
            <li key={id} className="bg-ink px-5 py-6">
              <span className="block font-medium">{CHAINS[id].name}</span>
              <span className="mt-1 block text-sm text-muted">
                {ru ? "Окончательно после " : "Final after "}
                <span className="tabular text-text">{CHAINS[id].confirmations}</span>{" "}
                {ru ? ruPlural(CHAINS[id].confirmations, "подтверждения", "подтверждений", "подтверждений") : "confirmations"}
              </span>
            </li>
          ))}
        </ul>
      </section>
    </>
  );
}
