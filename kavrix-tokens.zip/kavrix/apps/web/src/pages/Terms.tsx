import { Link } from "react-router";
import { DraftBanner, EnglishOnlyNote, Page, operator } from "../layout/Page.tsx";

export default function Terms() {
  return (
    <Page path="/terms">
      <DraftBanner />
      <EnglishOnlyNote />
      {/* lang="en" so screen readers pronounce the English text correctly on the Russian site. */}
      <div className="prose-kavrix" lang="en">
        <p>These terms govern your use of the Kavrix website and interface, operated by {operator()} ("Kavrix", "we").</p>
        <h2>1. What Kavrix provides</h2>
        <p>
          Kavrix is a software interface. It requests swap quotes from third-party aggregators, prepares transactions for your wallet
          and displays their status. Kavrix does not hold, control or transmit your digital assets and is not a party to your swaps.
        </p>
        <h2>2. Third parties</h2>
        <p>
          Swaps are executed by smart contracts operated by third parties (currently the KyberSwap aggregator). Fiat purchases and sales are provided by
          payment providers under their own terms, which you accept separately in their checkout.
        </p>
        <h2>3. Your responsibilities</h2>
        <ul>
          <li>You are responsible for your wallet, its keys and every transaction you sign.</li>
          <li>You must check transaction details in your wallet before signing.</li>
          <li>You must not use Kavrix where doing so is unlawful for you, including under sanctions laws.</li>
        </ul>
        <h2>4. Fees</h2>
        <p>
          Fees are described on the <Link to="/fees">fees page</Link> and shown before each swap. Network fees are paid to the network
          and are not refundable.
        </p>
        <h2>5. Risks</h2>
        <p>
          Digital assets are volatile. Transactions on public blockchains are irreversible. Smart contracts may contain defects. Kavrix
          cannot reverse, cancel or recover transactions.
        </p>
        <h2>6. Availability and restrictions</h2>
        <p>Kavrix may restrict access from certain jurisdictions and may change or suspend features at any time.</p>
        <h2>7. Liability</h2>
        <p>[To be completed with counsel for the operator's jurisdiction.]</p>
        <h2>8. Governing law</h2>
        <p>[To be completed with counsel.]</p>
      </div>
    </Page>
  );
}
