import { Link } from "react-router";
import type { ReactNode } from "react";
import { Page } from "../layout/Page.tsx";
import { useLang } from "../i18n/core.tsx";
import type { L10n } from "../i18n/lang.ts";

type Item = { q: string; a: ReactNode };

const ITEMS: L10n<readonly Item[]> = {
  en: [
    { q: "Do I need an account?", a: "No. Swaps only need a wallet. Card purchases require identity verification with the payment provider, not with Kavrix." },
    { q: "Which wallets work?", a: "Any EVM wallet that supports the network you use, including MetaMask, Rabby, Coinbase Wallet and mobile wallets via WalletConnect." },
    { q: "Why did my swap fail?", a: "Usually the price moved beyond your slippage tolerance before the transaction was mined, or the quote expired. Your tokens stay in your wallet, but the network fee is spent." },
    { q: "What is slippage tolerance?", a: "The largest drop from the quoted amount you accept. The default is 0.5%. A higher value makes the swap more likely to succeed but lets you receive less." },
    { q: "What is price impact?", a: "How much value a trade loses because it moves the price in the pool. Kavrix warns from 1% and asks you to confirm from 5%. A smaller amount usually gets a better rate." },
    { q: "Why do I approve a token first?", a: "ERC-20 tokens need permission before a contract can move them. Kavrix asks your wallet to approve exactly the amount you swap. Native coins like ETH need no approval." },
    { q: "Where does the price come from?", a: "From the KyberSwap aggregator, which routes across decentralized exchanges. Kavrix does not set prices or trade against you." },
    { q: "How much does Kavrix charge?", a: <>See <Link to="/fees">Fees</Link>. Every fee is shown before you sign.</> },
    { q: "Can Kavrix reverse or cancel a swap?", a: "No. Once confirmed on-chain, a swap is final. Before it is mined, only your wallet can try to replace it." },
    { q: "My card payment went through but I have no crypto yet.", a: "Card orders are processed by the provider and can take from minutes to a few hours. Check the order status on the history page and contact the provider if it is stuck." },
    { q: "Is Kavrix available in my country?", a: "Swaps work wherever you can lawfully use your wallet. Card purchases and sales depend on the provider's coverage and are checked during their checkout." },
  ],
  ru: [
    { q: "Нужен ли аккаунт?", a: "Нет. Для обмена нужен только кошелёк. Покупка картой требует проверки личности у платёжного провайдера, а не у Kavrix." },
    { q: "Какие кошельки подходят?", a: "Любой EVM-кошелёк, который поддерживает нужную сеть: MetaMask, Rabby, Coinbase Wallet и мобильные кошельки через WalletConnect." },
    { q: "Почему обмен не прошёл?", a: "Чаще всего цена сдвинулась сильнее допуска до попадания транзакции в блок, или котировка устарела. Токены остаются в кошельке, но комиссия сети потрачена." },
    { q: "Что такое допустимое проскальзывание?", a: "Насколько итог может оказаться меньше котировки, чтобы обмен всё ещё прошёл. По умолчанию 0,5%. Чем выше значение, тем вероятнее обмен пройдёт, но тем меньше вы можете получить." },
    { q: "Что такое потеря цены (price impact)?", a: "Сколько стоимости теряет сделка из-за того, что сама сдвигает цену в пуле. Kavrix предупреждает от 1% и просит подтверждение от 5%. При меньшей сумме курс обычно лучше." },
    { q: "Зачем сначала давать разрешение на токен?", a: "Токенам ERC-20 нужно разрешение, прежде чем контракт сможет их переместить. Kavrix просит разрешение ровно на сумму обмена. Нативным монетам вроде ETH разрешение не нужно." },
    { q: "Откуда берётся цена?", a: "От агрегатора KyberSwap, который ищет маршрут по децентрализованным биржам. Kavrix не устанавливает цены и не торгует против вас." },
    { q: "Сколько берёт Kavrix?", a: <>Смотрите <Link to="/fees">Комиссии</Link>. Все комиссии видны до подписи.</> },
    { q: "Может ли Kavrix отменить или развернуть обмен?", a: "Нет. После подтверждения в блокчейне обмен окончательный. Пока транзакция не попала в блок, заменить её может попробовать только ваш кошелёк." },
    { q: "Оплата картой прошла, а криптовалюты всё нет.", a: "Заказы по карте обрабатывает провайдер — от нескольких минут до нескольких часов. Проверьте статус на странице истории и, если заказ застрял, обратитесь к провайдеру." },
    { q: "Доступен ли Kavrix в моей стране?", a: "Обмен работает везде, где вы законно можете пользоваться своим кошельком. Покупка и продажа картой зависят от покрытия провайдера и проверяются на его странице оплаты." },
  ],
};

export default function Faq() {
  const lang = useLang();
  const ru = lang === "ru";
  return (
    <Page path="/faq">
      <div className="max-w-[68ch] divide-y divide-line border-y border-line">
        {ITEMS[lang].map((item) => (
          <details key={item.q} className="group py-4">
            <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-medium [&::-webkit-details-marker]:hidden">
              {item.q}
              <span aria-hidden className="text-muted transition-transform group-open:rotate-45">+</span>
            </summary>
            <div className="mt-3 text-muted">{item.a}</div>
          </details>
        ))}
      </div>
      <p className="mt-8 text-muted">
        {ru ? "Не нашли ответа? " : "Not answered here? "}
        <Link className="text-accent hover:underline" to="/support">
          {ru ? "Напишите в поддержку" : "Contact support"}
        </Link>
        .
      </p>
    </Page>
  );
}
