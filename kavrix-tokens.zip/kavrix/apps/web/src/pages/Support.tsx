import { Link } from "react-router";
import { Page } from "../layout/Page.tsx";
import { Notice } from "../ui/Notice.tsx";
import { SUPPORT_EMAIL } from "../site.ts";
import { useLang } from "../i18n/core.tsx";

export default function Support() {
  const ru = useLang() === "ru";
  return (
    <Page
      path="/support"
      lead={
        ru
          ? "Мы можем найти обмен по хэшу транзакции. Перемещать, отменять или возвращать средства мы не можем никогда."
          : "We can look up a swap by its transaction hash. We can never move, reverse or recover funds."
      }
    >
      <div className="prose-kavrix">
        {SUPPORT_EMAIL !== undefined ? (
          <p>
            {ru ? "Пишите на " : "Email "}
            <a href={`mailto:${SUPPORT_EMAIL}`}>{SUPPORT_EMAIL}</a>
            {ru ? ". Укажите сеть и хэш транзакции или номер заказа." : ". Include the network and the transaction hash or order id."}
          </p>
        ) : (
          <Notice title={ru ? "Контакт поддержки ещё не настроен" : "Support contact is not configured yet"} />
        )}
        <h2>{ru ? "Никому не сообщайте" : "Never share"}</h2>
        <p>
          {ru
            ? "Seed-фразу и приватный ключ. Сотрудники Kavrix никогда их не попросят, и никто не поможет вам, узнав их."
            : "Your seed phrase or private key. Kavrix staff will never ask for them, and nobody can help you by having them."}
        </p>
        <h2>{ru ? "Заказы по карте" : "Card orders"}</h2>
        <p>
          {ru
            ? "Оплату, проверку личности и выплаты проводит провайдер. Если заказ застрял, напишите провайдеру и укажите номер заказа из его письма-подтверждения."
            : "Payments, identity checks and payouts are handled by the provider. For a stuck order, contact the provider with the order id from its confirmation email."}
        </p>
        <h2>{ru ? "Прежде чем писать" : "Before writing"}</h2>
        {ru ? (
          <p>
            Загляните в <Link to="/faq">вопросы и ответы</Link> и проверьте статус обмена. Обмен со статусом «В обработке» ещё не
            окончательный; «Не прошло» значит, что он откатился в блокчейне, а токены остались в кошельке.
          </p>
        ) : (
          <p>
            Check the <Link to="/faq">FAQ</Link> and the status of your swap. A swap marked “submitted” is not final yet; one marked
            “reverted” failed on-chain and your tokens stayed in your wallet.
          </p>
        )}
      </div>
    </Page>
  );
}
