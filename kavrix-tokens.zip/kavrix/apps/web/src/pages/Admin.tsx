import { useState } from "react";
import { ApiError, describeError } from "../lib/api.ts";
import { useResource } from "../lib/resource.ts";
import { Page } from "../layout/Page.tsx";
import { Button } from "../ui/Button.tsx";
import { Notice } from "../ui/Notice.tsx";
import { LoadingRows } from "../ui/Skeleton.tsx";
import { adminFetch, parseMe, type AdminMe } from "../admin/api.ts";
import { AdminLogin } from "../admin/Login.tsx";
import { Overview } from "../admin/Overview.tsx";
import { RampList, SwapsList } from "../admin/Lists.tsx";
import { SettingsPanel, TokensPanel } from "../admin/Manage.tsx";
import { AuditPanel, HealthPanel } from "../admin/Monitor.tsx";
import { parseTokenIndex } from "../admin/shared.tsx";

const TABS = ["Overview", "Swaps", "Card orders", "Tokens", "Settings", "Health", "Audit log"] as const;
type Tab = (typeof TABS)[number];

function Dashboard({ me, onSignedOut }: { me: AdminMe; onSignedOut: () => void }) {
  const [tab, setTab] = useState<Tab>("Overview");
  const [tokenNonce, setTokenNonce] = useState(0);
  const tokens = useResource(async (signal) => parseTokenIndex(await adminFetch("GET", "/tokens", undefined, signal)), `admin-token-index:${tokenNonce}`);
  const index = tokens.status === "ready" ? tokens.data : null;

  const signOut = async () => {
    await adminFetch("DELETE", "/session").catch(() => undefined);
    onSignedOut();
  };

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-muted">
          {me.email} · <span className="text-text">{me.role}</span> · session ends {new Date(me.expiresAt).toLocaleTimeString()}
        </p>
        <Button variant="secondary" onClick={() => void signOut()}>Sign out</Button>
      </div>
      <div role="tablist" aria-label="Admin sections" className="mb-6 flex gap-1 overflow-x-auto border-b border-line">
        {TABS.map((t) => (
          <button
            key={t}
            role="tab"
            type="button"
            aria-selected={tab === t}
            aria-controls="admin-panel"
            onClick={() => setTab(t)}
            className={`whitespace-nowrap border-b-2 px-3 py-2 text-sm ${tab === t ? "border-accent text-text" : "border-transparent text-muted hover:text-text"}`}
          >
            {t}
          </button>
        ))}
      </div>
      <div id="admin-panel" role="tabpanel" aria-label={tab}>
        {tab === "Overview" ? <Overview tokens={index} /> : null}
        {tab === "Swaps" ? <SwapsList tokens={index} /> : null}
        {tab === "Card orders" ? <RampList /> : null}
        {tab === "Tokens" ? <TokensPanel role={me.role} onChanged={() => setTokenNonce((n) => n + 1)} /> : null}
        {tab === "Settings" ? <SettingsPanel role={me.role} /> : null}
        {tab === "Health" ? <HealthPanel /> : null}
        {tab === "Audit log" ? <AuditPanel /> : null}
      </div>
    </div>
  );
}

export default function Admin() {
  const [nonce, setNonce] = useState(0);
  const [signedIn, setSignedIn] = useState<AdminMe | null>(null);
  const me = useResource(async (signal) => parseMe(await adminFetch("GET", "/me", undefined, signal)), `admin-me:${nonce}`);

  const current = signedIn ?? (me.status === "ready" ? me.data : null);
  const unauthenticated = me.status === "error" && me.error instanceof ApiError && (me.error.status === 401 || me.error.status === 404);

  return (
    <Page path="/admin" heading={current === null ? "Sign in to Kavrix admin" : "Kavrix admin"}>
      {current !== null ? (
        <Dashboard me={current} onSignedOut={() => { setSignedIn(null); setNonce((n) => n + 1); }} />
      ) : me.status === "loading" ? (
        <LoadingRows label="Checking session" rows={2} />
      ) : unauthenticated ? (
        <>
          {me.status === "error" && me.error instanceof ApiError && me.error.status === 404 ? (
            <div className="mb-4 max-w-sm"><Notice title="Admin panel is not enabled on this server">Set ADMIN_ENCRYPTION_KEY and restart the API.</Notice></div>
          ) : null}
          <AdminLogin onSignedIn={setSignedIn} />
        </>
      ) : (
        <Notice tone="danger" title="Admin API unavailable">{me.status === "error" ? describeError(me.error) : null}</Notice>
      )}
    </Page>
  );
}
