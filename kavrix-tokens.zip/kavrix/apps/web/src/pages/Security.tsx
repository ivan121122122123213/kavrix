import { Link } from "react-router";
import { Page } from "../layout/Page.tsx";
import { useLang } from "../i18n/core.tsx";

export default function Security() {
  const ru = useLang() === "ru";
  return (
    <Page
      path="/security"
      lead={ru ? "Что Kavrix может и чего не может делать с вашими средствами, и какие проверки он проводит при каждом обмене." : "What Kavrix can and cannot do with your funds, and the checks it runs on every swap."}
    >
      {ru ? (
        <>
      <div className="prose-kavrix">
        <h2>Kavrix никогда не хранит ваши средства</h2>
        <p>
          Обмен идёт из вашего кошелька напрямую в публичные смарт-контракты. У Kavrix нет ключа, которым можно переместить ваши
          токены; он никогда не просит seed-фразу или приватный ключ и не может отправить транзакцию без вашей подписи. Если кто-то
          от имени Kavrix просит seed-фразу — это мошенник.
        </p>
        <h2>Что здесь централизовано</h2>
        <p>Kavrix не полностью децентрализован, и вам стоит знать, где вы от него зависите:</p>
        <ul>
          <li>Котировки приходят от агрегатора KyberSwap через серверы Kavrix. Если не работает любой из них, получить котировку здесь нельзя.</li>
          <li>Балансы и статусы транзакций читаются через серверы Kavrix с публичных узлов сети.</li>
          <li>Список токенов составляет Kavrix.</li>
          <li>Покупку и продажу картой проводят сторонние провайдеры по своим условиям.</li>
        </ul>
        <h2>Проверки до того, как транзакцию увидит кошелёк</h2>
        <ul>
          <li>Транзакция должна вызывать роутер агрегатора по опубликованному адресу (он одинаков во всех четырёх сетях). Всё остальное отклоняется.</li>
          <li>Kavrix сам расшифровывает данные транзакции и проверяет токены, сумму, что результат уходит на ваш кошелёк, что минимум к получению соответствует вашему допуску и что никакой неизвестный адрес не получает комиссию.</li>
          <li>Браузер повторяет проверку контракта, кошелька и суммы непосредственно перед запросом подписи.</li>
          <li>Для нативных монет отправляемая сумма должна равняться вашей; для остальных токенов — нулю.</li>
          <li>Разрешение на токен выдаётся ровно на сумму обмена, никогда не безлимитное.</li>
          <li>Котировки быстро устаревают, и после этого не принимаются.</li>
        </ul>
        <h2>Что стоит проверить самому</h2>
        <ul>
          <li>Адрес сайта в браузере — официальный домен Kavrix, и соединение идёт по HTTPS.</li>
          <li>Кошелёк показывает ожидаемые сеть, вызываемый контракт и сумму.</li>
          <li>
            Адреса контрактов токенов совпадают с <Link to="/networks">опубликованным списком</Link>.
          </li>
        </ul>
        <h2>Данные</h2>
        <p>
          Kavrix хранит адреса кошельков, детали обменов и хэши транзакций, чтобы показывать историю и статусы. Данные карт и
          банковских счетов он не хранит. В серверные журналы не попадают параметры запросов, например адреса кошельков. Подробнее
          — в <Link to="/privacy">политике конфиденциальности</Link>.
        </p>
        <h2>Аудит и сообщения об уязвимостях</h2>
        <p>
          Независимого аудита безопасности Kavrix пока не проходил. Если вы нашли уязвимость, сообщите через{" "}
          <Link to="/support">страницу поддержки</Link> и не раскрывайте её публично до исправления.
        </p>
      </div>
        </>
      ) : (
        <>
      <div className="prose-kavrix">
        <h2>Kavrix never holds your funds</h2>
        <p>
          Swaps run from your wallet to public smart contracts. Kavrix has no key that can move your tokens, never asks for a seed
          phrase or private key, and cannot send a transaction without your signature. If anyone claiming to be Kavrix asks for your
          seed phrase, it is a scam.
        </p>
        <h2>What is centralized</h2>
        <p>Kavrix is not fully decentralized, and you should know where you depend on it:</p>
        <ul>
          <li>Quotes come from the KyberSwap aggregator through Kavrix servers. If either is down, you cannot get a quote here.</li>
          <li>Balances and transaction status are read through Kavrix servers from public network nodes.</li>
          <li>The token list is curated by Kavrix.</li>
          <li>Card purchases and sales are processed by third-party providers under their own terms.</li>
        </ul>
        <h2>Checks before your wallet sees a transaction</h2>
        <ul>
          <li>The transaction must call the aggregator's router at its published address (the same on all four networks). Anything else is rejected.</li>
          <li>Kavrix decodes the transaction data itself and checks the tokens, the amount, that the output goes to your wallet, that the minimum you receive matches your slippage setting, and that no unknown address receives a fee.</li>
          <li>Your browser repeats the contract, wallet and amount checks right before asking your wallet to sign.</li>
          <li>For native coins the value sent must equal your amount; for other tokens it must be zero.</li>
          <li>Token approvals are for the exact swap amount, never unlimited.</li>
          <li>Quotes expire after a short time and are not accepted afterwards.</li>
        </ul>
        <h2>What you should check yourself</h2>
        <ul>
          <li>The site address in your browser is the official Kavrix domain, served over HTTPS.</li>
          <li>Your wallet shows the network, the contract it calls and the amount you expect.</li>
          <li>
            Token contract addresses match the <Link to="/networks">published list</Link>.
          </li>
        </ul>
        <h2>Data</h2>
        <p>
          Kavrix stores wallet addresses, swap details and transaction hashes to show history and status. It does not store card or
          bank details. Server logs exclude request parameters such as wallet addresses. See the <Link to="/privacy">privacy policy</Link>.
        </p>
        <h2>Audits and reporting</h2>
        <p>
          Kavrix has not undergone an independent security audit yet. If you find a vulnerability, report it through the{" "}
          <Link to="/support">support page</Link> and do not disclose it publicly until it is fixed.
        </p>
      </div>
        </>
      )}
    </Page>
  );
}
