import { Link } from "react-router";
import { Page } from "../layout/Page.tsx";
import { useLang } from "../i18n/core.tsx";

export default function Docs() {
  const ru = useLang() === "ru";
  return (
    <Page path="/docs" lead={ru ? "Как устроен Kavrix и как пользоваться им безопасно." : "How Kavrix is put together and how to use it safely."}>
      {ru ? (
        <>
      <div className="prose-kavrix">
        <h2 id="swap">Как сделать обмен</h2>
        <ol>
          <li>Выберите сеть, токен, который отдаёте, и токен, который хотите получить.</li>
          <li>Введите сумму. Kavrix получит котировку и покажет курс, комиссии, минимум к получению и маршрут.</li>
          <li>Если токену нужно разрешение, выдайте его в кошельке ровно на сумму обмена.</li>
          <li>Проверьте транзакцию в кошельке и подпишите её.</li>
          <li>Следите за страницей статуса, пока сеть не подтвердит обмен.</li>
        </ol>
        <h2 id="statuses">Статусы обмена</h2>
        <ul>
          <li><strong>Не отправлено</strong>: цена получена, но ничего не отправлялось.</li>
          <li><strong>В обработке</strong>: кошелёк отправил транзакцию в сеть, но она ещё не окончательная.</li>
          <li><strong>Подтверждено</strong>: транзакция в блокчейне и набрала нужное число подтверждений. Окончательно.</li>
          <li><strong>Не прошло</strong>: транзакция попала в блок, но откатилась — обычно из-за сдвига цены. Токены остались у вас, комиссия сети потрачена.</li>
          <li><strong>Пока не найдено</strong>: сеть давно не видит транзакцию. Она ещё может попасть в блок позже.</li>
          <li><strong>Отклонено</strong> или <strong>устарело</strong>: вы отказались в кошельке, или котировку не подписали вовремя.</li>
        </ul>
        <h2 id="parties">Кто за что отвечает</h2>
        <ul>
          <li><strong>Вы и ваш кошелёк</strong>: храните ключи и подписываете каждую транзакцию.</li>
          <li><strong>KyberSwap</strong>: находит маршрут и предоставляет контракт-роутер, который его исполняет.</li>
          <li><strong>Kavrix</strong>: запрашивает и проверяет котировки, показывает комиссии и статусы, хранит историю по адресу кошелька.</li>
          <li><strong>Платёжные провайдеры</strong>: проверка личности, оплата картой и выплаты по фиатным заказам.</li>
        </ul>
        <h2 id="fees">Комиссии и лимиты</h2>
        <p>
          Смотрите <Link to="/fees">Комиссии</Link>. Лимиты заказов по карте устанавливает провайдер, они зависят от уровня проверки.
        </p>
      </div>
        </>
      ) : (
        <>
      <div className="prose-kavrix">
        <h2 id="swap">Making a swap</h2>
        <ol>
          <li>Choose the network, the token you pay with and the token you want.</li>
          <li>Enter the amount. Kavrix fetches a quote and shows the rate, fees, minimum received and the route.</li>
          <li>If the token needs approval, approve the exact amount in your wallet.</li>
          <li>Review the transaction in your wallet and sign it.</li>
          <li>Follow the status page until the network confirms the swap.</li>
        </ol>
        <h2 id="statuses">Swap statuses</h2>
        <ul>
          <li><strong>Quoted</strong>: a price was fetched; nothing was sent.</li>
          <li><strong>Submitted</strong>: your wallet broadcast the transaction; it is not final.</li>
          <li><strong>Confirmed</strong>: included on-chain with enough confirmations. Final.</li>
          <li><strong>Reverted</strong>: mined but failed, usually due to price movement. Tokens stay with you; the network fee is spent.</li>
          <li><strong>Not found yet</strong>: the network has not seen the transaction for a while. It can still be mined later.</li>
          <li><strong>Rejected</strong> or <strong>expired</strong>: you declined in the wallet, or the quote timed out before signing.</li>
        </ul>
        <h2 id="parties">Who does what</h2>
        <ul>
          <li><strong>You and your wallet</strong>: hold the keys and sign every transaction.</li>
          <li><strong>KyberSwap</strong>: finds the route and provides the router contract that executes it.</li>
          <li><strong>Kavrix</strong>: requests and checks quotes, shows fees and status, keeps a history linked to your wallet address.</li>
          <li><strong>Payment providers</strong>: identity checks, card payments and payouts for fiat orders.</li>
        </ul>
        <h2 id="fees">Fees and limits</h2>
        <p>
          See <Link to="/fees">Fees</Link>. Card order limits are set by the provider and depend on your verification level.
        </p>
      </div>
        </>
      )}
    </Page>
  );
}
