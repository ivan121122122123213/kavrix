import { DraftBanner, EnglishOnlyNote, Page, operator } from "../layout/Page.tsx";

export default function Privacy() {
  return (
    <Page path="/privacy">
      <DraftBanner />
      <EnglishOnlyNote />
      {/* lang="en" so screen readers pronounce the English text correctly on the Russian site. */}
      <div className="prose-kavrix" lang="en">
        <p>This policy explains what {operator()} processes when you use Kavrix.</p>
        <h2>What we process</h2>
        <ul>
          <li><strong>Wallet address and swap details</strong> (network, tokens, amounts, fees, transaction hash, status) to provide quotes, history and status.</li>
          <li><strong>Card order references</strong> from payment providers (order id, status, amounts, currency). We do not receive card numbers or bank details.</li>
          <li><strong>Technical data</strong>: IP address and request metadata, used for security and rate limiting. Request parameters are excluded from our logs.</li>
        </ul>
        <h2>What we do not do</h2>
        <ul>
          <li>We do not ask for or store seed phrases or private keys.</li>
          <li>We do not load third-party analytics or advertising trackers.</li>
          <li>We do not sell personal data.</li>
        </ul>
        <h2>Public blockchains</h2>
        <p>Transactions you sign are recorded on public blockchains. We cannot delete or alter that data.</p>
        <h2>Payment providers</h2>
        <p>Identity verification and payments are processed by the provider you choose, as an independent controller under its own privacy policy.</p>
        <h2>Retention and your rights</h2>
        <p>[Retention periods, legal bases, and data-subject rights to be completed with counsel for the applicable jurisdictions.]</p>
      </div>
    </Page>
  );
}
