import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { WagmiProvider } from "wagmi";
import { wagmiConfig } from "./wallet/config.ts";
import { flushPendingSubmits } from "./lib/swaps.ts";
import "@fontsource-variable/geologica";
import { App, prefetchPages } from "./App.tsx";
import { I18nProvider } from "./i18n/core.tsx";
import "./styles.css";

const root = document.getElementById("root");
if (root === null) throw new Error("Root element missing");

// Static <head> tags from the build are for crawlers and link previews; React manages <head> from here.
for (const el of document.head.querySelectorAll("[data-prerender]")) el.remove();

// Deliver any transaction hashes a previous session could not report (closed tab, lost connection).
void flushPendingSubmits();
prefetchPages();

const queryClient = new QueryClient({ defaultOptions: { queries: { retry: 1, refetchOnWindowFocus: false } } });

createRoot(root).render(
  <StrictMode>
    <I18nProvider>
      <WagmiProvider config={wagmiConfig}>
        <QueryClientProvider client={queryClient}>
          <App />
        </QueryClientProvider>
      </WagmiProvider>
    </I18nProvider>
  </StrictMode>,
);
