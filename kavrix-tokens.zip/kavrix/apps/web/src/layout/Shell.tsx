import { useEffect, useState } from "react";
import { NavLink, Outlet, useLocation } from "react-router";
import { ROUTES } from "../routes.ts";
import { WalletButton } from "../wallet/WalletButton.tsx";
import { KavrixMark, Wordmark } from "../ui/Mark.tsx";
import { LANGS, useI18n } from "../i18n/core.tsx";

const linkClass = () => "k-nav-link block whitespace-nowrap";

/** RU / EN switch. Two buttons rather than a menu: one tap, and the current language is always visible. */
function LangSwitch() {
  const { lang, setLang } = useI18n();
  return (
    <div role="group" aria-label={lang === "ru" ? "Язык" : "Language"} className="flex rounded-[10px] p-0.5 shadow-[inset_0_0_0_1px_var(--k-line)]">
      {LANGS.map((l) => (
        <button
          key={l}
          type="button"
          lang={l}
          aria-pressed={lang === l}
          onClick={() => setLang(l)}
          className={`h-7 rounded-[8px] px-2 text-xs font-medium uppercase tracking-wide transition-colors ${lang === l ? "bg-white/8 text-text" : "text-faint hover:text-muted"}`}
        >
          {l}
        </button>
      ))}
    </div>
  );
}

function Logo() {
  const { lang } = useI18n();
  return (
    <NavLink to="/" aria-label={lang === "ru" ? "Kavrix, главная" : "Kavrix home"} className="rounded-md">
      <Wordmark />
    </NavLink>
  );
}

export function Shell() {
  const primary = ROUTES.filter((r) => r.nav === "primary");
  const footer = ROUTES.filter((r) => r.nav === "footer");
  const [menuOpen, setMenuOpen] = useState(false);
  const { pathname } = useLocation();
  const { lang } = useI18n();
  const ru = lang === "ru";

  useEffect(() => {
    setMenuOpen(false);
    window.scrollTo({ top: 0 });
  }, [pathname]);

  return (
    <div className="flex min-h-dvh flex-col">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded focus:bg-surface-raised focus:px-3 focus:py-2"
      >
        {ru ? "Перейти к содержимому" : "Skip to content"}
      </a>
      <header className="k-header sticky top-0 z-40">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4">
          <Logo />
          <nav aria-label={ru ? "Основная навигация" : "Primary"} className="hidden gap-1 md:flex">
            {primary.map((r) => (
              <NavLink key={r.path} to={r.path} className={linkClass}>
                {(r.label ?? r.title)[lang]}
              </NavLink>
            ))}
          </nav>
          <div className="ml-auto flex items-center gap-2 md:ml-0">
            <span className="hidden sm:block">
              <LangSwitch />
            </span>
            <WalletButton />
          </div>
          <button
            type="button"
            className="rounded-md p-2 text-muted hover:text-text md:hidden"
            aria-expanded={menuOpen}
            aria-controls="mobile-nav"
            onClick={() => setMenuOpen((o) => !o)}
          >
            <span className="sr-only">{menuOpen ? (ru ? "Закрыть меню" : "Close menu") : ru ? "Открыть меню" : "Open menu"}</span>
            <svg aria-hidden viewBox="0 0 20 20" className="size-5" fill="none" stroke="currentColor" strokeWidth="1.8">
              {menuOpen ? <path d="M5 5l10 10M15 5L5 15" strokeLinecap="round" /> : <path d="M3 6h14M3 10h14M3 14h14" strokeLinecap="round" />}
            </svg>
          </button>
        </div>
        {menuOpen ? (
          <nav id="mobile-nav" aria-label={ru ? "Основная навигация" : "Primary"} className="border-t border-line px-4 py-3 md:hidden">
            {[...primary, ...footer].map((r) => (
              <NavLink key={r.path} to={r.path} className={linkClass}>
                {(r.label ?? r.title)[lang]}
              </NavLink>
            ))}
            <div className="mt-3 border-t border-line pt-3 sm:hidden">
              <LangSwitch />
            </div>
          </nav>
        ) : null}
      </header>
      <main id="main" className="mx-auto w-full max-w-6xl flex-1 overflow-x-clip px-4 py-10 sm:py-14">
        {/* Keyed by route: content settles in on navigation. */}
        <div key={pathname} className="k-page">
          <Outlet />
        </div>
      </main>
      <footer className="border-t border-line">
        <div className="mx-auto flex max-w-6xl flex-col gap-4 px-4 py-8 text-sm text-muted sm:flex-row sm:items-center sm:justify-between">
          <nav aria-label={ru ? "Нижняя навигация" : "Footer"} className="flex flex-wrap gap-x-5 gap-y-2">
            {footer.map((r) => (
              <NavLink key={r.path} to={r.path} className="hover:text-text">
                {(r.label ?? r.title)[lang]}
              </NavLink>
            ))}
          </nav>
          <p className="flex items-center gap-2 text-faint">
            <KavrixMark size={16} />
            {ru
              ? "Kavrix не хранит ваши средства. Обмены выполняют смарт-контракты KyberSwap."
              : "Kavrix does not hold your funds. Swaps are executed by KyberSwap smart contracts."}
          </p>
        </div>
      </footer>
    </div>
  );
}
