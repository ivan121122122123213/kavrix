import type { RouteMeta } from "../routes.ts";
import { SITE_ORIGIN } from "../site.ts";
import { useLang } from "../i18n/core.tsx";

/** React 19 hoists these into <head>. */
export function Seo({ route, pathname }: { route: RouteMeta; pathname: string }) {
  const lang = useLang();
  const title = route.title[lang];
  const description = route.description[lang];
  const canonical = new URL(pathname, SITE_ORIGIN).toString();
  const image = new URL("/og.png", SITE_ORIGIN).toString();
  return (
    <>
      <title>{route.path === "/" ? title : `${title} · Kavrix`}</title>
      <meta name="description" content={description} />
      <meta name="robots" content={route.indexable ? "index,follow" : "noindex,nofollow"} />
      <link rel="canonical" href={canonical} />
      <meta property="og:type" content="website" />
      <meta property="og:site_name" content="Kavrix" />
      <meta property="og:title" content={title} />
      <meta property="og:locale" content={lang === "ru" ? "ru_RU" : "en_US"} />
      <meta property="og:description" content={description} />
      <meta property="og:url" content={canonical} />
      <meta property="og:image" content={image} />
      <meta property="og:image:width" content="1200" />
      <meta property="og:image:height" content="630" />
      <meta property="og:image:alt" content={lang === "ru" ? "Kavrix: обмен токенов без передачи средств" : "Kavrix: swap tokens without handing them over"} />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:image" content={image} />
      <meta name="twitter:title" content={title} />
      <meta name="twitter:description" content={description} />
    </>
  );
}
