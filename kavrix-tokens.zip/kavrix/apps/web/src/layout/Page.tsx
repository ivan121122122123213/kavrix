import type { ReactNode } from "react";
import { useLocation } from "react-router";
import { ROUTES } from "../routes.ts";
import { Seo } from "./Seo.tsx";
import { LEGAL_ENTITY } from "../site.ts";
import { useLang } from "../i18n/core.tsx";

export function routeFor(path: string) {
  const route = ROUTES.find((r) => r.path === path);
  if (route === undefined) throw new Error(`No route metadata for ${path}`);
  return route;
}

export function Page({ path, heading, lead, children }: { path: string; heading?: string; lead?: ReactNode; children: ReactNode }) {
  const route = routeFor(path);
  const { pathname } = useLocation();
  const lang = useLang();
  return (
    <article>
      <Seo route={route} pathname={pathname} />
      <header className="max-w-[68ch]">
        <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">{heading ?? route.title[lang]}</h1>
        {lead !== undefined ? <p className="mt-3 text-lg text-muted">{lead}</p> : null}
      </header>
      <div className="mt-8">{children}</div>
    </article>
  );
}

/** Shown on legal pages until the operator is configured; these texts need legal review before launch. */
export function DraftBanner() {
  const lang = useLang();
  if (LEGAL_ENTITY !== undefined) return null;
  return (
    <p role="note" className="mb-8 max-w-[68ch] rounded-control border border-warning/40 px-4 py-3 text-sm text-warning">
      {lang === "ru"
        ? "Черновик. Текст не проверен юристом, и компания-оператор ещё не указана. Он не является соглашением."
        : "Draft. This text has not been reviewed by a lawyer and the operating company is not yet named. It does not form an agreement."}
    </p>
  );
}

/** Legal documents stay in English until a lawyer approves a Russian version: diverging texts are a legal risk. */
export function EnglishOnlyNote() {
  const lang = useLang();
  if (lang !== "ru") return null;
  return (
    <p role="note" className="mb-8 max-w-[68ch] rounded-control border border-line-strong px-4 py-3 text-sm text-muted">
      Юридический текст пока доступен только на английском. Русская версия появится после проверки юристом, чтобы две версии не расходились.
    </p>
  );
}

export const operator = (lang: "en" | "ru" = "en") => LEGAL_ENTITY ?? (lang === "ru" ? "[название компании-оператора]" : "[Operator legal name]");
