import { apiGet, apiPost } from "./api.ts";
import { parseSwapList, parseSwapStatus } from "../swap/status.ts";

const PENDING_KEY = "kavrix.pendingSubmits.v1";
const MAX_PENDING = 20;

interface PendingSubmit {
  readonly id: string;
  readonly txHash: `0x${string}`;
}

function readPending(): PendingSubmit[] {
  try {
    const raw: unknown = JSON.parse(localStorage.getItem(PENDING_KEY) ?? "[]");
    if (!Array.isArray(raw)) return [];
    return raw.filter(
      (p): p is PendingSubmit =>
        typeof p === "object" && p !== null && typeof p.id === "string" && typeof p.txHash === "string" && /^0x[0-9a-f]{64}$/.test(p.txHash),
    );
  } catch {
    return [];
  }
}

function writePending(list: readonly PendingSubmit[]): void {
  try {
    localStorage.setItem(PENDING_KEY, JSON.stringify(list.slice(-MAX_PENDING)));
  } catch {
    // Storage may be unavailable (private mode); delivery still retries in memory.
  }
}

export async function createSwap(quoteToken: string, idempotencyKey: string): Promise<string> {
  const body = await apiPost("/v1/swaps", { quoteToken }, undefined, { "idempotency-key": idempotencyKey });
  const id = typeof body === "object" && body !== null ? (body as Record<string, unknown>)["id"] : undefined;
  if (typeof id !== "string" || !/^[0-9a-f-]{36}$/i.test(id)) throw new Error("Invalid swap record response");
  return id;
}

/**
 * Reports the broadcast hash. It is queued in localStorage first so it survives a closed tab or a
 * network blip; the queue is flushed on every app start. The server ignores duplicate deliveries.
 */
export async function reportSubmitted(id: string, txHash: `0x${string}`): Promise<boolean> {
  writePending([...readPending().filter((p) => p.id !== id), { id, txHash }]);
  return flushPendingSubmits();
}

export async function flushPendingSubmits(): Promise<boolean> {
  let allDelivered = true;
  for (const p of readPending()) {
    let delivered = false;
    for (let attempt = 0; attempt < 3 && !delivered; attempt++) {
      try {
        await apiPost(`/v1/swaps/${p.id}/submit`, { txHash: p.txHash });
        delivered = true;
      } catch (err) {
        // 404/409 are final answers from the server; keep retrying only transport/server errors.
        const status = (err as { status?: unknown }).status;
        if (typeof status === "number" && status >= 400 && status < 500) delivered = true;
        else await new Promise((r) => setTimeout(r, 500 * 2 ** attempt));
      }
    }
    if (delivered) writePending(readPending().filter((x) => x.id !== p.id));
    else allDelivered = false;
  }
  return allDelivered;
}

export function reportRejected(id: string): void {
  void apiPost(`/v1/swaps/${id}/reject`, {}).catch(() => undefined);
}

export async function fetchSwap(id: string, signal?: AbortSignal) {
  return parseSwapStatus(await apiGet(`/v1/swaps/${encodeURIComponent(id)}`, signal), id);
}

export async function fetchHistory(wallet: string, cursor: string | null, signal?: AbortSignal) {
  const q = new URLSearchParams({ wallet, limit: "20" });
  if (cursor !== null) q.set("before", cursor);
  return parseSwapList(await apiGet(`/v1/swaps?${q.toString()}`, signal));
}
