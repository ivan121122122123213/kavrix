import { formatUnits } from "@kavrix/shared";

function group(whole: string): string {
  return whole.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

/**
 * Display formatting for base-unit amounts. Truncates (never rounds up) so the UI never
 * shows more than the user will receive.
 */
export function formatTokenAmount(value: bigint, decimals: number, maxFraction = 6): string {
  const plain = formatUnits(value, decimals);
  const negative = plain.startsWith("-");
  const [whole = "0", fraction = ""] = (negative ? plain.slice(1) : plain).split(".");
  const cut = fraction.slice(0, maxFraction).replace(/0+$/, "");
  if (whole === "0" && cut.length === 0 && value !== 0n) {
    return `${negative ? ">-" : "<"}0.${"0".repeat(Math.max(maxFraction - 1, 0))}1`;
  }
  return `${negative ? "-" : ""}${group(whole)}${cut.length > 0 ? `.${cut}` : ""}`;
}

export function formatBps(bps: number): string {
  const percent = bps / 100;
  return `${Number.isInteger(percent) ? percent.toFixed(0) : percent.toFixed(2).replace(/0$/, "")}%`;
}

export function shortAddress(address: string): string {
  return address.length > 12 ? `${address.slice(0, 6)}…${address.slice(-4)}` : address;
}

/** Accepts "1.5", "1,5" and strips grouping spaces while typing; does not validate precision. */
export function normalizeAmountInput(raw: string): string {
  const cleaned = raw.replace(/\s/g, "").replace(",", ".");
  return /^\d*\.?\d*$/.test(cleaned) ? cleaned : raw;
}
