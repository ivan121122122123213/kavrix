import { isSupportedChainId, RAMP_STATUSES, type RampStatus, type SupportedChainId } from "@kavrix/shared";
import { apiGet } from "./api.ts";

export interface RampOrderView {
  readonly id: string;
  readonly provider: "moonpay" | "transak";
  readonly direction: "buy" | "sell";
  readonly chainId: SupportedChainId;
  readonly cryptoCurrency: string;
  readonly fiatCurrency: string;
  readonly fiatAmount: string | null;
  readonly cryptoAmount: string | null;
  readonly status: RampStatus;
  readonly createdAt: string;
}

function fail(): never {
  throw new Error("Invalid order response");
}

const DEC = /^\d{1,30}(\.\d{1,18})?$/;

export function parseRampOrder(v: unknown): RampOrderView {
  const o = typeof v === "object" && v !== null && !Array.isArray(v) ? (v as Record<string, unknown>) : fail();
  const { id, provider, direction, chainId, cryptoCurrency, fiatCurrency, fiatAmount, cryptoAmount, status, createdAt } = o;
  if (typeof id !== "string" || !/^[0-9a-f-]{36}$/i.test(id)) fail();
  if (provider !== "moonpay" && provider !== "transak") fail();
  if (direction !== "buy" && direction !== "sell") fail();
  if (!isSupportedChainId(chainId)) fail();
  if (typeof cryptoCurrency !== "string" || !/^[A-Za-z0-9.]{1,16}$/.test(cryptoCurrency)) fail();
  if (typeof fiatCurrency !== "string" || !/^[A-Z]{3}$/.test(fiatCurrency)) fail();
  if (!(fiatAmount === null || (typeof fiatAmount === "string" && DEC.test(fiatAmount)))) fail();
  if (!(cryptoAmount === null || (typeof cryptoAmount === "string" && DEC.test(cryptoAmount)))) fail();
  if (typeof status !== "string" || !(RAMP_STATUSES as readonly string[]).includes(status)) fail();
  if (typeof createdAt !== "string" || createdAt.length > 40) fail();
  return { id, provider, direction, chainId, cryptoCurrency, fiatCurrency, fiatAmount, cryptoAmount, status: status as RampStatus, createdAt };
}

export async function fetchRampOrders(wallet: string, signal?: AbortSignal): Promise<RampOrderView[]> {
  const body = await apiGet(`/v1/ramp/orders?wallet=${encodeURIComponent(wallet)}`, signal);
  const orders = typeof body === "object" && body !== null ? (body as Record<string, unknown>)["orders"] : undefined;
  if (!Array.isArray(orders) || orders.length > 50) fail();
  return orders.map(parseRampOrder);
}

export async function fetchRampOrder(id: string, signal?: AbortSignal): Promise<RampOrderView> {
  return parseRampOrder(await apiGet(`/v1/ramp/orders/${encodeURIComponent(id)}`, signal));
}

export const RAMP_STATUS_LABEL_RU: Record<RampStatus, string> = {
  created: "Оплата открыта",
  pending: "В обработке",
  completed: "Выполнен",
  failed: "Ошибка",
  cancelled: "Отменён",
  expired: "Истёк",
  refunded: "Возврат",
};

export const RAMP_STATUS_LABEL: Record<RampStatus, string> = {
  created: "Checkout opened",
  pending: "In progress",
  completed: "Completed",
  failed: "Failed",
  cancelled: "Cancelled",
  expired: "Expired",
  refunded: "Refunded",
};
