import { isSupportedChainId, type SupportedChainId } from "@kavrix/shared";
import type { Lang } from "../i18n/lang.ts";

export interface Problem {
  readonly code: string;
  readonly title: string;
  readonly detail?: string;
  readonly requestId?: string;
}

export class ApiError extends Error {
  override readonly name = "ApiError";
  readonly status: number;
  readonly problem: Problem | undefined;

  constructor(status: number, problem: Problem | undefined, message?: string) {
    super(message ?? problem?.title ?? `Request failed with status ${status}`);
    this.status = status;
    this.problem = problem;
  }
}

type Json = Record<string, unknown>;
const isObject = (v: unknown): v is Json => typeof v === "object" && v !== null && !Array.isArray(v);
const str = (o: Json, k: string): string | undefined => (typeof o[k] === "string" ? (o[k] as string) : undefined);
const num = (o: Json, k: string): number | undefined => (typeof o[k] === "number" ? (o[k] as number) : undefined);
const bool = (o: Json, k: string): boolean | undefined => (typeof o[k] === "boolean" ? (o[k] as boolean) : undefined);

function isProblem(value: unknown): value is Problem {
  return isObject(value) && str(value, "code") !== undefined && str(value, "title") !== undefined;
}

function invalid(what: string): never {
  throw new ApiError(502, undefined, `The server returned an invalid ${what} response`);
}

async function request(path: `/${string}`, init: RequestInit, signal?: AbortSignal): Promise<unknown> {
  const options: RequestInit = { ...init, credentials: "same-origin" };
  if (signal !== undefined) options.signal = signal;
  let res: Response;
  try {
    res = await fetch(`/api${path}`, options);
  } catch (err) {
    if (err instanceof DOMException && err.name === "AbortError") throw err;
    throw new ApiError(0, undefined, "Kavrix servers are unreachable. Check your connection and retry.");
  }
  const body: unknown = await res.json().catch(() => undefined);
  if (!res.ok) throw new ApiError(res.status, isProblem(body) ? body : undefined);
  return body;
}

export function apiGet(path: `/${string}`, signal?: AbortSignal): Promise<unknown> {
  return request(path, { method: "GET", headers: { accept: "application/json" } }, signal);
}

export function apiPost(path: `/${string}`, body: unknown, signal?: AbortSignal, headers: Record<string, string> = {}): Promise<unknown> {
  return request(
    path,
    { method: "POST", headers: { accept: "application/json", "content-type": "application/json", ...headers }, body: JSON.stringify(body) },
    signal,
  );
}

export interface Capabilities {
  readonly swap: {
    readonly quotes: boolean;
    /** True when the operator paused swaps (kill switch). */
    readonly paused: boolean;
    readonly platformFeeBps: number;
    readonly platformFeeBpsByChain: Readonly<Partial<Record<SupportedChainId, number>>>;
    readonly quoteTtlSeconds: number;
  };
  readonly ramp: { readonly moonpay: boolean; readonly transak: boolean; readonly buyLimits: { readonly min: number; readonly max: number } | null };
}

/** Effective platform fee for a chain as reported by the server. */
export function feeBpsFor(c: Capabilities, chainId: SupportedChainId): number {
  return c.swap.platformFeeBpsByChain[chainId] ?? c.swap.platformFeeBps;
}

export function parseCapabilities(body: unknown): Capabilities {
  if (!isObject(body) || !isObject(body["swap"]) || !isObject(body["ramp"])) invalid("capabilities");
  const swap = body["swap"] as Json;
  const ramp = body["ramp"] as Json;
  const quotes = bool(swap, "quotes");
  const platformFeeBps = num(swap, "platformFeeBps");
  const quoteTtlSeconds = num(swap, "quoteTtlSeconds");
  const moonpay = bool(ramp, "moonpay");
  const transak = bool(ramp, "transak");
  if (
    quotes === undefined ||
    platformFeeBps === undefined ||
    !Number.isInteger(platformFeeBps) ||
    platformFeeBps < 0 ||
    quoteTtlSeconds === undefined ||
    moonpay === undefined ||
    transak === undefined
  ) {
    invalid("capabilities");
  }
  const byChainRaw = swap["platformFeeBpsByChain"];
  const platformFeeBpsByChain: Partial<Record<SupportedChainId, number>> = {};
  if (isObject(byChainRaw)) {
    for (const [k, v] of Object.entries(byChainRaw)) {
      const id = Number(k);
      if (isSupportedChainId(id) && typeof v === "number" && Number.isInteger(v) && v >= 0 && v <= 300) platformFeeBpsByChain[id] = v;
    }
  }
  const limitsRaw = ramp["buyLimits"];
  const buyLimits =
    isObject(limitsRaw) && typeof limitsRaw["min"] === "number" && typeof limitsRaw["max"] === "number"
      ? { min: limitsRaw["min"], max: limitsRaw["max"] }
      : null;
  return {
    swap: { quotes, paused: bool(swap, "paused") === true, platformFeeBps, platformFeeBpsByChain, quoteTtlSeconds },
    ramp: { moonpay, transak, buyLimits },
  };
}

export interface ChainView {
  readonly id: SupportedChainId;
  readonly name: string;
  readonly explorerUrl: string;
  readonly confirmations: number;
  readonly nativeSymbol: string;
}

export function parseChains(body: unknown): ChainView[] {
  if (!isObject(body) || !Array.isArray(body["chains"])) invalid("chains");
  return (body["chains"] as unknown[]).map((c) => {
    if (!isObject(c) || !isObject(c["nativeCurrency"])) invalid("chains");
    const id = num(c, "id");
    const name = str(c, "name");
    const explorerUrl = str(c, "explorerUrl");
    const confirmations = num(c, "confirmations");
    const nativeSymbol = str(c["nativeCurrency"] as Json, "symbol");
    if (!isSupportedChainId(id) || !name || !explorerUrl?.startsWith("https://") || confirmations === undefined || !nativeSymbol) {
      invalid("chains");
    }
    return { id, name, explorerUrl, confirmations, nativeSymbol };
  });
}

export interface TokenOption {
  readonly chainId: SupportedChainId;
  readonly address: `0x${string}`;
  readonly symbol: string;
  readonly name: string;
  readonly decimals: number;
  readonly native: boolean;
  /** Operator-supplied artwork (same-origin /tokens/… or https); rendered only after validation. */
  readonly logoUrl: string | null;
  /** "high" = long-tail token (memecoins etc.): shown with a warning. Unknown values are treated as high. */
  readonly risk: "standard" | "high";
  readonly rank: number | null;
}

export function parseTokens(body: unknown, expectedChain: SupportedChainId): TokenOption[] {
  if (!isObject(body) || body["chainId"] !== expectedChain || !Array.isArray(body["tokens"])) invalid("tokens");
  return (body["tokens"] as unknown[]).map((t) => {
    if (!isObject(t)) invalid("tokens");
    const address = str(t, "address");
    const symbol = str(t, "symbol");
    const name = str(t, "name");
    const decimals = num(t, "decimals");
    const native = bool(t, "native");
    if (
      num(t, "chainId") !== expectedChain ||
      address === undefined ||
      !/^0x[0-9a-fA-F]{40}$/.test(address) ||
      !symbol ||
      !name ||
      decimals === undefined ||
      !Number.isInteger(decimals) ||
      decimals < 0 ||
      decimals > 36 ||
      native === undefined
    ) {
      invalid("tokens");
    }
    const logo = t["logoUrl"];
    const logoUrl = typeof logo === "string" && logo.length <= 512 ? logo : null;
    // Fail safe: anything other than an explicit "standard" from the server is shown as high risk.
    const risk = t["risk"] === "standard" || native ? "standard" : "high";
    const rankRaw = t["rank"];
    const rank = typeof rankRaw === "number" && Number.isInteger(rankRaw) && rankRaw > 0 ? rankRaw : null;
    return { chainId: expectedChain, address: address.toLowerCase() as `0x${string}`, symbol, name, decimals, native, logoUrl, risk, rank };
  });
}

/** Human message for any error surfaced in the UI. Never echoes raw server internals. */
/** Russian text for problem codes the API returns; other codes fall back to the server's English detail. */
const PROBLEM_RU: Readonly<Record<string, string>> = {
  UNSUPPORTED_CHAIN: "Эта сеть не поддерживается.",
  SAME_TOKEN: "Выберите два разных токена.",
  TOKEN_NOT_LISTED: "Одного из токенов нет в списке Kavrix для этой сети.",
  QUOTES_BUSY: "Сейчас слишком много запросов котировок. Повторите через пару секунд.",
  PROVIDER_UNAVAILABLE: "Провайдер цен не отвечает. Котировка не получена.",
  NO_ROUTE: "Для этой пары и суммы не нашлось маршрута ликвидности.",
  QUOTE_REJECTED: "Котировка провайдера не прошла проверки безопасности Kavrix и отброшена.",
  QUOTE_UNAVAILABLE: "Провайдер не смог дать котировку для этой пары или суммы.",
  PROVIDER_BAD_RESPONSE: "Провайдер цен вернул некорректный ответ.",
  SWAPS_PAUSED: "Обмены временно приостановлены оператором. Ваши средства в безопасности.",
  QUOTE_EXPIRED: "Котировка устарела. Получите новую.",
  QUOTE_INVALID: "Котировка недействительна. Получите новую.",
  HASH_CONFLICT: "Для этого обмена уже записана другая транзакция.",
  WRONG_STATE: "Этот обмен уже нельзя отправить. Начните новый.",
  NOT_FOUND: "Ничего не найдено.",
  DATABASE_UNAVAILABLE: "Сервис временно недоступен. Ничего не изменено — повторите чуть позже.",
  ASSET_NOT_SUPPORTED: "Этот актив недоступен для оплаты картой.",
  INVALID_AMOUNT: "Проверьте сумму.",
  AMOUNT_OUT_OF_RANGE: "Сумма вне допустимого диапазона для одного заказа.",
  PROVIDER_PAUSED: "Этот провайдер временно приостановлен. Выберите другого или попробуйте позже.",
  PROVIDER_DISABLED: "Этот провайдер не подключён.",
  RPC_UNAVAILABLE: "Узел сети не отвечает. Повторите чуть позже.",
};

export function describeError(error: unknown, lang: Lang = "en"): string {
  const ru = lang === "ru";
  if (error instanceof ApiError) {
    const code = error.problem?.code;
    if (ru && code !== undefined && Object.hasOwn(PROBLEM_RU, code)) return PROBLEM_RU[code] as string;
    if (error.status === 0) return ru ? "Нет связи с Kavrix. Проверьте интернет и повторите." : error.message;
    if (error.status === 429) return ru ? "Слишком много запросов. Подождите немного и повторите." : "Too many requests. Wait a moment and try again.";
    if (error.status >= 500) return ru ? "У Kavrix временные неполадки. Повторите через минуту." : "Kavrix is having trouble right now. Try again in a minute.";
    return error.problem?.detail ?? error.problem?.title ?? error.message;
  }
  return ru ? "Что-то пошло не так. Попробуйте ещё раз." : "Something went wrong. Try again.";
}
