import type { SupportedChainId } from "@kavrix/shared";
import { apiGet, parseCapabilities, parseChains, parseTokens, type Capabilities, type ChainView, type TokenOption } from "./api.ts";
import { useResource } from "./resource.ts";

export function useCapabilities() {
  return useResource<Capabilities>(async (signal) => parseCapabilities(await apiGet("/v1/capabilities", signal)), "capabilities");
}

export function useChains() {
  return useResource<ChainView[]>(async (signal) => parseChains(await apiGet("/v1/chains", signal)), "chains");
}

export function useTokens(chainId: SupportedChainId) {
  return useResource<TokenOption[]>(
    async (signal) => parseTokens(await apiGet(`/v1/tokens?chainId=${chainId}`, signal), chainId),
    `tokens:${chainId}`,
  );
}
