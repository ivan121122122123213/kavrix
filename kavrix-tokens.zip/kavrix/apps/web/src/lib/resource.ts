import { useCallback, useEffect, useRef, useState } from "react";

export type Resource<T> =
  | { readonly status: "loading" }
  | { readonly status: "error"; readonly error: unknown }
  | { readonly status: "ready"; readonly data: T };

/**
 * Loads data with cancellation on unmount/key change. A `retry` with the same key keeps showing
 * the last good data while refreshing (used for polling); a new key starts from "loading".
 * `key` must change whenever the inputs of `load` change.
 */
export function useResource<T>(load: (signal: AbortSignal) => Promise<T>, key: string): Resource<T> & { retry: () => void } {
  const [state, setState] = useState<Resource<T>>({ status: "loading" });
  const [attempt, setAttempt] = useState(0);
  const lastKey = useRef<string | null>(null);

  useEffect(() => {
    const controller = new AbortController();
    const keyChanged = lastKey.current !== key;
    lastKey.current = key;
    setState((prev) => (keyChanged || prev.status !== "ready" ? { status: "loading" } : prev));
    load(controller.signal).then(
      (data) => {
        if (!controller.signal.aborted) setState({ status: "ready", data });
      },
      (error: unknown) => {
        if (!controller.signal.aborted) setState({ status: "error", error });
      },
    );
    return () => controller.abort();
    // `load` is intentionally excluded: callers encode its inputs in `key`.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, attempt]);

  const retry = useCallback(() => setAttempt((n) => n + 1), []);
  return { ...state, retry };
}
