import type { L10n } from "./i18n/lang.ts";

/** Single source for navigation, <title>/<meta>, canonical URLs and sitemap generation. */
export interface RouteMeta {
  readonly path: string;
  readonly title: L10n;
  readonly description: L10n;
  readonly nav?: "primary" | "footer";
  /** Short label for navigation. */
  readonly label?: L10n;
  readonly indexable: boolean;
}

export const ROUTES: readonly RouteMeta[] = [
  {
    path: "/",
    title: { en: "Kavrix — non-custodial token swaps on Ethereum, Base, Arbitrum and Polygon", ru: "Kavrix — обмен токенов без передачи средств: Ethereum, Base, Arbitrum и Polygon" },
    description: { en: "Non-custodial token swaps with live aggregator quotes and every fee shown before you sign.", ru: "Обмен токенов прямо из вашего кошелька: живые котировки агрегатора и все комиссии до подписи." },
    indexable: true,
  },
  {
    path: "/buy-sell",
    title: { en: "Buy and sell crypto", ru: "Купить и продать криптовалюту" },
    description: { en: "Buy or sell crypto through licensed payment providers. Availability depends on your country.", ru: "Покупка и продажа криптовалюты через лицензированных платёжных провайдеров. Доступность зависит от страны." },
    nav: "primary",
    label: { en: "Buy / Sell", ru: "Купить / Продать" },
    indexable: true,
  },
  {
    path: "/history",
    title: { en: "Transaction history", ru: "История операций" },
    description: { en: "Your swaps and orders, with on-chain status.", ru: "Ваши обмены и заказы со статусом в блокчейне." },
    nav: "primary",
    label: { en: "History", ru: "История" },
    indexable: false,
  },
  {
    path: "/networks",
    title: { en: "Supported networks and tokens", ru: "Сети и токены" },
    description: { en: "Networks and token contracts Kavrix supports.", ru: "Сети и контракты токенов, которые поддерживает Kavrix." },
    nav: "primary",
    label: { en: "Networks", ru: "Сети" },
    indexable: true,
  },
  {
    path: "/fees",
    title: { en: "Fees", ru: "Комиссии" },
    description: { en: "How platform, network and provider fees are calculated.", ru: "Как считаются комиссии платформы, сети и провайдеров." },
    nav: "primary",
    label: { en: "Fees", ru: "Комиссии" },
    indexable: true,
  },
  {
    path: "/security",
    title: { en: "Security", ru: "Безопасность" },
    description: { en: "How Kavrix protects your wallet and data.", ru: "Как Kavrix защищает ваш кошелёк и данные." },
    nav: "footer",
    label: { en: "Security", ru: "Безопасность" },
    indexable: true,
  },
  {
    path: "/faq",
    title: { en: "FAQ", ru: "Вопросы и ответы" },
    description: { en: "Answers to common questions about swaps, fees and providers.", ru: "Ответы на частые вопросы об обмене, комиссиях и провайдерах." },
    nav: "footer",
    label: { en: "FAQ", ru: "Вопросы" },
    indexable: true,
  },
  {
    path: "/docs",
    title: { en: "Documentation", ru: "Документация" },
    description: { en: "How Kavrix works and how to use it.", ru: "Как устроен Kavrix и как им пользоваться." },
    nav: "footer",
    label: { en: "Docs", ru: "Документация" },
    indexable: true,
  },
  {
    path: "/about",
    title: { en: "About", ru: "О проекте" },
    description: { en: "Who operates Kavrix and what it does.", ru: "Кто управляет Kavrix и что он делает." },
    nav: "footer",
    label: { en: "About", ru: "О проекте" },
    indexable: true,
  },
  {
    path: "/terms",
    title: { en: "Terms of service", ru: "Условия использования" },
    description: { en: "Terms that govern use of Kavrix.", ru: "Условия, на которых предоставляется Kavrix." },
    nav: "footer",
    label: { en: "Terms", ru: "Условия" },
    indexable: true,
  },
  {
    path: "/privacy",
    title: { en: "Privacy policy", ru: "Политика конфиденциальности" },
    description: { en: "What data Kavrix processes and why.", ru: "Какие данные обрабатывает Kavrix и зачем." },
    nav: "footer",
    label: { en: "Privacy", ru: "Конфиденциальность" },
    indexable: true,
  },
  {
    path: "/support",
    title: { en: "Support", ru: "Поддержка" },
    description: { en: "Get help with a swap or an order.", ru: "Помощь с обменом или заказом." },
    nav: "footer",
    label: { en: "Support", ru: "Поддержка" },
    indexable: true,
  },
  {
    path: "/tx/:id",
    title: { en: "Transaction status", ru: "Статус операции" },
    description: { en: "Live status of a swap.", ru: "Текущий статус обмена." },
    indexable: false,
  },
  { path: "/admin", title: { en: "Admin", ru: "Админ-панель" }, description: { en: "Kavrix administration.", ru: "Управление Kavrix." }, indexable: false },
];
