import type React from "react";
import { createBrowserRouter, RouterProvider, type RouteObject } from "react-router";
import { Shell } from "./layout/Shell.tsx";
import Home from "./pages/Home.tsx";

/*
 * Pages load through the router's `lazy` option rather than <Suspense>: the router fetches the
 * chunk *before* committing the navigation, so the current page stays on screen until the next one
 * is ready. No skeleton flashes between pages, and the enter animation always plays on real content.
 */
const loaders: Record<string, () => Promise<{ default: React.ComponentType }>> = {
  "/buy-sell": () => import("./pages/BuySell.tsx"),
  "/history": () => import("./pages/History.tsx"),
  "/networks": () => import("./pages/Networks.tsx"),
  "/fees": () => import("./pages/Fees.tsx"),
  "/security": () => import("./pages/Security.tsx"),
  "/faq": () => import("./pages/Faq.tsx"),
  "/docs": () => import("./pages/Docs.tsx"),
  "/about": () => import("./pages/About.tsx"),
  "/terms": () => import("./pages/Terms.tsx"),
  "/privacy": () => import("./pages/Privacy.tsx"),
  "/support": () => import("./pages/Support.tsx"),
  "/tx/:id": () => import("./pages/TxStatus.tsx"),
  "/admin": () => import("./pages/Admin.tsx"),
};
const notFound = () => import("./pages/NotFound.tsx");

const lazyRoute = (load: () => Promise<{ default: React.ComponentType }>) => async () => ({ Component: (await load()).default });

const routes: RouteObject[] = [
  {
    element: <Shell />,
    children: [
      { path: "/", element: <Home /> },
      ...Object.entries(loaders).map(([path, load]) => ({ path, lazy: lazyRoute(load) })),
      { path: "*", lazy: lazyRoute(notFound) },
    ],
  },
];

const router = createBrowserRouter(routes);

/** Warm every page chunk once the browser is idle, so later navigations are instant. */
export function prefetchPages(): void {
  const run = () => {
    for (const load of [...Object.values(loaders), notFound]) void load().catch(() => undefined);
  };
  if ("requestIdleCallback" in window) window.requestIdleCallback(run, { timeout: 4000 });
  else setTimeout(run, 2500);
}

export function App() {
  return <RouterProvider router={router} />;
}
