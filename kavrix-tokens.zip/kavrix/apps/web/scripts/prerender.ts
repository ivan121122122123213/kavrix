import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname } from "node:path";
import { ROUTES } from "../src/routes.ts";
import { headFor, injectHead, outputPath } from "./prerender-head.ts";

const lang = process.env["VITE_DEFAULT_LANG"] === "en" ? "en" : "ru";

/** Writes one HTML file per static route after `vite build`, each with its own <head>. */
const origin = process.env["VITE_SITE_ORIGIN"];
if (origin === undefined || !origin.startsWith("https://")) {
  process.stderr.write("prerender: VITE_SITE_ORIGIN is not an https origin, skipping (required for production images)\n");
  process.exit(0);
}
const dist = new URL("../dist/", import.meta.url);
const template = readFileSync(new URL("index.html", dist), "utf8");
let count = 0;
for (const route of ROUTES) {
  if (route.path.includes(":")) continue;
  const file = new URL(outputPath(route.path), dist);
  mkdirSync(dirname(file.pathname), { recursive: true });
  writeFileSync(file, injectHead(template, headFor(route, origin, lang), lang));
  count++;
}
// The SPA fallback (unknown paths, /tx/:id) keeps neutral, non-indexable tags.
writeFileSync(
  new URL("200.html", dist),
  injectHead(template, headFor({ path: "/", title: { en: "Kavrix", ru: "Kavrix" }, description: { en: "Non-custodial token swaps.", ru: "Обмен токенов без передачи средств." }, indexable: false }, origin, lang), lang),
);
process.stdout.write(`prerender: ${count} routes\n`);
