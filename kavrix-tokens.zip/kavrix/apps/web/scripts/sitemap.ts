import { writeFileSync } from "node:fs";
import { ROUTES } from "../src/routes.ts";

/** Writes dist/sitemap.xml from the route table after `vite build`. */
const origin = process.env["VITE_SITE_ORIGIN"];
if (origin === undefined || !origin.startsWith("https://")) {
  process.stderr.write("sitemap: VITE_SITE_ORIGIN is not an https origin, skipping (required for production images)\n");
  process.exit(0);
}
const urls = ROUTES.filter((r) => r.indexable && !r.path.includes(":"))
  .map((r) => `  <url><loc>${new URL(r.path, origin).toString()}</loc></url>`)
  .join("\n");
writeFileSync(
  new URL("../dist/sitemap.xml", import.meta.url),
  `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`,
);
process.stdout.write("sitemap: written\n");
