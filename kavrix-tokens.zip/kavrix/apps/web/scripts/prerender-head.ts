import type { RouteMeta } from "../src/routes.ts";
import type { Lang } from "../src/i18n/lang.ts";

/**
 * Static <head> tags per route, written into the built HTML so link previews (Telegram, WhatsApp, X)
 * and crawlers that do not run JavaScript see the real title, description and image.
 * Tagged with data-prerender; the app removes them at boot and manages <head> itself from then on.
 */
const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

export function headFor(route: RouteMeta, origin: string, lang: Lang): string {
  const url = new URL(route.path, origin).toString();
  const title = route.path === "/" ? route.title[lang] : `${route.title[lang]} · Kavrix`;
  const description = route.description[lang];
  const image = new URL("/og.png", origin).toString();
  const tags = [
    `<title data-prerender>${esc(title)}</title>`,
    `<meta data-prerender name="description" content="${esc(description)}">`,
    `<link data-prerender rel="canonical" href="${esc(url)}">`,
    `<meta data-prerender property="og:type" content="website">`,
    `<meta data-prerender property="og:site_name" content="Kavrix">`,
    `<meta data-prerender property="og:title" content="${esc(title)}">`,
    `<meta data-prerender property="og:description" content="${esc(description)}">`,
    `<meta data-prerender property="og:locale" content="${lang === "ru" ? "ru_RU" : "en_US"}">`,
    `<meta data-prerender property="og:url" content="${esc(url)}">`,
    `<meta data-prerender property="og:image" content="${esc(image)}">`,
    `<meta data-prerender property="og:image:width" content="1200">`,
    `<meta data-prerender property="og:image:height" content="630">`,
    `<meta data-prerender name="twitter:card" content="summary_large_image">`,
    `<meta data-prerender name="twitter:image" content="${esc(image)}">`,
  ];
  if (!route.indexable) tags.push(`<meta data-prerender name="robots" content="noindex">`);
  return tags.join("\n    ");
}

/** Replaces the template's placeholder <title> with the route's tags. Throws if the template changed shape. */
export function injectHead(html: string, head: string, lang: Lang): string {
  if (!html.includes("<title>Kavrix</title>")) throw new Error("index.html no longer has the <title>Kavrix</title> placeholder");
  if (!/<html lang="[a-z]{2}">/.test(html)) throw new Error("index.html no longer has a <html lang> attribute");
  return html.replace("<title>Kavrix</title>", head).replace(/<html lang="[a-z]{2}">/, `<html lang="${lang}">`);
}

/** dist-relative output file for a route ("/" -> index.html, "/fees" -> fees/index.html). */
export function outputPath(path: string): string {
  return path === "/" ? "index.html" : `${path.replace(/^\//, "")}/index.html`;
}
