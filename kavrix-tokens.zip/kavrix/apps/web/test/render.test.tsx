import { describe, expect, it } from "vitest";
import { renderToString } from "react-dom/server";
import { MemoryRouter, Route, Routes } from "react-router";
import type { ComponentType, ReactNode } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { WagmiProvider } from "wagmi";
import { wagmiConfig } from "../src/wallet/config.ts";
import { Shell } from "../src/layout/Shell.tsx";
import { QuoteSummary } from "../src/swap/QuoteSummary.tsx";
import { SwapWidget } from "../src/swap/SwapWidget.tsx";
import type { Capabilities } from "../src/lib/api.ts";

const pages = import.meta.glob<{ default: ComponentType }>("../src/pages/*.tsx", { eager: true });
const PATH: Record<string, string> = {
  Home: "/", BuySell: "/buy-sell", History: "/history", Networks: "/networks", Fees: "/fees", Security: "/security",
  Faq: "/faq", Docs: "/docs", About: "/about", Terms: "/terms", Privacy: "/privacy", Support: "/support",
  TxStatus: "/tx/:id", Admin: "/admin", NotFound: "*",
};

function Providers({ children }: { children: ReactNode }) {
  return (
    <WagmiProvider config={wagmiConfig}>
      <QueryClientProvider client={new QueryClient()}>{children}</QueryClientProvider>
    </WagmiProvider>
  );
}

function render(path: string, url: string, Page: ComponentType): string {
  return renderToString(
    <Providers>
      <MemoryRouter initialEntries={[url]}>
        <Routes>
          <Route path={path} element={<Page />} />
        </Routes>
      </MemoryRouter>
    </Providers>,
  );
}

describe("every page server-renders with a heading and title", () => {
  for (const [file, mod] of Object.entries(pages)) {
    const name = file.split("/").pop()?.replace(".tsx", "") ?? file;
    it(name, () => {
      const path = PATH[name];
      expect(path, `add ${name} to PATH`).toBeDefined();
      const url = path === "/tx/:id" ? "/tx/3f2c9a1e-7b4d-4c8e-9f10-2a6b8c4d1e7f" : path === "*" ? "/missing" : (path as string);
      const html = render(path as string, url, mod.default);
      expect(html).toMatch(/<h1[^>]*>/);
      expect(html).toMatch(/<title>[^<]+<\/title>/);
      expect(html).not.toMatch(/undefined|NaN|\[object Object\]/);
    });
  }

  it("Shell renders navigation", () => {
    const html = renderToString(
      <Providers>
        <MemoryRouter>
          <Shell />
        </MemoryRouter>
      </Providers>,
    );
    expect(html).toContain('aria-label="Primary"');
    expect(html).toContain("Skip to content");
  });
});

describe("swap widget states", () => {
  const caps = (quotes: boolean): { status: "ready"; data: Capabilities } => ({
    status: "ready",
    data: {
      swap: { quotes, paused: false, platformFeeBps: 25, platformFeeBpsByChain: {}, quoteTtlSeconds: 30 },
      ramp: { moonpay: false, transak: false, buyLimits: null },
    },
  });

  it("explains missing quotes instead of estimating", () => {
    const html = renderToString(
      <Providers>
        <SwapWidget capabilities={caps(false)} />
      </Providers>,
    );
    expect(html).toContain("Quotes are unavailable");
    expect(html).toContain("disabled");
  });

  it("names the outage when the API is down", () => {
    const html = renderToString(
      <Providers>
        <SwapWidget capabilities={{ status: "error", error: new Error("down") }} />
      </Providers>,
    );
    expect(html).toContain("Kavrix is unreachable");
  });

  it("lists every fee separately in a quote", () => {
    const eth = { chainId: 8453 as const, address: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee" as const, symbol: "ETH", name: "Ether", decimals: 18, native: true, logoUrl: null, risk: "standard" as const, rank: null };
    const usdc = { chainId: 8453 as const, address: "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913" as const, symbol: "USDC", name: "USD Coin", decimals: 6, native: false, logoUrl: null, risk: "standard" as const, rank: null };
    const text = renderToString(
      <QuoteSummary
        sell={eth}
        buy={usdc}
        nativeSymbol="ETH"
        quote={{
          provider: "kyberswap",
          chainId: 8453,
          sellToken: eth.address,
          buyToken: usdc.address,
          sellAmount: 10n ** 18n,
          buyAmount: 3_492_150_000n,
          minBuyAmount: 3_474_689_250n,
          platformFee: { bps: 25, amount: 2_500_000_000_000_000n, token: "sell" },
          providerFee: null,
          networkFeeWei: 21_000_000_000_000n,
          route: [{ source: "uniswap-v3", proportionBps: 10_000 }],
          valueUsd: { sell: 3500, buy: 3482 },
          expiresAt: Date.now() + 20_000,
        }}
      />,
    ).replace(/<[^>]+>/g, "");
    expect(text).toContain("3,492.15");
    expect(text).toContain("3,474.68925");
    expect(text).toContain("0.0025 ETH");
    expect(text).toContain("0.000021");
    expect(text).toContain("uniswap-v3");
    expect(text).toContain("KyberSwap keeps the difference");
    expect(text).toContain("Price impact");
  });
});
