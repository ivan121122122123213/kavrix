import { describe, it } from "node:test";
import assert from "node:assert/strict";
import type { TokenOption } from "../src/lib/api.ts";
import { checkAmount, initialSwapState, parseSlippagePercent, slippageWarning, swapCta, swapReducer } from "../src/swap/state.ts";
import { filterTokens } from "../src/swap/tokens.ts";

const ETH: TokenOption = { chainId: 8453, address: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", symbol: "ETH", name: "Ether", decimals: 18, native: true, logoUrl: null, risk: "standard" as const, rank: null };
const USDC: TokenOption = { chainId: 8453, address: "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913", symbol: "USDC", name: "USD Coin", decimals: 6, native: false, logoUrl: null, risk: "standard" as const, rank: null };
const WETH: TokenOption = { chainId: 8453, address: "0x4200000000000000000000000000000000000006", symbol: "WETH", name: "Wrapped Ether", decimals: 18, native: false, logoUrl: null, risk: "standard" as const, rank: null };
const ARB_USDC: TokenOption = { ...USDC, chainId: 42161, address: "0xaf88d065e77c8cc2239327c5edb3a432268e5831" };

describe("swap reducer", () => {
  it("defaults to native → USDC once tokens load, and never overrides a user choice", () => {
    const s = swapReducer(initialSwapState(8453), { type: "defaults", tokens: [ETH, WETH, USDC] });
    assert.equal(s.sell?.symbol, "ETH");
    assert.equal(s.buy?.symbol, "USDC");
    const picked = swapReducer(s, { type: "pick", side: "buy", token: WETH });
    assert.equal(swapReducer(picked, { type: "defaults", tokens: [ETH, USDC] }).buy?.symbol, "WETH");
  });

  it("swaps sides instead of allowing the same token twice", () => {
    const s = swapReducer(initialSwapState(8453), { type: "defaults", tokens: [ETH, USDC] });
    const same = swapReducer(s, { type: "pick", side: "buy", token: ETH });
    assert.equal(same.sell?.symbol, "USDC");
    assert.equal(same.buy?.symbol, "ETH");
  });

  it("ignores tokens from another chain and clears tokens on chain change", () => {
    const s = swapReducer(initialSwapState(8453), { type: "defaults", tokens: [ETH, USDC] });
    assert.equal(swapReducer(s, { type: "pick", side: "buy", token: ARB_USDC }), s);
    const moved = swapReducer(s, { type: "chain", chainId: 42161 });
    assert.equal(moved.sell, null);
    assert.equal(moved.buy, null);
  });

  it("rejects out-of-range slippage", () => {
    const s = initialSwapState(1);
    assert.equal(swapReducer(s, { type: "slippage", bps: 2001 }).slippageBps, s.slippageBps);
    assert.equal(swapReducer(s, { type: "slippage", bps: 1.5 }).slippageBps, s.slippageBps);
    assert.equal(swapReducer(s, { type: "slippage", bps: 30 }).slippageBps, 30);
  });
});

describe("amount validation", () => {
  it("parses exactly and explains precision errors", () => {
    assert.deepEqual(checkAmount("", USDC), { kind: "empty" });
    assert.deepEqual(checkAmount("1.5", USDC), { kind: "ok", value: 1_500_000n });
    assert.equal(checkAmount("0", USDC).kind, "invalid");
    const precise = checkAmount("0.0000001", USDC);
    assert.equal(precise.kind === "invalid" && precise.message.includes("6 decimal"), true);
    assert.equal(checkAmount("abc", USDC).kind, "invalid");
    assert.equal(checkAmount("1", null).kind, "invalid");
  });
});

describe("primary action", () => {
  const ready = swapReducer(swapReducer(initialSwapState(8453), { type: "defaults", tokens: [ETH, USDC] }), { type: "amount", amount: "1" });
  const base = {
    capabilities: "ready" as const,
    quotesEnabled: true,
    state: ready,
    amount: checkAmount("1", ETH),
    wallet: "connected" as const,
    quote: "firm" as const,
    balance: 2n * 10n ** 18n,
    allowance: null,
  };

  it("names what is missing and enables only actionable steps", () => {
    assert.deepEqual(swapCta({ ...base, capabilities: "loading" }), { label: "Loading…", disabled: true, action: "none" });
    assert.equal(swapCta({ ...base, capabilities: "error" }).label, "Kavrix is unreachable");
    assert.equal(swapCta({ ...base, state: initialSwapState(8453) }).label, "Select a token");
    assert.equal(swapCta({ ...base, amount: { kind: "empty" } }).label, "Enter an amount");
    assert.equal(swapCta({ ...base, quotesEnabled: false }).label, "Quotes unavailable");
    assert.deepEqual(swapCta({ ...base, wallet: "disconnected" }), { label: "Connect wallet", disabled: false, action: "connect" });
    assert.deepEqual(swapCta({ ...base, wrongChain: true, chainName: "Base" }), { label: "Switch to Base", disabled: false, action: "switch" });
    assert.equal(swapCta({ ...base, balance: 1n }).label, "Insufficient ETH balance");
    assert.equal(swapCta({ ...base, balance: 1n }).disabled, true);
    assert.equal(swapCta({ ...base, quote: "loading" }).label, "Getting a quote…");
    assert.equal(swapCta({ ...base, quote: "indicative" }).disabled, true);
    assert.equal(swapCta({ ...base, quote: "expired" }).action, "refresh");
    assert.deepEqual(swapCta(base), { label: "Swap", disabled: false, action: "swap" });
  });

  it("requires an exact approval for ERC-20 sells", () => {
    const usdc = { ...base, state: { ...ready, sell: USDC, buy: ETH }, amount: checkAmount("5", USDC), balance: 10_000_000n };
    assert.equal(swapCta({ ...usdc, allowance: undefined }).label, "Checking allowance…");
    assert.deepEqual(swapCta({ ...usdc, allowance: 4_999_999n }), { label: "Approve USDC", disabled: false, action: "approve" });
    assert.equal(swapCta({ ...usdc, allowance: 5_000_000n }).action, "swap");
  });

  it("locks the action while the wallet or chain is working", () => {
    for (const exec of ["switching", "approve_sign", "approve_pending", "swap_sign", "swap_pending"] as const) {
      const cta = swapCta({ ...base, exec });
      assert.equal(cta.disabled, true, exec);
      assert.equal(cta.action, "none");
    }
  });
});

describe("slippage input", () => {
  it("parses percent to bps within limits", () => {
    assert.equal(parseSlippagePercent("0.3"), 30);
    assert.equal(parseSlippagePercent("20"), 2000);
    assert.equal(parseSlippagePercent("50"), undefined);
    assert.equal(parseSlippagePercent("0"), undefined);
    assert.equal(parseSlippagePercent("20.01"), undefined);
    assert.equal(parseSlippagePercent("0.001"), undefined);
    assert.equal(parseSlippagePercent("-1"), undefined);
  });

  it("warns at the extremes only", () => {
    assert.ok(slippageWarning(1));
    assert.equal(slippageWarning(50), undefined);
    assert.ok(slippageWarning(300));
  });
});

describe("token search", () => {
  it("matches symbol prefix, name, or exact address only", () => {
    assert.deepEqual(filterTokens([ETH, USDC, WETH], "us").map((t) => t.symbol), ["USDC"]);
    assert.deepEqual(filterTokens([ETH, USDC, WETH], "ether").map((t) => t.symbol), ["ETH", "WETH"]);
    assert.deepEqual(filterTokens([ETH, USDC], USDC.address.toUpperCase().replace("0X", "0x")).map((t) => t.symbol), ["USDC"]);
    assert.deepEqual(filterTokens([ETH, USDC], "0x1111111111111111111111111111111111111111"), []);
  });
});

import { GAS_RESERVE_WEI, maxSpendable } from "../src/swap/state.ts";
import { IMPACT_CONFIRM_BPS, formatUsd, priceImpactBps } from "../src/swap/impact.ts";

describe("Max", () => {
  it("uses the whole token balance but keeps gas for native coins", () => {
    assert.equal(maxSpendable(5_000_000n, false, 8453, null), 5_000_000n);
    assert.equal(maxSpendable(10n ** 18n, true, 1, null), 10n ** 18n - GAS_RESERVE_WEI[1]);
    assert.equal(maxSpendable(10n ** 18n, true, 1, 2n * 10n ** 15n), 10n ** 18n - 6n * 10n ** 15n, "3x quoted fee when larger");
    assert.equal(maxSpendable(GAS_RESERVE_WEI[137], true, 137, null), 0n, "nothing left after the reserve");
  });
});

describe("price impact", () => {
  const base = { platformFee: { bps: 25, amount: 0n, token: "sell" as const } };
  it("excludes Kavrix's own fee and ignores tiny or unknown values", () => {
    assert.equal(priceImpactBps({ ...base, valueUsd: { sell: 1000, buy: 997.5 } }), 0, "only the 0.25% fee");
    assert.equal(priceImpactBps({ ...base, valueUsd: { sell: 1000, buy: 947.5 } }), 501, "50 lost of 997.5 after the fee");
    assert.equal(priceImpactBps({ ...base, valueUsd: { sell: 1000, buy: 1010 } }), 0, "favourable moves are not negative");
    assert.equal(priceImpactBps({ ...base, valueUsd: { sell: 0.5, buy: 0.1 } }), null, "too small to judge");
    assert.equal(priceImpactBps({ ...base, valueUsd: null }), null);
    assert.equal(formatUsd(873.0412), "$873.04");
    assert.equal(formatUsd(0.001), "< $0.01");
  });

  it("blocks a high-impact swap until the user confirms", () => {
    const ready = swapReducer(swapReducer(initialSwapState(8453), { type: "defaults", tokens: [ETH, USDC] }), { type: "amount", amount: "1" });
    const input = { capabilities: "ready" as const, quotesEnabled: true, state: ready, amount: checkAmount("1", ETH), wallet: "connected" as const, quote: "firm" as const, balance: 2n * 10n ** 18n, allowance: null };
    assert.equal(swapCta({ ...input, impactBps: IMPACT_CONFIRM_BPS }).label, "Confirm the price impact");
    assert.equal(swapCta({ ...input, impactBps: IMPACT_CONFIRM_BPS }).disabled, true);
    assert.deepEqual(swapCta({ ...input, impactBps: IMPACT_CONFIRM_BPS, impactAccepted: true }), { label: "Swap anyway", disabled: false, action: "swap" });
    assert.equal(swapCta({ ...input, impactBps: 150 }).label, "Swap");
    assert.equal(swapCta({ ...input, impactBps: null }).label, "Swap");
  });
});

describe("Russian labels", () => {
  it("translates the primary action and amount errors", async () => {
    const { swapCta: cta, checkAmount: check, initialSwapState: init, swapReducer: reduce } = await import("../src/swap/state.ts");
    const eth = { chainId: 8453 as const, address: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee" as const, symbol: "ETH", name: "Ether", decimals: 18, native: true, logoUrl: null, risk: "standard" as const, rank: null };
    const usdc = { ...eth, address: "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913" as const, symbol: "USDC", decimals: 6, native: false };
    const state = reduce(reduce(init(8453), { type: "defaults", tokens: [eth, usdc] }), { type: "amount", amount: "1" });
    const base = { capabilities: "ready" as const, quotesEnabled: true, state, amount: check("1", eth), wallet: "connected" as const, quote: "firm" as const, balance: 10n ** 19n, allowance: null };
    assert.equal(cta(base, "ru").label, "Обменять");
    assert.equal(cta({ ...base, wallet: "disconnected" }, "ru").label, "Подключить кошелёк");
    assert.equal(cta({ ...base, balance: 1n }, "ru").label, "Недостаточно ETH");
    const bad = check("1.1234567", usdc, "ru");
    assert.equal(bad.kind === "invalid" ? bad.message : "", "У USDC не больше 6 знаков после запятой.");
  });
});
