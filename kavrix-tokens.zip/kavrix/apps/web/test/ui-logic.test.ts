import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { SWAP_STATUSES } from "@kavrix/shared";
import { formatBps, formatTokenAmount, normalizeAmountInput, shortAddress } from "../src/lib/format.ts";
import { ApiError, describeError, feeBpsFor, parseCapabilities, parseChains, parseTokens } from "../src/lib/api.ts";
import { parseSwapList, parseSwapStatus, statusCopy, stepsFor } from "../src/swap/status.ts";
import { unitRate } from "../src/swap/quote.ts";
import { validateRampDraft } from "../src/ramp/validate.ts";

describe("formatting", () => {
  it("truncates instead of rounding up and groups thousands", () => {
    assert.equal(formatTokenAmount(1_234_567_891n, 6), "1,234.567891");
    assert.equal(formatTokenAmount(1_999_999_999n, 9, 2), "1.99");
    assert.equal(formatTokenAmount(1n, 18), "<0.000001");
    assert.equal(formatTokenAmount(0n, 18), "0");
    assert.equal(formatBps(25), "0.25%");
    assert.equal(formatBps(50), "0.5%");
    assert.equal(formatBps(100), "1%");
    assert.equal(shortAddress("0x833589fcd6edb6e08f4c7c32d4f71b54bda02913"), "0x8335…2913");
    assert.equal(normalizeAmountInput("1,5"), "1.5");
    assert.equal(normalizeAmountInput("1 000"), "1000");
  });

  it("computes the unit rate in buy-token base units", () => {
    // 2 ETH -> 7,000 USDC  =>  1 ETH = 3,500 USDC
    assert.equal(unitRate({ sellAmount: 2n * 10n ** 18n, buyAmount: 7_000_000_000n }, 18), 3_500_000_000n);
    assert.equal(unitRate({ sellAmount: 0n, buyAmount: 1n }, 18), 0n);
  });
});

describe("API response guards", () => {
  it("accepts well-formed capabilities and rejects anything else", () => {
    const ok = {
      swap: { quotes: false, paused: true, provider: "kyberswap", platformFeeBps: 25, platformFeeBpsByChain: { "8453": 10, "999": 5, "1": 400 }, quoteTtlSeconds: 30 },
      ramp: { moonpay: false, transak: true, buyLimits: { min: 20, max: 5000 } },
    };
    const parsed = parseCapabilities(ok);
    assert.equal(parsed.swap.platformFeeBps, 25);
    assert.equal(parsed.swap.paused, true);
    assert.deepEqual(parsed.swap.platformFeeBpsByChain, { 8453: 10 }, "unknown chains and out-of-range fees are dropped");
    assert.equal(feeBpsFor(parsed, 8453), 10);
    assert.equal(feeBpsFor(parsed, 1), 25);
    assert.deepEqual(parsed.ramp.buyLimits, { min: 20, max: 5000 });
    assert.throws(() => parseCapabilities({ swap: { quotes: "yes" }, ramp: {} }), ApiError);
    assert.throws(() => parseCapabilities({ ...ok, swap: { ...ok.swap, platformFeeBps: -1 } }), ApiError);
  });

  it("validates tokens against the requested chain", () => {
    const body = { chainId: 8453, tokens: [{ chainId: 8453, address: "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913", symbol: "USDC", name: "USD Coin", decimals: 6, native: false }] };
    assert.equal(parseTokens(body, 8453)[0]?.address, "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913");
    assert.throws(() => parseTokens(body, 1), ApiError);
    assert.throws(() => parseTokens({ chainId: 8453, tokens: [{ ...body.tokens[0], decimals: 99 }] }, 8453), ApiError);
  });

  it("rejects chains with non-https explorers", () => {
    const chain = { id: 1, name: "Ethereum", explorerUrl: "https://etherscan.io", confirmations: 3, nativeCurrency: { symbol: "ETH" } };
    assert.equal(parseChains({ chains: [chain] }).length, 1);
    assert.throws(() => parseChains({ chains: [{ ...chain, explorerUrl: "javascript:alert(1)" }] }), ApiError);
  });

  it("describes errors without leaking internals", () => {
    assert.match(describeError(new ApiError(500, { code: "INTERNAL", title: "Internal error", detail: "stack trace" })), /trouble/);
    assert.match(describeError(new ApiError(0, undefined, "Kavrix servers are unreachable.")), /unreachable/);
    assert.match(describeError(new Error("boom")), /Something went wrong/);
  });
});

describe("swap status", () => {
  const id = "3f2c9a1e-7b4d-4c8e-9f10-2a6b8c4d1e7f";
  const hash = `0x${"ab".repeat(32)}`;
  const view = {
    id, status: "submitted", provider: "kyberswap", chainId: 8453, taker: "0x70a9f34f9b34c64957b9c401a97bfed35b95049e",
    sell: { address: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", symbol: "ETH", decimals: 18 },
    buy: { address: "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913", symbol: "USDC", decimals: 6 },
    sellAmount: "1000000000000000", quotedBuyAmount: "3500000", minBuyAmount: "3465000", actualBuyAmount: null,
    platformFee: { bps: 0, amount: "0" }, txHash: hash, blockNumber: null, confirmations: 2, requiredConfirmations: 5,
    failureCode: null, createdAt: "2026-10-25T10:00:00.000Z", updatedAt: "2026-10-25T10:00:05.000Z",
  };

  it("parses only consistent responses", () => {
    const v = parseSwapStatus(view, id);
    assert.equal(v.status, "submitted");
    assert.equal(v.minBuyAmount, 3_465_000n);
    assert.equal(v.confirmations, 2);
    assert.throws(() => parseSwapStatus({ ...view, id: "3f2c9a1e-7b4d-4c8e-9f10-2a6b8c4d1e70" }, id));
    assert.throws(() => parseSwapStatus({ ...view, status: "done" }, id));
    assert.throws(() => parseSwapStatus({ ...view, chainId: 10 }, id));
    assert.throws(() => parseSwapStatus({ ...view, txHash: "0x1" }, id));
    assert.throws(() => parseSwapStatus({ ...view, sell: { ...view.sell, decimals: 99 } }, id));
    assert.throws(() => parseSwapStatus({ ...view, failureCode: "<script>" }, id));
  });

  it("parses history pages", () => {
    const page = parseSwapList({ swaps: [view], nextCursor: null });
    assert.equal(page.swaps.length, 1);
    assert.throws(() => parseSwapList({ swaps: "x", nextCursor: null }));
  });

  it("never shows a confirmed step unless the swap is confirmed", () => {
    for (const status of SWAP_STATUSES) {
      const steps = stepsFor(status);
      assert.equal(steps.length, 3);
      assert.equal(steps[2]?.state === "done", status === "confirmed", status);
      assert.ok(statusCopy(status).title.length > 0);
    }
    assert.equal(stepsFor("reverted")[2]?.state, "failed");
  });
});

describe("buy/sell form", () => {
  const draft = { direction: "buy" as const, fiat: "USD" as const, amount: "100", chainId: 8453 as const, token: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee" as const, tokenDecimals: 18, wallet: "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913" };
  it("validates amount precision per direction and always requires an address", () => {
    assert.deepEqual(validateRampDraft(draft), {});
    assert.ok(validateRampDraft({ ...draft, wallet: "0x123" }).wallet);
    assert.ok(validateRampDraft({ ...draft, direction: "sell", wallet: "" }).wallet, "refund address needed for sells");
    assert.ok(validateRampDraft({ ...draft, amount: "0" }).amount);
    assert.ok(validateRampDraft({ ...draft, amount: "10.555" }).amount, "fiat has 2 decimals");
    assert.deepEqual(validateRampDraft({ ...draft, direction: "sell", amount: "0.123456789" }), {});
    assert.ok(validateRampDraft({ ...draft, direction: "sell", tokenDecimals: 6, amount: "1.1234567" }).amount);
    assert.ok(validateRampDraft({ ...draft, token: null }).token);
  });
});

import { parseQuote } from "../src/swap/quote.ts";
import { verifyFirmQuote } from "../src/swap/verify.ts";

describe("quote response guard", () => {
  const NATIVE = "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee";
  const USDC = "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913";
  const ROUTER = "0x6131b5fae19ea4f9d964eac0408e4408b66337b5";
  const TAKER = "0x70a9f34f9b34c64957b9c401a97bfed35b95049e";
  const expect = { chainId: 8453, sellToken: NATIVE, buyToken: USDC, sellAmount: 10n ** 15n };
  const body = {
    firm: true, provider: "kyberswap", chainId: 8453, sellToken: NATIVE, buyToken: USDC, sellAmount: "1000000000000000",
    buyAmount: "3500000", minBuyAmount: "3465000", platformFee: { bps: 25, amount: "2500000000000", token: "sell" },
    providerFee: null, networkFeeWei: "1000000000000", route: [{ source: "uniswap-v3", proportionBps: 10000 }],
    expiresAt: 2_000_000_000_000, quoteToken: `eyJ2IjoxfQ.${"a".repeat(43)}`, taker: TAKER, spender: null, tx: { to: ROUTER, data: "0x8af033fb00", value: "1000000000000000" },
  };

  it("parses a firm quote into bigints", () => {
    const q = parseQuote(body, expect);
    assert.equal(q.firm, true);
    assert.equal(q.minBuyAmount, 3_465_000n);
    if (q.firm) assert.equal(q.tx.value, 10n ** 15n);
  });

  it("rejects a response that answers a different request or is inconsistent", () => {
    assert.throws(() => parseQuote(body, { ...expect, sellAmount: 1n }), ApiError);
    assert.throws(() => parseQuote({ ...body, buyToken: NATIVE }, expect), ApiError);
    assert.throws(() => parseQuote({ ...body, minBuyAmount: "9999999" }, expect), ApiError);
    assert.throws(() => parseQuote({ ...body, provider: "evil" }, expect), ApiError);
    assert.throws(() => parseQuote({ ...body, platformFee: { ...body.platformFee, bps: 301 } }, expect), ApiError);
    assert.throws(() => parseQuote({ ...body, tx: { ...body.tx, data: "nope" } }, expect), ApiError);
    assert.throws(() => parseQuote({ ...body, quoteToken: "unsigned" }, expect), ApiError);
    assert.throws(() => parseQuote({ ...body, valueUsd: { sell: -1, buy: 1 } }, expect), ApiError);
    assert.equal(parseQuote({ ...body, valueUsd: null }, expect).valueUsd, null);
  });

  it("blocks unsafe firm quotes right before signing", () => {
    const q = parseQuote(body, expect);
    assert.ok(q.firm);
    if (!q.firm) return;
    const now = 1_999_999_000_000;
    assert.equal(verifyFirmQuote(q, TAKER, now), undefined);
    assert.equal(verifyFirmQuote(q, TAKER.toUpperCase().replace("0X", "0x"), now), undefined);
    assert.equal(verifyFirmQuote(q, "0x1111111111111111111111111111111111111111", now), "wrong_wallet");
    assert.equal(verifyFirmQuote(q, TAKER, 2_000_000_000_000), "expired");
    assert.equal(verifyFirmQuote({ ...q, tx: { ...q.tx, to: "0x1111111111111111111111111111111111111111" } }, TAKER, now), "wrong_target");
    assert.equal(verifyFirmQuote({ ...q, tx: { ...q.tx, value: 0n } }, TAKER, now), "wrong_value");
    assert.equal(verifyFirmQuote({ ...q, spender: ROUTER }, TAKER, now), "wrong_spender");
    const erc20 = { ...q, sellToken: USDC as `0x${string}`, buyToken: NATIVE as `0x${string}`, tx: { ...q.tx, value: 0n }, spender: ROUTER as `0x${string}` };
    assert.equal(verifyFirmQuote(erc20, TAKER, now), undefined);
    assert.equal(verifyFirmQuote({ ...erc20, spender: "0x1111111111111111111111111111111111111111" }, TAKER, now), "wrong_spender");
  });
});

import { parseRampOrder } from "../src/lib/ramp.ts";

describe("ramp order guard", () => {
  const order = {
    id: "3f2c9a1e-7b4d-4c8e-9f10-2a6b8c4d1e7f", provider: "moonpay", direction: "buy", chainId: 8453, cryptoCurrency: "USDC",
    fiatCurrency: "USD", fiatAmount: "100.00000000", cryptoAmount: null, status: "pending", providerStatus: "waitingPayment",
    createdAt: "2026-10-25T10:00:00.000Z", updatedAt: "2026-10-25T10:00:00.000Z",
  };
  it("accepts valid orders and rejects malformed ones", () => {
    assert.equal(parseRampOrder(order).status, "pending");
    assert.throws(() => parseRampOrder({ ...order, provider: "paypal" }));
    assert.throws(() => parseRampOrder({ ...order, status: "done" }));
    assert.throws(() => parseRampOrder({ ...order, fiatAmount: "1e9" }));
    assert.throws(() => parseRampOrder({ ...order, cryptoCurrency: "<b>" }));
  });
});


import { filterTokens, popularTokens, visibleRows, MAX_ROWS } from "../src/swap/tokens.ts";

describe("large token lists", () => {
  const mk = (i: number, symbol: string, extra: Record<string, unknown> = {}) => ({
    chainId: 1 as const, address: `0x${i.toString(16).padStart(40, "0")}` as `0x${string}`, symbol, name: `${symbol} token`, decimals: 18,
    native: false, logoUrl: null, risk: "standard" as const, rank: i, ...extra,
  });
  const list = [mk(1, "ETH", { native: true, address: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee" }), mk(2, "USDC"), mk(3, "USDCX"), mk(4, "PEPE", { risk: "high" }), mk(5, "WBTC"), mk(6, "AUSDC", { name: "Aave USDC" })];

  it("ranks exact symbol, then prefix, then name matches", () => {
    assert.deepEqual(filterTokens(list, "usdc").map((t) => t.symbol), ["USDC", "USDCX", "AUSDC"]);
    assert.deepEqual(filterTokens(list, list[3]!.address).map((t) => t.symbol), ["PEPE"]);
  });

  it("offers native coin and standard-risk majors as quick picks, never memecoins", () => {
    assert.deepEqual(popularTokens(list).map((t) => t.symbol), ["ETH", "USDC", "WBTC"]);
  });

  it("caps rendered rows and reports the rest", () => {
    const many = Array.from({ length: 200 }, (_, i) => mk(i + 10, `T${i}`));
    const { rows, hidden } = visibleRows(many);
    assert.equal(rows.length, MAX_ROWS);
    assert.equal(hidden, 200 - MAX_ROWS);
  });

  it("parses risk fail-safe: unknown means high", () => {
    const body = { chainId: 1, tokens: [
      { chainId: 1, address: "0x1111111111111111111111111111111111111111", symbol: "A", name: "A", decimals: 18, native: false, logoUrl: null, risk: "standard", rank: 3 },
      { chainId: 1, address: "0x2222222222222222222222222222222222222222", symbol: "B", name: "B", decimals: 18, native: false, logoUrl: null, risk: "weird", rank: -1 },
      { chainId: 1, address: "0x3333333333333333333333333333333333333333", symbol: "C", name: "C", decimals: 18, native: false, logoUrl: null },
    ] };
    const parsed = parseTokens(body, 1);
    assert.deepEqual(parsed.map((t) => [t.risk, t.rank]), [["standard", 3], ["high", null], ["high", null]]);
  });
});
