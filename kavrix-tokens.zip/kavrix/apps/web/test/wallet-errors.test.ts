import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { BaseError, UserRejectedRequestError } from "viem";
import { describeWalletError, isUserRejection } from "../src/wallet/errors.ts";

describe("scenario: user rejects in wallet / send failure", () => {
  it("recognises rejection from viem errors and raw EIP-1193 code 4001", () => {
    assert.equal(isUserRejection(new UserRejectedRequestError(new Error("User rejected the request."))), true);
    assert.equal(isUserRejection({ code: 4001, message: "rejected" }), true);
    assert.equal(isUserRejection(new Error("network")), false);
    assert.match(describeWalletError(new UserRejectedRequestError(new Error("x"))), /declined/);
  });

  it("explains insufficient funds and on-chain reverts without raw RPC payloads", () => {
    assert.match(describeWalletError(new BaseError("Transaction failed", { details: "insufficient funds for gas * price + value" })), /Not enough funds/);
    assert.match(describeWalletError(new BaseError("Execution failed", { details: "execution reverted" })), /would fail on-chain/);
    assert.match(describeWalletError({}), /wallet returned an error/);
  });
});
