import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { ROUTES } from "../src/routes.ts";
import { LANGS } from "../src/i18n/lang.ts";

describe("route table", () => {
  it("covers every page required by the brief exactly once", () => {
    const paths = ROUTES.map((r) => r.path);
    const required = ["/", "/buy-sell", "/history", "/networks", "/fees", "/security", "/faq", "/docs", "/about", "/terms", "/privacy", "/support", "/tx/:id", "/admin"];
    for (const p of required) assert.ok(paths.includes(p), p);
    assert.equal(new Set(paths).size, paths.length);
  });

  it("keeps private pages out of search engines", () => {
    for (const r of ROUTES.filter((x) => ["/admin", "/history", "/tx/:id"].includes(x.path))) assert.equal(r.indexable, false);
  });

  it("has unique, non-empty titles and descriptions within SEO limits in every language", () => {
    for (const lang of LANGS) {
      assert.equal(new Set(ROUTES.map((r) => r.title[lang])).size, ROUTES.length, lang);
      assert.equal(new Set(ROUTES.map((r) => r.description[lang])).size, ROUTES.length, lang);
      for (const r of ROUTES) {
        assert.ok(r.title[lang].trim().length > 0 && r.description[lang].trim().length > 0, `${lang} ${r.path}`);
        assert.ok(r.description[lang].length <= 160, `${lang} ${r.path}`);
      }
    }
  });

  it("actually translates: Russian text is not a copy of English", () => {
    for (const r of ROUTES.filter((x) => x.path !== "/admin")) assert.notEqual(r.description.ru, r.description.en, r.path);
  });
});
