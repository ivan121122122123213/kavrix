import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { ROUTES } from "../src/routes.ts";
import { headFor, injectHead, outputPath } from "../scripts/prerender-head.ts";

const template = `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Kavrix</title></head><body><div id="root"></div></body></html>`;

describe("prerendered heads", () => {
  it("gives every static route its own title, description, canonical and image", () => {
    const fees = ROUTES.find((r) => r.path === "/fees");
    assert.ok(fees);
    const html = injectHead(template, headFor(fees, "https://kavrix.example", "en"), "en");
    assert.match(html, /<title data-prerender>Fees · Kavrix<\/title>/);
    assert.match(html, /name="description" content="How platform, network and provider fees/);
    assert.match(html, /rel="canonical" href="https:\/\/kavrix.example\/fees"/);
    assert.match(html, /property="og:image" content="https:\/\/kavrix.example\/og.png"/);
    assert.equal((html.match(/<title/g) ?? []).length, 1, "exactly one title");
  });

  it("renders Russian heads and sets the document language", () => {
    const fees = ROUTES.find((r) => r.path === "/fees");
    assert.ok(fees);
    const html = injectHead(template, headFor(fees, "https://kavrix.example", "ru"), "ru");
    assert.match(html, /<html lang="ru">/);
    assert.match(html, /<title data-prerender>Комиссии · Kavrix<\/title>/);
    assert.match(html, /property="og:locale" content="ru_RU"/);
  });

  it("marks private pages noindex and escapes content", () => {
    const head = headFor({ path: "/x", title: { en: 'A "quoted" <title>', ru: "x" }, description: { en: "d & e", ru: "y" }, indexable: false }, "https://k.example", "en");
    assert.match(head, /name="robots" content="noindex"/);
    assert.match(head, /A &quot;quoted&quot; &lt;title&gt;/);
    assert.match(head, /d &amp; e/);
  });

  it("maps routes to files and refuses a changed template", () => {
    assert.equal(outputPath("/"), "index.html");
    assert.equal(outputPath("/buy-sell"), "buy-sell/index.html");
    assert.throws(() => injectHead("<html><head></head></html>", "", "en"));
  });
});
