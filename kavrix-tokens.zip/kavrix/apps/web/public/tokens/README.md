# Official token artwork (optional)

Kavrix draws its own coin icons. To show the issuers' official logos instead:

1. Download the files from each issuer's brand kit and check its usage terms
   (for example Circle for USDC, Tether for USDT, the Ethereum Foundation for ETH).
2. Save them here with lowercase names, e.g. `usdc.svg`, `usdt.svg`, `eth.svg`.
3. Point the token at the file (one row per network):

   ```sql
   UPDATE tokens SET logo_url = '/tokens/usdc.svg' WHERE symbol = 'USDC';
   ```

Only `/tokens/<name>.(svg|png|webp)` or `https://…` URLs are accepted, by the database and by the browser.
If a file fails to load, the Kavrix coin is shown instead.

Native coins (ETH, POL) are not rows in `tokens` and always use the Kavrix coin.
