import { randomBytes } from "node:crypto";
import { PgAdminRepository, createDatabase, type AdminRole } from "@kavrix/db";
import { ConfigError, parseConfig } from "./config.ts";
import { deriveKey, generatePassword, hashPassword, otpauthUri, seal } from "./admin/crypto.ts";

/**
 * Admin accounts are managed only from the server shell:
 *   node dist/admin-cli.js create <email> <owner|operator|viewer>
 *   node dist/admin-cli.js reset-password <email>
 *   node dist/admin-cli.js reset-totp <email>
 *   node dist/admin-cli.js disable <email> | enable <email>
 * Generated credentials are printed once to this terminal and never stored in plaintext.
 */
const USAGE = "usage: admin-cli <create email role | reset-password email | reset-totp email | disable email | enable email>";

async function main(argv: readonly string[]): Promise<number> {
  const [command, emailArg, roleArg] = argv;
  if (command === undefined || emailArg === undefined) {
    process.stderr.write(`${USAGE}\n`);
    return 64;
  }
  const email = emailArg.trim().toLowerCase();
  if (!/^[^\s@]{1,64}@[^\s@]{1,190}\.[a-z]{2,}$/.test(email)) {
    process.stderr.write("invalid email\n");
    return 64;
  }

  let config;
  try {
    config = parseConfig(process.env);
  } catch (err) {
    if (err instanceof ConfigError) {
      process.stderr.write(`${err.message}\n`);
      return 78;
    }
    throw err;
  }
  if (config.ADMIN_ENCRYPTION_KEY === undefined) {
    process.stderr.write("ADMIN_ENCRYPTION_KEY is not set; the admin panel is disabled\n");
    return 78;
  }
  const key = deriveKey(config.ADMIN_ENCRYPTION_KEY);
  const db = createDatabase({ url: config.DATABASE_URL, maxConnections: 1 });
  const repo = new PgAdminRepository(db.sql);

  const issueTotp = async (adminId: string) => {
    const secret = randomBytes(20);
    await repo.setTotpSecret(adminId, seal(secret, key, `admin:${adminId}`));
    process.stdout.write(`TOTP (add to an authenticator app, then discard this line):\n  ${otpauthUri(secret, email)}\n`);
  };
  const issuePassword = async (adminId: string | null) => {
    const password = generatePassword();
    const hash = await hashPassword(password);
    if (adminId !== null) await repo.setPassword(adminId, hash);
    process.stdout.write(`Password (shown once):\n  ${password}\n`);
    return hash;
  };

  try {
    const existing = await repo.findAdminByEmail(email);
    switch (command) {
      case "create": {
        if (roleArg !== "owner" && roleArg !== "operator" && roleArg !== "viewer") {
          process.stderr.write("role must be owner, operator or viewer\n");
          return 64;
        }
        if (existing !== null) {
          process.stderr.write("admin already exists\n");
          return 65;
        }
        const hash = await issuePassword(null);
        const id = await repo.createAdmin({ email, passwordHash: hash, role: roleArg as AdminRole });
        await issueTotp(id);
        process.stdout.write(`Created ${roleArg} ${email}\n`);
        return 0;
      }
      case "reset-password":
      case "reset-totp":
      case "disable":
      case "enable": {
        if (existing === null) {
          process.stderr.write("admin not found\n");
          return 65;
        }
        if (command === "reset-password") await issuePassword(existing.id);
        if (command === "reset-totp") await issueTotp(existing.id);
        if (command === "disable" || command === "enable") await repo.setDisabled(existing.id, command === "disable");
        process.stdout.write(`${command}: done (existing sessions revoked where applicable)\n`);
        return 0;
      }
      default:
        process.stderr.write(`${USAGE}\n`);
        return 64;
    }
  } finally {
    await db.close();
  }
}

process.exitCode = await main(process.argv.slice(2));
