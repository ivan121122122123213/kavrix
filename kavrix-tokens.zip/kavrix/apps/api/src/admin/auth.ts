import type { AdminRepository, AdminRole, AdminSession } from "@kavrix/db";
import { DUMMY_PASSWORD_HASH, hashSessionToken, newSessionToken, open, verifyPassword, verifyTotp } from "./crypto.ts";

export const SESSION_TTL_MS = 8 * 60 * 60_000;
export const SESSION_IDLE_MS = 30 * 60_000;
export const LOCK_AFTER_FAILURES = 5;
export const LOCK_FOR_MS = 15 * 60_000;

export type LoginResult =
  | { readonly ok: true; readonly token: string; readonly email: string; readonly role: AdminRole; readonly expiresAt: Date }
  | { readonly ok: false };

export interface AuthOptions {
  readonly repo: AdminRepository;
  readonly encryptionKey: Buffer;
  readonly now?: () => number;
}

/**
 * Email + password + TOTP. Every failure looks the same to the caller (no user enumeration),
 * and the password check runs even for unknown emails so timing does not leak either.
 */
export class AdminAuth {
  readonly #o: AuthOptions;

  constructor(options: AuthOptions) {
    this.#o = options;
  }

  #now(): number {
    return (this.#o.now ?? Date.now)();
  }

  async login(email: string, password: string, code: string, ip: string | null, userAgent: string | null): Promise<LoginResult> {
    const repo = this.#o.repo;
    const user = await repo.findAdminByEmail(email.trim().toLowerCase());
    const passwordOk = await verifyPassword(password, user?.passwordHash ?? DUMMY_PASSWORD_HASH);
    if (user === null) return { ok: false };

    const now = this.#now();
    const locked = user.lockedUntil !== null && user.lockedUntil.getTime() > now;
    let step: number | undefined;
    if (passwordOk && !locked && user.disabledAt === null && user.totpSecret !== null) {
      try {
        const secret = open(user.totpSecret, this.#o.encryptionKey, `admin:${user.id}`);
        step = verifyTotp(secret, code, now, user.totpLastStep);
      } catch {
        step = undefined;
      }
    }
    if (step === undefined || locked || user.disabledAt !== null) {
      if (!locked && user.disabledAt === null) await repo.recordFailedLogin(user.id, LOCK_AFTER_FAILURES, LOCK_FOR_MS);
      await repo.audit({ adminId: user.id, action: "admin.login_failed", target: null, before: null, after: { locked }, ip });
      return { ok: false };
    }
    // Atomic: a concurrent login with the same code cannot also succeed.
    if (!(await repo.acceptLogin(user.id, step))) return { ok: false };

    const { token, hash } = newSessionToken();
    const expiresAt = new Date(now + SESSION_TTL_MS);
    await repo.createSession({ tokenHash: hash, adminId: user.id, expiresAt, ip, userAgent });
    await repo.audit({ adminId: user.id, action: "admin.login", target: null, before: null, after: null, ip });
    return { ok: true, token, email: user.email, role: user.role, expiresAt };
  }

  async authenticate(token: string | undefined): Promise<AdminSession | null> {
    if (token === undefined || !/^[A-Za-z0-9_-]{43}$/.test(token)) return null;
    return this.#o.repo.touchSession(hashSessionToken(token), SESSION_IDLE_MS);
  }

  async logout(token: string | undefined, adminId: string, ip: string | null): Promise<void> {
    if (token === undefined) return;
    await this.#o.repo.revokeSession(hashSessionToken(token));
    await this.#o.repo.audit({ adminId, action: "admin.logout", target: null, before: null, after: null, ip });
  }
}

const RANK: Record<AdminRole, number> = { viewer: 0, operator: 1, owner: 2 };
export function hasRole(actual: AdminRole, required: AdminRole): boolean {
  return RANK[actual] >= RANK[required];
}
