/** In-memory ring buffer of recent server-side errors for the admin panel. No request bodies, no PII. */
export interface ErrorEntry {
  readonly at: string;
  readonly status: number;
  readonly code: string;
  readonly route: string;
  readonly requestId: string;
}

export class ErrorLog {
  readonly #size: number;
  readonly #entries: ErrorEntry[] = [];

  constructor(size = 200) {
    this.#size = size;
  }

  push(entry: Omit<ErrorEntry, "at">, now: number = Date.now()): void {
    this.#entries.push({ ...entry, at: new Date(now).toISOString() });
    if (this.#entries.length > this.#size) this.#entries.shift();
  }

  recent(limit = 100): ErrorEntry[] {
    return this.#entries.slice(-limit).reverse();
  }

  /** Counts per code over the last `windowMs`. */
  summary(windowMs: number, now: number = Date.now()): Record<string, number> {
    const since = now - windowMs;
    const out: Record<string, number> = {};
    for (const e of this.#entries) if (Date.parse(e.at) >= since) out[e.code] = (out[e.code] ?? 0) + 1;
    return out;
  }
}
