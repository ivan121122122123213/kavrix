import { createCipheriv, createDecipheriv, createHash, createHmac, randomBytes, scrypt, timingSafeEqual } from "node:crypto";

// ---------- passwords (scrypt) ----------

const SCRYPT = { N: 32768, r: 8, p: 1, keylen: 32, maxmem: 64 * 1024 * 1024 } as const;

function scryptAsync(password: string, salt: Buffer, N: number, r: number, p: number, keylen: number): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    scrypt(password.normalize("NFKC"), salt, keylen, { N, r, p, maxmem: SCRYPT.maxmem }, (err, key) => (err ? reject(err) : resolve(key)));
  });
}

/** `$scrypt$N=32768,r=8,p=1$<salt>$<hash>` (base64url). */
export async function hashPassword(password: string): Promise<string> {
  if (password.length < 12 || password.length > 256) throw new RangeError("Password must be 12-256 characters");
  const salt = randomBytes(16);
  const key = await scryptAsync(password, salt, SCRYPT.N, SCRYPT.r, SCRYPT.p, SCRYPT.keylen);
  return `$scrypt$N=${SCRYPT.N},r=${SCRYPT.r},p=${SCRYPT.p}$${salt.toString("base64url")}$${key.toString("base64url")}`;
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const m = /^\$scrypt\$N=(\d+),r=(\d+),p=(\d+)\$([A-Za-z0-9_-]+)\$([A-Za-z0-9_-]+)$/.exec(stored);
  if (m === null || password.length > 256) return false;
  const [N, r, p] = [Number(m[1]), Number(m[2]), Number(m[3])];
  // Refuse parameters outside a sane range so a tampered row cannot be used for DoS.
  if (N < 16384 || N > 1048576 || r < 8 || r > 16 || p < 1 || p > 4) return false;
  const expected = Buffer.from(m[5] ?? "", "base64url");
  if (expected.length < 16) return false;
  const key = await scryptAsync(password, Buffer.from(m[4] ?? "", "base64url"), N, r, p, expected.length);
  return timingSafeEqual(key, expected);
}

/** Used when the email is unknown, so failed logins take the same time either way. */
export const DUMMY_PASSWORD_HASH =
  "$scrypt$N=32768,r=8,p=1$c2FsdHNhbHRzYWx0c2FsdA$o1nOCmoFhTqFqtyAqQ7r7YQ4c2yvYk5yrWL6m8wKZbk";

const PASSWORD_ALPHABET = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789";
export function generatePassword(length = 24): string {
  const out: string[] = [];
  while (out.length < length) {
    for (const b of randomBytes(length * 2)) {
      // Rejection sampling keeps the distribution uniform.
      if (b < 256 - (256 % PASSWORD_ALPHABET.length) && out.length < length) out.push(PASSWORD_ALPHABET[b % PASSWORD_ALPHABET.length] as string);
    }
  }
  return out.join("");
}

// ---------- TOTP (RFC 6238, SHA-1, 30 s, 6 digits) ----------

const B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

export function base32Encode(buf: Buffer): string {
  let bits = 0;
  let value = 0;
  let out = "";
  for (const byte of buf) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      out += B32[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) out += B32[(value << (5 - bits)) & 31];
  return out;
}

export function base32Decode(text: string): Buffer {
  const clean = text.toUpperCase().replace(/=+$/, "");
  let bits = 0;
  let value = 0;
  const out: number[] = [];
  for (const ch of clean) {
    const idx = B32.indexOf(ch);
    if (idx === -1) throw new TypeError("Invalid base32");
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) {
      out.push((value >>> (bits - 8)) & 255);
      bits -= 8;
    }
  }
  return Buffer.from(out);
}

export const TOTP_STEP_SECONDS = 30;

export function totpAt(secret: Buffer, step: number, digits = 6): string {
  const counter = Buffer.alloc(8);
  counter.writeBigUInt64BE(BigInt(step));
  const mac = createHmac("sha1", secret).update(counter).digest();
  const offset = (mac[mac.length - 1] as number) & 0x0f;
  const bin = (mac.readUInt32BE(offset) & 0x7fffffff) % 10 ** digits;
  return bin.toString().padStart(digits, "0");
}

/**
 * Accepts the current step ±1 (clock skew) and returns the matched step, which the caller must
 * store and require to increase, so each code works only once.
 */
export function verifyTotp(secret: Buffer, code: string, nowMs: number, lastStep: number | null): number | undefined {
  if (!/^\d{6}$/.test(code)) return undefined;
  const current = Math.floor(nowMs / 1000 / TOTP_STEP_SECONDS);
  let matched: number | undefined;
  for (const step of [current - 1, current, current + 1]) {
    const expected = Buffer.from(totpAt(secret, step));
    if (timingSafeEqual(expected, Buffer.from(code)) && matched === undefined) matched = step;
  }
  if (matched === undefined || (lastStep !== null && matched <= lastStep)) return undefined;
  return matched;
}

export function otpauthUri(secret: Buffer, account: string, issuer = "Kavrix"): string {
  const label = encodeURIComponent(`${issuer}:${account}`);
  return `otpauth://totp/${label}?secret=${base32Encode(secret)}&issuer=${encodeURIComponent(issuer)}&algorithm=SHA1&digits=6&period=30`;
}

// ---------- secrets at rest (AES-256-GCM) ----------

/** Derives the 32-byte key from ADMIN_ENCRYPTION_KEY (any string of ≥ 32 characters). */
export function deriveKey(material: string): Buffer {
  if (material.length < 32) throw new RangeError("ADMIN_ENCRYPTION_KEY must be at least 32 characters");
  return createHash("sha256").update(`kavrix.admin.v1|${material}`).digest();
}

/** v1 || iv(12) || tag(16) || ciphertext. `aad` binds the ciphertext to its owner (e.g. admin id). */
export function seal(plaintext: Buffer, key: Buffer, aad: string): Buffer {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  cipher.setAAD(Buffer.from(aad));
  const body = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  return Buffer.concat([Buffer.from([1]), iv, cipher.getAuthTag(), body]);
}

export function open(sealed: Buffer, key: Buffer, aad: string): Buffer {
  if (sealed.length < 1 + 12 + 16 + 1 || sealed[0] !== 1) throw new Error("Unsupported sealed value");
  const decipher = createDecipheriv("aes-256-gcm", key, sealed.subarray(1, 13));
  decipher.setAAD(Buffer.from(aad));
  decipher.setAuthTag(sealed.subarray(13, 29));
  return Buffer.concat([decipher.update(sealed.subarray(29)), decipher.final()]);
}

// ---------- session tokens ----------

export function newSessionToken(): { token: string; hash: Buffer } {
  const token = randomBytes(32).toString("base64url");
  return { token, hash: hashSessionToken(token) };
}

export function hashSessionToken(token: string): Buffer {
  return createHash("sha256").update(token).digest();
}
