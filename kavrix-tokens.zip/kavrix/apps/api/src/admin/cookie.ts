/** Minimal Cookie header reader (exact name match, bounded input). */
export function readCookie(header: string | undefined, name: string): string | undefined {
  if (header === undefined || header.length > 8192) return undefined;
  for (const part of header.split(";")) {
    const i = part.indexOf("=");
    if (i > 0 && part.slice(0, i).trim() === name) return part.slice(i + 1).trim();
  }
  return undefined;
}
