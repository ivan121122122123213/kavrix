import { z } from "zod";
import type { SupportedChainId } from "@kavrix/shared";

/** Runtime settings editable in the admin panel. Anything not listed here cannot be read or written via the API. */
export const SETTING_KEYS = ["swap.enabled", "swap.fee_bps_by_chain", "swap.quote_rate_per_minute", "ramp.enabled", "ramp.buy_limits"] as const;
export type SettingKey = (typeof SETTING_KEYS)[number];

const chainKey = z.string().regex(/^(1|8453|42161|137)$/);
const bps = z.number().int().min(0).max(300);

export const SETTING_SCHEMAS: { readonly [K in SettingKey]: z.ZodType } = {
  "swap.enabled": z.boolean(),
  "swap.fee_bps_by_chain": z.record(chainKey, bps),
  "swap.quote_rate_per_minute": z.number().int().min(5).max(600),
  "ramp.enabled": z.object({ moonpay: z.boolean(), transak: z.boolean() }).strict(),
  "ramp.buy_limits": z
    .object({ min: z.number().min(1).max(100_000), max: z.number().min(1).max(1_000_000) })
    .strict()
    .refine((v) => v.min < v.max, "min must be below max"),
};

export interface RuntimeSnapshot {
  readonly swapEnabled: boolean;
  readonly feeBpsByChain: Readonly<Partial<Record<SupportedChainId, number>>>;
  readonly quoteRatePerMinute: number;
  readonly rampEnabled: { readonly moonpay: boolean; readonly transak: boolean };
  readonly buyLimits: { readonly min: number; readonly max: number };
}

export interface SettingsSource {
  snapshot(): Promise<RuntimeSnapshot>;
}

export const DEFAULT_SNAPSHOT: RuntimeSnapshot = {
  swapEnabled: true,
  feeBpsByChain: {},
  quoteRatePerMinute: 30,
  rampEnabled: { moonpay: true, transak: true },
  buyLimits: { min: 20, max: 5000 },
};

/**
 * Builds a snapshot from stored values. Invalid kill-switch values fail closed (disabled);
 * other invalid values fall back to defaults. Returns the keys that were invalid for logging.
 */
export function buildSnapshot(values: ReadonlyMap<string, unknown>): { snapshot: RuntimeSnapshot; invalid: string[] } {
  const invalid: string[] = [];
  const read = <T>(key: SettingKey, fallback: T): T => {
    if (!values.has(key)) return fallback;
    const parsed = SETTING_SCHEMAS[key].safeParse(values.get(key));
    if (parsed.success) return parsed.data as T;
    invalid.push(key);
    return fallback;
  };
  const fees = read<Record<string, number>>("swap.fee_bps_by_chain", {});
  return {
    snapshot: {
      swapEnabled: read("swap.enabled", false),
      feeBpsByChain: Object.fromEntries(Object.entries(fees).map(([k, v]) => [Number(k), v])) as Partial<Record<SupportedChainId, number>>,
      quoteRatePerMinute: read("swap.quote_rate_per_minute", DEFAULT_SNAPSHOT.quoteRatePerMinute),
      rampEnabled: read("ramp.enabled", { moonpay: false, transak: false }),
      buyLimits: read("ramp.buy_limits", DEFAULT_SNAPSHOT.buyLimits),
    },
    invalid,
  };
}

/** Settings validation that depends on deployment config (e.g. a fee needs a recipient). */
export function validateSetting(key: string, value: unknown, ctx: { hasFeeRecipient: boolean }): { ok: true } | { ok: false; message: string } {
  if (!(SETTING_KEYS as readonly string[]).includes(key)) return { ok: false, message: "Unknown setting" };
  const parsed = SETTING_SCHEMAS[key as SettingKey].safeParse(value);
  if (!parsed.success) return { ok: false, message: parsed.error.issues.map((i) => `${i.path.join(".") || key}: ${i.message}`).join("; ") };
  if (key === "swap.fee_bps_by_chain" && !ctx.hasFeeRecipient && Object.values(value as Record<string, number>).some((v) => v > 0)) {
    return { ok: false, message: "Set PLATFORM_FEE_RECIPIENT before charging a fee" };
  }
  return { ok: true };
}

/** Caches the snapshot briefly; if the store is unreachable, serves the last good snapshot for up to a minute. */
export class CachedSettings implements SettingsSource {
  readonly #load: () => Promise<ReadonlyMap<string, unknown>>;
  readonly #onInvalid: (keys: string[]) => void;
  readonly #now: () => number;
  #cached: { at: number; snapshot: RuntimeSnapshot } | undefined;
  #inflight: Promise<RuntimeSnapshot> | undefined;

  constructor(load: () => Promise<ReadonlyMap<string, unknown>>, onInvalid: (keys: string[]) => void, now: () => number = Date.now) {
    this.#load = load;
    this.#onInvalid = onInvalid;
    this.#now = now;
  }

  invalidate(): void {
    this.#cached = undefined;
  }

  async snapshot(): Promise<RuntimeSnapshot> {
    const now = this.#now();
    if (this.#cached !== undefined && now - this.#cached.at < 5_000) return this.#cached.snapshot;
    this.#inflight ??= this.#load()
      .then((values) => {
        const { snapshot, invalid } = buildSnapshot(values);
        if (invalid.length > 0) this.#onInvalid(invalid);
        this.#cached = { at: this.#now(), snapshot };
        return snapshot;
      })
      .catch((err: unknown) => {
        if (this.#cached !== undefined && this.#now() - this.#cached.at < 60_000) return this.#cached.snapshot;
        throw err;
      })
      .finally(() => {
        this.#inflight = undefined;
      });
    return this.#inflight;
  }
}

export function staticSettings(snapshot: RuntimeSnapshot = DEFAULT_SNAPSHOT): SettingsSource {
  return { snapshot: async () => snapshot };
}
