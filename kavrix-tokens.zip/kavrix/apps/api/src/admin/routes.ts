import type { FastifyInstance, FastifyReply, FastifyRequest } from "fastify";
import { CHAINS, RAMP_STATUSES, SWAP_STATUSES, isSupportedChainId, normalizeAddress, type RampStatus, type SupportedChainId, type SwapStatus } from "@kavrix/shared";
import type { AdminRepository, AdminRole, AdminSession, RampRecord, SwapRecord } from "@kavrix/db";
import { HttpProblem } from "../problem.ts";
import { AdminAuth, SESSION_TTL_MS, hasRole } from "./auth.ts";
import type { ErrorLog } from "./error-log.ts";
import { SETTING_KEYS, validateSetting } from "./settings.ts";
import { readCookie } from "./cookie.ts";

declare module "fastify" {
  interface FastifyRequest {
    admin: AdminSession | null;
  }
}

export const ADMIN_COOKIE = "__Host-kavrix_admin";
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export interface HealthReport {
  readonly database: "ok" | "fail";
  readonly rpc: Readonly<Record<string, { ok: boolean; block?: string; latencyMs?: number }>>;
  readonly tracker: { readonly enabled: boolean; readonly lastTickAt: string | null; readonly backlog: number | null };
  readonly providers: Readonly<Record<string, { configured: boolean; lastWebhookAt?: string | null }>>;
}

export type AdminDeps = {
  readonly repo: AdminRepository;
  readonly auth: AdminAuth;
  readonly publicOrigin: string;
  readonly hasFeeRecipient: boolean;
  readonly errors: ErrorLog;
  readonly health: () => Promise<HealthReport>;
  /** Reads `decimals()` from the contract; null when the address has no ERC-20 code. */
  readonly tokenDecimals: (chainId: SupportedChainId, address: `0x${string}`) => Promise<number | null>;
  readonly onSettingsChanged: () => void;
};

function sessionCookie(token: string, maxAgeSeconds: number): string {
  return `${ADMIN_COOKIE}=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${maxAgeSeconds}`;
}

function cursor(raw: string | undefined): { createdAt: Date; id: string } | undefined {
  if (raw === undefined) return undefined;
  const [ts, id] = raw.split("_");
  const createdAt = new Date(ts ?? "");
  if (Number.isNaN(createdAt.getTime()) || id === undefined || !UUID.test(id)) throw new HttpProblem(400, "INVALID_CURSOR", "Invalid cursor");
  return { createdAt, id };
}

const swapRow = (s: SwapRecord) => ({
  id: s.id, status: s.status, provider: s.provider, chainId: s.chainId, taker: s.taker, sellToken: s.sellToken, buyToken: s.buyToken,
  sellAmount: s.sellAmount.toString(), quotedBuyAmount: s.quotedBuyAmount.toString(), actualBuyAmount: s.actualBuyAmount?.toString() ?? null,
  platformFeeBps: s.platformFeeBps, platformFeeAmount: s.platformFeeAmount.toString(), txHash: s.txHash, failureCode: s.failureCode,
  createdAt: s.createdAt.toISOString(),
});

const rampRow = (r: RampRecord) => ({
  id: r.id, provider: r.provider, direction: r.direction, chainId: r.chainId, wallet: r.walletAddress, cryptoCurrency: r.cryptoCurrency,
  fiatCurrency: r.fiatCurrency, fiatAmount: r.fiatAmount, cryptoAmount: r.cryptoAmount, status: r.status, providerStatus: r.providerStatus,
  externalOrderId: r.externalOrderId, createdAt: r.createdAt.toISOString(),
});

export async function adminRoutes(app: FastifyInstance, deps: AdminDeps): Promise<void> {
  app.decorateRequest("admin", null);

  // Every admin response is private and uncacheable.
  app.addHook("onSend", async (_req, reply) => {
    reply.header("cache-control", "no-store");
  });

  // CSRF: state-changing requests must come from our own origin and carry a header a form cannot set.
  app.addHook("preValidation", async (req) => {
    if (req.method === "GET" || req.method === "HEAD") return;
    if (req.headers.origin !== deps.publicOrigin || req.headers["x-kavrix-admin"] !== "1") {
      throw new HttpProblem(403, "CSRF_REJECTED", "Request rejected");
    }
  });

  app.addHook("preHandler", async (req) => {
    if (req.routeOptions.url === "/admin/session" && req.method === "POST") return;
    req.admin = await deps.auth.authenticate(readCookie(req.headers.cookie, ADMIN_COOKIE));
    if (req.admin === null) throw new HttpProblem(401, "UNAUTHENTICATED", "Sign in required");
  });

  const requireRole = (req: FastifyRequest, role: AdminRole): AdminSession => {
    const a = req.admin;
    if (a === null) throw new HttpProblem(401, "UNAUTHENTICATED", "Sign in required");
    if (!hasRole(a.role, role)) throw new HttpProblem(403, "FORBIDDEN", "Insufficient role");
    return a;
  };

  app.post<{ Body: { email: string; password: string; code: string } }>(
    "/admin/session",
    {
      config: { rateLimit: { max: 10, timeWindow: "15 minutes" } },
      schema: {
        body: {
          type: "object",
          additionalProperties: false,
          required: ["email", "password", "code"],
          properties: {
            email: { type: "string", maxLength: 254 },
            password: { type: "string", maxLength: 256 },
            code: { type: "string", pattern: "^[0-9]{6}$" },
          },
        },
      },
    },
    async (req, reply: FastifyReply) => {
      const result = await deps.auth.login(req.body.email, req.body.password, req.body.code, req.ip, req.headers["user-agent"] ?? null);
      if (!result.ok) throw new HttpProblem(401, "INVALID_CREDENTIALS", "Invalid email, password or code");
      return reply
        .header("set-cookie", sessionCookie(result.token, Math.floor(SESSION_TTL_MS / 1000)))
        .send({ email: result.email, role: result.role, expiresAt: result.expiresAt.toISOString() });
    },
  );

  app.delete("/admin/session", async (req, reply) => {
    const a = requireRole(req, "viewer");
    await deps.auth.logout(readCookie(req.headers.cookie, ADMIN_COOKIE), a.adminId, req.ip);
    return reply.header("set-cookie", sessionCookie("", 0)).send({ ok: true });
  });

  app.get("/admin/me", async (req) => {
    const a = requireRole(req, "viewer");
    return { email: a.email, role: a.role, expiresAt: a.expiresAt.toISOString() };
  });

  app.get<{ Querystring: { days?: number } }>(
    "/admin/stats",
    { schema: { querystring: { type: "object", additionalProperties: false, properties: { days: { type: "integer", minimum: 1, maximum: 365 } } } } },
    async (req) => {
      requireRole(req, "viewer");
      const s = await deps.repo.stats(req.query.days ?? 30);
      return {
        swapsByStatus: s.swapsByStatus,
        confirmedVolume: s.confirmedVolume.map((v) => ({ ...v, amount: v.amount.toString() })),
        feeRevenue: s.feeRevenue.map((v) => ({ ...v, amount: v.amount.toString() })),
        rampByStatus: s.rampByStatus,
        dailyConfirmed: s.dailyConfirmed,
      };
    },
  );

  app.get<{ Querystring: { status?: string; chainId?: number; before?: string } }>(
    "/admin/swaps",
    {
      schema: {
        querystring: {
          type: "object",
          additionalProperties: false,
          properties: { status: { enum: [...SWAP_STATUSES] }, chainId: { type: "integer" }, before: { type: "string", maxLength: 128 } },
        },
      },
    },
    async (req) => {
      requireRole(req, "viewer");
      const chainId = req.query.chainId;
      if (chainId !== undefined && !isSupportedChainId(chainId)) throw new HttpProblem(400, "UNSUPPORTED_CHAIN", "Unsupported chain");
      const before = cursor(req.query.before);
      const rows = await deps.repo.listSwaps({
        limit: 50,
        ...(req.query.status === undefined ? {} : { status: req.query.status as SwapStatus }),
        ...(chainId === undefined ? {} : { chainId }),
        ...(before === undefined ? {} : { before }),
      });
      const last = rows.at(-1);
      return { swaps: rows.map(swapRow), nextCursor: rows.length === 50 && last ? `${last.createdAt.toISOString()}_${last.id}` : null };
    },
  );

  app.get<{ Querystring: { status?: string; provider?: string; before?: string } }>(
    "/admin/ramp-orders",
    {
      schema: {
        querystring: {
          type: "object",
          additionalProperties: false,
          properties: { status: { enum: [...RAMP_STATUSES] }, provider: { enum: ["moonpay", "transak"] }, before: { type: "string", maxLength: 128 } },
        },
      },
    },
    async (req) => {
      requireRole(req, "viewer");
      const before = cursor(req.query.before);
      const rows = await deps.repo.listRampOrders({
        limit: 50,
        ...(req.query.status === undefined ? {} : { status: req.query.status as RampStatus }),
        ...(req.query.provider === undefined ? {} : { provider: req.query.provider }),
        ...(before === undefined ? {} : { before }),
      });
      const last = rows.at(-1);
      return { orders: rows.map(rampRow), nextCursor: rows.length === 50 && last ? `${last.createdAt.toISOString()}_${last.id}` : null };
    },
  );

  app.get("/admin/tokens", async (req) => {
    requireRole(req, "viewer");
    return { tokens: await deps.repo.listAllTokens() };
  });

  app.patch<{ Params: { chainId: string; address: string }; Body: { enabled: boolean } }>(
    "/admin/tokens/:chainId/:address",
    {
      schema: {
        params: { type: "object", required: ["chainId", "address"], properties: { chainId: { type: "string", pattern: "^[0-9]{1,6}$" }, address: { type: "string", pattern: "^0x[0-9a-fA-F]{40}$" } } },
        body: { type: "object", additionalProperties: false, required: ["enabled"], properties: { enabled: { type: "boolean" } } },
      },
    },
    async (req) => {
      const a = requireRole(req, "operator");
      const chainId = Number(req.params.chainId);
      if (!isSupportedChainId(chainId)) throw new HttpProblem(400, "UNSUPPORTED_CHAIN", "Unsupported chain");
      const row = await deps.repo.setTokenEnabled(chainId, normalizeAddress(req.params.address), req.body.enabled, { adminId: a.adminId, ip: req.ip });
      if (row === null) throw new HttpProblem(404, "NOT_FOUND", "Token not found");
      return row;
    },
  );

  app.post<{ Body: { chainId: number; address: string; symbol: string; name: string; decimals: number } }>(
    "/admin/tokens",
    {
      schema: {
        body: {
          type: "object",
          additionalProperties: false,
          required: ["chainId", "address", "symbol", "name", "decimals"],
          properties: {
            chainId: { type: "integer" },
            address: { type: "string", pattern: "^0x[0-9a-fA-F]{40}$" },
            symbol: { type: "string", pattern: "^[A-Za-z0-9.]{1,16}$" },
            name: { type: "string", minLength: 1, maxLength: 64 },
            decimals: { type: "integer", minimum: 0, maximum: 36 },
          },
        },
      },
    },
    async (req, reply) => {
      const a = requireRole(req, "owner");
      const { chainId } = req.body;
      if (!isSupportedChainId(chainId)) throw new HttpProblem(400, "UNSUPPORTED_CHAIN", "Unsupported chain");
      const address = normalizeAddress(req.body.address);
      // Fail closed: the contract must exist and report the same decimals that will be used for amounts.
      const onChain = await deps.tokenDecimals(chainId, address);
      if (onChain === null) throw new HttpProblem(422, "NOT_A_TOKEN", "No ERC-20 contract at this address", `Checked on ${CHAINS[chainId].name}.`);
      if (onChain !== req.body.decimals) {
        throw new HttpProblem(422, "DECIMALS_MISMATCH", "Decimals do not match the contract", `The contract reports ${onChain}.`);
      }
      const result = await deps.repo.addToken(
        { chainId, address, symbol: req.body.symbol.toUpperCase(), name: req.body.name.trim(), decimals: req.body.decimals },
        { adminId: a.adminId, ip: req.ip },
      );
      if (result === "exists") throw new HttpProblem(409, "TOKEN_EXISTS", "Token already listed");
      return reply.code(201).send({ added: true, enabled: false });
    },
  );

  app.get("/admin/settings", async (req) => {
    requireRole(req, "viewer");
    const rows = await deps.repo.listSettings(SETTING_KEYS);
    return { settings: rows.map((r) => ({ key: r.key, value: r.value, version: r.version, updatedAt: r.updatedAt.toISOString() })) };
  });

  app.put<{ Params: { key: string }; Body: { value: unknown; version: number } }>(
    "/admin/settings/:key",
    {
      schema: {
        params: { type: "object", required: ["key"], properties: { key: { type: "string", maxLength: 64 } } },
        body: { type: "object", additionalProperties: false, required: ["value", "version"], properties: { value: {}, version: { type: "integer", minimum: 1 } } },
      },
    },
    async (req) => {
      const a = requireRole(req, "owner");
      const check = validateSetting(req.params.key, req.body.value, { hasFeeRecipient: deps.hasFeeRecipient });
      if (!check.ok) throw new HttpProblem(422, "INVALID_SETTING", "Invalid setting", check.message);
      const result = await deps.repo.updateSetting(req.params.key, req.body.value, req.body.version, { adminId: a.adminId, ip: req.ip });
      if (result === "not_found") throw new HttpProblem(404, "NOT_FOUND", "Setting not found");
      if (result === "version_conflict") throw new HttpProblem(409, "VERSION_CONFLICT", "Setting was changed by someone else", "Reload and try again.");
      deps.onSettingsChanged();
      return { updated: true };
    },
  );

  app.get<{ Querystring: { before?: string } }>(
    "/admin/audit",
    { schema: { querystring: { type: "object", additionalProperties: false, properties: { before: { type: "string", pattern: "^[0-9]{1,18}$" } } } } },
    async (req) => {
      requireRole(req, "viewer");
      const rows = await deps.repo.listAudit(100, req.query.before);
      return {
        entries: rows.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() })),
        nextCursor: rows.length === 100 ? (rows.at(-1)?.id ?? null) : null,
      };
    },
  );

  app.get("/admin/health", async (req) => {
    requireRole(req, "viewer");
    return { ...(await deps.health()), errorsLastHour: deps.errors.summary(60 * 60_000) };
  });

  app.get("/admin/errors", async (req) => {
    requireRole(req, "viewer");
    return { errors: deps.errors.recent(100) };
  });
}
