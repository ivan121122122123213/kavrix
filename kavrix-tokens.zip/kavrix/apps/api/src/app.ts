import { randomUUID } from "node:crypto";
import Fastify, { type FastifyError, type FastifyInstance } from "fastify";
import cors from "@fastify/cors";
import helmet from "@fastify/helmet";
import rateLimit from "@fastify/rate-limit";
import { featureFlags, type Config } from "./config.ts";
import { HttpProblem, problem } from "./problem.ts";
import { isDatabaseUnavailable } from "./db-errors.ts";
import { healthRoutes } from "./routes/health.ts";
import { metaRoutes, type MetaDeps } from "./routes/meta.ts";
import { rpcRoutes } from "./routes/rpc.ts";
import { swapRoutes } from "./routes/swap.ts";
import type { SwapProvider } from "@kavrix/integrations";
import type { RampRepository, SwapRepository } from "@kavrix/db";
import { rampRoutes, type RampDeps } from "./routes/ramp.ts";
import { CHAINS, isSupportedChainId, type SupportedChainId } from "@kavrix/shared";
import { swapsRoutes, type TokenMeta } from "./routes/swaps.ts";
import { staticSettings, type SettingsSource } from "./admin/settings.ts";
import { ErrorLog } from "./admin/error-log.ts";
import { adminRoutes, type AdminDeps } from "./admin/routes.ts";

export interface AppDeps {
  readonly config: Config;
  readonly pingDatabase: () => Promise<boolean>;
  readonly listTokens: MetaDeps["listTokens"];
  readonly swapProvider: SwapProvider | undefined;
  readonly swapRepo: SwapRepository;
  readonly rampRepo: RampRepository;
  readonly moonpay?: RampDeps["moonpay"];
  readonly transak?: RampDeps["transak"];
  /** HMAC key for firm-quote tokens. */
  readonly quoteKey: Buffer;
  readonly rpcFetch?: typeof fetch;
  /** Runtime settings; defaults to static values when absent (tests, admin disabled). */
  readonly settings?: SettingsSource;
  readonly errors?: ErrorLog;
  /** Admin panel; omitted when ADMIN_ENCRYPTION_KEY is not configured. */
  readonly admin?: Omit<AdminDeps, "publicOrigin" | "hasFeeRecipient" | "errors">;
  readonly version: string;
}

/** Header and body paths that may carry credentials; pino replaces them before serialization. */
export const REDACT_PATHS = [
  "req.headers.authorization",
  "req.headers.cookie",
  'req.headers["x-api-key"]',
  'req.headers["0x-api-key"]',
  'req.headers["moonpay-signature-v2"]',
  'req.headers["moonpay-signature"]',
  'res.headers["set-cookie"]',
  "*.apiKey",
  "*.apiSecret",
  "*.secretKey",
  "*.accessToken",
  "*.password",
  "*.token",
];

export async function buildApp(deps: AppDeps): Promise<FastifyInstance> {
  const { config } = deps;
  const settings = deps.settings ?? staticSettings();
  const errors = deps.errors ?? new ErrorLog();
  const hasFeeRecipient = config.PLATFORM_FEE_RECIPIENT !== undefined;
  const swapEnabled = async () => (await settings.snapshot()).swapEnabled;
  const app = Fastify({
    logger: {
      level: config.NODE_ENV === "test" ? "silent" : config.LOG_LEVEL,
      redact: { paths: REDACT_PATHS, censor: "[redacted]" },
      serializers: {
        // Query strings are dropped: they carry wallet addresses and amounts.
        req: (req: { method?: string | undefined; url?: string | undefined }) => ({
          method: req.method,
          path: req.url?.split("?")[0],
        }),
      },
    },
    genReqId: () => randomUUID(),
    requestIdHeader: false,
    trustProxy: config.TRUST_PROXY_HOPS,
    bodyLimit: 64 * 1024,
    return503OnClosing: true,
  });

  app.addHook("onSend", async (req, reply) => {
    reply.header("x-request-id", req.id);
  });

  await app.register(helmet, {
    // JSON API: nothing here should ever be rendered as a document.
    contentSecurityPolicy: { directives: { defaultSrc: ["'none'"], frameAncestors: ["'none'"] } },
    crossOriginResourcePolicy: { policy: "same-site" },
    hsts: config.NODE_ENV === "production" ? { maxAge: 31_536_000, includeSubDomains: true } : false,
  });
  await app.register(cors, {
    origin: [config.PUBLIC_WEB_ORIGIN],
    methods: ["GET", "POST"],
    credentials: false,
    maxAge: 600,
  });
  await app.register(rateLimit, {
    max: config.RATE_LIMIT_PER_MINUTE,
    timeWindow: "1 minute",
    errorResponseBuilder: (_req, ctx) => ({
      statusCode: 429,
      code: "RATE_LIMITED",
      message: `Retry after ${Math.ceil(ctx.ttl / 1000)}s`,
    }),
  });

  app.setErrorHandler((error: FastifyError | HttpProblem, req, reply) => {
    const route = req.routeOptions.url ?? "unmatched";
    if (error instanceof HttpProblem) {
      if (error.status >= 500) errors.push({ status: error.status, code: error.code, route, requestId: req.id });
      return reply
        .code(error.status)
        .type("application/problem+json")
        .send(problem(error.status, error.code, error.message, req.id, error.detail));
    }
    if (error.validation !== undefined) {
      return reply
        .code(400)
        .type("application/problem+json")
        .send(problem(400, "INVALID_REQUEST", "Request validation failed", req.id, error.message));
    }
    if (isDatabaseUnavailable(error)) {
      errors.push({ status: 503, code: "DATABASE_UNAVAILABLE", route, requestId: req.id });
      req.log.error({ code: (error as { code?: unknown }).code }, "database unavailable");
      return reply
        .code(503)
        .header("retry-after", "5")
        .type("application/problem+json")
        .send(problem(503, "DATABASE_UNAVAILABLE", "Service temporarily unavailable", req.id, "Kavrix cannot reach its database. Nothing was changed. Retry shortly."));
    }
    const status = typeof error.statusCode === "number" && error.statusCode >= 400 ? error.statusCode : 500;
    if (status === 429) {
      return reply
        .code(429)
        .type("application/problem+json")
        .send(problem(429, "RATE_LIMITED", "Too many requests", req.id, error.message));
    }
    if (status >= 500) {
      errors.push({ status: 500, code: "INTERNAL", route, requestId: req.id });
      req.log.error({ err: error }, "unhandled error");
      return reply
        .code(500)
        .type("application/problem+json")
        .send(problem(500, "INTERNAL", "Internal error", req.id));
    }
    return reply
      .code(status)
      .type("application/problem+json")
      .send(problem(status, error.code ?? "BAD_REQUEST", "Request rejected", req.id));
  });

  app.setNotFoundHandler((req, reply) =>
    reply.code(404).type("application/problem+json").send(problem(404, "NOT_FOUND", "Not found", req.id)),
  );

  await app.register(healthRoutes, { pingDatabase: deps.pingDatabase, version: deps.version });
  await app.register(metaRoutes, { features: featureFlags(config), config, listTokens: deps.listTokens, settings, hasFeeRecipient });
  if (deps.swapProvider !== undefined) {
    await app.register(swapRoutes, {
      provider: deps.swapProvider,
      feeFor: async (chainId) => {
        const bps = (await settings.snapshot()).feeBpsByChain[chainId] ?? config.PLATFORM_FEE_BPS;
        return bps > 0 && config.PLATFORM_FEE_RECIPIENT !== undefined ? { recipient: config.PLATFORM_FEE_RECIPIENT, bps } : undefined;
      },
      swapEnabled,
      quoteRatePerMinute: async () => (await settings.snapshot()).quoteRatePerMinute,
      quoteTtlSeconds: config.QUOTE_TTL_SECONDS,
      listTokens: deps.listTokens,
      quoteKey: deps.quoteKey,
    });
  }
  await app.register(rampRoutes, {
    repo: deps.rampRepo,
    moonpay: deps.moonpay,
    transak: deps.transak,
    publicOrigin: config.PUBLIC_WEB_ORIGIN,
    listTokens: deps.listTokens,
    settings,
  });
  await app.register(swapsRoutes, { repo: deps.swapRepo, quoteKey: deps.quoteKey, tokenMeta: tokenMetaLookup(deps.listTokens), swapEnabled });
  if (deps.admin !== undefined) {
    await app.register(adminRoutes, { ...deps.admin, publicOrigin: config.PUBLIC_WEB_ORIGIN, hasFeeRecipient, errors });
  }
  await app.register(rpcRoutes, {
    urls: { 1: config.RPC_URL_1, 8453: config.RPC_URL_8453, 42161: config.RPC_URL_42161, 137: config.RPC_URL_137 },
    ...(deps.rpcFetch === undefined ? {} : { fetch: deps.rpcFetch }),
  });
  return app;
}

/** Token symbol/decimals for display, cached per chain for a minute. */
function tokenMetaLookup(listTokens: MetaDeps["listTokens"]) {
  const cache = new Map<SupportedChainId, { at: number; map: Map<string, TokenMeta> }>();
  return async (chainId: SupportedChainId, address: string): Promise<TokenMeta | undefined> => {
    if (!isSupportedChainId(chainId) || CHAINS[chainId] === undefined) return undefined;
    let entry = cache.get(chainId);
    if (entry === undefined || Date.now() - entry.at > 60_000) {
      const rows = await listTokens(chainId);
      entry = { at: Date.now(), map: new Map(rows.map((r) => [r.address.toLowerCase(), { symbol: r.symbol, decimals: r.decimals }])) };
      cache.set(chainId, entry);
    }
    return entry.map.get(address.toLowerCase());
  };
}
