import { createHash } from "node:crypto";
import { CHAINS, NATIVE_TOKEN_ADDRESS } from "@kavrix/shared";
import type { SwapRecord, SwapRepository, ChainCheckUpdate } from "@kavrix/db";
import type { ChainReaders, ChainReceipt, ChainTx } from "../chain/reader.ts";

/** keccak256("Transfer(address,address,uint256)") */
export const ERC20_TRANSFER_TOPIC = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef";

export interface TrackerOptions {
  readonly repo: SwapRepository;
  readonly readers: ChainReaders;
  readonly now?: () => number;
  readonly log?: { warn: (obj: object, msg: string) => void; info: (obj: object, msg: string) => void };
  /** A submitted hash the network has never seen for this long is marked "dropped". */
  readonly dropAfterMs?: number;
  /** Dropped swaps are re-checked for this long, then tracking stops (status stays "dropped"). */
  readonly giveUpAfterMs?: number;
  /** Quotes are expired only after the router's transaction deadline (10 min) has also passed. */
  readonly quoteGraceMs?: number;
  readonly batchSize?: number;
}

const POLL_MS: Record<number, number> = { 1: 12_000, 8453: 4_000, 42161: 4_000, 137: 4_000 };
const RETRY_AFTER_ERROR_MS = 30_000;
const DROPPED_POLL_MS = 60_000;

/** Proves that the on-chain transaction is exactly the one Kavrix prepared for this swap. */
export function matchesRecord(tx: ChainTx, rec: SwapRecord): boolean {
  return (
    tx.from === rec.taker &&
    tx.to === rec.txTo &&
    tx.value === rec.txValue &&
    createHash("sha256").update(Buffer.from(tx.input.slice(2), "hex")).digest("hex") === rec.txDataSha256
  );
}

/** Output received, from ERC-20 Transfer logs of the buy token to the taker; null for native coin output. */
export function receivedAmount(receipt: ChainReceipt, rec: SwapRecord): bigint | null {
  if (rec.buyToken === NATIVE_TOKEN_ADDRESS) return null;
  const toTopic = `0x${rec.taker.slice(2).padStart(64, "0")}`;
  let total = 0n;
  for (const log of receipt.logs) {
    if (log.address === rec.buyToken && log.topics[0] === ERC20_TRANSFER_TOPIC && log.topics[2] === toTopic && log.data.length === 66) {
      total += BigInt(log.data);
    }
  }
  return total;
}

export class SwapTracker {
  readonly #o: Required<Omit<TrackerOptions, "log">> & Pick<TrackerOptions, "log">;

  constructor(options: TrackerOptions) {
    this.#o = {
      now: Date.now,
      dropAfterMs: 10 * 60_000,
      giveUpAfterMs: 24 * 60 * 60_000,
      quoteGraceMs: 15 * 60_000,
      batchSize: 25,
      ...options,
    };
  }

  /** One pass: expire stale quotes, then check every due swap. Returns the number of swaps checked. */
  async tick(): Promise<number> {
    const now = this.#o.now();
    await this.#o.repo.expireQuoted(new Date(now - this.#o.quoteGraceMs));
    const due = await this.#o.repo.claimDue(this.#o.batchSize, RETRY_AFTER_ERROR_MS);
    for (const rec of due) {
      let update: ChainCheckUpdate;
      try {
        update = await this.check(rec);
      } catch (err) {
        this.#o.log?.warn({ swapId: rec.id, chainId: rec.chainId, reason: err instanceof Error ? err.message : "unknown" }, "swap check failed");
        update = { nextCheckAt: new Date(this.#o.now() + RETRY_AFTER_ERROR_MS) };
      }
      await this.#o.repo.applyCheck(rec.id, update);
      if (update.status !== undefined) this.#o.log?.info({ swapId: rec.id, status: update.status }, "swap status changed");
    }
    return due.length;
  }

  async check(rec: SwapRecord): Promise<ChainCheckUpdate> {
    const now = this.#o.now();
    const poll = POLL_MS[rec.chainId] ?? 12_000;
    if (rec.txHash === null) return { nextCheckAt: null };
    const reader = this.#o.readers[rec.chainId];
    const age = now - (rec.submittedAt?.getTime() ?? now);

    const tx = await reader.getTransaction(rec.txHash);
    if (tx === null) {
      if (rec.status === "submitted" && age > this.#o.dropAfterMs) return { status: "dropped", nextCheckAt: new Date(now + DROPPED_POLL_MS) };
      if (rec.status === "dropped") return { nextCheckAt: age > this.#o.giveUpAfterMs ? null : new Date(now + DROPPED_POLL_MS) };
      return { nextCheckAt: new Date(now + poll) };
    }
    if (!matchesRecord(tx, rec)) return { status: "failed", failureCode: "TX_MISMATCH", nextCheckAt: null };

    const receipt = await reader.getReceipt(rec.txHash);
    if (receipt === null) return { nextCheckAt: new Date(now + poll) };
    const head = await reader.blockNumber();
    const depth = head >= receipt.blockNumber ? Number(head - receipt.blockNumber + 1n) : 0;
    const required = CHAINS[rec.chainId].confirmations;
    if (depth < required) return { blockNumber: receipt.blockNumber, confirmations: depth, nextCheckAt: new Date(now + poll) };

    if (receipt.status === "reverted") {
      return { status: "reverted", blockNumber: receipt.blockNumber, confirmations: depth, nextCheckAt: null };
    }
    const received = receivedAmount(receipt, rec);
    return {
      status: "confirmed",
      blockNumber: receipt.blockNumber,
      confirmations: depth,
      ...(received === null ? {} : { actualBuyAmount: received }),
      nextCheckAt: null,
    };
  }
}

/** Runs ticks back to back with a pause, never overlapping; `stop` waits for the current tick. */
export function startTracker(
  tracker: SwapTracker,
  intervalMs: number,
  onError: (err: unknown) => void,
): { stop: () => Promise<void>; lastTickAt: () => Date | null } {
  let stopped = false;
  let last: Date | null = null;
  let timer: NodeJS.Timeout | undefined;
  let running: Promise<void> = Promise.resolve();
  const loop = () => {
    running = tracker
      .tick()
      .then(() => {
        last = new Date();
      }, onError)
      .finally(() => {
        if (!stopped) timer = setTimeout(loop, intervalMs);
      });
  };
  timer = setTimeout(loop, intervalMs);
  return {
    lastTickAt: () => last,
    async stop() {
      stopped = true;
      clearTimeout(timer);
      await running;
    },
  };
}
