import { readFileSync } from "node:fs";
import { z } from "zod";

const SECRET_VARS = [
  "DATABASE_URL",
  "ZEROEX_API_KEY",
  "KYBERSWAP_API_KEY",
  "QUOTE_SIGNING_KEY",
  "ADMIN_ENCRYPTION_KEY",
  "MOONPAY_SECRET_KEY",
  "MOONPAY_WEBHOOK_KEY",
  "TRANSAK_API_SECRET",
  // RPC URLs often embed provider API keys.
  "RPC_URL_1",
  "RPC_URL_8453",
  "RPC_URL_42161",
  "RPC_URL_137",
] as const;

const address = z
  .string()
  .regex(/^0x[0-9a-fA-F]{40}$/, "must be an EVM address")
  .transform((v) => v.toLowerCase() as `0x${string}`);
const httpsUrl = z
  .string()
  .url()
  .refine((v) => v.startsWith("https://"), "must use https");
const optionalNonEmpty = z
  .string()
  .optional()
  .transform((v) => (v === undefined || v.trim() === "" ? undefined : v.trim()));

const schema = z
  .object({
    NODE_ENV: z.enum(["production", "development", "test"]).default("development"),
    HOST: z.string().default("0.0.0.0"),
    PORT: z.coerce.number().int().min(1).max(65_535).default(3000),
    LOG_LEVEL: z.enum(["fatal", "error", "warn", "info", "debug", "trace"]).default("info"),
    TRUST_PROXY_HOPS: z.coerce.number().int().min(0).max(5).default(1),
    PUBLIC_WEB_ORIGIN: z.string().url(),
    DATABASE_URL: z.string().regex(/^postgres(ql)?:\/\//, "must be a postgres:// URL"),
    DATABASE_MAX_CONNECTIONS: z.coerce.number().int().min(1).max(100).default(10),
    RATE_LIMIT_PER_MINUTE: z.coerce.number().int().min(10).max(10_000).default(120),

    /** Quote provider. KyberSwap needs no key; 0x needs ZEROEX_API_KEY. */
    SWAP_PROVIDER: z.enum(["kyberswap", "0x"]).default("kyberswap"),
    KYBERSWAP_CLIENT_ID: z.string().regex(/^[A-Za-z0-9_-]{2,64}$/).default("kavrix"),
    KYBERSWAP_API_KEY: optionalNonEmpty,
    ZEROEX_API_KEY: optionalNonEmpty,
    /** HMAC key for firm-quote tokens (≥32 chars). Required in production; random per process otherwise. */
    QUOTE_SIGNING_KEY: optionalNonEmpty.pipe(z.string().min(32).optional()),
    /** Encrypts admin TOTP secrets at rest (≥32 chars). Without it the admin panel is disabled. */
    ADMIN_ENCRYPTION_KEY: optionalNonEmpty.pipe(z.string().min(32).optional()),
    /** Daily import of verified tokens (KyberSwap whitelist + independent token lists). */
    TOKEN_SYNC_ENABLED: z.enum(["true", "false"]).default("true").transform((v) => v === "true"),
    /** Independent Token Lists (comma-separated https URLs, Token Lists format). */
    TOKEN_LIST_URLS: z
      .string()
      .default(
        "https://tokens.uniswap.org,https://tokens.coingecko.com/uniswap/all.json,https://tokens.coingecko.com/base/all.json,https://tokens.coingecko.com/arbitrum-one/all.json,https://tokens.coingecko.com/polygon-pos/all.json",
      )
      .transform((v) => v.split(",").map((u) => u.trim()).filter((u) => u !== ""))
      .pipe(z.array(z.string().url().startsWith("https://")).max(20)),
    /** Run the on-chain swap tracker in this process. Disable on extra API replicas if you run a dedicated worker. */
    WORKER_ENABLED: z.enum(["true", "false"]).default("true").transform((v) => v === "true"),
    QUOTE_TTL_SECONDS: z.coerce.number().int().min(10).max(120).default(30),
    PLATFORM_FEE_BPS: z.coerce.number().int().min(0).max(300).default(0),
    PLATFORM_FEE_RECIPIENT: address.optional(),

    // Free public endpoints by default; set your own (paid or self-hosted) for production reliability.
    RPC_URL_1: optionalNonEmpty.pipe(httpsUrl.default("https://ethereum-rpc.publicnode.com")),
    RPC_URL_8453: optionalNonEmpty.pipe(httpsUrl.default("https://base-rpc.publicnode.com")),
    RPC_URL_42161: optionalNonEmpty.pipe(httpsUrl.default("https://arbitrum-one-rpc.publicnode.com")),
    RPC_URL_137: optionalNonEmpty.pipe(httpsUrl.default("https://polygon-bor-rpc.publicnode.com")),

    MOONPAY_ENV: z.enum(["sandbox", "production"]).default("sandbox"),
    MOONPAY_PUBLISHABLE_KEY: optionalNonEmpty,
    MOONPAY_SECRET_KEY: optionalNonEmpty,
    MOONPAY_WEBHOOK_KEY: optionalNonEmpty,

    TRANSAK_ENV: z.enum(["staging", "production"]).default("staging"),
    TRANSAK_API_KEY: optionalNonEmpty,
    TRANSAK_API_SECRET: optionalNonEmpty,
  })
  .superRefine((env, ctx) => {
    const issue = (path: string, message: string) => ctx.addIssue({ code: "custom", path: [path], message });

    if (env.SWAP_PROVIDER === "0x" && env.ZEROEX_API_KEY === undefined) {
      issue("ZEROEX_API_KEY", "required when SWAP_PROVIDER=0x");
    }
    if (env.PLATFORM_FEE_BPS > 0 && env.PLATFORM_FEE_RECIPIENT === undefined) {
      issue("PLATFORM_FEE_RECIPIENT", "required when PLATFORM_FEE_BPS > 0");
    }
    const moonpay = [env.MOONPAY_PUBLISHABLE_KEY, env.MOONPAY_SECRET_KEY, env.MOONPAY_WEBHOOK_KEY];
    if (moonpay.some((v) => v !== undefined) && moonpay.some((v) => v === undefined)) {
      issue("MOONPAY_SECRET_KEY", "MoonPay keys must be set together or not at all");
    }
    if ((env.TRANSAK_API_KEY === undefined) !== (env.TRANSAK_API_SECRET === undefined)) {
      issue("TRANSAK_API_SECRET", "Transak key and secret must be set together");
    }

    if (env.NODE_ENV === "production") {
      if (!env.PUBLIC_WEB_ORIGIN.startsWith("https://")) issue("PUBLIC_WEB_ORIGIN", "must use https in production");
      if (/change[-_]?me/i.test(env.DATABASE_URL)) issue("DATABASE_URL", "placeholder password in production");
      if (env.QUOTE_SIGNING_KEY === undefined) issue("QUOTE_SIGNING_KEY", "required in production");
      if (env.MOONPAY_PUBLISHABLE_KEY?.startsWith("pk_test") === true && env.MOONPAY_ENV === "production") {
        issue("MOONPAY_PUBLISHABLE_KEY", "test key with MOONPAY_ENV=production");
      }
    }
  });

export type Config = z.infer<typeof schema>;

export class ConfigError extends Error {
  override readonly name = "ConfigError";
  /** Variable names and reasons only; values are never included. */
  readonly problems: readonly string[];

  constructor(problems: readonly string[]) {
    super(`Invalid configuration:\n  ${problems.join("\n  ")}`);
    this.problems = problems;
  }
}

type Env = Readonly<Record<string, string | undefined>>;
type FileReader = (path: string) => string;

/**
 * Resolves `<NAME>_FILE` (Docker/systemd secrets) for secret variables. Setting both the
 * variable and its _FILE twin is rejected to avoid ambiguity about which one is live.
 */
export function resolveSecretFiles(env: Env, readFile: FileReader = (p) => readFileSync(p, "utf8")): Env {
  const resolved: Record<string, string | undefined> = { ...env };
  const problems: string[] = [];
  for (const name of SECRET_VARS) {
    const filePath = env[`${name}_FILE`];
    if (filePath === undefined || filePath === "") continue;
    if (env[name] !== undefined && env[name] !== "") {
      problems.push(`${name}: set either ${name} or ${name}_FILE, not both`);
      continue;
    }
    try {
      resolved[name] = readFile(filePath).trim();
    } catch {
      problems.push(`${name}_FILE: file is not readable`);
    }
  }
  if (problems.length > 0) throw new ConfigError(problems);
  return resolved;
}

export function parseConfig(env: Env, readFile?: FileReader): Config {
  const result = schema.safeParse(resolveSecretFiles(env, readFile));
  if (!result.success) {
    throw new ConfigError(result.error.issues.map((i) => `${i.path.join(".") || "(root)"}: ${i.message}`));
  }
  return Object.freeze(result.data);
}

export interface FeatureFlags {
  readonly swapQuotes: boolean;
  readonly moonpay: boolean;
  readonly transak: boolean;
}

export function featureFlags(config: Config): FeatureFlags {
  return {
    swapQuotes: config.SWAP_PROVIDER === "kyberswap" || config.ZEROEX_API_KEY !== undefined,
    moonpay: config.MOONPAY_SECRET_KEY !== undefined,
    transak: config.TRANSAK_API_SECRET !== undefined,
  };
}
