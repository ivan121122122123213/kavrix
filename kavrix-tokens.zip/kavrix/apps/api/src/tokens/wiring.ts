import type { SupportedChainId } from "@kavrix/shared";
import { KyberTokenClient, RateGate, fetchTokenList, type SourceToken } from "@kavrix/integrations";
import type { TokenSyncRepository } from "@kavrix/db";
import type { JsonRpcReader } from "../chain/reader.ts";
import type { TokenSyncDeps } from "./sync.ts";

/** Which Token Lists source a URL belongs to (only affects the "standard risk" rule for Uniswap's curated list). */
export function sourceOf(url: string): "uniswap" | "coingecko" {
  return new URL(url).hostname.endsWith("uniswap.org") ? "uniswap" : "coingecko";
}

export function tokenSyncDeps(input: {
  repo: TokenSyncRepository;
  listUrls: readonly string[];
  clientId: string;
  readers: Readonly<Record<SupportedChainId, JsonRpcReader>>;
  log: TokenSyncDeps["log"];
}): TokenSyncDeps {
  // Separate, slower gate for the Token API so the sync never competes with users' quotes.
  const kyber = new KyberTokenClient({ clientId: input.clientId, gate: new RateGate(2) });
  return {
    repo: input.repo,
    kyberWhitelist: (chainId) => kyber.whitelisted(chainId),
    safety: (chainId, address) => kyber.safety(chainId, address),
    lists: async () =>
      Promise.all(
        input.listUrls.map(async (url) => {
          try {
            return { url, ok: true, tokens: await fetchTokenList(url, sourceOf(url)) as readonly SourceToken[] };
          } catch (err) {
            input.log?.warn({ url, reason: err instanceof Error ? err.message : "unknown" }, "token sync: list unavailable");
            return { url, ok: false, tokens: [] as readonly SourceToken[] };
          }
        }),
      ),
    onChainDecimals: (chainId, address) => input.readers[chainId].tokenDecimals(address),
    log: input.log,
  };
}
