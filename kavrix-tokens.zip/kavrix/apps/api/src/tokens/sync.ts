import { SUPPORTED_CHAIN_IDS, type Address, type SupportedChainId } from "@kavrix/shared";
import { decideCandidates, type Candidate, type SourceToken } from "@kavrix/integrations";
import type { SyncedToken, TokenSyncRepository } from "@kavrix/db";

export interface TokenSyncDeps {
  readonly repo: TokenSyncRepository;
  readonly kyberWhitelist: (chainId: SupportedChainId) => Promise<SourceToken[]>;
  /** Honeypot / fee-on-transfer status; must throw when unknown. */
  readonly safety: (chainId: SupportedChainId, address: Address) => Promise<{ isHoneypot: boolean; isFeeOnTransfer: boolean }>;
  /** Independent Token Lists (all chains). A failed list is reported, not thrown. */
  readonly lists: () => Promise<readonly { readonly url: string; readonly ok: boolean; readonly tokens: readonly SourceToken[] }[]>;
  readonly onChainDecimals: (chainId: SupportedChainId, address: Address) => Promise<number | null>;
  readonly log?: { info: (o: object, m: string) => void; warn: (o: object, m: string) => void };
  /** New tokens verified per run (on-chain + safety calls); the rest wait for the next run. */
  readonly maxChecksPerRun?: number;
  readonly chains?: readonly SupportedChainId[];
}

export interface ChainReport {
  readonly chainId: SupportedChainId;
  readonly enabled: number;
  readonly pending: number;
  readonly rejected: number;
  readonly retired: number;
  readonly deferred: number;
  readonly sourcesHealthy: boolean;
}

/**
 * One sync pass. Never touches operator-added (manual) tokens, never deletes, and never retires tokens
 * when a source is down: an outage must not empty the token list.
 */
export async function syncTokens(deps: TokenSyncDeps): Promise<ChainReport[]> {
  const lists = await deps.lists();
  const listOk = lists.some((l) => l.ok);
  const listTokens = lists.flatMap((l) => l.tokens);
  let budget = deps.maxChecksPerRun ?? 300;
  const reports: ChainReport[] = [];

  for (const chainId of deps.chains ?? SUPPORTED_CHAIN_IDS) {
    let kyber: SourceToken[] = [];
    let kyberOk = true;
    try {
      kyber = await deps.kyberWhitelist(chainId);
    } catch (err) {
      kyberOk = false;
      deps.log?.warn({ chainId, reason: err instanceof Error ? err.message : "unknown" }, "token sync: KyberSwap whitelist unavailable");
    }

    const stored = await deps.repo.all(chainId);
    const storedByAddress = new Map(stored.map((s) => [s.address, s]));
    const curated = stored.filter((s) => s.review === "manual").map((s) => ({ chainId, address: s.address, symbol: s.symbol }));
    const candidates = decideCandidates([...kyber, ...listTokens.filter((t) => t.chainId === chainId)], curated);

    const rows: SyncedToken[] = [];
    const keep = new Set<string>();
    let rejected = 0;
    let deferred = 0;

    const row = (c: Candidate, review: "auto" | "pending", enabled: boolean, note: string | null): SyncedToken => ({
      chainId,
      address: c.address,
      symbol: c.symbol,
      name: c.name,
      decimals: c.decimals,
      logoUrl: c.logoUrl,
      risk: c.risk,
      rank: c.rank,
      sources: c.sources,
      review,
      enabled,
      note: note === null ? null : note.slice(0, 300),
    });

    for (const c of candidates) {
      const existing = storedByAddress.get(c.address);
      if (existing?.review === "manual") continue;
      if (c.decision.kind === "reject") {
        rejected++;
        continue;
      }
      if (c.decision.kind === "pending") {
        rows.push(row(c, "pending", false, c.decision.reasons.join("; ")));
        continue;
      }
      // Already live and still endorsed by the sources: keep it without spending checks.
      if (existing?.review === "auto" && existing.enabled && existing.decimals === c.decimals) {
        rows.push(row(c, "auto", true, null));
        keep.add(c.address);
        continue;
      }
      if (budget <= 0) {
        deferred++;
        if (existing === undefined) rows.push(row(c, "pending", false, "awaiting automatic checks"));
        continue;
      }
      budget--;
      try {
        const onChain = await deps.onChainDecimals(chainId, c.address);
        if (onChain !== c.decimals) {
          rows.push(row(c, "pending", false, `contract reports ${onChain ?? "no"} decimals, lists say ${c.decimals}`));
          continue;
        }
        const safety = await deps.safety(chainId, c.address);
        if (safety.isHoneypot || safety.isFeeOnTransfer) {
          rejected++;
          continue;
        }
        rows.push(row(c, "auto", true, null));
        keep.add(c.address);
      } catch (err) {
        rows.push(row(c, "pending", false, `automatic check failed, will retry: ${err instanceof Error ? err.message : "unknown"}`));
      }
    }

    await deps.repo.upsert(rows);

    const liveBefore = stored.filter((s) => s.review === "auto" && s.enabled).length;
    const sourcesHealthy = kyberOk && listOk && keep.size >= Math.floor(liveBefore / 2);
    let retired = 0;
    if (sourcesHealthy) {
      retired = await deps.repo.retire(chainId, keep, "no longer listed by the token sources");
    } else if (liveBefore > 0) {
      deps.log?.warn({ chainId, kyberOk, listOk, confirmed: keep.size, liveBefore }, "token sync: sources unhealthy, nothing retired");
    }

    const report: ChainReport = { chainId, enabled: keep.size, pending: rows.filter((r) => r.review === "pending").length, rejected, retired, deferred, sourcesHealthy };
    deps.log?.info({ ...report }, "token sync: chain done");
    reports.push(report);
  }
  return reports;
}
