import { PgTokenSyncRepository, createDatabase } from "@kavrix/db";
import { ConfigError, parseConfig } from "./config.ts";
import { JsonRpcReader } from "./chain/reader.ts";
import { syncTokens } from "./tokens/sync.ts";
import { tokenSyncDeps } from "./tokens/wiring.ts";

/** One token sync pass from the server shell:  node dist/token-sync-cli.js */
async function main(): Promise<number> {
  let config;
  try {
    config = parseConfig(process.env);
  } catch (err) {
    if (err instanceof ConfigError) {
      process.stderr.write(`${err.message}\n`);
      return 78;
    }
    throw err;
  }
  const db = createDatabase({ url: config.DATABASE_URL, maxConnections: 2 });
  const log = {
    info: (o: object, m: string) => process.stdout.write(`${m} ${JSON.stringify(o)}\n`),
    warn: (o: object, m: string) => process.stderr.write(`WARN ${m} ${JSON.stringify(o)}\n`),
  };
  try {
    const reports = await syncTokens(
      tokenSyncDeps({
        repo: new PgTokenSyncRepository(db.sql),
        listUrls: config.TOKEN_LIST_URLS,
        clientId: config.KYBERSWAP_CLIENT_ID,
        readers: {
          1: new JsonRpcReader(config.RPC_URL_1),
          8453: new JsonRpcReader(config.RPC_URL_8453),
          42161: new JsonRpcReader(config.RPC_URL_42161),
          137: new JsonRpcReader(config.RPC_URL_137),
        },
        log,
      }),
    );
    const total = reports.reduce((n, r) => n + r.enabled, 0);
    process.stdout.write(`token sync done: ${total} tokens live across ${reports.length} networks\n`);
    return reports.every((r) => r.sourcesHealthy) ? 0 : 75;
  } finally {
    await db.close();
  }
}

process.exitCode = await main();
