/**
 * Recognises "database unreachable" failures from postgres.js / Node sockets so the API answers
 * 503 (retryable) instead of 500. Query errors (constraint violations etc.) are not matched.
 */
const TRANSPORT_CODES = new Set([
  "ECONNREFUSED",
  "ECONNRESET",
  "ETIMEDOUT",
  "EHOSTUNREACH",
  "ENOTFOUND",
  "EAI_AGAIN",
  "EPIPE",
  "CONNECT_TIMEOUT",
  "CONNECTION_CLOSED",
  "CONNECTION_ENDED",
  "CONNECTION_DESTROYED",
  // PostgreSQL SQLSTATE: admin shutdown, crash shutdown, cannot connect now, too many connections, statement timeout
  "57P01",
  "57P02",
  "57P03",
  "53300",
  "57014",
]);

export function isDatabaseUnavailable(err: unknown): boolean {
  for (let e: unknown = err, depth = 0; e !== null && typeof e === "object" && depth < 4; depth++) {
    const code = (e as { code?: unknown }).code;
    if (typeof code === "string" && TRANSPORT_CODES.has(code)) return true;
    e = (e as { cause?: unknown }).cause;
  }
  return false;
}
