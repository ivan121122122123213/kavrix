/** Injected at image build time (see apps/api/Dockerfile); "dev" locally. */
export const VERSION = process.env["KAVRIX_VERSION"] ?? "dev";
