import type { SupportedChainId } from "@kavrix/shared";

export interface ChainTx {
  readonly from: `0x${string}`;
  readonly to: `0x${string}` | null;
  readonly value: bigint;
  readonly input: `0x${string}`;
}

export interface ChainLog {
  readonly address: `0x${string}`;
  readonly topics: readonly `0x${string}`[];
  readonly data: `0x${string}`;
}

export interface ChainReceipt {
  readonly status: "success" | "reverted";
  readonly blockNumber: bigint;
  readonly logs: readonly ChainLog[];
}

export interface ChainReader {
  getTransaction(hash: `0x${string}`): Promise<ChainTx | null>;
  getReceipt(hash: `0x${string}`): Promise<ChainReceipt | null>;
  blockNumber(): Promise<bigint>;
}

export class RpcError extends Error {
  override readonly name = "RpcError";
}

const HEX = /^0x[0-9a-fA-F]*$/;
const ADDR = /^0x[0-9a-fA-F]{40}$/;

function qty(v: unknown): bigint {
  if (typeof v !== "string" || !/^0x[0-9a-fA-F]{1,64}$/.test(v)) throw new RpcError("bad quantity");
  return BigInt(v);
}
function addr(v: unknown): `0x${string}` {
  if (typeof v !== "string" || !ADDR.test(v)) throw new RpcError("bad address");
  return v.toLowerCase() as `0x${string}`;
}
function hex(v: unknown): `0x${string}` {
  if (typeof v !== "string" || !HEX.test(v) || v.length % 2 !== 0) throw new RpcError("bad hex");
  return v.toLowerCase() as `0x${string}`;
}
function obj(v: unknown): Record<string, unknown> {
  if (typeof v !== "object" || v === null || Array.isArray(v)) throw new RpcError("bad object");
  return v as Record<string, unknown>;
}

/** Minimal JSON-RPC reader with strict parsing; used by the server-side tracker only. */
export class JsonRpcReader implements ChainReader {
  readonly #url: string;
  readonly #fetch: typeof fetch;
  readonly #timeoutMs: number;
  #id = 0;

  constructor(url: string, options: { fetch?: typeof fetch; timeoutMs?: number } = {}) {
    this.#url = url;
    this.#fetch = options.fetch ?? fetch;
    this.#timeoutMs = options.timeoutMs ?? 8_000;
  }

  async #call(method: string, params: unknown[]): Promise<unknown> {
    const id = ++this.#id;
    let res: Response;
    try {
      res = await this.#fetch(this.#url, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ jsonrpc: "2.0", id, method, params }),
        redirect: "error",
        signal: AbortSignal.timeout(this.#timeoutMs),
      });
    } catch {
      throw new RpcError(`${method}: node unreachable`);
    }
    if (!res.ok) throw new RpcError(`${method}: HTTP ${res.status}`);
    const body = obj(await res.json().catch(() => null));
    if (body["id"] !== id) throw new RpcError(`${method}: id mismatch`);
    if (body["error"] !== undefined) throw new RpcError(`${method}: node error`);
    return body["result"];
  }

  async getTransaction(hash: `0x${string}`): Promise<ChainTx | null> {
    const r = await this.#call("eth_getTransactionByHash", [hash]);
    if (r === null) return null;
    const t = obj(r);
    return { from: addr(t["from"]), to: t["to"] === null ? null : addr(t["to"]), value: qty(t["value"]), input: hex(t["input"]) };
  }

  async getReceipt(hash: `0x${string}`): Promise<ChainReceipt | null> {
    const r = await this.#call("eth_getTransactionReceipt", [hash]);
    if (r === null) return null;
    const t = obj(r);
    const status = qty(t["status"]);
    if (status !== 0n && status !== 1n) throw new RpcError("bad receipt status");
    const logs = t["logs"];
    if (!Array.isArray(logs)) throw new RpcError("bad logs");
    return {
      status: status === 1n ? "success" : "reverted",
      blockNumber: qty(t["blockNumber"]),
      logs: logs.map((l) => {
        const o = obj(l);
        const topics = o["topics"];
        if (!Array.isArray(topics)) throw new RpcError("bad topics");
        return { address: addr(o["address"]), topics: topics.map(hex), data: hex(o["data"]) };
      }),
    };
  }

  async blockNumber(): Promise<bigint> {
    return qty(await this.#call("eth_blockNumber", []));
  }

  /** ERC-20 `decimals()`; null when the address has no contract code or the call does not return a uint8. */
  async tokenDecimals(address: `0x${string}`): Promise<number | null> {
    const code = hex(await this.#call("eth_getCode", [address, "latest"]));
    if (code === "0x") return null;
    let out: `0x${string}`;
    try {
      out = hex(await this.#call("eth_call", [{ to: address, data: "0x313ce567" }, "latest"]));
    } catch (err) {
      if (err instanceof RpcError && err.message.endsWith("node error")) return null;
      throw err;
    }
    if (out.length !== 66) return null;
    const value = BigInt(out);
    return value <= 36n ? Number(value) : null;
  }
}

export type ChainReaders = Readonly<Record<SupportedChainId, ChainReader>>;
