import { createDatabase, loadMigrations, migrate } from "@kavrix/db";
import { ConfigError, parseConfig } from "./config.ts";

async function main(): Promise<number> {
  let url: string;
  try {
    url = parseConfig(process.env).DATABASE_URL;
  } catch (err) {
    if (err instanceof ConfigError) {
      process.stderr.write(`${err.message}\n`);
      return 78;
    }
    throw err;
  }
  const database = createDatabase({ url, maxConnections: 1, statementTimeoutMs: 120_000 });
  try {
    const result = await migrate(database.sql, await loadMigrations());
    process.stdout.write(
      result.applied.length === 0
        ? `migrations: up to date (${result.alreadyApplied} applied)\n`
        : `migrations: applied ${result.applied.join(", ")}\n`,
    );
    return 0;
  } catch (err) {
    process.stderr.write(`migrations failed: ${err instanceof Error ? err.message : "unknown error"}\n`);
    return 1;
  } finally {
    await database.close();
  }
}

process.exitCode = await main();
