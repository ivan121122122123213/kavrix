import { randomBytes } from "node:crypto";
import { PgAdminRepository, PgRampRepository, PgSwapRepository, PgTokenSyncRepository, createDatabase, listEnabledTokens, readSetting, writeSetting } from "@kavrix/db";
import { syncTokens } from "./tokens/sync.ts";
import { tokenSyncDeps } from "./tokens/wiring.ts";
import { CHAINS, SUPPORTED_CHAIN_IDS, type SupportedChainId } from "@kavrix/shared";
import { AdminAuth } from "./admin/auth.ts";
import { deriveKey } from "./admin/crypto.ts";
import { ErrorLog } from "./admin/error-log.ts";
import type { HealthReport } from "./admin/routes.ts";
import { CachedSettings, SETTING_KEYS } from "./admin/settings.ts";
import { JsonRpcReader } from "./chain/reader.ts";
import { SwapTracker, startTracker } from "./worker/swap-tracker.ts";
import {
  KyberSwapProvider,
  MoonPayClient,
  RateGate,
  TransakClient,
  ZeroExClient,
  ZeroExProvider,
  type StoredTransakToken,
  type SwapProvider,
} from "@kavrix/integrations";
import { buildApp } from "./app.ts";
import { ConfigError, parseConfig, type Config } from "./config.ts";
import { VERSION } from "./version.ts";

function loadConfigOrExit(): Config {
  try {
    return parseConfig(process.env);
  } catch (err) {
    if (err instanceof ConfigError) {
      process.stderr.write(`${err.message}\n`);
      process.exit(78); // EX_CONFIG
    }
    throw err;
  }
}

function createSwapProvider(config: Config): SwapProvider | undefined {
  if (config.SWAP_PROVIDER === "kyberswap") {
    // One gate per process keeps Kavrix under KyberSwap's default 3 req/s (a firm quote costs 2 requests).
    return new KyberSwapProvider({
      clientId: config.KYBERSWAP_CLIENT_ID,
      apiKey: config.KYBERSWAP_API_KEY,
      gate: new RateGate(config.KYBERSWAP_API_KEY === undefined ? 3 : 10),
    });
  }
  return config.ZEROEX_API_KEY === undefined ? undefined : new ZeroExProvider(new ZeroExClient({ apiKey: config.ZEROEX_API_KEY }));
}

async function main(): Promise<void> {
  const config = loadConfigOrExit();

  const database = createDatabase({ url: config.DATABASE_URL, maxConnections: config.DATABASE_MAX_CONNECTIONS });
  const swapRepo = new PgSwapRepository(database.sql);
  const adminRepo = new PgAdminRepository(database.sql);
  const readers = {
    1: new JsonRpcReader(config.RPC_URL_1),
    8453: new JsonRpcReader(config.RPC_URL_8453),
    42161: new JsonRpcReader(config.RPC_URL_42161),
    137: new JsonRpcReader(config.RPC_URL_137),
  } as const;
  const errors = new ErrorLog();
  const settings = new CachedSettings(
    async () => new Map((await adminRepo.listSettings(SETTING_KEYS)).map((r) => [r.key, r.value])),
    (keys) => process.stderr.write(`invalid runtime settings, using safe defaults: ${keys.join(", ")}\n`),
  );
  const quoteKey = config.QUOTE_SIGNING_KEY !== undefined ? Buffer.from(config.QUOTE_SIGNING_KEY, "utf8") : randomBytes(32);
  const moonpay =
    config.MOONPAY_PUBLISHABLE_KEY !== undefined && config.MOONPAY_SECRET_KEY !== undefined && config.MOONPAY_WEBHOOK_KEY !== undefined
      ? {
          client: new MoonPayClient({
            environment: config.MOONPAY_ENV,
            publishableKey: config.MOONPAY_PUBLISHABLE_KEY,
            secretKey: config.MOONPAY_SECRET_KEY,
          }),
          webhookKey: config.MOONPAY_WEBHOOK_KEY,
        }
      : undefined;
  const transak =
    config.TRANSAK_API_KEY !== undefined && config.TRANSAK_API_SECRET !== undefined
      ? new TransakClient({
          environment: config.TRANSAK_ENV,
          apiKey: config.TRANSAK_API_KEY,
          apiSecret: config.TRANSAK_API_SECRET,
          tokenStore: {
            load: async () => {
              const v = await readSetting(database.sql, "transak.access_token");
              return typeof v === "object" && v !== null && typeof (v as StoredTransakToken).accessToken === "string"
                ? (v as StoredTransakToken)
                : null;
            },
            save: (token) => writeSetting(database.sql, "transak.access_token", token),
          },
        })
      : undefined;

  // Declared before the app so the health check can report on it.
  let tracker: { stop: () => Promise<void>; lastTickAt: () => Date | null } | undefined;
  const health = async (): Promise<HealthReport> => {
    const rpcEntries = await Promise.all(
      SUPPORTED_CHAIN_IDS.map(async (id: SupportedChainId) => {
        const started = Date.now();
        try {
          const block = await readers[id].blockNumber();
          return [CHAINS[id].key, { ok: true, block: block.toString(), latencyMs: Date.now() - started }] as const;
        } catch {
          return [CHAINS[id].key, { ok: false }] as const;
        }
      }),
    );
    const [dbOk, backlog, webhooks] = await Promise.all([
      database.ping(),
      adminRepo.trackerBacklog().catch(() => null),
      adminRepo.lastWebhookAt().catch(() => ({})),
    ]);
    const hooks = webhooks as Partial<Record<"moonpay" | "transak", Date>>;
    return {
      database: dbOk ? "ok" : "fail",
      rpc: Object.fromEntries(rpcEntries),
      tracker: { enabled: tracker !== undefined, lastTickAt: tracker?.lastTickAt()?.toISOString() ?? null, backlog },
      providers: {
        [config.SWAP_PROVIDER]: { configured: true },
        moonpay: { configured: moonpay !== undefined, lastWebhookAt: hooks.moonpay?.toISOString() ?? null },
        transak: { configured: transak !== undefined, lastWebhookAt: hooks.transak?.toISOString() ?? null },
      },
    };
  };
  const admin =
    config.ADMIN_ENCRYPTION_KEY === undefined
      ? undefined
      : {
          repo: adminRepo,
          auth: new AdminAuth({ repo: adminRepo, encryptionKey: deriveKey(config.ADMIN_ENCRYPTION_KEY) }),
          health,
          tokenDecimals: (chainId: SupportedChainId, address: `0x${string}`) => readers[chainId].tokenDecimals(address),
          onSettingsChanged: () => settings.invalidate(),
        };

  const app = await buildApp({
    config,
    settings,
    errors,
    ...(admin === undefined ? {} : { admin }),
    swapRepo,
    rampRepo: new PgRampRepository(database.sql),
    ...(moonpay === undefined ? {} : { moonpay }),
    ...(transak === undefined ? {} : { transak }),
    quoteKey,
    pingDatabase: database.ping,
    listTokens: (chainId) => listEnabledTokens(database.db, chainId),
    swapProvider: createSwapProvider(config),
    version: VERSION,
  });

  if (admin === undefined) app.log.warn("ADMIN_ENCRYPTION_KEY not set: admin panel disabled");
  if (config.QUOTE_SIGNING_KEY === undefined) {
    app.log.warn("QUOTE_SIGNING_KEY not set: using a per-process key (quotes do not survive restarts or span replicas)");
  }

  tracker = config.WORKER_ENABLED
    ? startTracker(
        new SwapTracker({
          repo: swapRepo,
          readers,
          log: app.log,
        }),
        2_000,
        (err) => app.log.error({ err }, "swap tracker tick failed"),
      )
    : undefined;

  // Daily token import, first run a minute after start; runs never overlap and failures are only logged.
  let tokenTimer: NodeJS.Timeout | undefined;
  if (config.TOKEN_SYNC_ENABLED) {
    const deps = tokenSyncDeps({ repo: new PgTokenSyncRepository(database.sql), listUrls: config.TOKEN_LIST_URLS, clientId: config.KYBERSWAP_CLIENT_ID, readers, log: app.log });
    const run = () => {
      syncTokens(deps)
        .catch((err: unknown) => app.log.error({ err }, "token sync failed"))
        .finally(() => {
          tokenTimer = setTimeout(run, 24 * 60 * 60_000);
        });
    };
    tokenTimer = setTimeout(run, 60_000);
  }

  let shuttingDown = false;
  const shutdown = async (signal: string) => {
    if (shuttingDown) return;
    shuttingDown = true;
    app.log.info({ signal }, "shutting down");
    const force = setTimeout(() => process.exit(1), 15_000);
    force.unref();
    try {
      clearTimeout(tokenTimer);
      await app.close();
      await tracker?.stop();
      await database.close();
      process.exit(0);
    } catch (err) {
      app.log.error({ err }, "shutdown failed");
      process.exit(1);
    }
  };
  process.once("SIGTERM", () => void shutdown("SIGTERM"));
  process.once("SIGINT", () => void shutdown("SIGINT"));

  await app.listen({ host: config.HOST, port: config.PORT });
}

/** Strips credentials from connection strings that may appear in driver error messages. */
function scrub(message: string): string {
  return message.replace(/(\w+:\/\/)[^/\s:@]+:[^@\s]+@/g, "$1[redacted]@");
}

main().catch((err: unknown) => {
  const detail = err instanceof Error ? `${err.name}: ${scrub(err.message)}` : "unknown error";
  process.stderr.write(`fatal: ${detail}\n`);
  process.exit(1);
});
