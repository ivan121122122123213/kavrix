import type { FastifyInstance } from "fastify";

export type HealthDeps = {
  readonly pingDatabase: () => Promise<boolean>;
  readonly version: string;
};

const READY_TIMEOUT_MS = 2_000;

async function withTimeout(check: () => Promise<boolean>): Promise<boolean> {
  let timer: NodeJS.Timeout | undefined;
  const timeout = new Promise<boolean>((resolve) => {
    timer = setTimeout(() => resolve(false), READY_TIMEOUT_MS);
  });
  try {
    return await Promise.race([check().catch(() => false), timeout]);
  } finally {
    clearTimeout(timer);
  }
}

export async function healthRoutes(app: FastifyInstance, deps: HealthDeps): Promise<void> {
  const noStore = { "cache-control": "no-store" };

  app.get("/health/live", { config: { rateLimit: false } }, async (_req, reply) => {
    return reply.headers(noStore).send({ status: "ok" });
  });

  // Readiness touches the database, so it stays rate limited.
  app.get("/health/ready", async (_req, reply) => {
    const database = (await withTimeout(deps.pingDatabase)) ? "ok" : "fail";
    const ready = database === "ok";
    return reply
      .code(ready ? 200 : 503)
      .headers(noStore)
      .send({ status: ready ? "ok" : "unavailable", version: deps.version, checks: { database } });
  });
}
