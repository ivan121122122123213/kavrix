import type { FastifyInstance } from "fastify";
import { CHAINS, NATIVE_TOKEN_ADDRESS, normalizeAddress, type SupportedChainId } from "@kavrix/shared";
import type { SwapRecord, SwapRepository } from "@kavrix/db";
import { HttpProblem } from "../problem.ts";
import { verifyQuote } from "../quote-token.ts";

export interface TokenMeta {
  readonly symbol: string;
  readonly decimals: number;
}

export type SwapsDeps = {
  readonly repo: SwapRepository;
  readonly quoteKey: Buffer;
  /** Symbol/decimals for display; unknown tokens fall back to the address. */
  readonly tokenMeta: (chainId: SupportedChainId, address: string) => Promise<TokenMeta | undefined>;
  readonly swapEnabled: () => Promise<boolean>;
  readonly now?: () => number;
};

const UUID = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$";
const IDEMPOTENCY_RE = /^[A-Za-z0-9_-]{16,128}$/;

async function view(rec: SwapRecord, tokenMeta: SwapsDeps["tokenMeta"]) {
  const meta = async (address: string) => {
    if (address === NATIVE_TOKEN_ADDRESS) {
      const n = CHAINS[rec.chainId].nativeCurrency;
      return { address, symbol: n.symbol, decimals: n.decimals };
    }
    const m = await tokenMeta(rec.chainId, address);
    return { address, symbol: m?.symbol ?? null, decimals: m?.decimals ?? null };
  };
  return {
    id: rec.id,
    status: rec.status,
    provider: rec.provider,
    chainId: rec.chainId,
    taker: rec.taker,
    sell: await meta(rec.sellToken),
    buy: await meta(rec.buyToken),
    sellAmount: rec.sellAmount.toString(),
    quotedBuyAmount: rec.quotedBuyAmount.toString(),
    minBuyAmount: rec.minBuyAmount.toString(),
    actualBuyAmount: rec.actualBuyAmount === null ? null : rec.actualBuyAmount.toString(),
    platformFee: { bps: rec.platformFeeBps, amount: rec.platformFeeAmount.toString() },
    txHash: rec.txHash,
    blockNumber: rec.blockNumber === null ? null : rec.blockNumber.toString(),
    confirmations: rec.confirmations,
    requiredConfirmations: CHAINS[rec.chainId].confirmations,
    failureCode: rec.failureCode,
    createdAt: rec.createdAt.toISOString(),
    updatedAt: rec.updatedAt.toISOString(),
  };
}

export async function swapsRoutes(app: FastifyInstance, deps: SwapsDeps): Promise<void> {
  const now = deps.now ?? Date.now;

  // Records a swap right before the wallet is asked to sign. All terms come from the signed quote token.
  app.post<{ Body: { quoteToken: string } }>(
    "/v1/swaps",
    {
      config: { rateLimit: { max: 20, timeWindow: "1 minute" } },
      schema: {
        body: { type: "object", additionalProperties: false, required: ["quoteToken"], properties: { quoteToken: { type: "string", maxLength: 8192 } } },
      },
    },
    async (req, reply) => {
      const key = req.headers["idempotency-key"];
      if (typeof key !== "string" || !IDEMPOTENCY_RE.test(key)) {
        throw new HttpProblem(400, "IDEMPOTENCY_KEY_REQUIRED", "Idempotency-Key header required", "Send a unique 16–128 character key per swap attempt.");
      }
      if (!(await deps.swapEnabled())) {
        throw new HttpProblem(503, "SWAPS_PAUSED", "Swaps are paused", "Nothing was sent. Try again later.");
      }
      const verified = verifyQuote(req.body.quoteToken, deps.quoteKey, now());
      if (!verified.ok) {
        throw verified.reason === "expired"
          ? new HttpProblem(409, "QUOTE_EXPIRED", "Quote expired", "Get a new quote before swapping.")
          : new HttpProblem(400, "QUOTE_INVALID", "Invalid quote token");
      }
      const c = verified.claims;
      const { record, created } = await deps.repo.create({
        idempotencyKey: key,
        provider: c.provider,
        chainId: c.chainId,
        taker: c.taker,
        sellToken: c.sellToken,
        buyToken: c.buyToken,
        sellAmount: c.sellAmount,
        quotedBuyAmount: c.buyAmount,
        minBuyAmount: c.minBuyAmount,
        slippageBps: c.slippageBps,
        platformFeeBps: c.platformFeeBps,
        platformFeeAmount: c.platformFeeAmount,
        providerFeeAmount: c.providerFeeAmount,
        networkFeeEstimate: c.networkFeeWei,
        quoteExpiresAt: new Date(c.expiresAt),
        txTo: c.txTo,
        txDataSha256: c.txDataSha256,
        txValue: c.txValue,
      });
      // A reused key must describe the same swap; anything else is a client bug or a replay.
      if (!created && (record.txDataSha256 !== c.txDataSha256 || record.taker !== c.taker)) {
        throw new HttpProblem(409, "IDEMPOTENCY_CONFLICT", "Idempotency key already used for a different swap");
      }
      return reply.code(created ? 201 : 200).header("cache-control", "no-store").send({ id: record.id, status: record.status });
    },
  );

  app.post<{ Params: { id: string }; Body: { txHash: string } }>(
    "/v1/swaps/:id/submit",
    {
      config: { rateLimit: { max: 30, timeWindow: "1 minute" } },
      schema: {
        params: { type: "object", required: ["id"], properties: { id: { type: "string", pattern: UUID } } },
        body: {
          type: "object",
          additionalProperties: false,
          required: ["txHash"],
          properties: { txHash: { type: "string", pattern: "^0x[0-9a-fA-F]{64}$" } },
        },
      },
    },
    async (req, reply) => {
      const result = await deps.repo.submit(req.params.id, req.body.txHash.toLowerCase() as `0x${string}`, new Date(now()));
      switch (result) {
        case "submitted":
        case "already_submitted":
          return reply.header("cache-control", "no-store").send({ id: req.params.id, status: "submitted" });
        case "not_found":
          throw new HttpProblem(404, "NOT_FOUND", "Swap not found");
        case "hash_conflict":
          throw new HttpProblem(409, "HASH_CONFLICT", "A different transaction was already recorded for this swap");
        case "wrong_state":
          throw new HttpProblem(409, "WRONG_STATE", "This swap can no longer be submitted", "Start a new swap.");
      }
    },
  );

  app.post<{ Params: { id: string } }>(
    "/v1/swaps/:id/reject",
    {
      config: { rateLimit: { max: 30, timeWindow: "1 minute" } },
      schema: { params: { type: "object", required: ["id"], properties: { id: { type: "string", pattern: UUID } } } },
    },
    async (req, reply) => {
      const result = await deps.repo.reject(req.params.id);
      if (result === "not_found") throw new HttpProblem(404, "NOT_FOUND", "Swap not found");
      if (result === "wrong_state") throw new HttpProblem(409, "WRONG_STATE", "This swap was already submitted");
      return reply.header("cache-control", "no-store").send({ id: req.params.id, status: "rejected" });
    },
  );

  app.get<{ Params: { id: string } }>(
    "/v1/swaps/:id",
    { schema: { params: { type: "object", required: ["id"], properties: { id: { type: "string", pattern: UUID } } } } },
    async (req, reply) => {
      const rec = await deps.repo.get(req.params.id);
      if (rec === null) throw new HttpProblem(404, "NOT_FOUND", "Swap not found");
      return reply.header("cache-control", "no-store").send(await view(rec, deps.tokenMeta));
    },
  );

  // Public by address, like a block explorer: only swaps that reached the chain are listed.
  app.get<{ Querystring: { wallet: string; limit?: number; before?: string } }>(
    "/v1/swaps",
    {
      config: { rateLimit: { max: 60, timeWindow: "1 minute" } },
      schema: {
        querystring: {
          type: "object",
          additionalProperties: false,
          required: ["wallet"],
          properties: {
            wallet: { type: "string", pattern: "^0x[0-9a-fA-F]{40}$" },
            limit: { type: "integer", minimum: 1, maximum: 50 },
            before: { type: "string", maxLength: 128 },
          },
        },
      },
    },
    async (req, reply) => {
      const limit = req.query.limit ?? 20;
      let before: { createdAt: Date; id: string } | undefined;
      if (req.query.before !== undefined) {
        const [ts, id] = req.query.before.split("_");
        const createdAt = new Date(ts ?? "");
        if (Number.isNaN(createdAt.getTime()) || id === undefined || !new RegExp(UUID).test(id)) {
          throw new HttpProblem(400, "INVALID_CURSOR", "Invalid cursor");
        }
        before = { createdAt, id };
      }
      const rows = await deps.repo.listByWallet(normalizeAddress(req.query.wallet), limit, before);
      const last = rows.at(-1);
      return reply.header("cache-control", "no-store").send({
        swaps: await Promise.all(rows.map((r) => view(r, deps.tokenMeta))),
        nextCursor: rows.length === limit && last !== undefined ? `${last.createdAt.toISOString()}_${last.id}` : null,
      });
    },
  );
}
