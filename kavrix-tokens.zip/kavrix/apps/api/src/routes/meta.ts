import type { FastifyInstance } from "fastify";
import { CHAINS, NATIVE_TOKEN_ADDRESS, SUPPORTED_CHAIN_IDS, isSupportedChainId } from "@kavrix/shared";
import type { Config, FeatureFlags } from "../config.ts";
import { HttpProblem } from "../problem.ts";
import type { SettingsSource } from "../admin/settings.ts";

export interface TokenView {
  readonly chainId: number;
  readonly address: string;
  readonly symbol: string;
  readonly name: string;
  readonly decimals: number;
  readonly logoUrl: string | null;
  readonly native: boolean;
  /** "high" for long-tail tokens (memecoins and the like): the interface warns before swapping them. */
  readonly risk: "standard" | "high";
  /** Prominence (lower first); null when unranked. */
  readonly rank: number | null;
}

/** Stored token as the database returns it; risk/rank are optional for operator-added rows from older data. */
export type ListedToken = Omit<TokenView, "native" | "risk" | "rank"> & Partial<Pick<TokenView, "risk" | "rank">>;

export type MetaDeps = {
  readonly features: FeatureFlags;
  readonly settings: SettingsSource;
  readonly hasFeeRecipient: boolean;
  readonly config: Pick<Config, "PLATFORM_FEE_BPS" | "QUOTE_TTL_SECONDS" | "SWAP_PROVIDER">;
  readonly listTokens: (chainId: number) => Promise<readonly ListedToken[]>;
};

export async function metaRoutes(app: FastifyInstance, deps: MetaDeps): Promise<void> {
  const chains = SUPPORTED_CHAIN_IDS.map((id) => {
    const c = CHAINS[id];
    return {
      id: c.id,
      key: c.key,
      name: c.name,
      nativeCurrency: c.nativeCurrency,
      explorerUrl: c.explorerUrl,
      confirmations: c.confirmations,
    };
  });

  app.get("/v1/chains", async (_req, reply) => {
    return reply.header("cache-control", "public, max-age=300").send({ chains });
  });

  // Tells the UI which flows are configured so it can explain unavailability instead of faking data.
  app.get("/v1/capabilities", async (_req, reply) => {
    const s = await deps.settings.snapshot();
    const effective = (id: number) => {
      const bps = s.feeBpsByChain[id as keyof typeof s.feeBpsByChain] ?? deps.config.PLATFORM_FEE_BPS;
      return deps.hasFeeRecipient ? bps : 0;
    };
    return reply.header("cache-control", "no-store").send({
      swap: {
        quotes: deps.features.swapQuotes && s.swapEnabled,
        paused: !s.swapEnabled,
        provider: deps.config.SWAP_PROVIDER,
        platformFeeBps: deps.hasFeeRecipient ? deps.config.PLATFORM_FEE_BPS : 0,
        platformFeeBpsByChain: Object.fromEntries(SUPPORTED_CHAIN_IDS.map((id) => [id, effective(id)])),
        quoteTtlSeconds: deps.config.QUOTE_TTL_SECONDS,
      },
      ramp: {
        moonpay: deps.features.moonpay && s.rampEnabled.moonpay,
        transak: deps.features.transak && s.rampEnabled.transak,
        buyLimits: s.buyLimits,
      },
    });
  });

  app.get<{ Querystring: { chainId: string } }>(
    "/v1/tokens",
    {
      schema: {
        querystring: {
          type: "object",
          required: ["chainId"],
          additionalProperties: false,
          properties: { chainId: { type: "string", pattern: "^[0-9]{1,6}$" } },
        },
      },
    },
    async (req, reply) => {
      const chainId = Number(req.query.chainId);
      if (!isSupportedChainId(chainId)) {
        throw new HttpProblem(400, "UNSUPPORTED_CHAIN", "Unsupported chain");
      }
      const chain = CHAINS[chainId];
      const native: TokenView = {
        chainId,
        address: NATIVE_TOKEN_ADDRESS,
        symbol: chain.nativeCurrency.symbol,
        name: chain.nativeCurrency.name,
        decimals: chain.nativeCurrency.decimals,
        logoUrl: null,
        native: true,
        risk: "standard",
        rank: null,
      };
      const rows = await deps.listTokens(chainId);
      const tokens: TokenView[] = [native, ...rows.map((t) => ({ ...t, native: false, risk: t.risk ?? "standard", rank: t.rank ?? null }))];
      return reply.header("cache-control", "public, max-age=60").send({ chainId, tokens });
    },
  );
}
