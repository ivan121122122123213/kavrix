import type { FastifyInstance } from "fastify";
import { isSupportedChainId, type SupportedChainId } from "@kavrix/shared";
import { HttpProblem } from "../problem.ts";

/**
 * Read-only JSON-RPC proxy so browsers never see RPC provider keys and CSP can stay `connect-src 'self'`.
 * Writes (eth_sendRawTransaction) are not proxied: wallets broadcast through their own RPC.
 */
export const RPC_METHODS = new Set([
  "eth_chainId",
  "eth_blockNumber",
  "eth_call",
  "eth_estimateGas",
  "eth_gasPrice",
  "eth_maxPriorityFeePerGas",
  "eth_feeHistory",
  "eth_getBalance",
  "eth_getCode",
  "eth_getTransactionCount",
  "eth_getTransactionByHash",
  "eth_getTransactionReceipt",
  "eth_getBlockByNumber",
]);

export type RpcDeps = {
  readonly urls: Readonly<Record<SupportedChainId, string>>;
  readonly fetch?: typeof fetch;
  readonly timeoutMs?: number;
};

interface RpcBody {
  jsonrpc: "2.0";
  id: number | string;
  method: string;
  params?: unknown[];
}

const MAX_RESPONSE_BYTES = 1024 * 1024;

export async function rpcRoutes(app: FastifyInstance, deps: RpcDeps): Promise<void> {
  const doFetch = deps.fetch ?? fetch;

  app.post<{ Params: { chainId: string }; Body: RpcBody }>(
    "/v1/rpc/:chainId",
    {
      bodyLimit: 16 * 1024,
      config: { rateLimit: { max: 600, timeWindow: "1 minute" } },
      schema: {
        params: { type: "object", properties: { chainId: { type: "string", pattern: "^[0-9]{1,6}$" } }, required: ["chainId"] },
        body: {
          type: "object",
          additionalProperties: false,
          required: ["jsonrpc", "id", "method"],
          properties: {
            jsonrpc: { const: "2.0" },
            id: { type: ["integer", "string"], maxLength: 64 },
            method: { type: "string", maxLength: 64 },
            params: { type: "array", maxItems: 4 },
          },
        },
      },
    },
    async (req, reply) => {
      const chainId = Number(req.params.chainId);
      if (!isSupportedChainId(chainId)) throw new HttpProblem(400, "UNSUPPORTED_CHAIN", "Unsupported chain");
      const { id, method, params = [] } = req.body;
      if (!RPC_METHODS.has(method)) {
        return reply.code(200).send({ jsonrpc: "2.0", id, error: { code: -32601, message: "Method not allowed" } });
      }
      let upstream: Response;
      try {
        upstream = await doFetch(deps.urls[chainId], {
          method: "POST",
          headers: { "content-type": "application/json", accept: "application/json" },
          body: JSON.stringify({ jsonrpc: "2.0", id, method, params }),
          redirect: "error",
          signal: AbortSignal.timeout(deps.timeoutMs ?? 8_000),
        });
      } catch {
        throw new HttpProblem(503, "RPC_UNAVAILABLE", "Network node unavailable", "The blockchain node did not respond. Retry shortly.");
      }
      const text = await upstream.text();
      if (!upstream.ok || text.length > MAX_RESPONSE_BYTES) {
        throw new HttpProblem(503, "RPC_UNAVAILABLE", "Network node unavailable", "The blockchain node returned an error. Retry shortly.");
      }
      let json: unknown;
      try {
        json = JSON.parse(text);
      } catch {
        throw new HttpProblem(502, "RPC_BAD_RESPONSE", "Invalid node response");
      }
      if (typeof json !== "object" || json === null || Array.isArray(json) || (json as Record<string, unknown>)["id"] !== id) {
        throw new HttpProblem(502, "RPC_BAD_RESPONSE", "Invalid node response");
      }
      return reply.header("cache-control", "no-store").send(json);
    },
  );
}
