import type { FastifyInstance, FastifyReply } from "fastify";
import { NATIVE_TOKEN_ADDRESS, isSupportedChainId, normalizeAddress, type Address, type SupportedChainId } from "@kavrix/shared";
import { ProviderError, type FirmQuote, type IndicativeQuote, type PlatformFeeConfig, type QuoteOutcome, type SwapProvider } from "@kavrix/integrations";
import { createHash } from "node:crypto";
import { HttpProblem } from "../problem.ts";
import { signQuote } from "../quote-token.ts";

export type SwapDeps = {
  readonly provider: SwapProvider;
  /** Effective platform fee for a chain (admin setting, else env default). */
  readonly feeFor: (chainId: SupportedChainId) => Promise<PlatformFeeConfig | undefined>;
  /** Admin kill switch. */
  readonly swapEnabled: () => Promise<boolean>;
  readonly quoteRatePerMinute: () => Promise<number>;
  readonly quoteTtlSeconds: number;
  readonly listTokens: (chainId: number) => Promise<readonly { address: string }[]>;
  readonly quoteKey: Buffer;
  readonly now?: () => number;
};

interface QuoteBody {
  chainId: number;
  sellToken: string;
  buyToken: string;
  sellAmount: string;
  slippageBps: number;
  taker?: string;
}

const ADDRESS = "^0x[0-9a-fA-F]{40}$";
const TOKEN_CACHE_MS = 60_000;

function serialize(quote: IndicativeQuote | FirmQuote, firm: boolean, expiresAt: number, slippageBps: number, key: Buffer) {
  const base = {
    firm,
    provider: quote.provider,
    chainId: quote.chainId,
    sellToken: quote.sellToken,
    buyToken: quote.buyToken,
    sellAmount: quote.sellAmount.toString(),
    buyAmount: quote.buyAmount.toString(),
    minBuyAmount: quote.minBuyAmount.toString(),
    platformFee: { bps: quote.platformFee.bps, amount: quote.platformFee.amount.toString(), token: quote.platformFee.token },
    providerFee: quote.providerFee === null ? null : quote.providerFee.toString(),
    networkFeeWei: quote.networkFeeWei === null ? null : quote.networkFeeWei.toString(),
    route: quote.route,
    valueUsd: quote.valueUsd,
    expiresAt,
  };
  if (!("tx" in quote)) return base;
  const quoteToken = signQuote(
    {
      v: 1,
      provider: quote.provider,
      chainId: quote.chainId,
      taker: quote.taker,
      sellToken: quote.sellToken,
      buyToken: quote.buyToken,
      sellAmount: quote.sellAmount,
      buyAmount: quote.buyAmount,
      minBuyAmount: quote.minBuyAmount,
      slippageBps,
      platformFeeBps: quote.platformFee.bps,
      platformFeeAmount: quote.platformFee.amount,
      providerFeeAmount: quote.providerFee ?? 0n,
      networkFeeWei: quote.networkFeeWei,
      txTo: quote.tx.to.toLowerCase() as `0x${string}`,
      txDataSha256: createHash("sha256").update(Buffer.from(quote.tx.data.slice(2), "hex")).digest("hex"),
      txValue: quote.tx.value,
      expiresAt,
    },
    key,
  );
  return {
    ...base,
    quoteToken,
    taker: quote.taker,
    spender: quote.spender,
    tx: { to: quote.tx.to, data: quote.tx.data, value: quote.tx.value.toString() },
  };
}

function providerProblem(err: ProviderError): HttpProblem {
  switch (err.code) {
    case "PROVIDER_RATE_LIMITED":
      return new HttpProblem(503, "QUOTES_BUSY", "Quotes are busy", "Too many quote requests right now. Retry in a moment.");
    case "PROVIDER_UNAVAILABLE":
    case "PROVIDER_TIMEOUT":
    case "PROVIDER_AUTH":
      return new HttpProblem(503, "PROVIDER_UNAVAILABLE", "Price provider unavailable", "The price provider is not responding. No quote was produced.");
    case "NO_LIQUIDITY":
      return new HttpProblem(422, "NO_ROUTE", "No route", "The route expired. Request a new quote.");
    case "QUOTE_UNSAFE":
      return new HttpProblem(502, "QUOTE_REJECTED", "Quote rejected", "The provider returned a quote that failed Kavrix safety checks, so it was discarded.");
    case "PROVIDER_REJECTED":
      return new HttpProblem(422, "QUOTE_UNAVAILABLE", "No quote", "The provider could not quote this pair or amount.");
    case "PROVIDER_BAD_RESPONSE":
      return new HttpProblem(502, "PROVIDER_BAD_RESPONSE", "Invalid provider response", "The price provider returned an invalid response.");
  }
}

export async function swapRoutes(app: FastifyInstance, deps: SwapDeps): Promise<void> {
  const now = deps.now ?? Date.now;
  const tokenCache = new Map<number, { at: number; set: Set<string> }>();

  async function allowedTokens(chainId: SupportedChainId): Promise<Set<string>> {
    const cached = tokenCache.get(chainId);
    if (cached !== undefined && now() - cached.at < TOKEN_CACHE_MS) return cached.set;
    const rows = await deps.listTokens(chainId);
    const set = new Set([NATIVE_TOKEN_ADDRESS, ...rows.map((r) => r.address.toLowerCase())]);
    tokenCache.set(chainId, { at: now(), set });
    return set;
  }

  app.post<{ Body: QuoteBody }>(
    "/v1/swap/quote",
    {
      config: { rateLimit: { max: async () => deps.quoteRatePerMinute(), timeWindow: "1 minute" } },
      schema: {
        body: {
          type: "object",
          additionalProperties: false,
          required: ["chainId", "sellToken", "buyToken", "sellAmount", "slippageBps"],
          properties: {
            chainId: { type: "integer" },
            sellToken: { type: "string", pattern: ADDRESS },
            buyToken: { type: "string", pattern: ADDRESS },
            sellAmount: { type: "string", pattern: "^[1-9][0-9]{0,77}$" },
            slippageBps: { type: "integer", minimum: 1, maximum: deps.provider.maxSlippageBps },
            taker: { type: "string", pattern: ADDRESS },
          },
        },
      },
    },
    async (req, reply: FastifyReply) => {
      const body = req.body;
      if (!isSupportedChainId(body.chainId)) throw new HttpProblem(400, "UNSUPPORTED_CHAIN", "Unsupported chain");
      if (!(await deps.swapEnabled())) {
        throw new HttpProblem(503, "SWAPS_PAUSED", "Swaps are paused", "The operator has paused swaps. Your funds are not affected.");
      }
      const sellToken = normalizeAddress(body.sellToken);
      const buyToken = normalizeAddress(body.buyToken);
      if (sellToken === buyToken) throw new HttpProblem(400, "SAME_TOKEN", "Choose two different tokens");

      // Only tokens Kavrix has verified can be quoted; unknown contracts are refused, not passed through.
      const allowed = await allowedTokens(body.chainId);
      if (!allowed.has(sellToken) || !allowed.has(buyToken)) {
        throw new HttpProblem(422, "TOKEN_NOT_LISTED", "Token not supported", "One of the tokens is not on the Kavrix list for this network.");
      }

      const taker: Address | undefined = body.taker === undefined ? undefined : normalizeAddress(body.taker);
      let outcome: QuoteOutcome;
      try {
        outcome = await deps.provider.quote(
          { chainId: body.chainId, sellToken, buyToken, sellAmount: BigInt(body.sellAmount), slippageBps: body.slippageBps, taker },
          await deps.feeFor(body.chainId),
        );
      } catch (err) {
        if (err instanceof ProviderError) {
          if (err.code === "QUOTE_UNSAFE" || err.code === "PROVIDER_BAD_RESPONSE") {
            req.log.warn({ provider: err.provider, code: err.code, reason: err.message }, "provider quote discarded");
          }
          const problem = providerProblem(err);
          if (problem.status === 503) reply.header("retry-after", "2");
          throw problem;
        }
        throw err;
      }

      if (outcome.kind === "no_route") {
        throw new HttpProblem(422, "NO_ROUTE", "No route", "No liquidity route was found for this pair and amount.");
      }
      const expiresAt = now() + deps.quoteTtlSeconds * 1000;
      return reply.header("cache-control", "no-store").send(serialize(outcome.quote, outcome.kind === "firm", expiresAt, body.slippageBps, deps.quoteKey));
    },
  );
}
