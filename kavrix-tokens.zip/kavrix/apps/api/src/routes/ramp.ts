import { createHash } from "node:crypto";
import type { FastifyInstance } from "fastify";
import { CHAINS, NATIVE_TOKEN_ADDRESS, isSupportedChainId, normalizeAddress, type SupportedChainId } from "@kavrix/shared";
import {
  ProviderError,
  parseMoonPayWebhook,
  parseTransakWebhook,
  resolveMoonPayCurrency,
  transakWidgetParams,
  verifyHs256Jwt,
  verifyMoonPayWebhook,
  type MoonPayClient,
  type MoonPayCurrency,
  type ParsedRampEvent,
  type TransakClient,
} from "@kavrix/integrations";
import type { RampRecord, RampRepository } from "@kavrix/db";
import { HttpProblem } from "../problem.ts";
import type { SettingsSource } from "../admin/settings.ts";

export type RampDeps = {
  readonly repo: RampRepository;
  readonly moonpay: { readonly client: MoonPayClient; readonly webhookKey: string } | undefined;
  readonly transak: TransakClient | undefined;
  readonly publicOrigin: string;
  readonly settings: SettingsSource;
  readonly listTokens: (chainId: number) => Promise<readonly { address: string; symbol: string; decimals: number }[]>;
};

/** Assets offered for fiat: the native coin plus these stablecoins, where listed on the chain. */
const RAMP_SYMBOLS = new Set(["USDC", "USDT"]);
const FIATS = ["USD", "EUR", "GBP"] as const;
const UUID = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$";
const IDEMPOTENCY_RE = /^[A-Za-z0-9_-]{16,128}$/;

interface SessionBody {
  provider: "moonpay" | "transak";
  direction: "buy" | "sell";
  chainId: number;
  token: string;
  fiatCurrency: (typeof FIATS)[number];
  amount: string;
  wallet: string;
}

function orderView(r: RampRecord) {
  return {
    id: r.id,
    provider: r.provider,
    direction: r.direction,
    chainId: r.chainId,
    cryptoCurrency: r.cryptoCurrency,
    fiatCurrency: r.fiatCurrency,
    fiatAmount: r.fiatAmount,
    cryptoAmount: r.cryptoAmount,
    status: r.status,
    providerStatus: r.providerStatus,
    createdAt: r.createdAt.toISOString(),
    updatedAt: r.updatedAt.toISOString(),
  };
}

export async function rampRoutes(app: FastifyInstance, deps: RampDeps): Promise<void> {
  app.post<{ Body: SessionBody }>(
    "/v1/ramp/sessions",
    {
      config: { rateLimit: { max: 10, timeWindow: "1 minute" } },
      schema: {
        body: {
          type: "object",
          additionalProperties: false,
          required: ["provider", "direction", "chainId", "token", "fiatCurrency", "amount", "wallet"],
          properties: {
            provider: { enum: ["moonpay", "transak"] },
            direction: { enum: ["buy", "sell"] },
            chainId: { type: "integer" },
            token: { type: "string", pattern: "^0x[0-9a-fA-F]{40}$" },
            fiatCurrency: { enum: FIATS },
            amount: { type: "string", pattern: "^(0|[1-9][0-9]{0,9})(\\.[0-9]{1,18})?$" },
            wallet: { type: "string", pattern: "^0x[0-9a-fA-F]{40}$" },
          },
        },
      },
    },
    async (req, reply) => {
      const key = req.headers["idempotency-key"];
      if (typeof key !== "string" || !IDEMPOTENCY_RE.test(key)) {
        throw new HttpProblem(400, "IDEMPOTENCY_KEY_REQUIRED", "Idempotency-Key header required");
      }
      const b = req.body;
      if (!isSupportedChainId(b.chainId)) throw new HttpProblem(400, "UNSUPPORTED_CHAIN", "Unsupported chain");
      const chainId: SupportedChainId = b.chainId;
      const token = normalizeAddress(b.token);
      const wallet = normalizeAddress(b.wallet);

      const native = token === NATIVE_TOKEN_ADDRESS;
      const listed = native ? undefined : (await deps.listTokens(chainId)).find((t) => t.address.toLowerCase() === token);
      const symbol = native ? CHAINS[chainId].nativeCurrency.symbol : listed?.symbol;
      const decimals = native ? 18 : listed?.decimals;
      if (symbol === undefined || decimals === undefined || (!native && !RAMP_SYMBOLS.has(symbol))) {
        throw new HttpProblem(422, "ASSET_NOT_SUPPORTED", "Asset not available for card orders", "Choose the network's native coin, USDC or USDT.");
      }
      const [, fraction = ""] = b.amount.split(".");
      const maxDecimals = b.direction === "buy" ? 2 : decimals;
      if (Number(b.amount) <= 0 || fraction.length > maxDecimals) {
        throw new HttpProblem(400, "INVALID_AMOUNT", "Invalid amount", `Use a positive amount with at most ${maxDecimals} decimal places.`);
      }

      const runtime = await deps.settings.snapshot();
      if (!runtime.rampEnabled[b.provider]) {
        throw new HttpProblem(503, "PROVIDER_PAUSED", "This provider is paused", "Choose the other provider or try again later.");
      }
      if (b.direction === "buy" && (Number(b.amount) < runtime.buyLimits.min || Number(b.amount) > runtime.buyLimits.max)) {
        throw new HttpProblem(422, "AMOUNT_OUT_OF_RANGE", "Amount outside the allowed range", `Card purchases are limited to ${runtime.buyLimits.min}–${runtime.buyLimits.max} ${b.fiatCurrency} per order.`);
      }

      let providerCurrency: string;
      if (b.provider === "moonpay") {
        if (deps.moonpay === undefined) throw new HttpProblem(503, "PROVIDER_DISABLED", "MoonPay is not enabled");
        let currencies: MoonPayCurrency[];
        try {
          currencies = await deps.moonpay.client.currencies();
        } catch (err) {
          if (err instanceof ProviderError) throw new HttpProblem(502, "PROVIDER_UNAVAILABLE", "MoonPay is not responding", "Try again shortly or choose the other provider.");
          throw err;
        }
        const code = resolveMoonPayCurrency(currencies, chainId, token, b.direction);
        if (code === undefined) {
          throw new HttpProblem(422, "ASSET_NOT_SUPPORTED", "MoonPay does not offer this asset", `MoonPay does not support ${b.direction === "buy" ? "buying" : "selling"} ${symbol} on ${CHAINS[chainId].name}.`);
        }
        providerCurrency = code;
      } else {
        if (deps.transak === undefined) throw new HttpProblem(503, "PROVIDER_DISABLED", "Transak is not enabled");
        providerCurrency = symbol;
      }

      const { record } = await deps.repo.create({
        idempotencyKey: key,
        provider: b.provider,
        direction: b.direction,
        walletAddress: wallet,
        chainId,
        tokenAddress: token,
        cryptoCurrency: symbol,
        providerCurrency,
        fiatCurrency: b.fiatCurrency,
        fiatAmount: b.direction === "buy" ? b.amount : null,
        cryptoAmount: b.direction === "sell" ? b.amount : null,
      });
      if (record.provider !== b.provider || record.walletAddress !== wallet || record.direction !== b.direction) {
        throw new HttpProblem(409, "IDEMPOTENCY_CONFLICT", "Idempotency key already used for a different order");
      }

      const redirectURL = new URL(`/history?order=${record.id}`, deps.publicOrigin).toString();
      let widgetUrl: URL;
      try {
        if (b.provider === "moonpay" && deps.moonpay !== undefined) {
          widgetUrl = deps.moonpay.client.widgetUrl({
            direction: b.direction,
            currencyCode: providerCurrency,
            fiatCurrency: b.fiatCurrency.toLowerCase() as "usd" | "eur" | "gbp",
            amount: b.amount,
            walletAddress: wallet,
            externalTransactionId: record.id,
            redirectURL,
          });
        } else if (deps.transak !== undefined) {
          widgetUrl = await deps.transak.createWidgetUrl(
            transakWidgetParams({ direction: b.direction, chainId, cryptoSymbol: symbol, fiatCurrency: b.fiatCurrency, amount: b.amount, walletAddress: wallet, partnerOrderId: record.id, redirectURL }),
            req.ip,
            new URL(deps.publicOrigin).hostname,
          );
        } else {
          throw new HttpProblem(503, "PROVIDER_DISABLED", "Provider not enabled");
        }
      } catch (err) {
        if (err instanceof ProviderError) {
          req.log.warn({ provider: err.provider, code: err.code, providerCode: err.providerCode }, "ramp session failed");
          throw new HttpProblem(502, "PROVIDER_UNAVAILABLE", "Checkout could not start", "The payment provider did not accept the request. Try again or choose the other provider.");
        }
        throw err;
      }
      return reply.code(201).header("cache-control", "no-store").send({ orderId: record.id, widgetUrl: widgetUrl.toString() });
    },
  );

  app.get<{ Params: { id: string } }>(
    "/v1/ramp/orders/:id",
    { schema: { params: { type: "object", required: ["id"], properties: { id: { type: "string", pattern: UUID } } } } },
    async (req, reply) => {
      const r = await deps.repo.get(req.params.id);
      if (r === null) throw new HttpProblem(404, "NOT_FOUND", "Order not found");
      return reply.header("cache-control", "no-store").send(orderView(r));
    },
  );

  app.get<{ Querystring: { wallet: string } }>(
    "/v1/ramp/orders",
    {
      config: { rateLimit: { max: 60, timeWindow: "1 minute" } },
      schema: {
        querystring: { type: "object", additionalProperties: false, required: ["wallet"], properties: { wallet: { type: "string", pattern: "^0x[0-9a-fA-F]{40}$" } } },
      },
    },
    async (req, reply) => {
      const rows = await deps.repo.listByWallet(normalizeAddress(req.query.wallet), 50);
      return reply.header("cache-control", "no-store").send({ orders: rows.map(orderView) });
    },
  );

  // Webhooks need the exact bytes for signature checks, so JSON is parsed as a string in this scope only.
  await app.register(async (hooks) => {
    hooks.addContentTypeParser("application/json", { parseAs: "string", bodyLimit: 256 * 1024 }, (_req, body, done) => done(null, body));

    const apply = async (provider: "moonpay" | "transak", rawBody: string, event: ParsedRampEvent | undefined) => {
      if (event === undefined) throw new HttpProblem(400, "WEBHOOK_UNRECOGNISED", "Unrecognised webhook");
      if (event.status === undefined) {
        hooks.log.info({ provider, providerStatus: event.providerStatus }, "webhook status not acted on");
        return "ignored";
      }
      const orderId = event.orderId !== null && new RegExp(UUID).test(event.orderId) ? event.orderId : null;
      const outcome = await deps.repo.applyEvent({
        provider,
        eventId: event.eventId,
        eventType: event.eventType,
        payloadSha256: createHash("sha256").update(rawBody).digest(),
        orderId,
        externalOrderId: event.externalOrderId,
        status: event.status,
        providerStatus: event.providerStatus,
      });
      if (outcome === "mismatch" || outcome === "unknown_order") hooks.log.warn({ provider, outcome }, "webhook not applied");
      return outcome;
    };

    hooks.post("/v1/webhooks/moonpay", { config: { rateLimit: { max: 600, timeWindow: "1 minute" } } }, async (req, reply) => {
      if (deps.moonpay === undefined) throw new HttpProblem(404, "NOT_FOUND", "Not found");
      const raw = typeof req.body === "string" ? req.body : "";
      const header = req.headers["moonpay-signature-v2"];
      const check = verifyMoonPayWebhook(typeof header === "string" ? header : undefined, raw, deps.moonpay.webhookKey);
      if (!check.ok) throw new HttpProblem(401, "WEBHOOK_SIGNATURE", "Invalid signature");
      return reply.send({ result: await apply("moonpay", raw, parseMoonPayWebhook(raw)) });
    });

    hooks.post("/v1/webhooks/transak", { config: { rateLimit: { max: 600, timeWindow: "1 minute" } } }, async (req, reply) => {
      if (deps.transak === undefined) throw new HttpProblem(404, "NOT_FOUND", "Not found");
      const raw = typeof req.body === "string" ? req.body : "";
      let jwt: unknown;
      try {
        jwt = (JSON.parse(raw) as Record<string, unknown>)["data"];
      } catch {
        throw new HttpProblem(400, "WEBHOOK_UNRECOGNISED", "Unrecognised webhook");
      }
      if (typeof jwt !== "string") throw new HttpProblem(400, "WEBHOOK_UNRECOGNISED", "Unrecognised webhook");
      const verified = verifyHs256Jwt(jwt, await deps.transak.webhookSecrets());
      if (!verified.ok) throw new HttpProblem(401, "WEBHOOK_SIGNATURE", "Invalid signature");
      return reply.send({ result: await apply("transak", raw, parseTransakWebhook(verified.payload)) });
    });
  });
}
