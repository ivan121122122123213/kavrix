/** RFC 9457 problem details. `detail` must be safe to show to end users. */
export interface Problem {
  readonly type: string;
  readonly title: string;
  readonly status: number;
  readonly code: string;
  readonly detail?: string;
  readonly requestId?: string;
}

export class HttpProblem extends Error {
  override readonly name = "HttpProblem";
  readonly status: number;
  readonly code: string;
  readonly detail: string | undefined;

  constructor(status: number, code: string, title: string, detail?: string) {
    super(title);
    this.status = status;
    this.code = code;
    this.detail = detail;
  }
}

export function problem(status: number, code: string, title: string, requestId: string, detail?: string): Problem {
  return {
    type: `https://docs.kavrix.app/errors/${code.toLowerCase()}`,
    title,
    status,
    code,
    requestId,
    ...(detail === undefined ? {} : { detail }),
  };
}
