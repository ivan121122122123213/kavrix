import { createHmac, timingSafeEqual } from "node:crypto";
import { isSupportedChainId, type Address, type SupportedChainId } from "@kavrix/shared";

/**
 * A firm quote, signed by the server. When the browser asks to record a swap it presents this token,
 * and every term of the swap is taken from it, so a client cannot alter amounts, recipient or calldata.
 */
export interface QuoteClaims {
  readonly v: 1;
  readonly provider: "kyberswap" | "0x";
  readonly chainId: SupportedChainId;
  readonly taker: Address;
  readonly sellToken: Address;
  readonly buyToken: Address;
  readonly sellAmount: bigint;
  readonly buyAmount: bigint;
  readonly minBuyAmount: bigint;
  readonly slippageBps: number;
  readonly platformFeeBps: number;
  readonly platformFeeAmount: bigint;
  readonly providerFeeAmount: bigint;
  readonly networkFeeWei: bigint | null;
  readonly txTo: Address;
  readonly txDataSha256: string;
  readonly txValue: bigint;
  readonly expiresAt: number;
}

const BIG = ["sellAmount", "buyAmount", "minBuyAmount", "platformFeeAmount", "providerFeeAmount", "txValue"] as const;
const ADDRS = ["taker", "sellToken", "buyToken", "txTo"] as const;

function mac(key: Buffer, payload: string): Buffer {
  return createHmac("sha256", key).update(`kavrix.quote.v1.${payload}`).digest();
}

export function signQuote(claims: QuoteClaims, key: Buffer): string {
  const json = JSON.stringify(claims, (_k, v: unknown) => (typeof v === "bigint" ? v.toString() : v));
  const payload = Buffer.from(json, "utf8").toString("base64url");
  return `${payload}.${mac(key, payload).toString("base64url")}`;
}

export type QuoteTokenResult =
  | { readonly ok: true; readonly claims: QuoteClaims }
  | { readonly ok: false; readonly reason: "malformed" | "signature" | "expired" };

export function verifyQuote(token: string, key: Buffer, nowMs: number): QuoteTokenResult {
  if (token.length > 8192) return { ok: false, reason: "malformed" };
  const dot = token.indexOf(".");
  if (dot <= 0 || token.indexOf(".", dot + 1) !== -1) return { ok: false, reason: "malformed" };
  const payload = token.slice(0, dot);
  const sig = token.slice(dot + 1);
  if (!/^[A-Za-z0-9_-]+$/.test(payload) || !/^[A-Za-z0-9_-]{43}$/.test(sig)) return { ok: false, reason: "malformed" };
  const expected = mac(key, payload);
  const got = Buffer.from(sig, "base64url");
  if (got.length !== expected.length || !timingSafeEqual(got, expected)) return { ok: false, reason: "signature" };

  let raw: Record<string, unknown>;
  try {
    const parsed: unknown = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
    if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) return { ok: false, reason: "malformed" };
    raw = parsed as Record<string, unknown>;
  } catch {
    return { ok: false, reason: "malformed" };
  }
  // The signature proves Kavrix issued the token; the shape is still checked so a key compromise cannot inject junk types.
  if (raw["v"] !== 1 || (raw["provider"] !== "kyberswap" && raw["provider"] !== "0x") || !isSupportedChainId(raw["chainId"])) {
    return { ok: false, reason: "malformed" };
  }
  for (const k of BIG) if (typeof raw[k] !== "string" || !/^\d{1,78}$/.test(raw[k] as string)) return { ok: false, reason: "malformed" };
  for (const k of ADDRS) if (typeof raw[k] !== "string" || !/^0x[0-9a-f]{40}$/.test(raw[k] as string)) return { ok: false, reason: "malformed" };
  const nf = raw["networkFeeWei"];
  if (!(nf === null || (typeof nf === "string" && /^\d{1,78}$/.test(nf)))) return { ok: false, reason: "malformed" };
  for (const k of ["slippageBps", "platformFeeBps", "expiresAt"] as const) {
    if (typeof raw[k] !== "number" || !Number.isSafeInteger(raw[k])) return { ok: false, reason: "malformed" };
  }
  if (typeof raw["txDataSha256"] !== "string" || !/^[0-9a-f]{64}$/.test(raw["txDataSha256"])) return { ok: false, reason: "malformed" };
  if ((raw["expiresAt"] as number) <= nowMs) return { ok: false, reason: "expired" };

  const big = (k: (typeof BIG)[number]) => BigInt(raw[k] as string);
  return {
    ok: true,
    claims: {
      v: 1,
      provider: raw["provider"],
      chainId: raw["chainId"],
      taker: raw["taker"] as Address,
      sellToken: raw["sellToken"] as Address,
      buyToken: raw["buyToken"] as Address,
      sellAmount: big("sellAmount"),
      buyAmount: big("buyAmount"),
      minBuyAmount: big("minBuyAmount"),
      slippageBps: raw["slippageBps"] as number,
      platformFeeBps: raw["platformFeeBps"] as number,
      platformFeeAmount: big("platformFeeAmount"),
      providerFeeAmount: big("providerFeeAmount"),
      networkFeeWei: nf === null ? null : BigInt(nf),
      txTo: raw["txTo"] as Address,
      txDataSha256: raw["txDataSha256"],
      txValue: big("txValue"),
      expiresAt: raw["expiresAt"] as number,
    },
  };
}
