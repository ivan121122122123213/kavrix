/**
 * End-to-end API scenarios from the specification that are not covered elsewhere.
 * See docs/TESTING.md for the full scenario → test map.
 */
import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { ProviderError, type QuoteOutcome, type SwapProvider } from "@kavrix/integrations";
import { buildApp } from "../src/app.ts";
import { parseConfig } from "../src/config.ts";
import { staticSettings, DEFAULT_SNAPSHOT } from "../src/admin/settings.ts";
import { MemorySwapRepository } from "./memory-repo.ts";
import { MemoryRampRepository } from "./memory-ramp.ts";

const config = parseConfig({ NODE_ENV: "test", PUBLIC_WEB_ORIGIN: "http://localhost:5173", DATABASE_URL: "postgres://k:t@localhost/k" });
const dbDown = () => Promise.reject(Object.assign(new Error("connect ECONNREFUSED 127.0.0.1:5432"), { code: "ECONNREFUSED" }));
const provider = (outcome: QuoteOutcome | ProviderError): SwapProvider => ({
  id: "kyberswap",
  maxSlippageBps: 2000,
  quote: async () => {
    if (outcome instanceof ProviderError) throw outcome;
    return outcome;
  },
});
const body = { chainId: 8453, sellToken: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", buyToken: "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913", sellAmount: "1000", slippageBps: 50 };

describe("scenario: database unavailable", () => {
  it("answers 503 DATABASE_UNAVAILABLE with Retry-After and changes nothing", async () => {
    const app = await buildApp({
      config, version: "t", swapProvider: provider({ kind: "no_route" }), swapRepo: new MemorySwapRepository(), rampRepo: new MemoryRampRepository(),
      quoteKey: Buffer.alloc(32, 1), pingDatabase: async () => false, listTokens: dbDown,
    });
    const tokens = await app.inject({ method: "GET", url: "/v1/tokens?chainId=8453" });
    assert.equal(tokens.statusCode, 503);
    assert.equal(tokens.json().code, "DATABASE_UNAVAILABLE");
    assert.equal(tokens.headers["retry-after"], "5");
    assert.equal(tokens.body.includes("127.0.0.1"), false, "no infrastructure details leak");
    assert.equal((await app.inject({ method: "POST", url: "/v1/swap/quote", payload: body })).statusCode, 503);
    assert.equal((await app.inject({ method: "GET", url: "/health/ready" })).statusCode, 503);
    await app.close();
  });
});

describe("scenario: provider unavailable", () => {
  it("returns a clear error and never a placeholder quote", async () => {
    const app = await buildApp({
      config, version: "t", swapProvider: provider(new ProviderError("kyberswap", "PROVIDER_UNAVAILABLE", "down")),
      swapRepo: new MemorySwapRepository(), rampRepo: new MemoryRampRepository(), quoteKey: Buffer.alloc(32, 1),
      pingDatabase: async () => true, listTokens: async () => [{ chainId: 8453, address: body.buyToken, symbol: "USDC", name: "USD Coin", decimals: 6, logoUrl: null }],
    });
    const res = await app.inject({ method: "POST", url: "/v1/swap/quote", payload: body });
    assert.equal(res.statusCode, 503);
    assert.equal(res.json().code, "PROVIDER_UNAVAILABLE");
    assert.equal("buyAmount" in res.json(), false);
    await app.close();
  });
});

describe("scenario: operator kill switch", () => {
  it("stops quotes and swap recording while paused", async () => {
    const app = await buildApp({
      config, version: "t", swapProvider: provider({ kind: "no_route" }), swapRepo: new MemorySwapRepository(), rampRepo: new MemoryRampRepository(),
      quoteKey: Buffer.alloc(32, 1), pingDatabase: async () => true, listTokens: async () => [],
      settings: staticSettings({ ...DEFAULT_SNAPSHOT, swapEnabled: false }),
    });
    assert.equal((await app.inject({ method: "POST", url: "/v1/swap/quote", payload: body })).json().code, "SWAPS_PAUSED");
    const rec = await app.inject({ method: "POST", url: "/v1/swaps", headers: { "idempotency-key": "attempt-0123456789abcdef" }, payload: { quoteToken: "x.y" } });
    assert.equal(rec.json().code, "SWAPS_PAUSED");
    const caps = (await app.inject({ method: "GET", url: "/v1/capabilities" })).json();
    assert.equal(caps.swap.paused, true);
    assert.equal(caps.swap.quotes, false);
    await app.close();
  });
});
