import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { randomBytes } from "node:crypto";
import { AdminAuth, LOCK_AFTER_FAILURES, hasRole } from "../src/admin/auth.ts";
import { deriveKey, hashPassword, seal, totpAt } from "../src/admin/crypto.ts";
import { buildSnapshot, CachedSettings, validateSetting } from "../src/admin/settings.ts";
import { readCookie } from "../src/admin/cookie.ts";
import { MemoryAdminRepository } from "./memory-admin.ts";

const key = deriveKey("e".repeat(40));
const PASSWORD = "correct horse battery staple";

async function setup() {
  let t = 1_800_000_000_000;
  const repo = new MemoryAdminRepository();
  repo.now = () => t;
  const id = await repo.createAdmin({ email: "ops@kavrix.example", passwordHash: await hashPassword(PASSWORD), role: "operator" });
  const secret = randomBytes(20);
  await repo.setTotpSecret(id, seal(secret, key, `admin:${id}`));
  const auth = new AdminAuth({ repo, encryptionKey: key, now: () => t });
  const code = (offsetSteps = 0) => totpAt(secret, Math.floor(t / 30_000) + offsetSteps);
  return { repo, auth, id, code, advance: (ms: number) => (t += ms) };
}

describe("admin login", () => {
  it("requires password and TOTP, issues a session, and audits", async () => {
    const env = await setup();
    const res = await env.auth.login("OPS@kavrix.example", PASSWORD, env.code(), "203.0.113.1", "ua");
    assert.equal(res.ok, true);
    if (!res.ok) return;
    assert.equal(res.role, "operator");
    const session = await env.auth.authenticate(res.token);
    assert.equal(session?.email, "ops@kavrix.example");
    assert.ok(env.repo.auditLog.some((e) => e.action === "admin.login"));
  });

  it("rejects wrong password, wrong code, unknown email and replayed codes identically", async () => {
    const env = await setup();
    assert.deepEqual(await env.auth.login("ops@kavrix.example", "wrong password!!", env.code(), null, null), { ok: false });
    assert.deepEqual(await env.auth.login("ops@kavrix.example", PASSWORD, "000000", null, null), { ok: false });
    assert.deepEqual(await env.auth.login("nobody@kavrix.example", PASSWORD, env.code(), null, null), { ok: false });
    const code = env.code();
    assert.equal((await env.auth.login("ops@kavrix.example", PASSWORD, code, null, null)).ok, true);
    assert.deepEqual(await env.auth.login("ops@kavrix.example", PASSWORD, code, null, null), { ok: false }, "TOTP replay");
  });

  it("locks the account after repeated failures, even for correct credentials", async () => {
    const env = await setup();
    for (let i = 0; i < LOCK_AFTER_FAILURES; i++) await env.auth.login("ops@kavrix.example", "wrong password!!", env.code(), null, null);
    assert.deepEqual(await env.auth.login("ops@kavrix.example", PASSWORD, env.code(), null, null), { ok: false });
    env.advance(16 * 60_000);
    assert.equal((await env.auth.login("ops@kavrix.example", PASSWORD, env.code(), null, null)).ok, true);
  });

  it("refuses disabled admins and a TOTP secret sealed for someone else", async () => {
    const env = await setup();
    await env.repo.setDisabled(env.id, true);
    assert.deepEqual(await env.auth.login("ops@kavrix.example", PASSWORD, env.code(), null, null), { ok: false });
    await env.repo.setDisabled(env.id, false);
    const other = randomBytes(20);
    await env.repo.setTotpSecret(env.id, seal(other, key, "admin:someone-else"));
    assert.deepEqual(await env.auth.login("ops@kavrix.example", PASSWORD, totpAt(other, Math.floor(1_800_000_000_000 / 30_000)), null, null), { ok: false });
  });

  it("expires idle sessions, revokes on logout and on disable", async () => {
    const env = await setup();
    const res = await env.auth.login("ops@kavrix.example", PASSWORD, env.code(), null, null);
    assert.ok(res.ok);
    if (!res.ok) return;
    env.advance(31 * 60_000);
    assert.equal(await env.auth.authenticate(res.token), null, "idle timeout");

    env.advance(60_000);
    const again = await env.auth.login("ops@kavrix.example", PASSWORD, env.code(), null, null);
    assert.ok(again.ok);
    if (!again.ok) return;
    await env.auth.logout(again.token, env.id, null);
    assert.equal(await env.auth.authenticate(again.token), null);
    assert.equal(await env.auth.authenticate("not-a-token"), null);
  });

  it("orders roles", () => {
    assert.ok(hasRole("owner", "operator"));
    assert.ok(hasRole("operator", "viewer"));
    assert.equal(hasRole("viewer", "operator"), false);
  });
});

describe("runtime settings", () => {
  it("parses stored values and fails closed on corrupted kill switches", () => {
    const ok = buildSnapshot(new Map<string, unknown>([["swap.enabled", false], ["swap.fee_bps_by_chain", { "8453": 25 }], ["ramp.enabled", { moonpay: true, transak: false }]]));
    assert.equal(ok.snapshot.swapEnabled, false);
    assert.equal(ok.snapshot.feeBpsByChain[8453], 25);
    assert.deepEqual(ok.invalid, []);
    const bad = buildSnapshot(new Map<string, unknown>([["swap.enabled", "yes"], ["ramp.enabled", 1], ["swap.quote_rate_per_minute", -1]]));
    assert.equal(bad.snapshot.swapEnabled, false);
    assert.deepEqual(bad.snapshot.rampEnabled, { moonpay: false, transak: false });
    assert.equal(bad.snapshot.quoteRatePerMinute, 30);
    assert.deepEqual(bad.invalid.sort(), ["ramp.enabled", "swap.enabled", "swap.quote_rate_per_minute"]);
  });

  it("validates writes, including fee recipient and unknown keys", () => {
    assert.deepEqual(validateSetting("swap.fee_bps_by_chain", { "137": 10 }, { hasFeeRecipient: true }), { ok: true });
    assert.equal(validateSetting("swap.fee_bps_by_chain", { "137": 10 }, { hasFeeRecipient: false }).ok, false);
    assert.equal(validateSetting("swap.fee_bps_by_chain", { "10": 10 }, { hasFeeRecipient: true }).ok, false);
    assert.equal(validateSetting("swap.fee_bps_by_chain", { "1": 301 }, { hasFeeRecipient: true }).ok, false);
    assert.equal(validateSetting("ramp.buy_limits", { min: 100, max: 50 }, { hasFeeRecipient: true }).ok, false);
    assert.equal(validateSetting("ramp.enabled", { moonpay: true, transak: true, extra: 1 }, { hasFeeRecipient: true }).ok, false);
    assert.equal(validateSetting("transak.access_token", "x", { hasFeeRecipient: true }).ok, false);
  });

  it("caches briefly and serves the last good snapshot during a short outage", async () => {
    let t = 0;
    let fail = false;
    let loads = 0;
    const s = new CachedSettings(async () => {
      loads++;
      if (fail) throw new Error("db down");
      return new Map<string, unknown>([["swap.enabled", true]]);
    }, () => undefined, () => t);
    assert.equal((await s.snapshot()).swapEnabled, true);
    await s.snapshot();
    assert.equal(loads, 1);
    fail = true;
    t = 10_000;
    assert.equal((await s.snapshot()).swapEnabled, true, "stale but recent");
    t = 120_000;
    await assert.rejects(s.snapshot(), /db down/);
  });
});

describe("cookie parsing", () => {
  it("reads only the named cookie", () => {
    assert.equal(readCookie("a=1; __Host-kavrix_admin=tok_en; b=2", "__Host-kavrix_admin"), "tok_en");
    assert.equal(readCookie("x__Host-kavrix_admin=evil", "__Host-kavrix_admin"), undefined);
    assert.equal(readCookie(undefined, "x"), undefined);
  });
});
