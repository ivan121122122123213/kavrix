import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { isDatabaseUnavailable } from "../src/db-errors.ts";

describe("database availability classification", () => {
  it("matches transport and server-unavailable errors, including wrapped causes", () => {
    assert.ok(isDatabaseUnavailable(Object.assign(new Error("connect"), { code: "ECONNREFUSED" })));
    assert.ok(isDatabaseUnavailable(Object.assign(new Error("x"), { code: "CONNECT_TIMEOUT" })));
    assert.ok(isDatabaseUnavailable(Object.assign(new Error("x"), { code: "57P01" })));
    assert.ok(isDatabaseUnavailable(new Error("outer", { cause: Object.assign(new Error("inner"), { code: "ETIMEDOUT" }) })));
  });

  it("does not hide real query errors behind 503", () => {
    assert.equal(isDatabaseUnavailable(Object.assign(new Error("dup"), { code: "23505" })), false);
    assert.equal(isDatabaseUnavailable(Object.assign(new Error("check"), { code: "23514" })), false);
    assert.equal(isDatabaseUnavailable(new Error("plain")), false);
    assert.equal(isDatabaseUnavailable(null), false);
  });
});
