import { randomUUID } from "node:crypto";
import type { AdminRepository, AdminRole, AdminSession, AdminTokenRow, AdminUser, AuditEntry, AuditRow, SettingRow, Stats } from "@kavrix/db";

/** In-memory AdminRepository with the same semantics as the Postgres one, for tests. */
export class MemoryAdminRepository implements AdminRepository {
  now: () => number = Date.now;
  readonly users = new Map<string, AdminUser>();
  readonly sessions = new Map<string, { adminId: string; expiresAt: Date; lastSeenAt: Date; revoked: boolean }>();
  readonly auditLog: (AuditEntry & { at: Date })[] = [];
  readonly tokens: AdminTokenRow[] = [];
  readonly settings = new Map<string, { value: unknown; version: number; updatedAt: Date }>();

  async findAdminByEmail(email: string) {
    return [...this.users.values()].find((u) => u.email === email.toLowerCase()) ?? null;
  }
  async createAdmin(input: { email: string; passwordHash: string; role: AdminRole }) {
    const id = randomUUID();
    this.users.set(id, { id, email: input.email, passwordHash: input.passwordHash, role: input.role, totpSecret: null, totpLastStep: null, failedAttempts: 0, lockedUntil: null, disabledAt: null });
    return id;
  }
  #patch(id: string, p: Partial<AdminUser>) {
    const u = this.users.get(id);
    if (u !== undefined) this.users.set(id, { ...u, ...p });
  }
  async setTotpSecret(id: string, sealed: Buffer) {
    this.#patch(id, { totpSecret: sealed, totpLastStep: null });
  }
  async setPassword(id: string, passwordHash: string) {
    this.#patch(id, { passwordHash, failedAttempts: 0, lockedUntil: null });
  }
  async setDisabled(id: string, disabled: boolean) {
    this.#patch(id, { disabledAt: disabled ? new Date(this.now()) : null });
    if (disabled) await this.revokeAllSessions(id);
  }
  async recordFailedLogin(id: string, lockAfter: number, lockForMs: number) {
    const u = this.users.get(id);
    if (u === undefined) return;
    const failed = u.failedAttempts + 1;
    this.#patch(id, { failedAttempts: failed, lockedUntil: failed >= lockAfter ? new Date(this.now() + lockForMs) : u.lockedUntil });
  }
  async acceptLogin(id: string, step: number) {
    const u = this.users.get(id);
    if (u === undefined || (u.totpLastStep !== null && u.totpLastStep >= step)) return false;
    this.#patch(id, { totpLastStep: step, failedAttempts: 0, lockedUntil: null });
    return true;
  }
  async createSession(s: { tokenHash: Buffer; adminId: string; expiresAt: Date }) {
    this.sessions.set(s.tokenHash.toString("hex"), { adminId: s.adminId, expiresAt: s.expiresAt, lastSeenAt: new Date(this.now()), revoked: false });
  }
  async touchSession(hash: Buffer, idleMs: number): Promise<AdminSession | null> {
    const s = this.sessions.get(hash.toString("hex"));
    const t = this.now();
    if (s === undefined || s.revoked || s.expiresAt.getTime() <= t || s.lastSeenAt.getTime() <= t - idleMs) return null;
    const u = this.users.get(s.adminId);
    if (u === undefined || u.disabledAt !== null) return null;
    s.lastSeenAt = new Date(t);
    return { adminId: u.id, email: u.email, role: u.role, expiresAt: s.expiresAt, lastSeenAt: s.lastSeenAt };
  }
  async revokeSession(hash: Buffer) {
    const s = this.sessions.get(hash.toString("hex"));
    if (s !== undefined) s.revoked = true;
  }
  async revokeAllSessions(id: string) {
    for (const s of this.sessions.values()) if (s.adminId === id) s.revoked = true;
  }
  async audit(e: AuditEntry) {
    this.auditLog.push({ ...e, at: new Date(this.now()) });
  }
  async listAudit(limit: number): Promise<AuditRow[]> {
    return this.auditLog
      .map((e, i) => ({ ...e, id: String(i + 1), adminEmail: null, createdAt: e.at }))
      .reverse()
      .slice(0, limit);
  }
  async stats(): Promise<Stats> {
    return { swapsByStatus: [], confirmedVolume: [], feeRevenue: [], rampByStatus: [], dailyConfirmed: [] };
  }
  async listSwaps() {
    return [];
  }
  async listRampOrders() {
    return [];
  }
  async listAllTokens() {
    return this.tokens;
  }
  async setTokenEnabled(chainId: number, address: string, enabled: boolean, a: { adminId: string | null; ip: string | null }) {
    const i = this.tokens.findIndex((t) => t.chainId === chainId && t.address === address);
    const t = this.tokens[i];
    if (t === undefined) return null;
    this.tokens[i] = { ...t, enabled, review: "manual", note: null };
    await this.audit({ ...a, action: "token.enabled_changed", target: `${chainId}:${address}`, before: { enabled: t.enabled }, after: { enabled } });
    return this.tokens[i] ?? null;
  }
  async addToken(t: Omit<AdminTokenRow, "enabled">, a: { adminId: string | null; ip: string | null }) {
    if (this.tokens.some((x) => x.chainId === t.chainId && x.address === t.address)) return "exists" as const;
    this.tokens.push({ ...t, enabled: false });
    await this.audit({ ...a, action: "token.added", target: `${t.chainId}:${t.address}`, before: null, after: t });
    return "added" as const;
  }
  async listSettings(keys: readonly string[]): Promise<SettingRow[]> {
    return keys.flatMap((k) => {
      const s = this.settings.get(k);
      return s === undefined ? [] : [{ key: k, value: s.value, version: s.version, updatedAt: s.updatedAt }];
    });
  }
  async updateSetting(key: string, value: unknown, expected: number, a: { adminId: string | null; ip: string | null }) {
    const s = this.settings.get(key);
    if (s === undefined) return "not_found" as const;
    if (s.version !== expected) return "version_conflict" as const;
    this.settings.set(key, { value, version: s.version + 1, updatedAt: new Date(this.now()) });
    await this.audit({ ...a, action: "setting.updated", target: key, before: s.value, after: value });
    return "updated" as const;
  }
  async trackerBacklog() {
    return 0;
  }
  async lastWebhookAt() {
    return {};
  }
}
