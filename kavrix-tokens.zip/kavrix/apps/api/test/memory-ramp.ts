import { randomUUID } from "node:crypto";
import type { Address } from "@kavrix/shared";
import { decideEvent, type EventOutcome, type NewRampOrder, type ProviderEvent, type RampRecord, type RampRepository } from "@kavrix/db";

export class MemoryRampRepository implements RampRepository {
  readonly rows = new Map<string, RampRecord>();
  readonly events = new Set<string>();

  async create(o: NewRampOrder) {
    for (const r of this.rows.values()) if (r.idempotencyKey === o.idempotencyKey) return { record: r, created: false };
    const t = new Date();
    const rec: RampRecord = { ...o, id: randomUUID(), status: "created", providerStatus: null, externalOrderId: null, createdAt: t, updatedAt: t };
    this.rows.set(rec.id, rec);
    return { record: rec, created: true };
  }

  async get(id: string) {
    return this.rows.get(id) ?? null;
  }

  async applyEvent(e: ProviderEvent): Promise<EventOutcome> {
    const key = `${e.provider}:${e.eventId}`;
    if (this.events.has(key)) return "duplicate";
    this.events.add(key);
    const order = e.orderId === null ? undefined : this.rows.get(e.orderId);
    if (order === undefined) return "unknown_order";
    const outcome = decideEvent(order, e);
    if (outcome === "applied") {
      this.rows.set(order.id, { ...order, status: e.status, providerStatus: e.providerStatus, externalOrderId: order.externalOrderId ?? e.externalOrderId });
    }
    return outcome;
  }

  async listByWallet(wallet: Address, limit: number) {
    return [...this.rows.values()].filter((r) => r.walletAddress === wallet && r.externalOrderId !== null).slice(0, limit);
  }
}
