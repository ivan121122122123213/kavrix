import { randomUUID } from "node:crypto";
import { canTransitionSwap, type Address } from "@kavrix/shared";
import type { ChainCheckUpdate, NewSwap, RejectResult, SubmitResult, SwapRecord, SwapRepository } from "@kavrix/db";

/** In-memory SwapRepository mirroring the Postgres semantics, including the status trigger. */
export class MemorySwapRepository implements SwapRepository {
  readonly rows = new Map<string, SwapRecord & { nextCheckAt: Date | null }>();
  now: () => number = Date.now;

  async create(s: NewSwap) {
    for (const r of this.rows.values()) if (r.idempotencyKey === s.idempotencyKey) return { record: r, created: false };
    const t = new Date(this.now());
    const rec = {
      ...s, id: randomUUID(), status: "quoted" as const, actualBuyAmount: null, txHash: null, blockNumber: null,
      confirmations: null, failureCode: null, submittedAt: null, createdAt: t, updatedAt: t, nextCheckAt: null,
    };
    this.rows.set(rec.id, rec);
    return { record: rec, created: true };
  }

  async get(id: string) {
    return this.rows.get(id) ?? null;
  }

  async submit(id: string, txHash: `0x${string}`, now: Date): Promise<SubmitResult> {
    const r = this.rows.get(id);
    if (r === undefined) return "not_found";
    if (r.status === "quoted") {
      this.rows.set(id, { ...r, status: "submitted", txHash, submittedAt: now, nextCheckAt: now, updatedAt: now });
      return "submitted";
    }
    if (r.txHash !== null) return r.txHash === txHash ? "already_submitted" : "hash_conflict";
    return "wrong_state";
  }

  async reject(id: string): Promise<RejectResult> {
    const r = this.rows.get(id);
    if (r === undefined) return "not_found";
    if (r.status === "quoted") {
      this.rows.set(id, { ...r, status: "rejected" });
      return "rejected";
    }
    return r.status === "rejected" ? "already_rejected" : "wrong_state";
  }

  async listByWallet(taker: Address, limit: number, before?: { createdAt: Date; id: string }) {
    return [...this.rows.values()]
      .filter((r) => r.taker === taker && r.txHash !== null)
      .filter((r) => before === undefined || r.createdAt < before.createdAt || (r.createdAt.getTime() === before.createdAt.getTime() && r.id < before.id))
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime() || (a.id < b.id ? 1 : -1))
      .slice(0, limit);
  }

  async claimDue(limit: number, leaseMs: number) {
    const t = this.now();
    const due = [...this.rows.values()]
      .filter((r) => r.nextCheckAt !== null && r.nextCheckAt.getTime() <= t && (r.status === "submitted" || r.status === "dropped"))
      .slice(0, limit);
    for (const r of due) this.rows.set(r.id, { ...r, nextCheckAt: new Date(t + leaseMs) });
    return due;
  }

  async applyCheck(id: string, u: ChainCheckUpdate) {
    const r = this.rows.get(id);
    if (r === undefined) return;
    if (u.status !== undefined && u.status !== r.status && !canTransitionSwap(r.status, u.status)) {
      throw new Error(`illegal swap status transition ${r.status} -> ${u.status}`);
    }
    this.rows.set(id, {
      ...r,
      status: u.status ?? r.status,
      blockNumber: u.blockNumber ?? r.blockNumber,
      confirmations: u.confirmations ?? r.confirmations,
      actualBuyAmount: u.actualBuyAmount ?? r.actualBuyAmount,
      failureCode: u.failureCode ?? r.failureCode,
      nextCheckAt: u.nextCheckAt,
    });
  }

  async expireQuoted(before: Date) {
    let n = 0;
    for (const r of this.rows.values()) {
      if (r.status === "quoted" && r.quoteExpiresAt < before) {
        this.rows.set(r.id, { ...r, status: "expired" });
        n++;
      }
    }
    return n;
  }
}
