import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import type { Address } from "@kavrix/shared";
import type { NewSwap } from "@kavrix/db";
import type { ChainReader, ChainReceipt, ChainTx } from "../src/chain/reader.ts";
import { ERC20_TRANSFER_TOPIC, SwapTracker } from "../src/worker/swap-tracker.ts";
import { MemorySwapRepository } from "./memory-repo.ts";

const TAKER: Address = "0x70a9f34f9b34c64957b9c401a97bfed35b95049e";
const ROUTER: Address = "0x6131b5fae19ea4f9d964eac0408e4408b66337b5";
const USDC: Address = "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913";
const NATIVE: Address = "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee";
const DATA = "0x8af033fb0011223344" as const;
const HASH = `0x${"ab".repeat(32)}` as const;

const newSwap = (over: Partial<NewSwap> = {}): NewSwap => ({
  idempotencyKey: `key-${Math.random().toString(36).slice(2)}-0000000`,
  provider: "kyberswap", chainId: 8453, taker: TAKER, sellToken: NATIVE, buyToken: USDC,
  sellAmount: 10n ** 15n, quotedBuyAmount: 3_500_000n, minBuyAmount: 3_465_000n, slippageBps: 100,
  platformFeeBps: 0, platformFeeAmount: 0n, providerFeeAmount: 0n, networkFeeEstimate: null,
  quoteExpiresAt: new Date(1_000_000 + 30_000), txTo: ROUTER,
  txDataSha256: createHash("sha256").update(Buffer.from(DATA.slice(2), "hex")).digest("hex"), txValue: 10n ** 15n,
  ...over,
});

class FakeChain implements ChainReader {
  tx: ChainTx | null = null;
  receipt: ChainReceipt | null = null;
  head = 100n;
  fail = false;
  async getTransaction() {
    if (this.fail) throw new Error("node down");
    return this.tx;
  }
  async getReceipt() {
    return this.receipt;
  }
  async blockNumber() {
    return this.head;
  }
}

function setup() {
  let t = 1_000_000;
  const repo = new MemorySwapRepository();
  repo.now = () => t;
  const chain = new FakeChain();
  const tracker = new SwapTracker({ repo, readers: { 1: chain, 8453: chain, 42161: chain, 137: chain }, now: () => t });
  return { repo, chain, tracker, advance: (ms: number) => (t += ms), now: () => t };
}

const goodTx: ChainTx = { from: TAKER, to: ROUTER, value: 10n ** 15n, input: DATA };
const transferLog = (to: Address, amount: bigint) => ({
  address: USDC,
  topics: [ERC20_TRANSFER_TOPIC, `0x${"00".repeat(12)}${ROUTER.slice(2)}`, `0x${"00".repeat(12)}${to.slice(2)}`] as `0x${string}`[],
  data: `0x${amount.toString(16).padStart(64, "0")}` as `0x${string}`,
});

async function submitted(env: ReturnType<typeof setup>) {
  const { record } = await env.repo.create(newSwap());
  await env.repo.submit(record.id, HASH, new Date(env.now()));
  return record.id;
}

describe("swap tracker", () => {
  it("confirms only after the chain's confirmation depth, recording the received amount", async () => {
    const env = setup();
    const id = await submitted(env);
    env.chain.tx = goodTx;
    env.chain.receipt = { status: "success", blockNumber: 98n, logs: [transferLog(TAKER, 3_480_000n), transferLog(ROUTER, 5n)] };
    env.chain.head = 99n; // depth 2 < 5 on Base
    await env.tracker.tick();
    assert.equal((await env.repo.get(id))?.status, "submitted");
    assert.equal((await env.repo.get(id))?.confirmations, 2);

    env.advance(5_000);
    env.chain.head = 102n; // depth 5
    await env.tracker.tick();
    const rec = await env.repo.get(id);
    assert.equal(rec?.status, "confirmed");
    assert.equal(rec?.actualBuyAmount, 3_480_000n);
    assert.equal(env.repo.rows.get(id)?.nextCheckAt, null, "tracking stops");
  });

  it("marks reverts as reverted, never as success", async () => {
    const env = setup();
    const id = await submitted(env);
    env.chain.tx = goodTx;
    env.chain.receipt = { status: "reverted", blockNumber: 90n, logs: [] };
    await env.tracker.tick();
    assert.equal((await env.repo.get(id))?.status, "reverted");
  });

  it("rejects a reported hash that is not the prepared transaction", async () => {
    for (const tx of [
      { ...goodTx, from: ROUTER },
      { ...goodTx, to: USDC },
      { ...goodTx, value: 1n },
      { ...goodTx, input: "0x8af033fb00" as const },
    ]) {
      const env = setup();
      const id = await submitted(env);
      env.chain.tx = tx;
      env.chain.receipt = { status: "success", blockNumber: 1n, logs: [] };
      await env.tracker.tick();
      const rec = await env.repo.get(id);
      assert.equal(rec?.status, "failed");
      assert.equal(rec?.failureCode, "TX_MISMATCH");
    }
  });

  it("drops unseen transactions after the timeout and still confirms them if they appear", async () => {
    const env = setup();
    const id = await submitted(env);
    await env.tracker.tick();
    assert.equal((await env.repo.get(id))?.status, "submitted");
    env.advance(11 * 60_000);
    await env.tracker.tick();
    assert.equal((await env.repo.get(id))?.status, "dropped");
    env.advance(61_000);
    env.chain.tx = goodTx;
    env.chain.receipt = { status: "success", blockNumber: 50n, logs: [transferLog(TAKER, 1n)] };
    await env.tracker.tick();
    assert.equal((await env.repo.get(id))?.status, "confirmed");
  });

  it("backs off on node errors without changing status", async () => {
    const env = setup();
    const id = await submitted(env);
    env.chain.fail = true;
    await env.tracker.tick();
    const row = env.repo.rows.get(id);
    assert.equal(row?.status, "submitted");
    assert.ok((row?.nextCheckAt?.getTime() ?? 0) >= env.now() + 30_000);
  });

  it("expires unsigned quotes only after the router deadline grace", async () => {
    const env = setup();
    const { record } = await env.repo.create(newSwap());
    env.advance(60_000);
    await env.tracker.tick();
    assert.equal((await env.repo.get(record.id))?.status, "quoted");
    env.advance(15 * 60_000);
    await env.tracker.tick();
    assert.equal((await env.repo.get(record.id))?.status, "expired");
  });

  it("reports native output as unknown rather than guessing", async () => {
    const env = setup();
    const { record } = await env.repo.create(newSwap({ sellToken: USDC, buyToken: NATIVE, txValue: 0n }));
    await env.repo.submit(record.id, HASH, new Date(env.now()));
    env.chain.tx = { ...goodTx, value: 0n };
    env.chain.receipt = { status: "success", blockNumber: 1n, logs: [] };
    await env.tracker.tick();
    const rec = await env.repo.get(record.id);
    assert.equal(rec?.status, "confirmed");
    assert.equal(rec?.actualBuyAmount, null);
  });
});
