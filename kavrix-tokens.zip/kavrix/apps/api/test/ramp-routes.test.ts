import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createHmac } from "node:crypto";
import { MoonPayClient, TransakClient } from "@kavrix/integrations";
import { buildApp } from "../src/app.ts";
import { parseConfig } from "../src/config.ts";
import { MemorySwapRepository } from "./memory-repo.ts";
import { MemoryRampRepository } from "./memory-ramp.ts";

const config = parseConfig({ NODE_ENV: "test", PUBLIC_WEB_ORIGIN: "https://kavrix.example", DATABASE_URL: "postgres://k:t@localhost/k" });
const WALLET = "0x70a9f34f9b34c64957b9c401a97bfed35b95049e";
const USDC = "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913";
const WEBHOOK_KEY = "wk_test_123";
const TOKEN = "transak-access-token-".padEnd(48, "x");

const moonpayFetch = (async () =>
  Response.json([
    { type: "crypto", code: "usdc_base", isSellSupported: true, metadata: { contractAddress: USDC, chainId: "8453" } },
    { type: "crypto", code: "eth_base", isSellSupported: false, metadata: { contractAddress: null, chainId: "8453" } },
  ])) as typeof fetch;

async function setup() {
  const repo = new MemoryRampRepository();
  const app = await buildApp({
    config, version: "t", swapProvider: undefined, swapRepo: new MemorySwapRepository(), rampRepo: repo, quoteKey: Buffer.alloc(32, 1),
    pingDatabase: async () => true,
    listTokens: async () => [{ chainId: 8453, address: USDC, symbol: "USDC", name: "USD Coin", decimals: 6, logoUrl: null }],
    moonpay: { client: new MoonPayClient({ environment: "sandbox", publishableKey: "pk_test_x", secretKey: "sk_test_x", fetch: moonpayFetch }), webhookKey: WEBHOOK_KEY },
    transak: new TransakClient({
      environment: "staging", apiKey: "pk", apiSecret: "sk",
      tokenStore: { load: async () => ({ accessToken: TOKEN, expiresAt: 4_000_000_000, previous: null }), save: async () => undefined },
      fetch: (async () => Response.json({ data: { widgetUrl: "https://global-stg.transak.com?apiKey=pk&sessionId=s1" } })) as typeof fetch,
    }),
  });
  return { app, repo };
}

const session = { provider: "moonpay", direction: "buy", chainId: 8453, token: USDC, fiatCurrency: "USD", amount: "100", wallet: WALLET };
const idem = { "idempotency-key": "ramp-attempt-0123456789" };

function moonpayHook(body: object, key = WEBHOOK_KEY, t = Math.floor(Date.now() / 1000)) {
  const raw = JSON.stringify(body);
  const s = createHmac("sha256", key).update(`${t}.${raw}`).digest("hex");
  return { headers: { "content-type": "application/json", "moonpay-signature-v2": `t=${t},s=${s}` }, payload: raw };
}

function transakHook(claims: object, secret = TOKEN) {
  const b64 = (v: object) => Buffer.from(JSON.stringify(v)).toString("base64url");
  const input = `${b64({ alg: "HS256", typ: "JWT" })}.${b64(claims)}`;
  const jwt = `${input}.${createHmac("sha256", secret).update(input).digest("base64url")}`;
  return { headers: { "content-type": "application/json" }, payload: JSON.stringify({ data: jwt }) };
}

describe("ramp sessions", () => {
  it("creates a MoonPay order with a signed URL bound to the order id", async () => {
    const { app, repo } = await setup();
    const res = await app.inject({ method: "POST", url: "/v1/ramp/sessions", headers: idem, payload: session });
    assert.equal(res.statusCode, 201);
    const { orderId, widgetUrl } = res.json();
    const url = new URL(widgetUrl);
    assert.equal(url.origin, "https://buy-sandbox.moonpay.com");
    assert.equal(url.searchParams.get("externalTransactionId"), orderId);
    assert.equal(url.searchParams.get("currencyCode"), "usdc_base");
    assert.equal(url.searchParams.get("redirectURL"), `https://kavrix.example/history?order=${orderId}`);
    assert.ok(url.searchParams.get("signature"));
    assert.equal(repo.rows.get(orderId)?.status, "created");
    await app.close();
  });

  it("creates a Transak session", async () => {
    const { app } = await setup();
    const res = await app.inject({ method: "POST", url: "/v1/ramp/sessions", headers: idem, payload: { ...session, provider: "transak", fiatCurrency: "EUR" } });
    assert.equal(res.statusCode, 201);
    assert.equal(new URL(res.json().widgetUrl).host, "global-stg.transak.com");
    await app.close();
  });

  it("refuses unsupported assets, bad amounts and missing keys", async () => {
    const { app } = await setup();
    const post = (body: object, headers: Record<string, string> = idem) => app.inject({ method: "POST", url: "/v1/ramp/sessions", headers, payload: body });
    assert.equal((await post({ ...session, direction: "sell", token: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", amount: "1" })).json().code, "ASSET_NOT_SUPPORTED");
    assert.equal((await post({ ...session, token: "0x1111111111111111111111111111111111111111" })).json().code, "ASSET_NOT_SUPPORTED");
    assert.equal((await post({ ...session, amount: "10.555" })).json().code, "INVALID_AMOUNT");
    assert.equal((await post({ ...session, direction: "sell", amount: "1.1234567" })).json().code, "INVALID_AMOUNT");
    assert.equal((await post(session, {})).json().code, "IDEMPOTENCY_KEY_REQUIRED");
    await app.close();
  });
});

describe("provider webhooks", () => {
  it("applies a verified MoonPay webhook once and ignores replays", async () => {
    const { app, repo } = await setup();
    const { orderId } = (await app.inject({ method: "POST", url: "/v1/ramp/sessions", headers: idem, payload: session })).json();
    const body = { type: "transaction_updated", data: { id: "mp-1", status: "completed", externalTransactionId: orderId, updatedAt: "t1" } };
    const first = await app.inject({ method: "POST", url: "/v1/webhooks/moonpay", ...moonpayHook(body) });
    assert.equal(first.json().result, "applied");
    assert.equal(repo.rows.get(orderId)?.status, "completed");
    const replay = await app.inject({ method: "POST", url: "/v1/webhooks/moonpay", ...moonpayHook(body) });
    assert.equal(replay.json().result, "duplicate");
    const late = { type: "transaction_updated", data: { id: "mp-1", status: "pending", externalTransactionId: orderId, updatedAt: "t0" } };
    assert.equal((await app.inject({ method: "POST", url: "/v1/webhooks/moonpay", ...moonpayHook(late) })).json().result, "stale");
    assert.equal(repo.rows.get(orderId)?.status, "completed", "never moves backwards");
    await app.close();
  });

  it("rejects forged, stale and tampered MoonPay webhooks", async () => {
    const { app } = await setup();
    const body = { type: "transaction_updated", data: { id: "mp-1", status: "completed" } };
    assert.equal((await app.inject({ method: "POST", url: "/v1/webhooks/moonpay", ...moonpayHook(body, "wrong") })).statusCode, 401);
    assert.equal((await app.inject({ method: "POST", url: "/v1/webhooks/moonpay", ...moonpayHook(body, WEBHOOK_KEY, 1_000) })).statusCode, 401);
    const signed = moonpayHook(body);
    const tampered = { ...signed, payload: signed.payload.replace("completed", "failed") };
    assert.equal((await app.inject({ method: "POST", url: "/v1/webhooks/moonpay", ...tampered })).statusCode, 401);
    await app.close();
  });

  it("verifies Transak JWT webhooks with the stored access token", async () => {
    const { app, repo } = await setup();
    const { orderId } = (await app.inject({ method: "POST", url: "/v1/ramp/sessions", headers: idem, payload: { ...session, provider: "transak" } })).json();
    const claims = { eventID: "ORDER_FAILED", webhookData: { id: "tk-1", status: "EXPIRED", partnerOrderId: orderId } };
    assert.equal((await app.inject({ method: "POST", url: "/v1/webhooks/transak", ...transakHook(claims, "other-secret") })).statusCode, 401);
    const ok = await app.inject({ method: "POST", url: "/v1/webhooks/transak", ...transakHook(claims) });
    assert.equal(ok.json().result, "applied");
    assert.equal(repo.rows.get(orderId)?.status, "expired");
    await app.close();
  });
});
