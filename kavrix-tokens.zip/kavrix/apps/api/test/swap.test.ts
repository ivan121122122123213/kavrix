import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { ProviderError, type QuoteOutcome, type SwapProvider, type SwapRequest } from "@kavrix/integrations";
import { buildApp } from "../src/app.ts";
import { MemorySwapRepository } from "./memory-repo.ts";
import { MemoryRampRepository } from "./memory-ramp.ts";
import { parseConfig } from "../src/config.ts";

const USDC = "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913";
const NATIVE = "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee";
const TAKER = "0x70a9f34f9b34c64957b9c401a97bfed35b95049e";
const ROUTER = "0x6131b5fae19ea4f9d964eac0408e4408b66337b5";

const config = parseConfig({ NODE_ENV: "test", PUBLIC_WEB_ORIGIN: "http://localhost:5173", DATABASE_URL: "postgres://k:t@localhost/k" });

function fakeProvider(outcome: QuoteOutcome | ProviderError, seen: SwapRequest[] = []): SwapProvider {
  return {
    id: "kyberswap",
    maxSlippageBps: 2000,
    async quote(request) {
      seen.push(request);
      if (outcome instanceof ProviderError) throw outcome;
      return outcome;
    },
  };
}

const firm: QuoteOutcome = {
  kind: "firm",
  quote: {
    provider: "kyberswap", chainId: 8453, sellToken: NATIVE, buyToken: USDC, sellAmount: 10n ** 15n, buyAmount: 3_500_000n,
    minBuyAmount: 3_465_000n, platformFee: { bps: 0, amount: 0n, token: "sell" }, providerFee: null, networkFeeWei: 10n ** 12n,
    route: [{ source: "uniswap-v3", proportionBps: 10_000 }], valueUsd: { sell: 3.5, buy: 3.49 }, taker: TAKER, spender: null,
    tx: { to: ROUTER, data: "0x8af033fb00", value: 10n ** 15n },
  },
};

async function app(provider: SwapProvider, rpcFetch?: typeof fetch) {
  return buildApp({
    config,
    swapRepo: new MemorySwapRepository(), rampRepo: new MemoryRampRepository(),
    quoteKey: Buffer.alloc(32, 7),
    version: "t",
    pingDatabase: async () => true,
    listTokens: async () => [{ chainId: 8453, address: USDC, symbol: "USDC", name: "USD Coin", decimals: 6, logoUrl: null }],
    swapProvider: provider,
    ...(rpcFetch === undefined ? {} : { rpcFetch }),
  });
}

const body = { chainId: 8453, sellToken: NATIVE, buyToken: USDC, sellAmount: "1000000000000000", slippageBps: 100, taker: TAKER };

describe("POST /v1/swap/quote", () => {
  it("returns a firm quote with bigint fields as strings and an expiry", async () => {
    const seen: SwapRequest[] = [];
    const a = await app(fakeProvider(firm, seen));
    const res = await a.inject({ method: "POST", url: "/v1/swap/quote", payload: body });
    assert.equal(res.statusCode, 200);
    const json = res.json();
    assert.equal(json.firm, true);
    assert.equal(json.tx.value, "1000000000000000");
    assert.equal(json.minBuyAmount, "3465000");
    assert.match(json.quoteToken, /^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]{43}$/);
    assert.ok(json.expiresAt > Date.now());
    assert.equal(seen[0]?.sellAmount, 10n ** 15n);
    await a.close();
  });

  it("refuses tokens that are not listed", async () => {
    const a = await app(fakeProvider(firm));
    const res = await a.inject({ method: "POST", url: "/v1/swap/quote", payload: { ...body, buyToken: "0x1111111111111111111111111111111111111111" } });
    assert.equal(res.json().code, "TOKEN_NOT_LISTED");
    await a.close();
  });

  it("validates input strictly", async () => {
    const a = await app(fakeProvider(firm));
    for (const bad of [{ ...body, sellAmount: "0" }, { ...body, sellAmount: "1.5" }, { ...body, slippageBps: 2001 }, { ...body, extra: 1 }, { ...body, chainId: 10 }]) {
      const res = await a.inject({ method: "POST", url: "/v1/swap/quote", payload: bad });
      assert.equal(res.statusCode, 400, JSON.stringify(bad));
    }
    await a.close();
  });

  it("maps provider failures without leaking details", async () => {
    const cases: [ProviderError | QuoteOutcome, number, string][] = [
      [{ kind: "no_route" }, 422, "NO_ROUTE"],
      [new ProviderError("kyberswap", "QUOTE_UNSAFE", "Calldata sends output to another address"), 502, "QUOTE_REJECTED"],
      [new ProviderError("kyberswap", "PROVIDER_RATE_LIMITED", "x"), 503, "QUOTES_BUSY"],
      [new ProviderError("kyberswap", "PROVIDER_TIMEOUT", "x"), 503, "PROVIDER_UNAVAILABLE"],
    ];
    for (const [outcome, status, code] of cases) {
      const a = await app(fakeProvider(outcome));
      const res = await a.inject({ method: "POST", url: "/v1/swap/quote", payload: body });
      assert.equal(res.statusCode, status, code);
      assert.equal(res.json().code, code);
      assert.equal(res.body.includes("another address"), false);
      await a.close();
    }
  });
});

describe("POST /v1/rpc/:chainId", () => {
  const rpc = { jsonrpc: "2.0", id: 1, method: "eth_blockNumber", params: [] };

  it("forwards allowed read methods to the configured node", async () => {
    let target = "";
    const a = await app(fakeProvider(firm), (async (url: string | URL | Request) => {
      target = String(url);
      return Response.json({ jsonrpc: "2.0", id: 1, result: "0x10" });
    }) as typeof fetch);
    const res = await a.inject({ method: "POST", url: "/v1/rpc/8453", payload: rpc });
    assert.equal(res.json().result, "0x10");
    assert.equal(target, "https://base-rpc.publicnode.com");
    await a.close();
  });

  it("blocks writes and unknown methods without contacting the node", async () => {
    const a = await app(fakeProvider(firm), (async () => assert.fail("must not forward")) as typeof fetch);
    const res = await a.inject({ method: "POST", url: "/v1/rpc/1", payload: { ...rpc, method: "eth_sendRawTransaction", params: ["0x00"] } });
    assert.equal(res.json().error.code, -32601);
    assert.equal((await a.inject({ method: "POST", url: "/v1/rpc/1", payload: [rpc] })).statusCode, 400);
    assert.equal((await a.inject({ method: "POST", url: "/v1/rpc/10", payload: rpc })).statusCode, 400);
    await a.close();
  });

  it("reports node outages as 503", async () => {
    const a = await app(fakeProvider(firm), (async () => {
      throw new TypeError("fetch failed");
    }) as typeof fetch);
    assert.equal((await a.inject({ method: "POST", url: "/v1/rpc/1", payload: rpc })).json().code, "RPC_UNAVAILABLE");
    await a.close();
  });
});
