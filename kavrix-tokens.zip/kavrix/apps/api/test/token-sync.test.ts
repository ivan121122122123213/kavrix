import { describe, it } from "node:test";
import assert from "node:assert/strict";
import type { Address, SupportedChainId } from "@kavrix/shared";
import type { SourceToken } from "@kavrix/integrations";
import type { StoredToken, SyncedToken, TokenSyncRepository } from "@kavrix/db";
import { syncTokens, type TokenSyncDeps } from "../src/tokens/sync.ts";

const addr = (n: number) => `0x${n.toString(16).padStart(40, "0")}` as Address;
const USDC = "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48" as Address;

class MemoryTokens implements TokenSyncRepository {
  rows = new Map<string, StoredToken & { note?: string | null }>();
  constructor(seed: StoredToken[] = []) {
    for (const s of seed) this.rows.set(`${s.chainId}:${s.address}`, s);
  }
  async all(chainId: SupportedChainId) {
    return [...this.rows.values()].filter((r) => r.chainId === chainId);
  }
  async upsert(rows: readonly SyncedToken[]) {
    let n = 0;
    for (const r of rows) {
      const k = `${r.chainId}:${r.address}`;
      const cur = this.rows.get(k);
      if (cur?.review === "manual" || (cur !== undefined && cur.decimals !== r.decimals)) continue;
      this.rows.set(k, { chainId: r.chainId, address: r.address, symbol: r.symbol, decimals: r.decimals, enabled: r.enabled, review: r.review, note: r.note });
      n++;
    }
    return n;
  }
  async retire(chainId: SupportedChainId, keep: ReadonlySet<string>) {
    let n = 0;
    for (const [k, r] of this.rows) {
      if (r.chainId === chainId && r.review === "auto" && r.enabled && !keep.has(r.address)) {
        this.rows.set(k, { ...r, enabled: false, review: "pending" });
        n++;
      }
    }
    return n;
  }
  get(a: Address) {
    return this.rows.get(`1:${a}`);
  }
}

const kyber = (a: Address, symbol: string, extra: Partial<SourceToken> = {}): SourceToken => ({ source: "kyberswap", chainId: 1, address: a, symbol, name: symbol, decimals: 18, logoUrl: null, ...extra });
const listed = (a: Address, symbol: string): SourceToken => ({ source: "coingecko", chainId: 1, address: a, symbol, name: symbol, decimals: 18, logoUrl: null });

function deps(repo: MemoryTokens, over: Partial<TokenSyncDeps> = {}): TokenSyncDeps {
  return {
    repo,
    chains: [1],
    kyberWhitelist: async () => [kyber(addr(1), "PEPE"), kyber(addr(2), "SOLO"), kyber(addr(3), "TRAP")],
    lists: async () => [{ url: "cg", ok: true, tokens: [listed(addr(1), "PEPE"), listed(addr(3), "TRAP")] }],
    onChainDecimals: async () => 18,
    safety: async (_c, a) => ({ isHoneypot: a === addr(3), isFeeOnTransfer: false }),
    ...over,
  };
}

describe("token sync", () => {
  it("enables verified tokens, parks single-source ones and drops honeypots", async () => {
    const repo = new MemoryTokens();
    const [r] = await syncTokens(deps(repo));
    assert.equal(repo.get(addr(1))?.enabled, true);
    assert.equal(repo.get(addr(1))?.review, "auto");
    assert.equal(repo.get(addr(2))?.review, "pending");
    assert.equal(repo.get(addr(2))?.enabled, false);
    assert.equal(repo.get(addr(3)), undefined, "honeypot never stored as listable");
    assert.equal(r?.enabled, 1);
  });

  it("refuses a token whose contract disagrees with the lists", async () => {
    const repo = new MemoryTokens();
    await syncTokens(deps(repo, { onChainDecimals: async () => 9 }));
    assert.equal(repo.get(addr(1))?.enabled, false);
    assert.match(repo.get(addr(1))?.note ?? "", /contract reports 9 decimals/);
  });

  it("treats a failed safety check as not verified", async () => {
    const repo = new MemoryTokens();
    await syncTokens(deps(repo, { safety: async () => { throw new Error("token api down"); } }));
    assert.equal(repo.get(addr(1))?.enabled, false);
    assert.match(repo.get(addr(1))?.note ?? "", /will retry/);
  });

  it("never changes operator-added tokens and blocks look-alikes of them", async () => {
    const repo = new MemoryTokens([{ chainId: 1, address: USDC, symbol: "USDC", decimals: 6, enabled: true, review: "manual" }]);
    await syncTokens(
      deps(repo, {
        kyberWhitelist: async () => [kyber(USDC, "USDC", { decimals: 6 }), kyber(addr(9), "USDC")],
        lists: async () => [{ url: "cg", ok: true, tokens: [{ ...listed(USDC, "USDC"), decimals: 6 }, listed(addr(9), "USDC")] }],
      }),
    );
    assert.equal(repo.get(USDC)?.review, "manual");
    assert.equal(repo.get(addr(9)), undefined, "fake USDC rejected");
  });

  it("retires tokens the sources dropped, but not during an outage", async () => {
    const live = (n: number): StoredToken => ({ chainId: 1, address: addr(n), symbol: `T${n}`, decimals: 18, enabled: true, review: "auto" });
    const outage = new MemoryTokens([live(10), live(11)]);
    const [r1] = await syncTokens(deps(outage, { kyberWhitelist: async () => { throw new Error("down"); } }));
    assert.equal(r1?.sourcesHealthy, false);
    assert.equal(outage.get(addr(10))?.enabled, true, "outage must not empty the list");

    const healthy = new MemoryTokens([live(10)]);
    await syncTokens(deps(healthy));
    assert.equal(healthy.get(addr(10))?.enabled, false, "dropped by the sources, so retired");
    assert.equal(healthy.get(addr(10))?.review, "pending");
  });

  it("spends a bounded number of checks per run and continues next time", async () => {
    const many = Array.from({ length: 5 }, (_, i) => addr(100 + i));
    const repo = new MemoryTokens();
    let checks = 0;
    const d = deps(repo, {
      maxChecksPerRun: 2,
      kyberWhitelist: async () => many.map((a, i) => kyber(a, `M${i}`)),
      lists: async () => [{ url: "cg", ok: true, tokens: many.map((a, i) => listed(a, `M${i}`)) }],
      onChainDecimals: async () => {
        checks++;
        return 18;
      },
    });
    const [first] = await syncTokens(d);
    assert.equal(first?.enabled, 2);
    assert.equal(first?.deferred, 3);
    await syncTokens(d);
    await syncTokens(d);
    assert.equal([...repo.rows.values()].filter((r) => r.enabled).length, 5);
    assert.equal(checks, 5, "already-live tokens are not re-checked");
  });
});
