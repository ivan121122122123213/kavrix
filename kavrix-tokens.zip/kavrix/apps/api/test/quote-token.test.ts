import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { randomBytes } from "node:crypto";
import { signQuote, verifyQuote, type QuoteClaims } from "../src/quote-token.ts";

const key = randomBytes(32);
const claims: QuoteClaims = {
  v: 1, provider: "kyberswap", chainId: 8453,
  taker: "0x70a9f34f9b34c64957b9c401a97bfed35b95049e", sellToken: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
  buyToken: "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913", sellAmount: 10n ** 15n, buyAmount: 3_500_000n, minBuyAmount: 3_465_000n,
  slippageBps: 100, platformFeeBps: 25, platformFeeAmount: 2_500_000_000_000n, providerFeeAmount: 0n, networkFeeWei: null,
  txTo: "0x6131b5fae19ea4f9d964eac0408e4408b66337b5", txDataSha256: "ab".repeat(32), txValue: 10n ** 15n, expiresAt: 2_000,
};

describe("quote token", () => {
  it("round-trips every term", () => {
    const res = verifyQuote(signQuote(claims, key), key, 1_000);
    assert.equal(res.ok, true);
    if (res.ok) assert.deepEqual(res.claims, claims);
  });

  it("rejects tampering, foreign keys, expiry and junk", () => {
    const token = signQuote(claims, key);
    const [payload, sig] = token.split(".") as [string, string];
    const forged = Buffer.from(JSON.stringify({ ...JSON.parse(Buffer.from(payload, "base64url").toString()), minBuyAmount: "1" })).toString("base64url");
    assert.deepEqual(verifyQuote(`${forged}.${sig}`, key, 1_000), { ok: false, reason: "signature" });
    assert.deepEqual(verifyQuote(token, randomBytes(32), 1_000), { ok: false, reason: "signature" });
    assert.deepEqual(verifyQuote(token, key, 2_000), { ok: false, reason: "expired" });
    assert.deepEqual(verifyQuote("abc", key, 0), { ok: false, reason: "malformed" });
    assert.deepEqual(verifyQuote(`${payload}.${sig}.x`, key, 0), { ok: false, reason: "malformed" });
  });

  it("refuses a validly signed token with a malformed body", () => {
    const bad = signQuote({ ...claims, taker: "0xNOPE" as `0x${string}` }, key);
    assert.deepEqual(verifyQuote(bad, key, 1_000), { ok: false, reason: "malformed" });
  });
});
