import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { buildApp } from "../src/app.ts";
import { MemorySwapRepository } from "./memory-repo.ts";
import { MemoryRampRepository } from "./memory-ramp.ts";
import { parseConfig } from "../src/config.ts";

const config = parseConfig({
  NODE_ENV: "test",
  PUBLIC_WEB_ORIGIN: "http://localhost:5173",
  DATABASE_URL: "postgres://kavrix:test@localhost:5432/kavrix",
});

const usdc = { chainId: 8453, address: "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913", symbol: "USDC", name: "USD Coin", decimals: 6, logoUrl: null };

describe("api app", () => {
  it("lists the native asset first, then enabled tokens", async () => {
    const app = await buildApp({ config, swapRepo: new MemorySwapRepository(), rampRepo: new MemoryRampRepository(), quoteKey: Buffer.alloc(32, 7), version: "t", swapProvider: undefined, pingDatabase: async () => true, listTokens: async () => [usdc] });
    const res = await app.inject({ method: "GET", url: "/v1/tokens?chainId=8453" });
    assert.equal(res.statusCode, 200);
    const body = res.json();
    assert.equal(body.tokens[0].native, true);
    assert.equal(body.tokens[0].symbol, "ETH");
    assert.equal(body.tokens[1].symbol, "USDC");
    await app.close();
  });

  it("rejects unsupported or malformed chain ids", async () => {
    const app = await buildApp({ config, swapRepo: new MemorySwapRepository(), rampRepo: new MemoryRampRepository(), quoteKey: Buffer.alloc(32, 7), version: "t", swapProvider: undefined, pingDatabase: async () => true, listTokens: async () => [] });
    assert.equal((await app.inject({ method: "GET", url: "/v1/tokens?chainId=10" })).json().code, "UNSUPPORTED_CHAIN");
    assert.equal((await app.inject({ method: "GET", url: "/v1/tokens?chainId=abc" })).statusCode, 400);
    assert.equal((await app.inject({ method: "GET", url: "/v1/tokens" })).statusCode, 400);
    await app.close();
  });

  it("reports liveness without touching the database", async () => {
    const app = await buildApp({ config, swapRepo: new MemorySwapRepository(), rampRepo: new MemoryRampRepository(), quoteKey: Buffer.alloc(32, 7), version: "t", swapProvider: undefined, listTokens: async () => [], pingDatabase: async () => { throw new Error("must not be called"); } });
    const res = await app.inject({ method: "GET", url: "/health/live" });
    assert.equal(res.statusCode, 200);
    assert.ok(res.headers["x-request-id"]);
    await app.close();
  });

  it("reports not-ready when the database is down", async () => {
    const app = await buildApp({ config, swapRepo: new MemorySwapRepository(), rampRepo: new MemoryRampRepository(), quoteKey: Buffer.alloc(32, 7), version: "t", swapProvider: undefined, listTokens: async () => [], pingDatabase: async () => false });
    const res = await app.inject({ method: "GET", url: "/health/ready" });
    assert.equal(res.statusCode, 503);
    assert.deepEqual(res.json().checks, { database: "fail" });
    await app.close();
  });

  it("serves chains and honest capability flags", async () => {
    const app = await buildApp({ config, swapRepo: new MemorySwapRepository(), rampRepo: new MemoryRampRepository(), quoteKey: Buffer.alloc(32, 7), version: "t", swapProvider: undefined, listTokens: async () => [], pingDatabase: async () => true });
    const chains = await app.inject({ method: "GET", url: "/v1/chains" });
    assert.deepEqual(chains.json().chains.map((c: { id: number }) => c.id), [1, 8453, 42161, 137]);
    const caps = await app.inject({ method: "GET", url: "/v1/capabilities" });
    assert.equal(caps.json().swap.quotes, true);
    assert.equal(caps.json().swap.provider, "kyberswap");
    await app.close();
  });

  it("returns problem+json for unknown routes", async () => {
    const app = await buildApp({ config, swapRepo: new MemorySwapRepository(), rampRepo: new MemoryRampRepository(), quoteKey: Buffer.alloc(32, 7), version: "t", swapProvider: undefined, listTokens: async () => [], pingDatabase: async () => true });
    const res = await app.inject({ method: "GET", url: "/v1/nope" });
    assert.equal(res.statusCode, 404);
    assert.match(String(res.headers["content-type"]), /application\/problem\+json/);
    assert.equal(res.json().code, "NOT_FOUND");
    await app.close();
  });
});
