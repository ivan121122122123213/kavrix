import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { buildApp } from "../src/app.ts";
import { parseConfig } from "../src/config.ts";
import { signQuote, type QuoteClaims } from "../src/quote-token.ts";
import { MemorySwapRepository } from "./memory-repo.ts";
import { MemoryRampRepository } from "./memory-ramp.ts";

const key = Buffer.alloc(32, 9);
const config = parseConfig({ NODE_ENV: "test", PUBLIC_WEB_ORIGIN: "http://localhost:5173", DATABASE_URL: "postgres://k:t@localhost/k" });
const TAKER = "0x70a9f34f9b34c64957b9c401a97bfed35b95049e";
const claims = (over: Partial<QuoteClaims> = {}): QuoteClaims => ({
  v: 1, provider: "kyberswap", chainId: 8453, taker: TAKER, sellToken: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
  buyToken: "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913", sellAmount: 10n ** 15n, buyAmount: 3_500_000n, minBuyAmount: 3_465_000n,
  slippageBps: 100, platformFeeBps: 0, platformFeeAmount: 0n, providerFeeAmount: 0n, networkFeeWei: null,
  txTo: "0x6131b5fae19ea4f9d964eac0408e4408b66337b5", txDataSha256: "cd".repeat(32), txValue: 10n ** 15n,
  expiresAt: Date.now() + 30_000, ...over,
});

async function setup() {
  const repo = new MemorySwapRepository();
  const app = await buildApp({
    config, version: "t", swapProvider: undefined, swapRepo: repo, rampRepo: new MemoryRampRepository(), quoteKey: key, pingDatabase: async () => true,
    listTokens: async () => [{ chainId: 8453, address: "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913", symbol: "USDC", name: "USD Coin", decimals: 6, logoUrl: null }],
  });
  return { app, repo };
}

const idem = { "idempotency-key": "attempt-0123456789abcdef" };

describe("swap records", () => {
  it("creates once per idempotency key and refuses key reuse for another swap", async () => {
    const { app } = await setup();
    const token = signQuote(claims(), key);
    const a = await app.inject({ method: "POST", url: "/v1/swaps", headers: idem, payload: { quoteToken: token } });
    const b = await app.inject({ method: "POST", url: "/v1/swaps", headers: idem, payload: { quoteToken: token } });
    assert.equal(a.statusCode, 201);
    assert.equal(b.statusCode, 200);
    assert.equal(a.json().id, b.json().id);
    const other = signQuote(claims({ txDataSha256: "ef".repeat(32) }), key);
    assert.equal((await app.inject({ method: "POST", url: "/v1/swaps", headers: idem, payload: { quoteToken: other } })).json().code, "IDEMPOTENCY_CONFLICT");
    await app.close();
  });

  it("rejects missing keys, forged, foreign and expired tokens", async () => {
    const { app } = await setup();
    const post = (headers: Record<string, string>, quoteToken: string) => app.inject({ method: "POST", url: "/v1/swaps", headers, payload: { quoteToken } });
    assert.equal((await post({}, signQuote(claims(), key))).json().code, "IDEMPOTENCY_KEY_REQUIRED");
    assert.equal((await post(idem, signQuote(claims(), Buffer.alloc(32, 1)))).json().code, "QUOTE_INVALID");
    assert.equal((await post(idem, signQuote(claims({ expiresAt: Date.now() - 1 }), key))).json().code, "QUOTE_EXPIRED");
    await app.close();
  });

  it("submits idempotently, refuses a second hash, and supports rejection", async () => {
    const { app } = await setup();
    const id = (await app.inject({ method: "POST", url: "/v1/swaps", headers: idem, payload: { quoteToken: signQuote(claims(), key) } })).json().id as string;
    const hash = `0x${"ab".repeat(32)}`;
    const submit = (h: string) => app.inject({ method: "POST", url: `/v1/swaps/${id}/submit`, payload: { txHash: h } });
    assert.equal((await submit(hash)).statusCode, 200);
    assert.equal((await submit(hash)).statusCode, 200);
    assert.equal((await submit(`0x${"cd".repeat(32)}`)).json().code, "HASH_CONFLICT");
    assert.equal((await app.inject({ method: "POST", url: `/v1/swaps/${id}/reject` })).json().code, "WRONG_STATE");

    const view = (await app.inject({ method: "GET", url: `/v1/swaps/${id}` })).json();
    assert.equal(view.status, "submitted");
    assert.equal(view.sell.symbol, "ETH");
    assert.equal(view.buy.symbol, "USDC");
    assert.equal(view.requiredConfirmations, 5);
    await app.close();
  });

  it("lists only on-chain swaps for a wallet, with a cursor", async () => {
    const { app } = await setup();
    const make = async (n: number) => {
      const r = await app.inject({ method: "POST", url: "/v1/swaps", headers: { "idempotency-key": `attempt-${n}-0123456789abcdef` }, payload: { quoteToken: signQuote(claims({ txDataSha256: n.toString(16).padStart(64, "0") }), key) } });
      return r.json().id as string;
    };
    const unsigned = await make(1);
    const sent = await make(2);
    await app.inject({ method: "POST", url: `/v1/swaps/${sent}/submit`, payload: { txHash: `0x${"12".repeat(32)}` } });
    const list = (await app.inject({ method: "GET", url: `/v1/swaps?wallet=${TAKER}` })).json();
    assert.deepEqual(list.swaps.map((s: { id: string }) => s.id), [sent]);
    assert.equal(list.swaps.some((s: { id: string }) => s.id === unsigned), false);
    assert.equal((await app.inject({ method: "GET", url: `/v1/swaps?wallet=${TAKER}&before=bad` })).json().code, "INVALID_CURSOR");
    assert.equal((await app.inject({ method: "GET", url: "/v1/swaps/not-a-uuid" })).statusCode, 400);
    await app.close();
  });
});
