import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { randomBytes } from "node:crypto";
import { buildApp } from "../src/app.ts";
import { parseConfig } from "../src/config.ts";
import { AdminAuth } from "../src/admin/auth.ts";
import { deriveKey, hashPassword, seal, totpAt } from "../src/admin/crypto.ts";
import { MemoryAdminRepository } from "./memory-admin.ts";
import { MemorySwapRepository } from "./memory-repo.ts";
import { MemoryRampRepository } from "./memory-ramp.ts";

const ORIGIN = "https://kavrix.example";
const config = parseConfig({ NODE_ENV: "test", PUBLIC_WEB_ORIGIN: ORIGIN, DATABASE_URL: "postgres://k:t@localhost/k" });
const key = deriveKey("e".repeat(40));
const PASSWORD = "correct horse battery staple";
const USDC = "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913";

async function setup(role: "owner" | "operator" | "viewer" = "owner") {
  const repo = new MemoryAdminRepository();
  const id = await repo.createAdmin({ email: "ops@kavrix.example", passwordHash: await hashPassword(PASSWORD), role });
  const secret = randomBytes(20);
  await repo.setTotpSecret(id, seal(secret, key, `admin:${id}`));
  repo.tokens.push({ chainId: 8453, address: USDC, symbol: "USDC", name: "USD Coin", decimals: 6, enabled: true });
  repo.settings.set("swap.enabled", { value: true, version: 1, updatedAt: new Date() });
  let changed = 0;
  const app = await buildApp({
    config, version: "t", swapProvider: undefined, swapRepo: new MemorySwapRepository(), rampRepo: new MemoryRampRepository(),
    quoteKey: Buffer.alloc(32, 1), pingDatabase: async () => true, listTokens: async () => [],
    admin: {
      repo,
      auth: new AdminAuth({ repo, encryptionKey: key }),
      health: async () => ({ database: "ok", rpc: {}, tracker: { enabled: true, lastTickAt: null, backlog: 0 }, providers: {} }),
      tokenDecimals: async () => 6,
      onSettingsChanged: () => {
        changed++;
      },
    },
  });
  const csrf = { origin: ORIGIN, "x-kavrix-admin": "1" };
  const login = async () => {
    const res = await app.inject({
      method: "POST", url: "/admin/session", headers: csrf,
      payload: { email: "ops@kavrix.example", password: PASSWORD, code: totpAt(secret, Math.floor(Date.now() / 30_000)) },
    });
    const cookie = String(res.headers["set-cookie"]).split(";")[0] ?? "";
    return { res, cookie };
  };
  return { app, repo, csrf, login, changed: () => changed };
}

describe("admin API", () => {
  it("sets a hardened session cookie and requires it", async () => {
    const env = await setup();
    const { res, cookie } = await env.login();
    assert.equal(res.statusCode, 200);
    const setCookie = String(res.headers["set-cookie"]);
    for (const flag of ["__Host-kavrix_admin=", "HttpOnly", "Secure", "SameSite=Strict", "Path=/"]) assert.ok(setCookie.includes(flag), flag);
    assert.equal((await env.app.inject({ method: "GET", url: "/admin/me" })).statusCode, 401);
    assert.equal((await env.app.inject({ method: "GET", url: "/admin/me", headers: { cookie } })).json().role, "owner");
    assert.equal((await env.app.inject({ method: "GET", url: "/admin/me", headers: { cookie } })).headers["cache-control"], "no-store");
    await env.app.close();
  });

  it("rejects cross-site or header-less mutations, including login", async () => {
    const env = await setup();
    const login = await env.app.inject({ method: "POST", url: "/admin/session", headers: { origin: "https://evil.example", "x-kavrix-admin": "1" }, payload: { email: "a", password: "b", code: "123456" } });
    assert.equal(login.json().code, "CSRF_REJECTED");
    const { cookie } = await env.login();
    const patch = await env.app.inject({ method: "PATCH", url: `/admin/tokens/8453/${USDC}`, headers: { cookie, origin: ORIGIN }, payload: { enabled: false } });
    assert.equal(patch.json().code, "CSRF_REJECTED");
    await env.app.close();
  });

  it("enforces roles", async () => {
    const env = await setup("viewer");
    const { cookie } = await env.login();
    const res = await env.app.inject({ method: "PATCH", url: `/admin/tokens/8453/${USDC}`, headers: { cookie, ...env.csrf }, payload: { enabled: false } });
    assert.equal(res.json().code, "FORBIDDEN");
    await env.app.close();
  });

  it("updates settings with optimistic locking and audit", async () => {
    const env = await setup();
    const { cookie } = await env.login();
    const put = (value: unknown, version: number) =>
      env.app.inject({ method: "PUT", url: "/admin/settings/swap.enabled", headers: { cookie, ...env.csrf }, payload: { value, version } });
    assert.equal((await put(false, 1)).json().updated, true);
    assert.equal((await put(true, 1)).json().code, "VERSION_CONFLICT");
    assert.equal((await put("no", 2)).json().code, "INVALID_SETTING");
    assert.equal(env.changed(), 1);
    assert.ok(env.repo.auditLog.some((e) => e.action === "setting.updated" && e.target === "swap.enabled"));
    const blocked = await env.app.inject({ method: "PUT", url: "/admin/settings/transak.access_token", headers: { cookie, ...env.csrf }, payload: { value: "x", version: 1 } });
    assert.equal(blocked.json().code, "INVALID_SETTING");
    await env.app.close();
  });

  it("adds tokens disabled and only when decimals match the contract", async () => {
    const env = await setup();
    const { cookie } = await env.login();
    const add = (decimals: number, address = "0x1111111111111111111111111111111111111111") =>
      env.app.inject({ method: "POST", url: "/admin/tokens", headers: { cookie, ...env.csrf }, payload: { chainId: 8453, address, symbol: "TKN", name: "Token", decimals } });
    assert.equal((await add(18)).json().code, "DECIMALS_MISMATCH");
    const ok = await add(6);
    assert.equal(ok.statusCode, 201);
    assert.equal(env.repo.tokens.at(-1)?.enabled, false);
    assert.equal((await add(6)).json().code, "TOKEN_EXISTS");
    await env.app.close();
  });

  it("revokes the session on logout", async () => {
    const env = await setup();
    const { cookie } = await env.login();
    await env.app.inject({ method: "DELETE", url: "/admin/session", headers: { cookie, ...env.csrf } });
    assert.equal((await env.app.inject({ method: "GET", url: "/admin/me", headers: { cookie } })).statusCode, 401);
    await env.app.close();
  });
});
