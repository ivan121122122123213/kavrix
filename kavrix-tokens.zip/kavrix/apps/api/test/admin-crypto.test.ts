import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { randomBytes } from "node:crypto";
import {
  DUMMY_PASSWORD_HASH,
  base32Decode,
  base32Encode,
  deriveKey,
  generatePassword,
  hashPassword,
  open,
  otpauthUri,
  seal,
  totpAt,
  verifyPassword,
  verifyTotp,
} from "../src/admin/crypto.ts";

describe("passwords", () => {
  it("hashes with scrypt and verifies only the right password", async () => {
    const h = await hashPassword("correct horse battery");
    assert.match(h, /^\$scrypt\$N=32768,r=8,p=1\$/);
    assert.equal(await verifyPassword("correct horse battery", h), true);
    assert.equal(await verifyPassword("correct horse batterY", h), false);
  });

  it("rejects short passwords, malformed and weakened hashes", async () => {
    await assert.rejects(hashPassword("short"));
    assert.equal(await verifyPassword("x", "plain"), false);
    const weak = (await hashPassword("correct horse battery")).replace("N=32768", "N=1024");
    assert.equal(await verifyPassword("correct horse battery", weak), false);
  });

  it("has a well-formed dummy hash for timing equalisation", async () => {
    assert.equal(await verifyPassword("anything at all", DUMMY_PASSWORD_HASH), false);
  });

  it("generates strong passwords", () => {
    const p = generatePassword();
    assert.equal(p.length, 24);
    assert.notEqual(p, generatePassword());
  });
});

describe("TOTP", () => {
  // RFC 6238 Appendix B, SHA-1, truncated to 6 digits.
  const rfcSecret = Buffer.from("12345678901234567890");
  it("matches the RFC 6238 test vectors", () => {
    assert.equal(totpAt(rfcSecret, Math.floor(59 / 30)), "287082");
    assert.equal(totpAt(rfcSecret, Math.floor(1111111109 / 30)), "081804");
    assert.equal(totpAt(rfcSecret, Math.floor(1234567890 / 30)), "005924");
  });

  it("accepts ±1 step once and never replays", () => {
    const now = 1_800_000_000_000;
    const step = Math.floor(now / 30_000);
    const code = totpAt(rfcSecret, step);
    const used = verifyTotp(rfcSecret, code, now, null);
    assert.equal(used, step);
    assert.equal(verifyTotp(rfcSecret, code, now, used ?? null), undefined, "same code twice");
    assert.equal(verifyTotp(rfcSecret, totpAt(rfcSecret, step - 1), now, null), step - 1);
    assert.equal(verifyTotp(rfcSecret, totpAt(rfcSecret, step - 2), now, null), undefined);
    assert.equal(verifyTotp(rfcSecret, "12345", now, null), undefined);
    assert.equal(verifyTotp(rfcSecret, "abcdef", now, null), undefined);
  });

  it("round-trips base32 and builds an otpauth URI", () => {
    const s = randomBytes(20);
    assert.deepEqual(base32Decode(base32Encode(s)), s);
    assert.equal(base32Encode(Buffer.from("12345678901234567890")), "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ");
    assert.match(otpauthUri(s, "ops@kavrix.example"), /^otpauth:\/\/totp\/Kavrix%3Aops%40kavrix\.example\?secret=[A-Z2-7]+&issuer=Kavrix/);
  });
});

describe("secrets at rest", () => {
  const key = deriveKey("k".repeat(40));
  it("encrypts with AES-GCM bound to its owner", () => {
    const sealed = seal(Buffer.from("totp-secret"), key, "admin:1");
    assert.equal(open(sealed, key, "admin:1").toString(), "totp-secret");
    assert.throws(() => open(sealed, key, "admin:2"), "different owner");
    assert.throws(() => open(sealed, deriveKey("z".repeat(40)), "admin:1"), "different key");
    const tampered = Buffer.from(sealed);
    tampered[tampered.length - 1] = (tampered[tampered.length - 1] as number) ^ 1;
    assert.throws(() => open(tampered, key, "admin:1"));
  });

  it("requires long key material", () => {
    assert.throws(() => deriveKey("short"));
  });
});
