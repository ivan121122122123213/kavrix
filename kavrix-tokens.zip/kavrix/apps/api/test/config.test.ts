import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { ConfigError, featureFlags, parseConfig, resolveSecretFiles } from "../src/config.ts";

const base = {
  NODE_ENV: "production",
  PUBLIC_WEB_ORIGIN: "https://kavrix.example",
  DATABASE_URL: "postgres://kavrix:s3cr3t-pass@db:5432/kavrix",
  QUOTE_SIGNING_KEY: "k".repeat(48),
};

function problems(fn: () => unknown): readonly string[] {
  try {
    fn();
  } catch (err) {
    if (err instanceof ConfigError) return err.problems;
    throw err;
  }
  assert.fail("expected ConfigError");
}

describe("config", () => {
  it("parses a minimal production config with safe defaults", () => {
    const config = parseConfig(base);
    assert.equal(config.PORT, 3000);
    assert.equal(config.PLATFORM_FEE_BPS, 0);
    assert.equal(config.SWAP_PROVIDER, "kyberswap");
    assert.equal(config.RPC_URL_8453, "https://base-rpc.publicnode.com");
    assert.deepEqual(featureFlags(config), { swapQuotes: true, moonpay: false, transak: false });
  });

  it("fails closed on insecure production settings", () => {
    const p = problems(() =>
      parseConfig({ ...base, PUBLIC_WEB_ORIGIN: "http://kavrix.example", DATABASE_URL: "postgres://u:change_me@db/k" }),
    );
    assert.ok(p.some((x) => x.startsWith("PUBLIC_WEB_ORIGIN")));
    assert.ok(p.some((x) => x.startsWith("DATABASE_URL")));
  });

  it("requires a fee recipient when a fee is configured and caps the fee", () => {
    assert.ok(problems(() => parseConfig({ ...base, PLATFORM_FEE_BPS: "25" })).some((x) => x.startsWith("PLATFORM_FEE_RECIPIENT")));
    assert.ok(problems(() => parseConfig({ ...base, PLATFORM_FEE_BPS: "301" })).some((x) => x.startsWith("PLATFORM_FEE_BPS")));
    const ok = parseConfig({ ...base, PLATFORM_FEE_BPS: "25", PLATFORM_FEE_RECIPIENT: "0xAbC0000000000000000000000000000000000001" });
    assert.equal(ok.PLATFORM_FEE_RECIPIENT, "0xabc0000000000000000000000000000000000001");
  });

  it("requires provider credentials as complete sets", () => {
    assert.ok(problems(() => parseConfig({ ...base, MOONPAY_SECRET_KEY: "sk" })).length > 0);
    assert.ok(problems(() => parseConfig({ ...base, TRANSAK_API_KEY: "pk" })).length > 0);
  });

  it("never includes secret values in error messages", () => {
    const err = problems(() => parseConfig({ ...base, DATABASE_URL: "mysql://root:TopSecret@db/x", PUBLIC_WEB_ORIGIN: "nope" }));
    assert.equal(err.join("\n").includes("TopSecret"), false);
  });

  it("reads *_FILE secrets and rejects ambiguous double definitions", () => {
    const env = resolveSecretFiles({ ZEROEX_API_KEY_FILE: "/run/secrets/zeroex" }, () => "key-from-file\n");
    assert.equal(env["ZEROEX_API_KEY"], "key-from-file");
    assert.ok(problems(() => resolveSecretFiles({ ZEROEX_API_KEY: "a", ZEROEX_API_KEY_FILE: "/x" }, () => "b")).length === 1);
    assert.ok(problems(() => resolveSecretFiles({ ZEROEX_API_KEY_FILE: "/missing" }, () => { throw new Error("ENOENT"); })).length === 1);
  });
});

describe("config: RPC URLs", () => {
  it("falls back to public RPCs when unset and requires https otherwise", () => {
    assert.equal(parseConfig({ ...base, RPC_URL_1: "" }).RPC_URL_1, "https://ethereum-rpc.publicnode.com");
    assert.ok(problems(() => parseConfig({ ...base, RPC_URL_1: "http://rpc.example" })).some((x) => x.startsWith("RPC_URL_1")));
    assert.equal(parseConfig({ ...base, RPC_URL_8453: "https://base.example/v2/key" }).RPC_URL_8453, "https://base.example/v2/key");
  });
});

describe("config: swap provider", () => {
  it("requires a 0x key only when 0x is selected", () => {
    assert.ok(problems(() => parseConfig({ ...base, SWAP_PROVIDER: "0x" })).some((x) => x.startsWith("ZEROEX_API_KEY")));
    assert.equal(featureFlags(parseConfig({ ...base, SWAP_PROVIDER: "0x", ZEROEX_API_KEY: "k" })).swapQuotes, true);
    assert.ok(problems(() => parseConfig({ ...base, KYBERSWAP_CLIENT_ID: "bad id!" })).length > 0);
  });
});

describe("config: quote signing key", () => {
  it("is mandatory in production and must be long", () => {
    const { QUOTE_SIGNING_KEY: _k, ...noKey } = base;
    assert.ok(problems(() => parseConfig(noKey)).some((x) => x.startsWith("QUOTE_SIGNING_KEY")));
    assert.ok(problems(() => parseConfig({ ...base, QUOTE_SIGNING_KEY: "short" })).some((x) => x.startsWith("QUOTE_SIGNING_KEY")));
    assert.equal(parseConfig({ ...noKey, NODE_ENV: "development" }).QUOTE_SIGNING_KEY, undefined);
    assert.equal(parseConfig(base).WORKER_ENABLED, true);
  });
});
