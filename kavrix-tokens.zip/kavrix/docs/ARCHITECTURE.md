# Kavrix — архитектура (этапы 1–2)

Документ фиксирует решения этапа 1 (архитектура) и результаты этапа 2 (проверка внешних API, 23.10.2026). Всё, что здесь заявлено о провайдерах, взято из их официальной документации на эту дату; перед запуском в production каждую ссылку нужно перепроверить.

## 1. Что делает платформа и чего не делает

Kavrix — **некастодиальный** интерфейс обмена EVM-токенов плюс точка входа в фиатные виджеты лицензированных провайдеров.

| Операция | Кто исполняет | Роль Kavrix |
|---|---|---|
| Обмен токенов | Роутер KyberSwap `MetaAggregationRouterV2` (по умолчанию) или 0x AllowanceHolder (опционально) | Получает котировку на сервере, декодирует и проверяет calldata, отдаёт её в кошелёк пользователя. Ключей не хранит, транзакции не подписывает. |
| Покупка / продажа за фиат | MoonPay или Transak (KYC, платежи, выплаты) | Создаёт подписанную ссылку / сессию виджета, принимает подписанные вебхуки, показывает статус. Карточные данные не видит. |
| Комиссия платформы | KyberSwap: `chargeFeeBy=currency_in` (точная сумма в токене оплаты); 0x: `swapFeeBps` в buy-токене | Показывается до подписи, записывается в БД. |

Платформа **не полностью децентрализована**: котировки зависят от централизованного API агрегатора, фиатные операции — от провайдеров, сайт — от нашего сервера. Это должно быть отражено на страницах About/Security/Terms.

## 2. Стек и версии

| Слой | Выбор | Почему |
|---|---|---|
| Runtime | Node.js ≥ 24.12 (LTS) | Нативный type stripping: dev-сервер и тесты запускают `.ts` без tsx/ts-node. |
| Язык | TypeScript ^6.0, strict + `exactOptionalPropertyTypes`, `erasableSyntaxOnly` | Тот же исходник исполняется Node напрямую и компилируется `tsc` для production. |
| Пакеты | pnpm 10 workspace, lockfile обязателен, install-скрипты зависимостей запрещены (`onlyBuiltDependencies: []`) | Защита цепочки поставок. |
| API | Fastify ^5 + @fastify/helmet, cors, rate-limit | Быстрый, встроенный pino-логгер с redaction. |
| Валидация | zod ^4 | Конфиг, ответы провайдеров, входные данные API. |
| БД | PostgreSQL 17, драйвер `postgres` ^3.4, Drizzle ORM (только query builder) | Миграции — **ручной SQL** с собственным раннером (advisory lock, checksum). Drizzle Kit не используется: у него идёт переход 0.x→1.0 с новым форматом папки миграций, а SQL-миграции переживают любую смену ORM. |
| Frontend | React ^19.2, Vite ^8 (Rolldown), @vitejs/plugin-react ^6, Tailwind CSS ^4.1, React Router ^7 | Vite 8 стабилен с марта 2026; plugin-react v6 работает на Oxc без Babel. |
| Кошельки (этап 5) | wagmi ^3, viem ^2, `@wagmi/connectors`, WalletConnect | В wagmi 3 зависимости коннекторов — опциональные peer deps, ставим только нужные. |
| Кэш / очереди | **Нет Redis на старте** | Один инстанс API: rate limit в памяти, фоновая проверка транзакций — поллинг из процесса с блокировкой строк в Postgres (`FOR UPDATE SKIP LOCKED`). Redis добавляется, только если появится второй инстанс API. |
| Edge | Caddy 2.10 | Автоматический HTTPS, CSP и security headers, статика SPA, reverse proxy `/api/*`. |

Точные версии фиксирует `pnpm-lock.yaml`, который создаётся первым `pnpm install` и коммитится. Docker-сборка без lockfile намеренно падает.

## 3. Модули

```
apps/
  api/            Fastify: HTTP, конфиг, маршруты, health, (этап 6+) воркер статусов
  web/            React SPA: публичные страницы, обмен, buy/sell, история, админка
packages/
  shared/         Без зависимостей: сети, адреса, bigint-математика сумм, автоматы статусов
  integrations/   Клиенты 0x / MoonPay / Transak: строгая проверка ответов, подписи, вебхуки
  db/             SQL-миграции, раннер, типизированная схема, подключение
infra/
  caddy/          Caddyfile + образ (сборка web внутри)
  scripts/        секреты, бэкап, проверка восстановления, внешний healthcheck
```

Правило зависимостей: `shared` ← `integrations`, `db` ← `api`. Web зависит только от `shared`. Провайдерские клиенты никогда не импортируются во frontend: ключи физически не попадают в бандл.

## 4. Поток обмена (реализация на этапах 5–6)

1. Web → `GET /api/v1/swap/price` (индикативная цена, без calldata) — для набора суммы.
2. Web → `POST /api/v1/swap/quote` с `Idempotency-Key`. API запрашивает `/swap/allowance-holder/quote`, затем `assertQuoteSafe`:
   - пара токенов и `sellAmount` совпадают с запросом;
   - `transaction.to` и `issues.allowance.spender` == AllowanceHolder этой сети (`0x0000000000001fF3684f28c67538d4D072C22734` для всех четырёх сетей);
   - `transaction.value` == `sellAmount` для нативного токена и 0 для ERC-20;
   - запрошенная комиссия платформы реально применена, незапрошенной нет;
   - `0 < minBuyAmount ≤ buyAmount`.
   Любое расхождение → `QUOTE_UNSAFE`, котировка не уходит в браузер. Запись `swap_operations` создаётся со своим `quote_expires_at` (по умолчанию 30 с).
3. Web проверяет chain ID кошелька, баланс и allowance через viem; approve — ровно на `sellAmount` и только на AllowanceHolder.
4. Пользователь подписывает транзакцию в кошельке. Web отправляет хэш → `POST /api/v1/swap/:id/submit`; повтор с тем же хэшем идемпотентен.
5. Воркер API читает receipt через RPC сервера: `status=success` + N подтверждений → `confirmed`; `reverted` → `reverted`; нет receipt дольше таймаута → `dropped` (и может позже стать `confirmed`). **Только receipt** переводит операцию в финальное состояние — это продублировано триггером в БД.

## 5. Фиат (этап 7)

- **MoonPay**: ссылка виджета (buy или sell) подписывается на сервере: HMAC-SHA256 от `url.search` секретным ключом, base64. Вебхуки: заголовок `Moonpay-Signature-V2: t=<unix>,s=<hex>`, подпись = HMAC-SHA256(webhook key, `t + "." + rawBody`). Проверяем по сырому телу, с окном ±5 минут.
- **Transak**: передача параметров прямо в URL виджета устарела; обязательна серверная сессия `POST /api/v2/auth/session` (gateway), `sessionId` одноразовый, ссылка живёт 5 минут, вызов только с бэкенда с whitelist IP. Нужен partner access token (`POST /partners/api/v2/refresh-token`, живёт 7 дней, обновлять только при истечении). Вебхук: поле `data` — JWT HS256, подписанный этим access token. При ротации токена проверяем текущим и предыдущим.
- Обе системы шлют статусы вебхуками; статусы Kavrix выставляются **только** по проверенным вебхукам или ответам API провайдера.
- Сырые тела вебхуков не сохраняются (там ПДн): только SHA-256 и нужные поля. Дедупликация по `(provider, event_id)`.
- Доступность стран, валют, направлений (особенно sell и выплат на карты), лимиты и KYC-уровни зависят от договора и юрисдикции бизнеса. API это не решает — см. `docs/STATUS.md`, раздел «Блокеры».

## 6. Безопасность (предварительная модель угроз)

| Угроза | Мера |
|---|---|
| Подмена calldata / адреса контракта (скомпрометированный провайдер, MITM) | `assertQuoteSafe`: фиксированный AllowanceHolder на сеть, сверка value/пары/суммы; во frontend повторная проверка `to` перед `sendTransaction`. |
| Approve на неверный контракт / бесконечный approve | Spender только из реестра сетей; сумма = `sellAmount`. |
| Устаревшая котировка | Свой `quote_expires_at`; просроченную котировку сервер не принимает в `submit`. Минимальный выход — `minBuyAmount` в calldata. |
| Утечка ключей | Ключи только на сервере; `*_FILE` (Docker secrets, mode 600); pino redaction; сообщения ошибок без значений; query-строки вырезаны из логов API и Caddy. |
| Подделка / повтор вебхуков | HMAC/JWT по сырому телу, окно времени, уникальный `(provider, event_id)`, переходы статусов только по автомату. |
| Подделка статусов админом | Нет API для смены статуса; триггер запрещает нелегальные переходы и изменение экономических условий; журнал админа append-only на уровне БД. |
| XSS | React без `dangerouslySetInnerHTML`; строгий CSP (`script-src 'self'`); API отдаёт только JSON с `default-src 'none'`. |
| CSRF | Публичное API без cookie. Админка (этап 8): cookie `__Host-`, `SameSite=Strict`, проверка `Origin`, CSRF-токен на изменяющих запросах. |
| DoS | Rate limit на API (readiness тоже), лимит тела 64 КБ, таймауты провайдеров 8 с, лимит размера ответа 2 МБ, `statement_timeout` в Postgres. |
| Supply chain | Lockfile, запрет install-скриптов, `pnpm audit --prod` в CI, минимум зависимостей (тесты — встроенный `node:test`). |

Аудит безопасности не проводился. Это самопроверка разработчика, а не заключение аудитора.

## 7. Проверенные факты по API (источники)

- 0x: базовый URL `https://api.0x.org`, заголовки `0x-api-key` и `0x-version: v2`, эндпоинты `/swap/allowance-holder/{price,quote}`. `taker` обязателен для `/quote`. `slippageBps` помечен deprecated в пользу `slippagePpm` (мы шлём ppm). Лимит `swapFeeBps` по умолчанию 1000. При отсутствии ликвидности приходит `liquidityAvailable: false`. — docs.0x.org/api-reference/evm-ap-is/swap/allowanceholder-getquote, docs.0x.org/docs/core-concepts/contracts.
- MoonPay: формат `Moonpay-Signature-V2` и signed payload — dev.moonpay.com/reference/reference-webhooks-signature.
- Transak: обязательная миграция на Create Widget URL API, single-use `sessionId`, 5 минут жизни, только бэкенд — docs.transak.com/api/public/create-widget-url и guides/migration-to-api-based-transak-widget-url; access token 7 дней — docs.transak.com/api/public/refresh-access-token; JWT в вебхуке — docs.transak.com/guides/how-to-decrypt-webhook-payload.
- wagmi 3: коннекторы требуют явной установки своих зависимостей и `@wagmi/connectors` — wagmi.sh/react/guides/migrate-from-v2-to-v3.
- Vite 8 / plugin-react 6 — vite.dev/blog/announcing-vite8.

Не проверено и требует аккаунта: актуальные тарифы и квоты 0x для вашего плана; список стран и методов выплат MoonPay/Transak для вашей юрисдикции; поддержка sell на Base/Arbitrum/Polygon у каждого провайдера.


## 8. Провайдер котировок (этап 5)

Выбор: **KyberSwap Aggregator по умолчанию**, 0x — альтернатива через `SWAP_PROVIDER=0x`. Обе реализации скрыты за интерфейсом `SwapProvider` (`packages/integrations/src/swap/types.ts`).

Почему KyberSwap: API без ключа и без абонентской платы (лимит по умолчанию 3 req/s на client id, повышается через BD), комиссия интегратора поддерживается. 0x на стандартном тарифе добавляет пользователю 0.15% на части пар и забирает trade surplus. KyberSwap тоже оставляет себе положительное проскальзывание и «пыль» от частичного исполнения — это раскрыто на странице Fees и в блоке котировки. Минимум к получению от этого не страдает.

Проверено по docs.kyberswap.com (25.10.2026):
- `GET https://aggregator-api.kyberswap.com/{chain}/api/v1/routes` → `routeSummary`, `routerAddress`; `POST …/api/v1/route/build` с `routeSummary` без изменений, `sender`, `recipient`, `slippageTolerance` (bps, до 2000), `deadline`.
- Шлюз `https://api.kyberswap.com/swap` с заголовком `X-Api-Key` (ключ выдаёт BD) — используется автоматически, если задан `KYBERSWAP_API_KEY`.
- Слаги сетей: `ethereum`, `base`, `arbitrum`, `polygon`. Роутер `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` — один на всех четырёх сетях.

Проверки ответа (fail-closed, `KyberSwapProvider`):
1. `routerAddress` == закреплённый адрес; пара токенов и `amountIn` совпадают с запросом.
2. `transactionValue` == сумма для нативной монеты и 0 для ERC-20.
3. **calldata декодируется на сервере** (`kyberswap/abi.ts`, без внешних библиотек, со строгой проверкой смещений). Допустимы только `swap` (`0xe21fd0e9`) и `swapSimpleMode` (`0x8af033fb`). Проверяются: `srcToken`/`dstToken`, `dstReceiver` == кошелёк пользователя, `amount` ≤ суммы продажи, `minReturnAmount` соответствует проскальзыванию (допуск 1 bps на округление) и не больше ожидаемого выхода, среди `feeReceivers` нет посторонних адресов.
4. В интерфейсе «Минимум к получению» берётся из calldata — это то, что гарантирует контракт.

Селекторы и раскладка структуры проверены независимо: селекторы посчитаны отдельной реализацией Keccak-256, тестовые calldata для `test/kyberswap.test.ts` сгенерированы отдельным ABI-энкодером на Python.

Браузер повторяет проверки перед подписью (`apps/web/src/swap/verify.ts`): срок котировки, кошелёк, адрес контракта, `value`, spender.

Чтение блокчейна идёт через `POST /api/v1/rpc/:chainId` — прокси только для чтения с белым списком методов. Ключи RPC остаются на сервере, CSP браузера остаётся `connect-src 'self'` (плюс WalletConnect/Coinbase). По умолчанию используются бесплатные узлы publicnode.com.


## 9. Учёт операций и проверка по блокчейну (этап 6)

```
quote (firm) ──► quoteToken (HMAC: все условия + sha256(calldata))
POST /v1/swaps  {quoteToken} + Idempotency-Key ──► swap_operations: quoted
wallet.sendTransaction ──► POST /v1/swaps/:id/submit {txHash} ──► submitted
                        └─ отказ в кошельке ──► POST /v1/swaps/:id/reject ──► rejected
воркер (каждые 2 с, аренда строк FOR UPDATE SKIP LOCKED):
  tx по хэшу: from == taker, to == роутер, value, sha256(input) == записанному?  нет ──► failed / TX_MISMATCH
  receipt + глубина ≥ подтверждений сети ──► confirmed (+ фактически полученная сумма из Transfer-логов) | reverted
  хэш не виден сети 10 мин ──► dropped (проверяется ещё 24 ч, может стать confirmed)
  quoted без отправки дольше срока котировки + 15 мин (дедлайн роутера 10 мин) ──► expired
```

Свойства:
- Клиент не может записать произвольные условия: всё берётся из токена, подписанного сервером (`QUOTE_SIGNING_KEY`, ≥ 32 символов, обязателен в production).
- Клиент не может «подтвердить» операцию: статус меняет только воркер по данным узла и только для той транзакции, которую Kavrix подготовил.
- Если операцию не удалось записать, кошелёк не получает транзакцию.
- Если хэш не удалось сообщить (закрыта вкладка, сбой сети), он лежит в очереди `localStorage` и досылается при следующем открытии сайта. Повторная доставка безопасна.
- Публичная история по адресу содержит только операции, дошедшие до сети (они и так видны в эксплорере). Отменённые и просроченные попытки не раскрываются.
- Воркер можно отключить на дополнительных репликах API (`WORKER_ENABLED=false`); аренда строк исключает двойную обработку, даже если оставить его включённым везде.


## 10. Фиат (этап 7)

```
POST /v1/ramp/sessions (Idempotency-Key) ──► ramp_orders: created
  MoonPay: подписанный URL buy/sell с externalTransactionId = id заказа
  Transak: серверная сессия (Create Widget URL) с partnerOrderId = id заказа
браузер ──► полноэкранный переход к провайдеру ──► KYC/оплата у провайдера ──► redirect /history?order=<id>
вебхук ──► проверка подписи (MoonPay HMAC / Transak JWT) ──► webhook_events (уникально) ──► переход статуса вперёд
```

- Код актива MoonPay берётся из `GET /v3/currencies` (сеть + контракт), а не задаётся вручную.
- Вебхуки обрабатываются в одной транзакции: запись события (дедупликация по `(provider, event_id)`), блокировка заказа, решение `decideEvent`. Устаревшие события не двигают статус назад. Чужой `externalOrderId` отклоняется.
- Сырое тело вебхука не хранится, только SHA-256.
- Перед переходом браузер проверяет, что адрес виджета — один из шести хостов MoonPay/Transak.
- Настройка аккаунтов — `docs/PROVIDERS.md`.


## 11. Админ-панель (этап 8)

Аутентификация:
- email + пароль (scrypt N=32768, r=8, p=1) + обязательный TOTP (RFC 6238). Секрет TOTP хранится зашифрованным AES-256-GCM с привязкой к id администратора (`ADMIN_ENCRYPTION_KEY`). Код принимается один раз: последний использованный шаг хранится и должен расти (атомарная проверка в БД).
- Ошибки входа неразличимы (неизвестный email, неверный пароль или код, блокировка), проверка пароля выполняется и для несуществующего email. 5 неудач — блокировка на 15 минут, лимит 10 попыток / 15 мин на IP.
- Сессия: случайные 256 бит в cookie `__Host-kavrix_admin` (HttpOnly, Secure, SameSite=Strict, Path=/), в БД только SHA-256; 8 ч максимум, 30 мин бездействия, отзыв при выходе, сбросе пароля/TOTP и отключении.
- CSRF: любой не-GET запрос (включая вход) требует `Origin` == `PUBLIC_WEB_ORIGIN` и заголовок `X-Kavrix-Admin: 1`.
- Администраторы создаются только CLI на сервере (`admin-cli create|reset-password|reset-totp|disable|enable`).

Права:

| Роль | Чтение | Вкл./выкл. токенов | Добавление токенов, настройки |
|---|---|---|---|
| viewer | ✓ | | |
| operator | ✓ | ✓ | |
| owner | ✓ | ✓ | ✓ |

Нет API для изменения статусов операций или балансов. Все изменения пишутся в `admin_audit_log` (до/после, IP) в той же транзакции; таблица защищена триггером от UPDATE/DELETE.

Настройки времени выполнения (`settings`, строгая схема, оптимистическая блокировка по версии): `swap.enabled`, `swap.fee_bps_by_chain`, `swap.quote_rate_per_minute`, `ramp.enabled`, `ramp.buy_limits`. Повреждённые значения выключателей трактуются как «выключено». API отдаёт и принимает только ключи из белого списка, поэтому токен Transak в той же таблице недоступен через админку.

Добавление токена: сервер читает `decimals()` из контракта и отказывает при расхождении; новый токен создаётся выключенным.

Статистика — только из БД, в единицах токенов, без пересчёта в USD (цен в системе нет, и выдумывать их нельзя).
