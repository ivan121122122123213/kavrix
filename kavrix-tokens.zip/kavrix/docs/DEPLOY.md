# Установка на чистый Ubuntu VPS

Проверено по шагам для Ubuntu 24.04 LTS. Минимум: 2 vCPU, 4 ГБ RAM, 40 ГБ SSD. Нужны домен и доступ к его DNS.

Все команды выполняются по SSH. Строки с `<…>` замените своими значениями.

## 1. Базовая защита сервера

```bash
# под root
adduser --disabled-password --gecos "" kavrix
usermod -aG sudo kavrix
mkdir -p /home/kavrix/.ssh && cp ~/.ssh/authorized_keys /home/kavrix/.ssh/
chown -R kavrix:kavrix /home/kavrix/.ssh && chmod 700 /home/kavrix/.ssh && chmod 600 /home/kavrix/.ssh/authorized_keys

# вход только по ключу, без root
sed -i -E 's/^#?PasswordAuthentication .*/PasswordAuthentication no/; s/^#?PermitRootLogin .*/PermitRootLogin no/' /etc/ssh/sshd_config
systemctl reload ssh

apt update && apt -y upgrade
apt -y install ufw unattended-upgrades fail2ban git curl gnupg rsync
dpkg-reconfigure -f noninteractive unattended-upgrades

ufw default deny incoming && ufw default allow outgoing
ufw allow OpenSSH && ufw allow 80/tcp && ufw allow 443/tcp && ufw allow 443/udp
ufw --force enable
```

Docker публикует порты в обход ufw. В `docker-compose.yml` наружу открыты только 80 и 443 (Caddy); PostgreSQL живёт во внутренней сети без выхода в интернет и снаружи недоступен.

Проверьте, что вход под `kavrix` по ключу работает, **до** закрытия текущей сессии root.

## 2. Docker

```bash
# под root
install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo "$VERSION_CODENAME") stable" > /etc/apt/sources.list.d/docker.list
apt update && apt -y install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
usermod -aG docker kavrix
```

Перезайдите под `kavrix`, чтобы группа применилась: `docker version` должна работать без sudo.

## 3. Код

```bash
sudo mkdir -p /opt/kavrix && sudo chown kavrix:kavrix /opt/kavrix
cd /opt/kavrix
git clone <ваш-репозиторий> .        # или: unzip kavrix.zip && mv kavrix/* kavrix/.[!.]* . 
infra/scripts/lockfile.sh            # только если в репозитории ещё нет pnpm-lock.yaml; закоммитьте его
```

## 4. DNS

У регистратора домена создайте записи на IP сервера:

| Тип | Имя | Значение |
|---|---|---|
| A | `kavrix.example.com` | IPv4 сервера |
| AAAA | `kavrix.example.com` | IPv6 сервера (если есть) |

Проверка: `dig +short kavrix.example.com` возвращает IP сервера. Без этого Caddy не получит сертификат.

## 5. Конфигурация и секреты

```bash
cp .env.example .env && chmod 600 .env
nano .env        # SITE_DOMAIN, PUBLIC_WEB_ORIGIN=https://<домен>, ACME_EMAIL, KAVRIX_VERSION, VITE_LEGAL_ENTITY, VITE_SUPPORT_EMAIL
infra/scripts/init-secrets.sh
```

`init-secrets.sh` создаёт в `secrets/` (права 600): пароль и URL базы, ключ подписи котировок, ключ шифрования админки, пустые файлы для ключей провайдеров.

**Сразу сохраните копию `secrets/` вне сервера** (менеджер паролей или зашифрованный архив). Без `admin_encryption_key` придётся перевыпускать TOTP всем администраторам; без `postgres_password`/`database_url` — восстанавливать доступ к базе вручную.

Ключи провайдеров — по мере получения (подробно в `docs/PROVIDERS.md`):

```bash
printf '%s' '<секрет>' > secrets/moonpay_secret_key        # и т. д.; пустой файл = функция выключена
```

Обмен через KyberSwap работает без ключей. Комиссия платформы включается в `.env` (`PLATFORM_FEE_BPS`, `PLATFORM_FEE_RECIPIENT`) или в админке по сетям.

## 6. Сборка и запуск

```bash
docker compose build
docker compose up -d
docker compose ps
```

Ожидаемо: `postgres` и `api` — healthy, `migrate` — exited (0), `caddy` — running. Caddy сам получает сертификат Let's Encrypt и продлевает его; HTTP перенаправляется на HTTPS, включены HSTS, HTTP/3 и строгий CSP.

```bash
infra/scripts/healthcheck.sh                 # ok: {"status":"ok",...}
curl -sI https://<домен> | head -n1          # HTTP/2 200
docker compose logs --tail=50 api caddy
```

## 7. Первый администратор

```bash
docker compose run --rm migrate node dist/admin-cli.js create <you@example.com> owner
```

Пароль и ссылка `otpauth://` выводятся один раз: добавьте ссылку в приложение-аутентификатор (Google Authenticator, Aegis, 1Password и т. п.) и сохраните пароль в менеджере паролей. Вход: `https://<домен>/admin`.

## 8. Резервные копии и мониторинг

```bash
sudo cp infra/systemd/kavrix-*.service infra/systemd/kavrix-*.timer /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now kavrix-backup.timer kavrix-verify-backup.timer kavrix-healthcheck.timer
systemctl list-timers 'kavrix-*'
sudo systemctl start kavrix-backup.service && ls -l backups/    # первый бэкап сразу
```

Вынос копий за пределы сервера и оповещения — `docs/OPERATIONS.md`.

## 9. Провайдеры (по готовности)

Webhook URL в дашбордах: `https://<домен>/api/v1/webhooks/moonpay` и `https://<домен>/api/v1/webhooks/transak`. Для Transak — whitelist IP сервера. После изменения `.env` или `secrets/`: `docker compose up -d` (пересоздаёт контейнеры с новыми значениями).

## Частые проблемы

| Симптом | Причина и решение |
|---|---|
| Caddy не получает сертификат | DNS ещё не указывает на сервер или закрыт порт 80. Проверьте `dig`, `ufw status`, `docker compose logs caddy`. |
| `migrate` завершился с ошибкой | `docker compose logs migrate`. «was modified» — файл миграции изменён после применения: верните исходный. |
| `api` unhealthy, код выхода 78 | Ошибка конфигурации: `docker compose logs api` перечисляет переменные (без значений). |
| Сборка падает на `pnpm-lock.yaml` | Выполните `infra/scripts/lockfile.sh` и закоммитьте файл. |
| `/admin` пишет «not enabled» | Пустой `secrets/admin_encryption_key`: выполните `init-secrets.sh`, затем `docker compose up -d`. |

## Behind an existing nginx (порты 80/443 уже заняты)

Если на сервере уже работает nginx (с другими сайтами или старой версией), Kavrix встаёт за него:

1. В `.env` добавьте:
   ```bash
   COMPOSE_PROJECT_NAME=kavrix2
   CADDY_SITE_ADDRESS=:80
   KAVRIX_HTTP_BIND=127.0.0.1:8090
   KAVRIX_HTTPS_BIND=127.0.0.1:8453
   TRUST_PROXY_HOPS=2
   KAVRIX_VERSION=2.0.0
   ```
   `COMPOSE_PROJECT_NAME` отделяет новую установку от старой (свои контейнеры и своя база); `KAVRIX_VERSION` с новым номером не даёт перезаписать образы старой установки.
2. `docker compose build && docker compose up -d`, проверка без nginx:
   `curl -s -H 'Host: ВАШ-ДОМЕН' http://127.0.0.1:8090/api/health/ready`
3. В блоке `server` вашего домена в nginx укажите `proxy_pass http://127.0.0.1:8090;` и заголовки:
   ```nginx
   proxy_set_header Host $host;
   proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
   proxy_set_header X-Forwarded-Proto $scheme;
   ```
   затем `nginx -t && systemctl reload nginx`. Сертификаты остаются у nginx.

`TRUST_PROXY_HOPS=2` обязателен: иначе API увидит вместо посетителей адрес nginx, и лимиты запросов станут общими на весь сайт.
