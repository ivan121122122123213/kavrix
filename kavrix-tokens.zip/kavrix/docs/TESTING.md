# Тестирование

## Как запускать

```bash
pnpm test                 # unit + сценарные тесты всех пакетов (без внешних сервисов)
pnpm test:integration     # PostgreSQL: нужен DATABASE_URL_TEST
pnpm ci                   # всё сразу: lockfile, поиск секретов, typecheck, тесты, сборка, audit
CI_DOCKER=1 pnpm ci       # плюс сборка production-образов
```

Локальная база для интеграционных тестов:

```bash
docker compose -f infra/compose.dev.yml up -d     # создаёт kavrix и kavrix_test
export DATABASE_URL_TEST=postgres://kavrix:kavrix_dev_only@127.0.0.1:5432/kavrix_test
pnpm test:integration
```

Набор **полностью стирает** схему `public` тестовой базы. Он откажется запускаться, если имя базы не содержит `test` или `NODE_ENV=production`.

Если база уже создавалась без `kavrix_test`, выполните: `docker compose -f infra/compose.dev.yml exec postgres createdb -U kavrix kavrix_test`.

CI (`.github/workflows/ci.yml`) поднимает PostgreSQL 17 и запускает `infra/scripts/ci.sh`. Без `DATABASE_URL_TEST` CI падает, а не пропускает интеграционные тесты.

## Сценарии из ТЗ → тесты

| # | Сценарий | Что проверяется | Где |
|---|---|---|---|
| 1 | Успешная котировка | Параметры запроса к KyberSwap; декодирование calldata (независимо сгенерированные данные); роутер, получатель, минимум, получатели комиссии; подписанный токен котировки; разбор ответа в браузере | `integrations/test/kyberswap.test.ts`, `api/test/swap.test.ts`, `web/test/ui-logic.test.ts` |
| 2 | Недоступность провайдера | 5xx, таймаут, сеть, лимит → типизированные ошибки, 503 с понятным кодом, никакой подставной цены | `integrations/test/kyberswap.test.ts`, `integrations/test/zeroex.test.ts`, `api/test/scenarios.test.ts` |
| 3 | Недостаточный баланс | Кнопка «Insufficient … balance» неактивна; повторная проверка баланса перед подписью; понятное сообщение кошелька об insufficient funds | `web/test/swap-state.test.ts`, `web/test/wallet-errors.test.ts`, `web/src/swap/useSwapExecution.ts` |
| 4 | Отклонение пользователем | Распознавание отказа (viem и EIP-1193 4001); операция помечается `rejected`; ничего не отправлено | `web/test/wallet-errors.test.ts`, `api/test/swaps-routes.test.ts` |
| 5 | Ошибка отправки | Понятное сообщение без сырого RPC; при недоступности записи операции транзакция не отправляется | `web/test/wallet-errors.test.ts`, `web/src/swap/useSwapExecution.ts` |
| 6 | Неуспешная транзакция | Receipt со status 0 → `reverted`, никогда не «успех» | `api/test/tracker.test.ts` |
| 7 | Подтверждённая транзакция | `confirmed` только после глубины подтверждений сети; фактическая сумма из Transfer-логов; подмена хэша → `failed/TX_MISMATCH` | `api/test/tracker.test.ts`, `db/test-integration/swaps.it.test.ts` |
| 8 | Повторный вебхук | MoonPay и Transak: повтор → `duplicate`; опоздавшее событие не откатывает статус; подделка/просрочка подписи → 401 | `api/test/ramp-routes.test.ts`, `integrations/test/moonpay.test.ts`, `db/test-integration/ramp-admin.it.test.ts` |
| 9 | Устаревшая котировка | Срок в браузере перед подписью; просроченный токен котировки → 409; истечение неподписанных операций воркером | `web/test/ui-logic.test.ts`, `api/test/quote-token.test.ts`, `api/test/tracker.test.ts` |
| 10 | Недоступность БД | 503 `DATABASE_UNAVAILABLE` + Retry-After, readiness 503, без утечки адресов инфраструктуры; классификация ошибок драйвера | `api/test/scenarios.test.ts`, `api/test/db-errors.test.ts`, `api/test/app.test.ts` |

Дополнительно:
- **Админка**: TOTP по векторам RFC 6238, запрет повтора кода, блокировка, сессии, CSRF, роли, версии настроек, аварийная остановка → `api/test/admin-*.test.ts`, `api/test/scenarios.test.ts`.
- **База данных**: миграции и защита от правки, триггеры автоматов статусов и неизменяемости, параллельная аренда строк без двойной обработки, неизменяемый журнал, идемпотентность → `db/test-integration/*`.

## Тестовые сети и sandbox

Агрегаторы 0x и KyberSwap не работают в тестовых сетях, поэтому обмен проверяется на mainnet минимальной суммой (README, «Первый реальный обмен»). Фиатные сценарии проверяются в sandbox MoonPay и staging Transak (`docs/PROVIDERS.md`). Реальные денежные операции начинаются только после прохождения `pnpm ci` и чек-листа из `docs/STATUS.md`.
