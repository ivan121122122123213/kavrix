# Подключение фиатных провайдеров

Kavrix открывает оплату у провайдера на его собственной странице (полноэкранный переход, не iframe). Kavrix не видит данные карт и банковских счетов. Статус заказа выставляется только по проверенным вебхукам.

## MoonPay

1. Партнёрский аккаунт: https://www.moonpay.com/business → dashboard.moonpay.com.
2. Developers → ключи для нужного окружения:
   - `pk_test_…` / `pk_live_…` → `.env`: `MOONPAY_PUBLISHABLE_KEY` (публичный);
   - secret key → `secrets/moonpay_secret_key` (подписывает URL виджета);
   - webhook API key → `secrets/moonpay_webhook_key` (проверка `Moonpay-Signature-V2`).
3. `MOONPAY_ENV=sandbox` для тестов (`buy-sandbox` / `sell-sandbox`), `production` — для боевых. Тестовый ключ вместе с `production` сервер не примет.
4. Webhook URL в дашборде: `https://<домен>/api/v1/webhooks/moonpay`. События: on-ramp и off-ramp transactions.
5. Если для вашего аккаунта MoonPay требует whitelist домена виджета — добавьте домен сайта.

Какой код валюты MoonPay использовать (`usdc_base`, `eth` и т. п.), сервер определяет сам по `GET /v3/currencies`: сопоставляет `metadata.chainId` и адрес контракта, кэширует на 10 минут. Если актив на сети не найден, приостановлен или для продажи `isSellSupported=false`, пользователь получает понятный отказ. Угадывания нет.

## Transak

1. Аккаунт: dashboard.transak.com → Developers: API key и API secret отдельно для staging и production.
2. `.env`: `TRANSAK_ENV=staging|production`, `TRANSAK_API_KEY`. Secret → `secrets/transak_api_secret`.
3. **Whitelist IP сервера** в дашборде: Create Widget URL принимается только с IP партнёра.
4. Webhook URL: `https://<домен>/api/v1/webhooks/transak`.
5. Partner access token (живёт 7 дней) хранится в таблице `settings` и общий для всех реплик. После перезапуска вебхуки проверяются тем же токеном. При обновлении предыдущий токен сохраняется для вебхуков «в полёте».

## Что проверить в sandbox до запуска

- Покупка USDC на Base у каждого провайдера: заказ появляется в «Card orders» со статусом «In progress», затем «Completed».
- Отмена или просрочка оплаты переводит заказ в Cancelled/Expired.
- Повторная доставка вебхука (кнопка resend в дашборде провайдера) не меняет статус и отвечает `duplicate`.
- Продажа: у MoonPay — только для активов с `isSellSupported`.

## Что зависит от договора и юрисдикции (не решается кодом)

- Страны клиентов, доступные фиатные валюты, способы оплаты и выплат (в т. ч. выплаты на карту), лимиты, уровни KYC.
- Партнёрская комиссия (если предусмотрена договором) настраивается у провайдера, а не в Kavrix. Пользователь видит итоговые курс и комиссию в окне провайдера до оплаты.
- Если в стране клиента продажа или выплата на карту недоступна, провайдер покажет это в своём окне. Kavrix не имитирует выплату.
