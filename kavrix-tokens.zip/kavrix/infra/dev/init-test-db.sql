-- Development only: a separate database for `pnpm test:integration` (it is wiped on every run).
CREATE DATABASE kavrix_test OWNER kavrix;
