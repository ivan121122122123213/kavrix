#!/usr/bin/env bash
# Deploys new source already present in this directory (git pull / unpacked release).
# Usage: infra/scripts/update.sh <version-label>     e.g. 1.0.1
# Images are tagged per version, so the previous release can be started again (see docs/OPERATIONS.md).
set -euo pipefail
cd "$(dirname "$0")/../.."
next="${1:?usage: update.sh <version-label>}"
[[ "$next" =~ ^[A-Za-z0-9._-]{1,64}$ ]] || { echo "invalid version label" >&2; exit 64; }
[[ -f pnpm-lock.yaml ]] || { echo "pnpm-lock.yaml missing (infra/scripts/lockfile.sh)" >&2; exit 1; }
previous="$(grep -E '^KAVRIX_VERSION=' .env | cut -d= -f2- || true)"

echo "1/5 backup before changing anything"
infra/scripts/backup.sh

echo "2/5 building $next (the running release keeps serving)"
KAVRIX_VERSION="$next" docker compose build

echo "3/5 switching .env to $next (was ${previous:-unset})"
if grep -qE '^KAVRIX_VERSION=' .env; then sed -i -E "s/^KAVRIX_VERSION=.*/KAVRIX_VERSION=$next/" .env; else echo "KAVRIX_VERSION=$next" >> .env; fi

echo "4/5 migrations, then API and web"
docker compose up -d

echo "5/5 waiting for the API to become healthy"
for _ in $(seq 1 40); do
  state="$(docker inspect --format '{{.State.Health.Status}}' "$(docker compose ps -q api)" 2>/dev/null || echo unknown)"
  [[ "$state" == "healthy" ]] && break
  sleep 3
done
if [[ "${state:-}" != "healthy" ]]; then
  echo "API is not healthy. Roll back with: sed -i 's/^KAVRIX_VERSION=.*/KAVRIX_VERSION=${previous}/' .env && docker compose up -d" >&2
  echo "If $next applied new migrations, restore the backup taken in step 1 instead (docs/OPERATIONS.md)." >&2
  exit 1
fi
infra/scripts/healthcheck.sh
echo "updated to $next (previous: ${previous:-unset})"
