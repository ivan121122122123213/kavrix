#!/usr/bin/env bash
# Full verification, identical locally and in CI.
#   DATABASE_URL_TEST  throwaway PostgreSQL database (name must contain "test"); required when CI=true
#   CI_DOCKER=1        also build both production images
set -euo pipefail
cd "$(dirname "$0")/../.."

step() { printf '\n\033[1m== %s\033[0m\n' "$1"; }

step "install (frozen lockfile)"
pnpm install --frozen-lockfile

step "secret scan"
# Real credentials must never be committed. Test fixtures use obviously fake values and are excluded.
if grep -RInE --exclude-dir={node_modules,dist,.git,test,test-integration,secrets,backups} \
  -e 'sk_live_[A-Za-z0-9]{8,}' -e '-----BEGIN [A-Z ]*PRIVATE KEY-----' -e 'AKIA[0-9A-Z]{16}' \
  -e 'xox[abp]-[0-9A-Za-z-]{10,}' . ; then
  echo "possible secret committed (see matches above)" >&2
  exit 1
fi
for f in .env secrets; do
  if git ls-files --error-unmatch "$f" >/dev/null 2>&1; then echo "$f must not be tracked by git" >&2; exit 1; fi
done

step "typecheck"
pnpm typecheck

step "unit tests"
pnpm test

step "integration tests (PostgreSQL)"
if [[ -n "${DATABASE_URL_TEST:-}" ]]; then
  pnpm test:integration
elif [[ "${CI:-}" == "true" ]]; then
  echo "DATABASE_URL_TEST is required in CI" >&2
  exit 1
else
  echo "SKIPPED: set DATABASE_URL_TEST (see docs/TESTING.md)"
fi

step "build"
VITE_SITE_ORIGIN="${VITE_SITE_ORIGIN:-https://ci.kavrix.invalid}" pnpm build

step "dependency audit (production, high+)"
pnpm audit --prod --audit-level high

if [[ "${CI_DOCKER:-}" == "1" ]]; then
  step "docker images"
  docker build -f apps/api/Dockerfile -t kavrix-api:ci .
  docker build -f infra/caddy/Dockerfile --build-arg VITE_SITE_ORIGIN=https://ci.kavrix.invalid -t kavrix-web:ci .
fi

printf '\n\033[1;32mAll checks passed.\033[0m\n'
