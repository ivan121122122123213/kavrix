#!/usr/bin/env bash
# Builds and tests the whole project in a throwaway Node container (no Node needed on the host).
# Writes everything to ./ci.log for review.
set -euo pipefail
cd "$(dirname "$0")/../.."
[[ -f pnpm-lock.yaml ]] || { echo "pnpm-lock.yaml missing: run infra/scripts/lockfile.sh first" >&2; exit 1; }
docker run --rm -u "$(id -u):$(id -g)" -e HOME=/tmp -v "$PWD":/repo -w /repo node:24.12.0-bookworm-slim sh -c '
  npm install -g --prefix /tmp/pnpm pnpm@10.12.1 >/dev/null &&
  export PATH=/tmp/pnpm/bin:$PATH &&
  pnpm install --frozen-lockfile &&
  pnpm typecheck &&
  pnpm test &&
  VITE_SITE_ORIGIN=https://example.com pnpm build
' 2>&1 | tee ci.log
status=${PIPESTATUS[0]}
if [[ $status -eq 0 ]]; then echo; echo "CHECK PASSED (log: ci.log)"; else echo; echo "CHECK FAILED with code $status (log: ci.log)"; fi
exit "$status"
