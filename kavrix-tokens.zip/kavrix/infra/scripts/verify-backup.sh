#!/usr/bin/env bash
# Restores a dump into a throwaway database and checks it, without touching production data.
# Usage: infra/scripts/verify-backup.sh backups/kavrix-<ts>.dump
set -euo pipefail
cd "$(dirname "$0")/../.."
dump="${1:?usage: verify-backup.sh <dump>}"
sha256sum --check --status "$dump.sha256"
db="kavrix_restore_check_$(date +%s)"
cleanup() { docker compose exec -T postgres dropdb -U kavrix --if-exists "$db" >/dev/null 2>&1 || true; }
trap cleanup EXIT
docker compose exec -T postgres createdb -U kavrix "$db"
docker compose exec -T postgres pg_restore -U kavrix -d "$db" --no-owner --exit-on-error < "$dump"
count=$(docker compose exec -T postgres psql -U kavrix -d "$db" -tAc "select count(*) from kavrix_migrations")
[[ "$count" -ge 1 ]] || { echo "verify: no migrations recorded in restored copy" >&2; exit 1; }
echo "verify: OK ($count migrations, database $db dropped)"
