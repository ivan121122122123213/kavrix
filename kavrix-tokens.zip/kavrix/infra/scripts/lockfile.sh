#!/usr/bin/env bash
# Generates pnpm-lock.yaml inside a pinned Node container, so the server needs no Node install.
# Run once after receiving the source, review the diff, and commit the lockfile.
set -euo pipefail
cd "$(dirname "$0")/../.."
if [[ -f pnpm-lock.yaml ]]; then
  echo "pnpm-lock.yaml already exists; delete it first to regenerate" >&2
  exit 1
fi
docker run --rm -u "$(id -u):$(id -g)" -e HOME=/tmp -v "$PWD":/repo -w /repo node:24.12.0-bookworm-slim \
  sh -c "npm install --global --prefix /tmp/pnpm --ignore-scripts pnpm@10.12.1 && /tmp/pnpm/bin/pnpm install --lockfile-only --ignore-scripts"
echo "created pnpm-lock.yaml — commit it; Docker builds refuse to run without it"
