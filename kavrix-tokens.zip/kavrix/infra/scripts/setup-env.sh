#!/usr/bin/env bash
# Creates .env from .env.example for a domain, so nothing has to be typed by hand.
#   infra/scripts/setup-env.sh <domain> <email> [--behind-proxy]
# --behind-proxy: an existing nginx on this host owns ports 80/443 and terminates HTTPS;
#                 Kavrix listens on 127.0.0.1:8090 as a separate Docker project.
set -euo pipefail
cd "$(dirname "$0")/../.."
domain="${1:?usage: setup-env.sh <domain> <email> [--behind-proxy]}"
email="${2:?usage: setup-env.sh <domain> <email> [--behind-proxy]}"
mode="${3:-}"
[[ "$domain" =~ ^[a-z0-9.-]+\.[a-z]{2,}$ ]] || { echo "domain looks wrong: $domain (no https://, no slash)" >&2; exit 64; }
[[ "$email" =~ ^[^@[:space:]]+@[^@[:space:]]+\.[a-z]{2,}$ ]] || { echo "email looks wrong: $email" >&2; exit 64; }
[[ -z "$mode" || "$mode" == "--behind-proxy" ]] || { echo "unknown option: $mode" >&2; exit 64; }
[[ -e .env ]] && { echo ".env already exists; move it away first if you want a fresh one" >&2; exit 1; }

umask 077
sed -e "s#^SITE_DOMAIN=.*#SITE_DOMAIN=$domain#" \
    -e "s#^PUBLIC_WEB_ORIGIN=.*#PUBLIC_WEB_ORIGIN=https://$domain#" \
    -e "s#^ACME_EMAIL=.*#ACME_EMAIL=$email#" \
    -e "s#^VITE_SUPPORT_EMAIL=.*#VITE_SUPPORT_EMAIL=$email#" \
    .env.example > .env

if [[ "$mode" == "--behind-proxy" ]]; then
  sed -i -e "s#^TRUST_PROXY_HOPS=.*#TRUST_PROXY_HOPS=2#" -e "s#^KAVRIX_VERSION=.*#KAVRIX_VERSION=2.0.0#" .env
  cat >> .env <<'BLOCK'

# --- Behind the existing nginx (written by setup-env.sh --behind-proxy) ---
COMPOSE_PROJECT_NAME=kavrix2
CADDY_SITE_ADDRESS=:80
KAVRIX_HTTP_BIND=127.0.0.1:8090
KAVRIX_HTTPS_BIND=127.0.0.1:8453
BLOCK
fi
chmod 600 .env
echo ".env created for $domain${mode:+ ($mode)}:"
grep -E '^(SITE_DOMAIN|PUBLIC_WEB_ORIGIN|ACME_EMAIL|TRUST_PROXY_HOPS|KAVRIX_VERSION|COMPOSE_PROJECT_NAME|CADDY_SITE_ADDRESS|KAVRIX_HTTP_BIND)=' .env
