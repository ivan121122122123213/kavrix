#!/usr/bin/env bash
# Creates ./secrets with a random Postgres password and empty provider secret files.
# Never overwrites existing files. Fill provider secrets with: printf '%s' 'value' > secrets/<name>
set -euo pipefail
cd "$(dirname "$0")/../.."
umask 077
mkdir -p secrets
chmod 700 secrets

if [[ ! -s secrets/postgres_password ]]; then
  openssl rand -hex 32 | tr -d '\n' > secrets/postgres_password
  echo "created secrets/postgres_password"
fi
if [[ ! -s secrets/database_url ]]; then
  printf 'postgres://kavrix:%s@postgres:5432/kavrix' "$(cat secrets/postgres_password)" > secrets/database_url
  echo "created secrets/database_url"
fi
if [[ ! -s secrets/quote_signing_key ]]; then
  openssl rand -base64 48 | tr -d '\n' > secrets/quote_signing_key
  echo "created secrets/quote_signing_key"
fi
if [[ ! -s secrets/admin_encryption_key ]]; then
  openssl rand -base64 48 | tr -d '\n' > secrets/admin_encryption_key
  echo "created secrets/admin_encryption_key (losing it invalidates every admin's TOTP; back it up)"
fi
for name in zeroex_api_key kyberswap_api_key moonpay_secret_key moonpay_webhook_key transak_api_secret; do
  [[ -e "secrets/$name" ]] || { : > "secrets/$name"; echo "created empty secrets/$name"; }
done
chmod 600 secrets/*
echo "secrets ready in ./secrets (mode 600)"
