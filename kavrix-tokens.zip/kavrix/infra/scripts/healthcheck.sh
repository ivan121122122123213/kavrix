#!/usr/bin/env bash
# External readiness probe through Caddy (DNS, TLS, proxy, API, database).
#   ALERT_WEBHOOK_URL  optional: POSTs a short JSON alert on failure (Slack/Discord/Telegram-bot compatible relay)
set -euo pipefail
cd "$(dirname "$0")/../.."
origin="$(grep -E '^PUBLIC_WEB_ORIGIN=' .env | cut -d= -f2-)"
if body="$(curl --fail --silent --show-error --max-time 10 "$origin/api/health/ready" 2>&1)"; then
  echo "ok: $body"
  exit 0
fi
echo "FAIL: $origin/api/health/ready -> $body" >&2
if [[ -n "${ALERT_WEBHOOK_URL:-}" ]]; then
  curl --silent --max-time 10 -H 'content-type: application/json' \
    -d "{\"text\":\"Kavrix health check failed for $origin at $(date -u +%FT%TZ)\"}" "$ALERT_WEBHOOK_URL" >/dev/null || true
fi
exit 1
