#!/usr/bin/env bash
# Replaces the production database with a dump. A safety backup of the current state is taken first.
# Usage: infra/scripts/restore.sh backups/kavrix-<ts>.dump --yes-replace-production
set -euo pipefail
cd "$(dirname "$0")/../.."
dump="${1:?usage: restore.sh <dump> --yes-replace-production}"
[[ "${2:-}" == "--yes-replace-production" ]] || { echo "refusing without --yes-replace-production" >&2; exit 64; }
[[ -f "$dump" ]] || { echo "no such file: $dump" >&2; exit 66; }
if [[ -f "$dump.sha256" ]]; then sha256sum --check --status "$dump.sha256" || { echo "checksum mismatch" >&2; exit 65; }; fi

echo "1/5 verifying the dump in a scratch database"
infra/scripts/verify-backup.sh "$dump"

echo "2/5 safety backup of the current database"
KEEP=1000 infra/scripts/backup.sh

echo "3/5 stopping the API (the site shows maintenance errors meanwhile)"
docker compose stop api

echo "4/5 replacing the database"
docker compose exec -T postgres dropdb -U kavrix --if-exists --force kavrix
docker compose exec -T postgres createdb -U kavrix kavrix
docker compose exec -T postgres pg_restore -U kavrix -d kavrix --no-owner --exit-on-error < "$dump"

echo "5/5 starting: pending migrations run first, then the API"
docker compose up -d migrate api
infra/scripts/healthcheck.sh
echo "restore complete"
