#!/usr/bin/env bash
# Logical backup (custom format) of the production database.
#   KEEP=14                       local dumps to keep
#   BACKUP_GPG_RECIPIENT=<keyid>  encrypt the dump (recommended before it leaves the server)
#   BACKUP_REMOTE=user@host:/dir  copy the (encrypted) dump off-site with rsync over SSH
set -euo pipefail
cd "$(dirname "$0")/../.."
KEEP="${KEEP:-14}"
umask 077
mkdir -p backups
file="backups/kavrix-$(date -u +%Y%m%dT%H%M%SZ).dump"
docker compose exec -T postgres pg_dump -U kavrix -d kavrix --format=custom --no-owner > "$file.partial"
mv "$file.partial" "$file"
sha256sum "$file" > "$file.sha256"
echo "backup: $file ($(du -h "$file" | cut -f1))"

if [[ -n "${BACKUP_GPG_RECIPIENT:-}" ]]; then
  gpg --batch --yes --trust-model always --recipient "$BACKUP_GPG_RECIPIENT" --output "$file.gpg" --encrypt "$file"
  echo "encrypted: $file.gpg"
fi
if [[ -n "${BACKUP_REMOTE:-}" ]]; then
  if [[ -z "${BACKUP_GPG_RECIPIENT:-}" ]]; then
    echo "refusing to copy an unencrypted dump off-site; set BACKUP_GPG_RECIPIENT" >&2
    exit 1
  fi
  rsync -a --chmod=F600 "$file.gpg" "$file.sha256" "$BACKUP_REMOTE/"
  echo "copied off-site: $BACKUP_REMOTE"
fi

ls -1t backups/kavrix-*.dump | tail -n +"$((KEEP + 1))" | while read -r old; do rm -f "$old" "$old.sha256" "$old.gpg"; done
