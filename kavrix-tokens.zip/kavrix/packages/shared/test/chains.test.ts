import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { CHAINS, SUPPORTED_CHAIN_IDS, explorerTxUrl, getChain, isSupportedChainId } from "../src/chains.ts";
import { isAddressLike, normalizeAddress, sameAddress } from "../src/address.ts";

describe("chain registry", () => {
  it("covers exactly the launch chains", () => {
    assert.deepEqual([...SUPPORTED_CHAIN_IDS].sort((a, b) => a - b), [1, 137, 8453, 42161]);
    for (const id of SUPPORTED_CHAIN_IDS) {
      assert.equal(CHAINS[id].id, id);
      assert.ok(isAddressLike(CHAINS[id].zeroExAllowanceHolder));
      assert.ok(CHAINS[id].confirmations >= 1);
    }
  });

  it("fails closed on unknown chains", () => {
    assert.throws(() => getChain(10), RangeError);
    assert.equal(isSupportedChainId("1"), false);
    assert.equal(isSupportedChainId(56), false);
  });

  it("builds explorer links only for valid hashes", () => {
    const hash = `0x${"ab".repeat(32)}`;
    assert.equal(explorerTxUrl(8453, hash), `https://basescan.org/tx/${hash}`);
    assert.throws(() => explorerTxUrl(1, "0x123"), TypeError);
    assert.throws(() => explorerTxUrl(1, `0x${"ab".repeat(32)}/../x`), TypeError);
  });
});

describe("addresses", () => {
  it("normalizes and compares case-insensitively", () => {
    const mixed = "0x0000000000001fF3684f28c67538d4D072C22734";
    assert.equal(normalizeAddress(mixed), mixed.toLowerCase());
    assert.ok(sameAddress(mixed, mixed.toLowerCase()));
    assert.equal(sameAddress(mixed, "nope"), false);
    assert.throws(() => normalizeAddress("0x123"), TypeError);
  });
});

describe("aggregator contracts", () => {
  it("pins the KyberSwap router on every launch chain", () => {
    for (const id of SUPPORTED_CHAIN_IDS) {
      assert.equal(CHAINS[id].kyberRouter, "0x6131b5fae19ea4f9d964eac0408e4408b66337b5");
      assert.equal(CHAINS[id].kyberSlug, CHAINS[id].key);
    }
  });
});
