import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  AmountError,
  applyBps,
  bpsToPpm,
  formatUnits,
  minAmountAfterSlippage,
  parseBaseUnits,
  parseUnits,
} from "../src/amount.ts";

describe("parseUnits", () => {
  it("parses whole and fractional values exactly", () => {
    assert.equal(parseUnits("1", 18), 10n ** 18n);
    assert.equal(parseUnits("1.5", 6), 1_500_000n);
    assert.equal(parseUnits("0.000001", 6), 1n);
    assert.equal(parseUnits("0", 0), 0n);
  });

  it("rejects excess precision instead of rounding", () => {
    assert.throws(() => parseUnits("0.0000001", 6), AmountError);
  });

  it("rejects malformed input", () => {
    for (const bad of ["", "-1", "1e6", "01", ".5", "1.", "0x10", "NaN", "1,5"]) {
      assert.throws(() => parseUnits(bad, 18), AmountError, bad);
    }
  });

  it("rejects unsupported decimals", () => {
    assert.throws(() => parseUnits("1", -1), AmountError);
    assert.throws(() => parseUnits("1", 1.5), AmountError);
    assert.throws(() => parseUnits("1", 77), AmountError);
  });
});

describe("formatUnits", () => {
  it("round-trips with parseUnits", () => {
    for (const v of ["1", "1.5", "0.000001", "123456789.123456"]) {
      assert.equal(formatUnits(parseUnits(v, 6), 6), v);
    }
  });

  it("formats negatives and zero", () => {
    assert.equal(formatUnits(0n, 18), "0");
    assert.equal(formatUnits(-1_500_000n, 6), "-1.5");
  });
});

describe("fees and slippage", () => {
  it("rounds fees down", () => {
    assert.equal(applyBps(10_000n, 25), 25n);
    assert.equal(applyBps(399n, 25), 0n);
    assert.equal(applyBps(1_000_000n, 0), 0n);
  });

  it("computes minimum output conservatively", () => {
    assert.equal(minAmountAfterSlippage(1_000_000n, 50), 995_000n);
    assert.equal(minAmountAfterSlippage(3n, 5000), 1n);
    assert.equal(minAmountAfterSlippage(1n, 0), 1n);
  });

  it("rejects invalid bps", () => {
    assert.throws(() => applyBps(1n, -1), AmountError);
    assert.throws(() => applyBps(1n, 10_001), AmountError);
    assert.throws(() => applyBps(1n, 0.5), AmountError);
  });

  it("converts bps to ppm", () => {
    assert.equal(bpsToPpm(50), 5000);
  });
});

describe("parseBaseUnits", () => {
  it("accepts integer strings only", () => {
    assert.equal(parseBaseUnits("123"), 123n);
    assert.throws(() => parseBaseUnits("1.0"), AmountError);
    assert.throws(() => parseBaseUnits("-1"), AmountError);
    assert.throws(() => parseBaseUnits(""), AmountError);
    assert.throws(() => parseBaseUnits((1n << 256n).toString()), AmountError);
  });
});
