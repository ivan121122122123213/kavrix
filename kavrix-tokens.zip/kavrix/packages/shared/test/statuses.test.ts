import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  RAMP_STATUSES,
  SWAP_STATUSES,
  canTransitionRamp,
  canTransitionSwap,
  isTerminalRampStatus,
  isTerminalSwapStatus,
} from "../src/statuses.ts";

describe("swap lifecycle", () => {
  it("never leaves a terminal state", () => {
    for (const from of SWAP_STATUSES.filter(isTerminalSwapStatus)) {
      for (const to of SWAP_STATUSES) assert.equal(canTransitionSwap(from, to), false, `${from}->${to}`);
    }
  });

  it("only a receipt can finalize a submitted swap", () => {
    assert.ok(canTransitionSwap("submitted", "confirmed"));
    assert.ok(canTransitionSwap("dropped", "confirmed"));
    assert.equal(canTransitionSwap("quoted", "confirmed"), false);
    assert.equal(canTransitionSwap("submitted", "rejected"), false);
    assert.equal(canTransitionSwap("submitted", "expired"), false);
    assert.ok(canTransitionSwap("submitted", "failed"), "on-chain mismatch");
    assert.equal(canTransitionSwap("quoted", "dropped"), false);
  });
});

describe("ramp lifecycle", () => {
  it("allows refunds only after completion or pending", () => {
    assert.ok(canTransitionRamp("completed", "refunded"));
    assert.equal(canTransitionRamp("failed", "refunded"), false);
    for (const from of RAMP_STATUSES.filter(isTerminalRampStatus)) {
      for (const to of RAMP_STATUSES) assert.equal(canTransitionRamp(from, to), false);
    }
  });
});
