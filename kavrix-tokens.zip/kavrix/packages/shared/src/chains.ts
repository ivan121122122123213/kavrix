import type { Address } from "./address.ts";

export const SUPPORTED_CHAIN_IDS = [1, 8453, 42161, 137] as const;
export type SupportedChainId = (typeof SUPPORTED_CHAIN_IDS)[number];

export interface ChainInfo {
  readonly id: SupportedChainId;
  readonly key: "ethereum" | "base" | "arbitrum" | "polygon";
  readonly name: string;
  readonly nativeCurrency: { readonly symbol: string; readonly name: string; readonly decimals: 18 };
  readonly explorerUrl: string;
  /** Confirmations after inclusion before an operation is reported as final. Tunable per chain. */
  readonly confirmations: number;
  /** 0x AllowanceHolder (Cancun chains). Source: docs.0x.org/docs/core-concepts/contracts, checked 2026-10-23. */
  readonly zeroExAllowanceHolder: Address;
  /** KyberSwap MetaAggregationRouterV2. Source: docs.kyberswap.com/developer-guide/aggregator-api/contracts, checked 2026-10-25. */
  readonly kyberRouter: Address;
  /** Chain path segment in the KyberSwap Aggregator API. */
  readonly kyberSlug: "ethereum" | "base" | "arbitrum" | "polygon";
}

const ALLOWANCE_HOLDER_CANCUN: Address = "0x0000000000001ff3684f28c67538d4d072c22734";
const KYBER_ROUTER: Address = "0x6131b5fae19ea4f9d964eac0408e4408b66337b5";

export const CHAINS: Readonly<Record<SupportedChainId, ChainInfo>> = Object.freeze({
  1: {
    id: 1,
    key: "ethereum",
    kyberSlug: "ethereum",
    kyberRouter: KYBER_ROUTER,
    name: "Ethereum",
    nativeCurrency: { symbol: "ETH", name: "Ether", decimals: 18 },
    explorerUrl: "https://etherscan.io",
    confirmations: 3,
    zeroExAllowanceHolder: ALLOWANCE_HOLDER_CANCUN,
  },
  8453: {
    id: 8453,
    key: "base",
    kyberSlug: "base",
    kyberRouter: KYBER_ROUTER,
    name: "Base",
    nativeCurrency: { symbol: "ETH", name: "Ether", decimals: 18 },
    explorerUrl: "https://basescan.org",
    confirmations: 5,
    zeroExAllowanceHolder: ALLOWANCE_HOLDER_CANCUN,
  },
  42161: {
    id: 42161,
    key: "arbitrum",
    kyberSlug: "arbitrum",
    kyberRouter: KYBER_ROUTER,
    name: "Arbitrum One",
    nativeCurrency: { symbol: "ETH", name: "Ether", decimals: 18 },
    explorerUrl: "https://arbiscan.io",
    confirmations: 5,
    zeroExAllowanceHolder: ALLOWANCE_HOLDER_CANCUN,
  },
  137: {
    id: 137,
    key: "polygon",
    kyberSlug: "polygon",
    kyberRouter: KYBER_ROUTER,
    name: "Polygon PoS",
    nativeCurrency: { symbol: "POL", name: "POL", decimals: 18 },
    explorerUrl: "https://polygonscan.com",
    confirmations: 16,
    zeroExAllowanceHolder: ALLOWANCE_HOLDER_CANCUN,
  },
});

export function isSupportedChainId(value: unknown): value is SupportedChainId {
  return typeof value === "number" && (SUPPORTED_CHAIN_IDS as readonly number[]).includes(value);
}

/** Fail-closed lookup: unknown chains throw instead of falling back to a default. */
export function getChain(chainId: number): ChainInfo {
  if (!isSupportedChainId(chainId)) {
    throw new RangeError(`Unsupported chain: ${chainId}`);
  }
  return CHAINS[chainId];
}

export function explorerTxUrl(chainId: SupportedChainId, txHash: string): string {
  if (!/^0x[0-9a-fA-F]{64}$/.test(txHash)) {
    throw new TypeError("Invalid transaction hash");
  }
  return `${CHAINS[chainId].explorerUrl}/tx/${txHash}`;
}
