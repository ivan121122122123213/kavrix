/**
 * Operation lifecycles. Transitions are enforced twice: here (application) and by the latest
 * trigger definition in packages/db/migrations (database). A test keeps both in sync.
 */

export const SWAP_STATUSES = [
  "quoted",
  "awaiting_approval",
  "submitted",
  "confirmed",
  "reverted",
  "dropped",
  "rejected",
  "expired",
  "failed",
] as const;
export type SwapStatus = (typeof SWAP_STATUSES)[number];

const SWAP_TRANSITIONS: Readonly<Record<SwapStatus, readonly SwapStatus[]>> = {
  quoted: ["awaiting_approval", "submitted", "rejected", "expired", "failed"],
  awaiting_approval: ["quoted", "rejected", "expired", "failed"],
  // "failed" from here means the on-chain transaction did not match the recorded swap (TX_MISMATCH).
  submitted: ["confirmed", "reverted", "dropped", "failed"],
  // A dropped transaction may still be mined; only a chain receipt resolves it.
  dropped: ["confirmed", "reverted", "failed"],
  confirmed: [],
  reverted: [],
  rejected: [],
  expired: [],
  failed: [],
};

export function canTransitionSwap(from: SwapStatus, to: SwapStatus): boolean {
  return SWAP_TRANSITIONS[from].includes(to);
}

export function isTerminalSwapStatus(status: SwapStatus): boolean {
  return SWAP_TRANSITIONS[status].length === 0;
}

export const RAMP_STATUSES = [
  "created",
  "pending",
  "completed",
  "failed",
  "cancelled",
  "expired",
  "refunded",
] as const;
export type RampStatus = (typeof RAMP_STATUSES)[number];

const RAMP_TRANSITIONS: Readonly<Record<RampStatus, readonly RampStatus[]>> = {
  created: ["pending", "completed", "failed", "cancelled", "expired"],
  // Providers can expire an order that is already waiting for payment.
  pending: ["completed", "failed", "cancelled", "refunded", "expired"],
  completed: ["refunded"],
  failed: [],
  cancelled: [],
  expired: [],
  refunded: [],
};

export function canTransitionRamp(from: RampStatus, to: RampStatus): boolean {
  return RAMP_TRANSITIONS[from].includes(to);
}

export function isTerminalRampStatus(status: RampStatus): boolean {
  return RAMP_TRANSITIONS[status].length === 0;
}

/** Exposed so the SQL trigger can be generated/verified from a single source of truth. */
export const STATUS_TRANSITIONS = { swap: SWAP_TRANSITIONS, ramp: RAMP_TRANSITIONS } as const;
