/**
 * Exact decimal <-> base-unit conversion on bigint. Floating point is never used for money.
 */

const DECIMAL_RE = /^(0|[1-9]\d*)(\.\d+)?$/;
const MAX_DECIMALS = 36;

export const BPS_DENOMINATOR = 10_000n;
export const MAX_UINT256 = (1n << 256n) - 1n;

export class AmountError extends Error {
  override readonly name = "AmountError";
}

function assertDecimals(decimals: number): void {
  if (!Number.isInteger(decimals) || decimals < 0 || decimals > MAX_DECIMALS) {
    throw new AmountError(`Unsupported token decimals: ${decimals}`);
  }
}

/** Parses a human decimal string ("1.5") into base units. Rejects excess precision instead of rounding. */
export function parseUnits(value: string, decimals: number): bigint {
  assertDecimals(decimals);
  const trimmed = value.trim();
  if (!DECIMAL_RE.test(trimmed)) {
    throw new AmountError("Amount must be a non-negative decimal number");
  }
  const [whole = "0", fraction = ""] = trimmed.split(".");
  if (fraction.length > decimals) {
    throw new AmountError(`Amount has more than ${decimals} decimal places`);
  }
  return BigInt(whole) * 10n ** BigInt(decimals) + BigInt(fraction.padEnd(decimals, "0") || "0");
}

export function formatUnits(value: bigint, decimals: number): string {
  assertDecimals(decimals);
  const negative = value < 0n;
  const abs = negative ? -value : value;
  const base = 10n ** BigInt(decimals);
  const whole = abs / base;
  const fraction = (abs % base).toString().padStart(decimals, "0").replace(/0+$/, "");
  const body = fraction.length > 0 ? `${whole}.${fraction}` : whole.toString();
  return negative ? `-${body}` : body;
}

/** Parses a base-unit integer string as returned by provider APIs. */
export function parseBaseUnits(value: string): bigint {
  if (!/^\d+$/.test(value)) {
    throw new AmountError("Base-unit amount must be a non-negative integer string");
  }
  const parsed = BigInt(value);
  if (parsed > MAX_UINT256) throw new AmountError("Base-unit amount exceeds uint256");
  return parsed;
}

export function assertBps(bps: number, max = 10_000): void {
  if (!Number.isInteger(bps) || bps < 0 || bps > max) {
    throw new AmountError(`Basis points out of range [0, ${max}]: ${bps}`);
  }
}

/** Fee rounded down: the user is never charged more than the advertised rate. */
export function applyBps(amount: bigint, bps: number): bigint {
  assertBps(bps);
  if (amount < 0n) throw new AmountError("Amount must be non-negative");
  return (amount * BigInt(bps)) / BPS_DENOMINATOR;
}

/** Minimum output after slippage, rounded down (conservative for the user-facing guarantee). */
export function minAmountAfterSlippage(amount: bigint, slippageBps: number): bigint {
  assertBps(slippageBps);
  if (amount < 0n) throw new AmountError("Amount must be non-negative");
  return (amount * (BPS_DENOMINATOR - BigInt(slippageBps))) / BPS_DENOMINATOR;
}

export function bpsToPpm(bps: number): number {
  assertBps(bps);
  return bps * 100;
}
