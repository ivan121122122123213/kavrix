export type Address = `0x${string}`;

const ADDRESS_RE = /^0x[0-9a-fA-F]{40}$/;
const ZERO_ADDRESS = "0x0000000000000000000000000000000000000000";

/** Sentinel used by 0x and most aggregators for the chain's native asset. */
export const NATIVE_TOKEN_ADDRESS: Address = "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee";

/**
 * Syntactic check only. EIP-55 checksum validation lives in the web app (viem `isAddress`),
 * the server normalizes to lowercase and compares against its own allowlists.
 */
export function isAddressLike(value: unknown): value is Address {
  return typeof value === "string" && ADDRESS_RE.test(value);
}

export function normalizeAddress(value: string): Address {
  if (!isAddressLike(value)) {
    throw new TypeError("Invalid EVM address");
  }
  return value.toLowerCase() as Address;
}

export function isZeroAddress(value: Address): boolean {
  return value.toLowerCase() === ZERO_ADDRESS;
}

export function sameAddress(a: string, b: string): boolean {
  return isAddressLike(a) && isAddressLike(b) && a.toLowerCase() === b.toLowerCase();
}
