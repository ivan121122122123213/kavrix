import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { SWAP_STATUSES, RAMP_STATUSES, STATUS_TRANSITIONS } from "@kavrix/shared";
import { loadMigrations } from "../src/migrate.ts";

describe("migration files", () => {
  it("load in sequence with stable checksums", async () => {
    const files = await loadMigrations();
    assert.ok(files.length >= 1);
    assert.equal(files[0]?.name, "0001_init.sql");
    assert.match(files[0]?.sha256 ?? "", /^[0-9a-f]{64}$/);
  });

  it("reject gaps and bad names", async () => {
    const dir = await mkdtemp(join(tmpdir(), "kavrix-mig-"));
    await writeFile(join(dir, "0001_a.sql"), "select 1;");
    await writeFile(join(dir, "0003_c.sql"), "select 1;");
    await assert.rejects(loadMigrations(dir), /sequence gap/);
    const bad = await mkdtemp(join(tmpdir(), "kavrix-mig-"));
    await writeFile(join(bad, "init.sql"), "select 1;");
    await assert.rejects(loadMigrations(bad), /Invalid migration file name/);
  });

  it("the latest SQL trigger of each kind matches the shared state machine", async () => {
    const files = await loadMigrations();
    const [init] = files;
    for (const status of [...SWAP_STATUSES, ...RAMP_STATUSES]) assert.ok((init?.sql ?? "").includes(`'${status}'`), status);
    for (const [kind, table] of Object.entries(STATUS_TRANSITIONS)) {
      const fnName = `FUNCTION kavrix_${kind}_transition()`;
      const latest = [...files].reverse().find((f) => f.sql.includes(fnName));
      assert.ok(latest, `no trigger for ${kind}`);
      const body = latest.sql.slice(latest.sql.indexOf(fnName));
      const fnSql = body.slice(0, body.indexOf("$$;"));
      for (const [from, targets] of Object.entries(table)) {
        if (targets.length === 0) continue;
        const line = fnSql
          .split("\n")
          .find((l) => l.includes(`OLD.status = '${from}'`) && l.includes("NEW.status"));
        assert.ok(line, `${kind}: missing trigger rule for ${from}`);
        const inSql = [...line.matchAll(/'([a-z_]+)'/g)].map((m) => m[1]).filter((s) => s !== from);
        assert.deepEqual(new Set(inSql), new Set(targets), `${kind}: ${from}`);
      }
    }
  });
});

describe("token seed", () => {
  it("contains only lowercase addresses on supported chains with sane decimals", async () => {
    const files = await loadMigrations();
    const seed = files.find((f) => f.name === "0002_seed_tokens.sql");
    assert.ok(seed);
    const rows = [...seed.sql.matchAll(/\((\d+),\s*'(0x[0-9a-fA-F]+)',\s*'([^']+)',\s*'[^']+',\s*(\d+),/g)];
    assert.equal(rows.length, 12);
    const seen = new Set<string>();
    for (const [, chain, address, symbol, decimals] of rows) {
      assert.ok(["1", "8453", "42161", "137"].includes(chain ?? ""), `chain ${chain}`);
      assert.match(address ?? "", /^0x[0-9a-f]{40}$/, `${symbol} on ${chain}`);
      assert.equal(decimals, symbol === "USDC" || symbol === "USDT" ? "6" : "18", `${symbol} decimals`);
      const key = `${chain}:${address}`;
      assert.equal(seen.has(key), false, `duplicate ${key}`);
      seen.add(key);
    }
  });
});

import { decideEvent, type ProviderEvent } from "../src/ramp.ts";

describe("ramp event decisions", () => {
  const ev = (status: ProviderEvent["status"], externalOrderId = "mp-1"): ProviderEvent => ({
    provider: "moonpay", eventId: "e", eventType: "transaction_updated", payloadSha256: Buffer.alloc(32),
    orderId: "o", externalOrderId, status, providerStatus: status,
  });

  it("moves forward, ignores stale events, and binds the provider order id once", () => {
    assert.equal(decideEvent({ provider: "moonpay", status: "created", externalOrderId: null }, ev("pending")), "applied");
    assert.equal(decideEvent({ provider: "moonpay", status: "created", externalOrderId: null }, ev("created")), "applied");
    assert.equal(decideEvent({ provider: "moonpay", status: "completed", externalOrderId: "mp-1" }, ev("pending")), "stale");
    assert.equal(decideEvent({ provider: "moonpay", status: "pending", externalOrderId: "mp-1" }, ev("pending")), "stale");
    assert.equal(decideEvent({ provider: "moonpay", status: "pending", externalOrderId: "mp-1" }, ev("expired")), "applied");
    assert.equal(decideEvent({ provider: "moonpay", status: "pending", externalOrderId: "mp-1" }, ev("completed", "mp-2")), "mismatch");
    assert.equal(decideEvent({ provider: "transak", status: "pending", externalOrderId: null }, ev("completed")), "mismatch");
  });
});
