import { sql } from "drizzle-orm";
import {
  bigint,
  boolean,
  customType,
  inet,
  integer,
  jsonb,
  numeric,
  pgTable,
  primaryKey,
  smallint,
  text,
  timestamp,
  unique,
  uuid,
} from "drizzle-orm/pg-core";
import type { RampStatus, SwapStatus } from "@kavrix/shared";

/**
 * Typed mirror of migrations/*.sql, used for queries only. SQL migrations are the source of
 * truth; Drizzle Kit is intentionally not used to generate them.
 */

const bytea = customType<{ data: Buffer; driverData: Buffer }>({ dataType: () => "bytea" });
const tsz = (name: string) => timestamp(name, { withTimezone: true, mode: "date" });
/** numeric(78,0) as string on the wire, bigint in code. */
const uint256 = customType<{ data: bigint; driverData: string }>({
  dataType: () => "numeric(78,0)",
  toDriver: (value) => value.toString(),
  fromDriver: (value) => BigInt(value),
});

export const tokens = pgTable(
  "tokens",
  {
    chainId: integer("chain_id").notNull(),
    address: text("address").notNull(),
    symbol: text("symbol").notNull(),
    name: text("name").notNull(),
    decimals: smallint("decimals").notNull(),
    logoUrl: text("logo_url"),
    enabled: boolean("enabled").notNull().default(false),
    review: text("review").$type<"manual" | "auto" | "pending">().notNull().default("manual"),
    risk: text("risk").$type<"standard" | "high">().notNull().default("standard"),
    rank: integer("rank"),
    createdAt: tsz("created_at").notNull().defaultNow(),
    updatedAt: tsz("updated_at").notNull().defaultNow(),
  },
  (t) => [primaryKey({ columns: [t.chainId, t.address] })],
);

export const settings = pgTable("settings", {
  key: text("key").primaryKey(),
  value: jsonb("value").notNull(),
  version: integer("version").notNull().default(1),
  updatedBy: uuid("updated_by"),
  updatedAt: tsz("updated_at").notNull().defaultNow(),
});

export const swapOperations = pgTable("swap_operations", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  idempotencyKey: text("idempotency_key").notNull().unique(),
  chainId: integer("chain_id").notNull(),
  taker: text("taker").notNull(),
  sellToken: text("sell_token").notNull(),
  buyToken: text("buy_token").notNull(),
  sellAmount: uint256("sell_amount").notNull(),
  quotedBuyAmount: uint256("quoted_buy_amount").notNull(),
  minBuyAmount: uint256("min_buy_amount").notNull(),
  actualBuyAmount: uint256("actual_buy_amount"),
  slippageBps: integer("slippage_bps").notNull(),
  platformFeeBps: integer("platform_fee_bps").notNull(),
  platformFeeAmount: uint256("platform_fee_amount").notNull().default(0n),
  providerFeeAmount: uint256("provider_fee_amount").notNull().default(0n),
  networkFeeEstimate: uint256("network_fee_estimate"),
  provider: text("provider").$type<"kyberswap" | "0x">().notNull().default("kyberswap"),
  providerQuoteId: text("provider_quote_id"),
  quoteExpiresAt: tsz("quote_expires_at").notNull(),
  status: text("status").$type<SwapStatus>().notNull().default("quoted"),
  txHash: text("tx_hash"),
  blockNumber: bigint("block_number", { mode: "bigint" }),
  failureCode: text("failure_code"),
  txTo: text("tx_to"),
  txDataSha256: bytea("tx_data_sha256"),
  txValue: uint256("tx_value"),
  confirmations: integer("confirmations"),
  submittedAt: tsz("submitted_at"),
  nextCheckAt: tsz("next_check_at"),
  createdAt: tsz("created_at").notNull().defaultNow(),
  updatedAt: tsz("updated_at").notNull().defaultNow(),
});

export const rampOrders = pgTable("ramp_orders", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  idempotencyKey: text("idempotency_key").notNull().unique(),
  provider: text("provider").$type<"moonpay" | "transak">().notNull(),
  direction: text("direction").$type<"buy" | "sell">().notNull(),
  externalOrderId: text("external_order_id"),
  walletAddress: text("wallet_address").notNull(),
  chainId: integer("chain_id").notNull(),
  fiatCurrency: text("fiat_currency").notNull(),
  fiatAmount: numeric("fiat_amount", { precision: 38, scale: 8 }),
  cryptoCurrency: text("crypto_currency").notNull(),
  cryptoAmount: numeric("crypto_amount", { precision: 78, scale: 18 }),
  status: text("status").$type<RampStatus>().notNull().default("created"),
  providerStatus: text("provider_status"),
  createdAt: tsz("created_at").notNull().defaultNow(),
  updatedAt: tsz("updated_at").notNull().defaultNow(),
});

export const webhookEvents = pgTable(
  "webhook_events",
  {
    id: bigint("id", { mode: "bigint" }).primaryKey().generatedAlwaysAsIdentity(),
    provider: text("provider").$type<"moonpay" | "transak">().notNull(),
    eventId: text("event_id").notNull(),
    eventType: text("event_type").notNull(),
    payloadSha256: bytea("payload_sha256").notNull(),
    rampOrderId: uuid("ramp_order_id").references(() => rampOrders.id),
    receivedAt: tsz("received_at").notNull().defaultNow(),
    processedAt: tsz("processed_at"),
    errorCode: text("error_code"),
  },
  (t) => [unique().on(t.provider, t.eventId)],
);

export const adminUsers = pgTable("admin_users", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: text("role").$type<"owner" | "operator" | "viewer">().notNull(),
  totpSecret: bytea("totp_secret"),
  disabledAt: tsz("disabled_at"),
  createdAt: tsz("created_at").notNull().defaultNow(),
});

export const adminSessions = pgTable("admin_sessions", {
  tokenSha256: bytea("token_sha256").primaryKey(),
  adminId: uuid("admin_id")
    .notNull()
    .references(() => adminUsers.id, { onDelete: "cascade" }),
  createdAt: tsz("created_at").notNull().defaultNow(),
  expiresAt: tsz("expires_at").notNull(),
  lastSeenAt: tsz("last_seen_at").notNull().defaultNow(),
  revokedAt: tsz("revoked_at"),
});

export const adminAuditLog = pgTable("admin_audit_log", {
  id: bigint("id", { mode: "bigint" }).primaryKey().generatedAlwaysAsIdentity(),
  adminId: uuid("admin_id").references(() => adminUsers.id),
  action: text("action").notNull(),
  target: text("target"),
  before: jsonb("before"),
  after: jsonb("after"),
  ip: inet("ip"),
  createdAt: tsz("created_at").notNull().defaultNow(),
});
