import { canTransitionRamp, type Address, type RampStatus, type SupportedChainId } from "@kavrix/shared";
import type { SqlClient } from "./client.ts";

export type RampProvider = "moonpay" | "transak";
export type RampDirection = "buy" | "sell";

export interface NewRampOrder {
  readonly idempotencyKey: string;
  readonly provider: RampProvider;
  readonly direction: RampDirection;
  readonly walletAddress: Address;
  readonly chainId: SupportedChainId;
  readonly tokenAddress: Address;
  readonly cryptoCurrency: string;
  readonly providerCurrency: string;
  readonly fiatCurrency: string;
  /** Decimal strings as entered: fiat for buys, crypto for sells. */
  readonly fiatAmount: string | null;
  readonly cryptoAmount: string | null;
}

export interface RampRecord extends NewRampOrder {
  readonly id: string;
  readonly status: RampStatus;
  readonly providerStatus: string | null;
  readonly externalOrderId: string | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

export interface ProviderEvent {
  readonly provider: RampProvider;
  /** Stable id for deduplication (provider event id or a hash of id+status+timestamp). */
  readonly eventId: string;
  readonly eventType: string;
  readonly payloadSha256: Buffer;
  /** Our order id as echoed by the provider (externalTransactionId / partnerOrderId). */
  readonly orderId: string | null;
  readonly externalOrderId: string;
  readonly status: RampStatus;
  readonly providerStatus: string;
}

export type EventOutcome = "applied" | "duplicate" | "stale" | "unknown_order" | "mismatch";

export interface RampRepository {
  create(order: NewRampOrder): Promise<{ record: RampRecord; created: boolean }>;
  get(id: string): Promise<RampRecord | null>;
  /**
   * Records a verified provider event exactly once and applies it if it moves the order forward.
   * Out-of-order events never move an order backwards ("stale").
   */
  applyEvent(event: ProviderEvent): Promise<EventOutcome>;
  /** Orders the provider has acknowledged (an external id exists), newest first. */
  listByWallet(wallet: Address, limit: number): Promise<RampRecord[]>;
}

/** Returns what an event should do to an order, independent of storage. */
export function decideEvent(order: Pick<RampRecord, "provider" | "status" | "externalOrderId">, event: ProviderEvent): EventOutcome {
  if (order.provider !== event.provider) return "mismatch";
  if (order.externalOrderId !== null && order.externalOrderId !== event.externalOrderId) return "mismatch";
  if (order.status === event.status) return order.externalOrderId === null ? "applied" : "stale";
  return canTransitionRamp(order.status, event.status) ? "applied" : "stale";
}

export interface RampRow {
  id: string;
  idempotency_key: string;
  provider: RampProvider;
  direction: RampDirection;
  wallet_address: string;
  chain_id: number;
  token_address: string;
  crypto_currency: string;
  provider_currency: string;
  fiat_currency: string;
  fiat_amount: string | null;
  crypto_amount: string | null;
  status: RampStatus;
  provider_status: string | null;
  external_order_id: string | null;
  created_at: Date;
  updated_at: Date;
}

export const RAMP_COLUMNS = `id, idempotency_key, provider, direction, wallet_address, chain_id, token_address, crypto_currency, provider_currency,
  fiat_currency, fiat_amount::text, crypto_amount::text, status, provider_status, external_order_id, created_at, updated_at`;

export function rampFromRow(r: RampRow): RampRecord {
  return {
    id: r.id,
    idempotencyKey: r.idempotency_key,
    provider: r.provider,
    direction: r.direction,
    walletAddress: r.wallet_address as Address,
    chainId: r.chain_id as SupportedChainId,
    tokenAddress: r.token_address as Address,
    cryptoCurrency: r.crypto_currency,
    providerCurrency: r.provider_currency,
    fiatCurrency: r.fiat_currency,
    fiatAmount: r.fiat_amount,
    cryptoAmount: r.crypto_amount,
    status: r.status,
    providerStatus: r.provider_status,
    externalOrderId: r.external_order_id,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
  };
}

export class PgRampRepository implements RampRepository {
  readonly #sql: SqlClient;

  constructor(sql: SqlClient) {
    this.#sql = sql;
  }

  async create(o: NewRampOrder): Promise<{ record: RampRecord; created: boolean }> {
    const sql = this.#sql;
    const inserted = await sql<RampRow[]>`
      INSERT INTO ramp_orders (idempotency_key, provider, direction, wallet_address, chain_id, token_address, crypto_currency,
        provider_currency, fiat_currency, fiat_amount, crypto_amount)
      VALUES (${o.idempotencyKey}, ${o.provider}, ${o.direction}, ${o.walletAddress}, ${o.chainId}, ${o.tokenAddress},
        ${o.cryptoCurrency}, ${o.providerCurrency}, ${o.fiatCurrency}, ${o.fiatAmount}, ${o.cryptoAmount})
      ON CONFLICT (idempotency_key) DO NOTHING
      RETURNING ${sql.unsafe(RAMP_COLUMNS)}`;
    if (inserted[0] !== undefined) return { record: rampFromRow(inserted[0]), created: true };
    const existing = await sql<RampRow[]>`SELECT ${sql.unsafe(RAMP_COLUMNS)} FROM ramp_orders WHERE idempotency_key = ${o.idempotencyKey}`;
    if (existing[0] === undefined) throw new Error("idempotent insert lost its row");
    return { record: rampFromRow(existing[0]), created: false };
  }

  async get(id: string): Promise<RampRecord | null> {
    const rows = await this.#sql<RampRow[]>`SELECT ${this.#sql.unsafe(RAMP_COLUMNS)} FROM ramp_orders WHERE id = ${id}`;
    return rows[0] === undefined ? null : rampFromRow(rows[0]);
  }

  async applyEvent(e: ProviderEvent): Promise<EventOutcome> {
    return this.#sql.begin(async (tx) => {
      const order =
        e.orderId === null
          ? undefined
          : (await tx<RampRow[]>`SELECT ${tx.unsafe(RAMP_COLUMNS)} FROM ramp_orders WHERE id = ${e.orderId} FOR UPDATE`)[0];
      const inserted = await tx<{ id: string }[]>`
        INSERT INTO webhook_events (provider, event_id, event_type, payload_sha256, ramp_order_id)
        VALUES (${e.provider}, ${e.eventId}, ${e.eventType}, ${e.payloadSha256}, ${order?.id ?? null})
        ON CONFLICT (provider, event_id) DO NOTHING RETURNING id`;
      const eventRow = inserted[0];
      if (eventRow === undefined) return "duplicate";
      if (order === undefined) {
        await tx`UPDATE webhook_events SET processed_at = now(), error_code = 'UNKNOWN_ORDER' WHERE id = ${eventRow.id}`;
        return "unknown_order";
      }
      const outcome = decideEvent(rampFromRow(order), e);
      if (outcome === "applied") {
        await tx`
          UPDATE ramp_orders SET status = ${e.status}, provider_status = ${e.providerStatus.slice(0, 64)},
            external_order_id = COALESCE(external_order_id, ${e.externalOrderId}), status_updated_at = now()
          WHERE id = ${order.id}`;
      } else if (outcome === "stale") {
        // Keep the latest provider wording for support, without moving the lifecycle backwards.
        await tx`UPDATE ramp_orders SET external_order_id = COALESCE(external_order_id, ${e.externalOrderId}) WHERE id = ${order.id}`;
      }
      await tx`
        UPDATE webhook_events SET processed_at = now(), error_code = ${outcome === "mismatch" ? "EXTERNAL_ID_MISMATCH" : null}
        WHERE id = ${eventRow.id}`;
      return outcome;
    });
  }

  async listByWallet(wallet: Address, limit: number): Promise<RampRecord[]> {
    const sql = this.#sql;
    const rows = await sql<RampRow[]>`
      SELECT ${sql.unsafe(RAMP_COLUMNS)} FROM ramp_orders
      WHERE wallet_address = ${wallet} AND external_order_id IS NOT NULL
      ORDER BY created_at DESC, id DESC LIMIT ${limit}`;
    return rows.map(rampFromRow);
  }
}

/** Small JSON key-value store over the `settings` table. */
export async function readSetting(sql: SqlClient, key: string): Promise<unknown> {
  const rows = await sql<{ value: unknown }[]>`SELECT value FROM settings WHERE key = ${key}`;
  return rows[0]?.value ?? null;
}

export async function writeSetting(sql: SqlClient, key: string, value: unknown): Promise<void> {
  await sql`
    INSERT INTO settings (key, value) VALUES (${key}, ${sql.json(value as never)})
    ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, version = settings.version + 1, updated_at = now()`;
}
