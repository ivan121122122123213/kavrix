import { and, asc, eq, sql as dsql } from "drizzle-orm";
import type { Address, SupportedChainId } from "@kavrix/shared";
import type { Database, SqlClient } from "./client.ts";
import { tokens } from "./schema.ts";

export interface TokenRecord {
  readonly chainId: number;
  readonly address: string;
  readonly symbol: string;
  readonly name: string;
  readonly decimals: number;
  readonly logoUrl: string | null;
  readonly risk: "standard" | "high";
  readonly rank: number | null;
}

/** Enabled tokens, most prominent first (ranked, then alphabetical). */
export async function listEnabledTokens(db: Database, chainId: number): Promise<TokenRecord[]> {
  return db
    .select({
      chainId: tokens.chainId,
      address: tokens.address,
      symbol: tokens.symbol,
      name: tokens.name,
      decimals: tokens.decimals,
      logoUrl: tokens.logoUrl,
      risk: tokens.risk,
      rank: tokens.rank,
    })
    .from(tokens)
    .where(and(eq(tokens.chainId, chainId), eq(tokens.enabled, true)))
    .orderBy(dsql`${tokens.rank} ASC NULLS LAST`, asc(tokens.symbol));
}

export type TokenReview = "manual" | "auto" | "pending";

export interface StoredToken {
  readonly chainId: SupportedChainId;
  readonly address: Address;
  readonly symbol: string;
  readonly decimals: number;
  readonly enabled: boolean;
  readonly review: TokenReview;
}

export interface SyncedToken {
  readonly chainId: SupportedChainId;
  readonly address: Address;
  readonly symbol: string;
  readonly name: string;
  readonly decimals: number;
  readonly logoUrl: string | null;
  readonly risk: "standard" | "high";
  readonly rank: number | null;
  readonly sources: readonly string[];
  readonly review: "auto" | "pending";
  readonly enabled: boolean;
  readonly note: string | null;
}

/** Persistence for the token sync job. Rows with review = 'manual' are read but never written. */
export interface TokenSyncRepository {
  all(chainId: SupportedChainId): Promise<StoredToken[]>;
  /** Inserts or updates synced rows; a manual row with the same key is left untouched. */
  upsert(rows: readonly SyncedToken[]): Promise<number>;
  /** Disables synced rows no longer backed by the sources (kept for history, never deleted). */
  retire(chainId: SupportedChainId, keep: ReadonlySet<string>, note: string): Promise<number>;
}

export class PgTokenSyncRepository implements TokenSyncRepository {
  readonly #sql: SqlClient;

  constructor(sql: SqlClient) {
    this.#sql = sql;
  }

  async all(chainId: SupportedChainId): Promise<StoredToken[]> {
    const rows = await this.#sql<{ chain_id: number; address: string; symbol: string; decimals: number; enabled: boolean; review: TokenReview }[]>`
      SELECT chain_id, address, symbol, decimals, enabled, review FROM tokens WHERE chain_id = ${chainId}`;
    return rows.map((r) => ({ chainId: r.chain_id as SupportedChainId, address: r.address as Address, symbol: r.symbol, decimals: r.decimals, enabled: r.enabled, review: r.review }));
  }

  async upsert(rows: readonly SyncedToken[]): Promise<number> {
    let n = 0;
    await this.#sql.begin(async (tx) => {
      for (const r of rows) {
        const res = await tx`
          INSERT INTO tokens (chain_id, address, symbol, name, decimals, logo_url, enabled, review, risk, rank, sources, review_note, synced_at)
          VALUES (${r.chainId}, ${r.address}, ${r.symbol}, ${r.name}, ${r.decimals}, ${r.logoUrl}, ${r.enabled}, ${r.review}, ${r.risk},
                  ${r.rank}, ${tx.array([...r.sources])}, ${r.note}, now())
          ON CONFLICT (chain_id, address) DO UPDATE SET
            symbol = EXCLUDED.symbol, name = EXCLUDED.name, logo_url = EXCLUDED.logo_url, enabled = EXCLUDED.enabled,
            review = EXCLUDED.review, risk = EXCLUDED.risk, rank = EXCLUDED.rank, sources = EXCLUDED.sources,
            review_note = EXCLUDED.review_note, synced_at = now()
          WHERE tokens.review <> 'manual' AND tokens.decimals = EXCLUDED.decimals
          RETURNING address`;
        n += res.length;
      }
    });
    return n;
  }

  async retire(chainId: SupportedChainId, keep: ReadonlySet<string>, note: string): Promise<number> {
    const rows = await this.#sql<{ address: string }[]>`
      UPDATE tokens SET enabled = false, review = 'pending', review_note = ${note}, synced_at = now()
      WHERE chain_id = ${chainId} AND review = 'auto' AND enabled
        AND NOT (address = ANY(${this.#sql.array([...keep])}))
      RETURNING address`;
    return rows.length;
  }
}
