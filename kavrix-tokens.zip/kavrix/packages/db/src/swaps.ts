import type { SqlClient } from "./client.ts";
import type { Address, SupportedChainId, SwapStatus } from "@kavrix/shared";

export interface NewSwap {
  readonly idempotencyKey: string;
  readonly provider: "kyberswap" | "0x";
  readonly chainId: SupportedChainId;
  readonly taker: Address;
  readonly sellToken: Address;
  readonly buyToken: Address;
  readonly sellAmount: bigint;
  readonly quotedBuyAmount: bigint;
  readonly minBuyAmount: bigint;
  readonly slippageBps: number;
  readonly platformFeeBps: number;
  readonly platformFeeAmount: bigint;
  readonly providerFeeAmount: bigint;
  readonly networkFeeEstimate: bigint | null;
  readonly quoteExpiresAt: Date;
  readonly txTo: Address;
  /** Hex SHA-256 of the calldata handed to the wallet. */
  readonly txDataSha256: string;
  readonly txValue: bigint;
}

export interface SwapRecord extends NewSwap {
  readonly id: string;
  readonly status: SwapStatus;
  readonly actualBuyAmount: bigint | null;
  readonly txHash: `0x${string}` | null;
  readonly blockNumber: bigint | null;
  readonly confirmations: number | null;
  readonly failureCode: string | null;
  readonly submittedAt: Date | null;
  readonly createdAt: Date;
  readonly updatedAt: Date;
}

export type SubmitResult = "submitted" | "already_submitted" | "hash_conflict" | "not_found" | "wrong_state";
export type RejectResult = "rejected" | "already_rejected" | "not_found" | "wrong_state";

export interface ChainCheckUpdate {
  readonly status?: "confirmed" | "reverted" | "dropped" | "failed";
  readonly blockNumber?: bigint;
  readonly confirmations?: number;
  readonly actualBuyAmount?: bigint;
  readonly failureCode?: string;
  /** null stops tracking. */
  readonly nextCheckAt: Date | null;
}

/** Persistence port used by the API and the tracker; the Postgres implementation is below. */
export interface SwapRepository {
  /** Inserts once per idempotency key; a repeated key returns the stored row with `created: false`. */
  create(swap: NewSwap): Promise<{ record: SwapRecord; created: boolean }>;
  get(id: string): Promise<SwapRecord | null>;
  submit(id: string, txHash: `0x${string}`, now: Date): Promise<SubmitResult>;
  reject(id: string): Promise<RejectResult>;
  /** On-chain swaps (with a transaction hash) for a wallet, newest first. */
  listByWallet(taker: Address, limit: number, before?: { createdAt: Date; id: string }): Promise<SwapRecord[]>;
  /** Leases due rows so concurrent workers never process the same swap at once. */
  claimDue(limit: number, leaseMs: number): Promise<SwapRecord[]>;
  applyCheck(id: string, update: ChainCheckUpdate): Promise<void>;
  /** Marks never-submitted quotes as expired once their transaction deadline has passed. */
  expireQuoted(quotedBefore: Date): Promise<number>;
}

export interface SwapRow {
  id: string;
  idempotency_key: string;
  provider: "kyberswap" | "0x";
  chain_id: number;
  taker: string;
  sell_token: string;
  buy_token: string;
  sell_amount: string;
  quoted_buy_amount: string;
  min_buy_amount: string;
  actual_buy_amount: string | null;
  slippage_bps: number;
  platform_fee_bps: number;
  platform_fee_amount: string;
  provider_fee_amount: string;
  network_fee_estimate: string | null;
  quote_expires_at: Date;
  status: SwapStatus;
  tx_hash: string | null;
  tx_to: string;
  tx_data_sha256: Buffer;
  tx_value: string;
  block_number: string | null;
  confirmations: number | null;
  failure_code: string | null;
  submitted_at: Date | null;
  created_at: Date;
  updated_at: Date;
}

export function swapFromRow(r: SwapRow): SwapRecord {
  return {
    id: r.id,
    idempotencyKey: r.idempotency_key,
    provider: r.provider,
    chainId: r.chain_id as SupportedChainId,
    taker: r.taker as Address,
    sellToken: r.sell_token as Address,
    buyToken: r.buy_token as Address,
    sellAmount: BigInt(r.sell_amount),
    quotedBuyAmount: BigInt(r.quoted_buy_amount),
    minBuyAmount: BigInt(r.min_buy_amount),
    actualBuyAmount: r.actual_buy_amount === null ? null : BigInt(r.actual_buy_amount),
    slippageBps: r.slippage_bps,
    platformFeeBps: r.platform_fee_bps,
    platformFeeAmount: BigInt(r.platform_fee_amount),
    providerFeeAmount: BigInt(r.provider_fee_amount),
    networkFeeEstimate: r.network_fee_estimate === null ? null : BigInt(r.network_fee_estimate),
    quoteExpiresAt: r.quote_expires_at,
    status: r.status,
    txHash: r.tx_hash as `0x${string}` | null,
    txTo: r.tx_to as Address,
    txDataSha256: r.tx_data_sha256.toString("hex"),
    txValue: BigInt(r.tx_value),
    blockNumber: r.block_number === null ? null : BigInt(r.block_number),
    confirmations: r.confirmations,
    failureCode: r.failure_code,
    submittedAt: r.submitted_at,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
  };
}

export const SWAP_COLUMNS = `id, idempotency_key, provider, chain_id, taker, sell_token, buy_token, sell_amount::text, quoted_buy_amount::text,
  min_buy_amount::text, actual_buy_amount::text, slippage_bps, platform_fee_bps, platform_fee_amount::text,
  provider_fee_amount::text, network_fee_estimate::text, quote_expires_at, status, tx_hash, tx_to, tx_data_sha256,
  tx_value::text, block_number::text, confirmations, failure_code, submitted_at, created_at, updated_at`;

export class PgSwapRepository implements SwapRepository {
  readonly #sql: SqlClient;

  constructor(sql: SqlClient) {
    this.#sql = sql;
  }

  async create(s: NewSwap): Promise<{ record: SwapRecord; created: boolean }> {
    const sql = this.#sql;
    const inserted = await sql<SwapRow[]>`
      INSERT INTO swap_operations (
        idempotency_key, provider, chain_id, taker, sell_token, buy_token, sell_amount, quoted_buy_amount, min_buy_amount,
        slippage_bps, platform_fee_bps, platform_fee_amount, provider_fee_amount, network_fee_estimate, quote_expires_at,
        status, tx_to, tx_data_sha256, tx_value
      ) VALUES (
        ${s.idempotencyKey}, ${s.provider}, ${s.chainId}, ${s.taker}, ${s.sellToken}, ${s.buyToken}, ${s.sellAmount.toString()},
        ${s.quotedBuyAmount.toString()}, ${s.minBuyAmount.toString()}, ${s.slippageBps}, ${s.platformFeeBps},
        ${s.platformFeeAmount.toString()}, ${s.providerFeeAmount.toString()},
        ${s.networkFeeEstimate === null ? null : s.networkFeeEstimate.toString()}, ${s.quoteExpiresAt},
        'quoted', ${s.txTo}, ${Buffer.from(s.txDataSha256, "hex")}, ${s.txValue.toString()}
      )
      ON CONFLICT (idempotency_key) DO NOTHING
      RETURNING ${sql.unsafe(SWAP_COLUMNS)}`;
    if (inserted[0] !== undefined) return { record: swapFromRow(inserted[0]), created: true };
    const existing = await sql<SwapRow[]>`SELECT ${sql.unsafe(SWAP_COLUMNS)} FROM swap_operations WHERE idempotency_key = ${s.idempotencyKey}`;
    if (existing[0] === undefined) throw new Error("idempotent insert lost its row");
    return { record: swapFromRow(existing[0]), created: false };
  }

  async get(id: string): Promise<SwapRecord | null> {
    const rows = await this.#sql<SwapRow[]>`SELECT ${this.#sql.unsafe(SWAP_COLUMNS)} FROM swap_operations WHERE id = ${id}`;
    return rows[0] === undefined ? null : swapFromRow(rows[0]);
  }

  async submit(id: string, txHash: `0x${string}`, now: Date): Promise<SubmitResult> {
    const sql = this.#sql;
    const updated = await sql`
      UPDATE swap_operations SET status = 'submitted', tx_hash = ${txHash}, submitted_at = ${now}, next_check_at = ${now}
      WHERE id = ${id} AND status = 'quoted' RETURNING id`;
    if (updated.length === 1) return "submitted";
    const rows = await sql<{ status: SwapStatus; tx_hash: string | null }[]>`SELECT status, tx_hash FROM swap_operations WHERE id = ${id}`;
    const row = rows[0];
    if (row === undefined) return "not_found";
    if (row.tx_hash !== null) return row.tx_hash === txHash ? "already_submitted" : "hash_conflict";
    return "wrong_state";
  }

  async reject(id: string): Promise<RejectResult> {
    const sql = this.#sql;
    const updated = await sql`UPDATE swap_operations SET status = 'rejected' WHERE id = ${id} AND status = 'quoted' RETURNING id`;
    if (updated.length === 1) return "rejected";
    const rows = await sql<{ status: SwapStatus }[]>`SELECT status FROM swap_operations WHERE id = ${id}`;
    if (rows[0] === undefined) return "not_found";
    return rows[0].status === "rejected" ? "already_rejected" : "wrong_state";
  }

  async listByWallet(taker: Address, limit: number, before?: { createdAt: Date; id: string }): Promise<SwapRecord[]> {
    const sql = this.#sql;
    const rows =
      before === undefined
        ? await sql<SwapRow[]>`
            SELECT ${sql.unsafe(SWAP_COLUMNS)} FROM swap_operations
            WHERE taker = ${taker} AND tx_hash IS NOT NULL
            ORDER BY created_at DESC, id DESC LIMIT ${limit}`
        : await sql<SwapRow[]>`
            SELECT ${sql.unsafe(SWAP_COLUMNS)} FROM swap_operations
            WHERE taker = ${taker} AND tx_hash IS NOT NULL AND (created_at, id) < (${before.createdAt}, ${before.id})
            ORDER BY created_at DESC, id DESC LIMIT ${limit}`;
    return rows.map(swapFromRow);
  }

  async claimDue(limit: number, leaseMs: number): Promise<SwapRecord[]> {
    const sql = this.#sql;
    const rows = await sql<SwapRow[]>`
      UPDATE swap_operations SET next_check_at = now() + make_interval(secs => ${leaseMs / 1000})
      WHERE id IN (
        SELECT id FROM swap_operations
        WHERE next_check_at IS NOT NULL AND next_check_at <= now() AND status IN ('submitted', 'dropped')
        ORDER BY next_check_at
        LIMIT ${limit}
        FOR UPDATE SKIP LOCKED
      )
      RETURNING ${sql.unsafe(SWAP_COLUMNS)}`;
    return rows.map(swapFromRow);
  }

  async applyCheck(id: string, u: ChainCheckUpdate): Promise<void> {
    const sql = this.#sql;
    await sql`
      UPDATE swap_operations SET
        status = COALESCE(${u.status ?? null}, status),
        block_number = COALESCE(${u.blockNumber === undefined ? null : u.blockNumber.toString()}::bigint, block_number),
        confirmations = COALESCE(${u.confirmations ?? null}::integer, confirmations),
        actual_buy_amount = COALESCE(${u.actualBuyAmount === undefined ? null : u.actualBuyAmount.toString()}::numeric, actual_buy_amount),
        failure_code = COALESCE(${u.failureCode ?? null}, failure_code),
        next_check_at = ${u.nextCheckAt}
      WHERE id = ${id}`;
  }

  async expireQuoted(quotedBefore: Date): Promise<number> {
    const rows = await this.#sql`
      UPDATE swap_operations SET status = 'expired'
      WHERE status = 'quoted' AND quote_expires_at < ${quotedBefore} RETURNING id`;
    return rows.length;
  }
}
