import postgres from "postgres";
import { drizzle, type PostgresJsDatabase } from "drizzle-orm/postgres-js";
import * as schema from "./schema.ts";

export type Database = PostgresJsDatabase<typeof schema>;
export type SqlClient = postgres.Sql;

export interface DatabaseOptions {
  readonly url: string;
  readonly maxConnections?: number;
  readonly statementTimeoutMs?: number;
}

export interface DatabaseHandle {
  readonly db: Database;
  readonly sql: SqlClient;
  ping(): Promise<boolean>;
  close(): Promise<void>;
}

export function createDatabase(options: DatabaseOptions): DatabaseHandle {
  const sql = postgres(options.url, {
    max: options.maxConnections ?? 10,
    idle_timeout: 30,
    connect_timeout: 5,
    prepare: true,
    // Never echo parameters (could include addresses or ids) into server notices.
    onnotice: () => undefined,
    connection: {
      application_name: "kavrix-api",
      statement_timeout: options.statementTimeoutMs ?? 10_000,
    },
  });
  const db = drizzle(sql, { schema });
  return {
    db,
    sql,
    async ping() {
      try {
        const rows = await sql`select 1 as ok`;
        return rows.length === 1;
      } catch {
        return false;
      }
    },
    async close() {
      await sql.end({ timeout: 5 });
    },
  };
}
