import type { Address, RampStatus, SupportedChainId, SwapStatus } from "@kavrix/shared";
import type { SqlClient } from "./client.ts";
import { SWAP_COLUMNS, swapFromRow, type SwapRecord, type SwapRow } from "./swaps.ts";
import { RAMP_COLUMNS, rampFromRow, type RampRecord, type RampRow } from "./ramp.ts";

export type AdminRole = "owner" | "operator" | "viewer";

export interface AdminUser {
  readonly id: string;
  readonly email: string;
  readonly passwordHash: string;
  readonly role: AdminRole;
  readonly totpSecret: Buffer | null;
  readonly totpLastStep: number | null;
  readonly failedAttempts: number;
  readonly lockedUntil: Date | null;
  readonly disabledAt: Date | null;
}

export interface AdminSession {
  readonly adminId: string;
  readonly email: string;
  readonly role: AdminRole;
  readonly expiresAt: Date;
  readonly lastSeenAt: Date;
}

export interface AuditEntry {
  readonly adminId: string | null;
  readonly action: string;
  readonly target: string | null;
  readonly before: unknown;
  readonly after: unknown;
  readonly ip: string | null;
}

export interface AuditRow extends AuditEntry {
  readonly id: string;
  readonly adminEmail: string | null;
  readonly createdAt: Date;
}

export interface AdminTokenRow {
  readonly chainId: SupportedChainId;
  readonly address: Address;
  readonly symbol: string;
  readonly name: string;
  readonly decimals: number;
  readonly enabled: boolean;
  /** manual = owned by an operator (never changed by the sync); auto/pending = managed by the sync. */
  readonly review?: "manual" | "auto" | "pending";
  readonly risk?: "standard" | "high";
  readonly sources?: readonly string[];
  readonly note?: string | null;
}

export interface Stats {
  readonly swapsByStatus: readonly { status: SwapStatus; count: number }[];
  readonly confirmedVolume: readonly { chainId: SupportedChainId; token: Address; amount: bigint; count: number }[];
  readonly feeRevenue: readonly { chainId: SupportedChainId; token: Address; amount: bigint }[];
  readonly rampByStatus: readonly { provider: string; status: RampStatus; count: number }[];
  readonly dailyConfirmed: readonly { day: string; count: number }[];
}

export interface SettingRow {
  readonly key: string;
  readonly value: unknown;
  readonly version: number;
  readonly updatedAt: Date;
}

export type SettingUpdate = "updated" | "version_conflict" | "not_found";

/** Persistence for the admin panel. Every mutating method writes its audit entry in the same transaction. */
export interface AdminRepository {
  findAdminByEmail(email: string): Promise<AdminUser | null>;
  createAdmin(input: { email: string; passwordHash: string; role: AdminRole }): Promise<string>;
  setTotpSecret(adminId: string, sealed: Buffer): Promise<void>;
  setPassword(adminId: string, passwordHash: string): Promise<void>;
  setDisabled(adminId: string, disabled: boolean): Promise<void>;
  recordFailedLogin(adminId: string, lockAfter: number, lockForMs: number): Promise<void>;
  /** Atomically accepts a TOTP step only if it is newer than the last one; resets the failure counter. */
  acceptLogin(adminId: string, totpStep: number): Promise<boolean>;

  createSession(input: { tokenHash: Buffer; adminId: string; expiresAt: Date; ip: string | null; userAgent: string | null }): Promise<void>;
  /** Returns the session and refreshes last_seen_at, or null when missing, revoked, expired or idle too long. */
  touchSession(tokenHash: Buffer, idleMs: number): Promise<AdminSession | null>;
  revokeSession(tokenHash: Buffer): Promise<void>;
  revokeAllSessions(adminId: string): Promise<void>;

  audit(entry: AuditEntry): Promise<void>;
  listAudit(limit: number, beforeId?: string): Promise<AuditRow[]>;

  stats(days: number): Promise<Stats>;
  listSwaps(filter: { status?: SwapStatus; chainId?: SupportedChainId; limit: number; before?: { createdAt: Date; id: string } }): Promise<SwapRecord[]>;
  listRampOrders(filter: { status?: RampStatus; provider?: string; limit: number; before?: { createdAt: Date; id: string } }): Promise<RampRecord[]>;

  listAllTokens(): Promise<AdminTokenRow[]>;
  setTokenEnabled(chainId: SupportedChainId, address: Address, enabled: boolean, audit: Omit<AuditEntry, "action" | "target" | "before" | "after">): Promise<AdminTokenRow | null>;
  addToken(token: Omit<AdminTokenRow, "enabled">, audit: Omit<AuditEntry, "action" | "target" | "before" | "after">): Promise<"added" | "exists">;

  listSettings(keys: readonly string[]): Promise<SettingRow[]>;
  updateSetting(key: string, value: unknown, expectedVersion: number, audit: Omit<AuditEntry, "action" | "target" | "before" | "after">): Promise<SettingUpdate>;

  trackerBacklog(): Promise<number>;
  lastWebhookAt(): Promise<Partial<Record<"moonpay" | "transak", Date>>>;
}

const toNum = (v: string | number | bigint): number => Number(v);

export class PgAdminRepository implements AdminRepository {
  readonly #sql: SqlClient;

  constructor(sql: SqlClient) {
    this.#sql = sql;
  }

  async findAdminByEmail(email: string): Promise<AdminUser | null> {
    const rows = await this.#sql<
      {
        id: string; email: string; password_hash: string; role: AdminRole; totp_secret: Buffer | null; totp_last_step: string | null;
        failed_attempts: number; locked_until: Date | null; disabled_at: Date | null;
      }[]
    >`SELECT id, email, password_hash, role, totp_secret, totp_last_step::text, failed_attempts, locked_until, disabled_at
      FROM admin_users WHERE email = ${email.toLowerCase()}`;
    const r = rows[0];
    if (r === undefined) return null;
    return {
      id: r.id, email: r.email, passwordHash: r.password_hash, role: r.role, totpSecret: r.totp_secret,
      totpLastStep: r.totp_last_step === null ? null : Number(r.totp_last_step), failedAttempts: r.failed_attempts,
      lockedUntil: r.locked_until, disabledAt: r.disabled_at,
    };
  }

  async createAdmin(input: { email: string; passwordHash: string; role: AdminRole }): Promise<string> {
    const rows = await this.#sql<{ id: string }[]>`
      INSERT INTO admin_users (email, password_hash, role) VALUES (${input.email.toLowerCase()}, ${input.passwordHash}, ${input.role}) RETURNING id`;
    const id = rows[0]?.id;
    if (id === undefined) throw new Error("admin insert failed");
    await this.audit({ adminId: null, action: "admin.created", target: input.email.toLowerCase(), before: null, after: { role: input.role }, ip: null });
    return id;
  }

  async setTotpSecret(adminId: string, sealed: Buffer): Promise<void> {
    await this.#sql`UPDATE admin_users SET totp_secret = ${sealed}, totp_last_step = NULL WHERE id = ${adminId}`;
    await this.revokeAllSessions(adminId);
    await this.audit({ adminId: null, action: "admin.totp_reset", target: adminId, before: null, after: null, ip: null });
  }

  async setPassword(adminId: string, passwordHash: string): Promise<void> {
    await this.#sql`UPDATE admin_users SET password_hash = ${passwordHash}, failed_attempts = 0, locked_until = NULL WHERE id = ${adminId}`;
    await this.revokeAllSessions(adminId);
    await this.audit({ adminId: null, action: "admin.password_reset", target: adminId, before: null, after: null, ip: null });
  }

  async setDisabled(adminId: string, disabled: boolean): Promise<void> {
    await this.#sql`UPDATE admin_users SET disabled_at = ${disabled ? new Date() : null} WHERE id = ${adminId}`;
    if (disabled) await this.revokeAllSessions(adminId);
    await this.audit({ adminId: null, action: disabled ? "admin.disabled" : "admin.enabled", target: adminId, before: null, after: null, ip: null });
  }

  async recordFailedLogin(adminId: string, lockAfter: number, lockForMs: number): Promise<void> {
    await this.#sql`
      UPDATE admin_users SET
        failed_attempts = failed_attempts + 1,
        locked_until = CASE WHEN failed_attempts + 1 >= ${lockAfter} THEN now() + make_interval(secs => ${lockForMs / 1000}) ELSE locked_until END
      WHERE id = ${adminId}`;
  }

  async acceptLogin(adminId: string, totpStep: number): Promise<boolean> {
    const rows = await this.#sql`
      UPDATE admin_users SET totp_last_step = ${totpStep}, failed_attempts = 0, locked_until = NULL, last_login_at = now()
      WHERE id = ${adminId} AND (totp_last_step IS NULL OR totp_last_step < ${totpStep}) RETURNING id`;
    return rows.length === 1;
  }

  async createSession(s: { tokenHash: Buffer; adminId: string; expiresAt: Date; ip: string | null; userAgent: string | null }): Promise<void> {
    await this.#sql`
      INSERT INTO admin_sessions (token_sha256, admin_id, expires_at, ip, user_agent)
      VALUES (${s.tokenHash}, ${s.adminId}, ${s.expiresAt}, ${s.ip}, ${s.userAgent === null ? null : s.userAgent.slice(0, 256)})`;
  }

  async touchSession(tokenHash: Buffer, idleMs: number): Promise<AdminSession | null> {
    const rows = await this.#sql<{ admin_id: string; email: string; role: AdminRole; expires_at: Date; last_seen_at: Date }[]>`
      UPDATE admin_sessions s SET last_seen_at = now()
      FROM admin_users u
      WHERE s.token_sha256 = ${tokenHash} AND s.admin_id = u.id AND s.revoked_at IS NULL AND s.expires_at > now()
        AND s.last_seen_at > now() - make_interval(secs => ${idleMs / 1000}) AND u.disabled_at IS NULL
      RETURNING s.admin_id, u.email, u.role, s.expires_at, s.last_seen_at`;
    const r = rows[0];
    return r === undefined ? null : { adminId: r.admin_id, email: r.email, role: r.role, expiresAt: r.expires_at, lastSeenAt: r.last_seen_at };
  }

  async revokeSession(tokenHash: Buffer): Promise<void> {
    await this.#sql`UPDATE admin_sessions SET revoked_at = now() WHERE token_sha256 = ${tokenHash} AND revoked_at IS NULL`;
  }

  async revokeAllSessions(adminId: string): Promise<void> {
    await this.#sql`UPDATE admin_sessions SET revoked_at = now() WHERE admin_id = ${adminId} AND revoked_at IS NULL`;
  }

  async audit(e: AuditEntry): Promise<void> {
    const sql = this.#sql;
    await sql`
      INSERT INTO admin_audit_log (admin_id, action, target, before, after, ip)
      VALUES (${e.adminId}, ${e.action}, ${e.target}, ${e.before === null ? null : sql.json(e.before as never)},
              ${e.after === null ? null : sql.json(e.after as never)}, ${e.ip})`;
  }

  async listAudit(limit: number, beforeId?: string): Promise<AuditRow[]> {
    const sql = this.#sql;
    const rows = await sql<
      { id: string; admin_id: string | null; email: string | null; action: string; target: string | null; before: unknown; after: unknown; ip: string | null; created_at: Date }[]
    >`
      SELECT l.id::text, l.admin_id, u.email, l.action, l.target, l.before, l.after, host(l.ip) AS ip, l.created_at
      FROM admin_audit_log l LEFT JOIN admin_users u ON u.id = l.admin_id
      WHERE ${beforeId === undefined ? sql`TRUE` : sql`l.id < ${beforeId}::bigint`}
      ORDER BY l.id DESC LIMIT ${limit}`;
    return rows.map((r) => ({
      id: r.id, adminId: r.admin_id, adminEmail: r.email, action: r.action, target: r.target, before: r.before, after: r.after, ip: r.ip, createdAt: r.created_at,
    }));
  }

  async stats(days: number): Promise<Stats> {
    const sql = this.#sql;
    // A fresh fragment per query: fragments are not shared between concurrently running statements.
    const since = () => sql`now() - make_interval(days => ${days})`;
    const [byStatus, volume, fees, ramp, daily] = await Promise.all([
      sql<{ status: SwapStatus; count: string }[]>`
        SELECT status, count(*)::text AS count FROM swap_operations WHERE created_at > ${since()} GROUP BY status`,
      sql<{ chain_id: number; token: string; amount: string; count: string }[]>`
        SELECT chain_id, sell_token AS token, sum(sell_amount)::text AS amount, count(*)::text AS count
        FROM swap_operations WHERE status = 'confirmed' AND created_at > ${since()} GROUP BY 1, 2`,
      sql<{ chain_id: number; token: string; amount: string }[]>`
        SELECT chain_id, CASE WHEN provider = 'kyberswap' THEN sell_token ELSE buy_token END AS token, sum(platform_fee_amount)::text AS amount
        FROM swap_operations WHERE status = 'confirmed' AND platform_fee_amount > 0 AND created_at > ${since()} GROUP BY 1, 2`,
      sql<{ provider: string; status: RampStatus; count: string }[]>`
        SELECT provider, status, count(*)::text AS count FROM ramp_orders
        WHERE external_order_id IS NOT NULL AND created_at > ${since()} GROUP BY 1, 2`,
      sql<{ day: string; count: string }[]>`
        SELECT to_char(date_trunc('day', created_at), 'YYYY-MM-DD') AS day, count(*)::text AS count
        FROM swap_operations WHERE status = 'confirmed' AND created_at > ${since()} GROUP BY 1 ORDER BY 1`,
    ]);
    return {
      swapsByStatus: byStatus.map((r) => ({ status: r.status, count: toNum(r.count) })),
      confirmedVolume: volume.map((r) => ({ chainId: r.chain_id as SupportedChainId, token: r.token as Address, amount: BigInt(r.amount), count: toNum(r.count) })),
      feeRevenue: fees.map((r) => ({ chainId: r.chain_id as SupportedChainId, token: r.token as Address, amount: BigInt(r.amount) })),
      rampByStatus: ramp.map((r) => ({ provider: r.provider, status: r.status, count: toNum(r.count) })),
      dailyConfirmed: daily.map((r) => ({ day: r.day, count: toNum(r.count) })),
    };
  }

  async listSwaps(f: { status?: SwapStatus; chainId?: SupportedChainId; limit: number; before?: { createdAt: Date; id: string } }): Promise<SwapRecord[]> {
    const sql = this.#sql;
    const rows = await sql<SwapRow[]>`
      SELECT ${sql.unsafe(SWAP_COLUMNS)} FROM swap_operations
      WHERE ${f.status === undefined ? sql`TRUE` : sql`status = ${f.status}`}
        AND ${f.chainId === undefined ? sql`TRUE` : sql`chain_id = ${f.chainId}`}
        AND ${f.before === undefined ? sql`TRUE` : sql`(created_at, id) < (${f.before.createdAt}, ${f.before.id})`}
      ORDER BY created_at DESC, id DESC LIMIT ${f.limit}`;
    return rows.map(swapFromRow);
  }

  async listRampOrders(f: { status?: RampStatus; provider?: string; limit: number; before?: { createdAt: Date; id: string } }): Promise<RampRecord[]> {
    const sql = this.#sql;
    const rows = await sql<RampRow[]>`
      SELECT ${sql.unsafe(RAMP_COLUMNS)} FROM ramp_orders
      WHERE ${f.status === undefined ? sql`TRUE` : sql`status = ${f.status}`}
        AND ${f.provider === undefined ? sql`TRUE` : sql`provider = ${f.provider}`}
        AND ${f.before === undefined ? sql`TRUE` : sql`(created_at, id) < (${f.before.createdAt}, ${f.before.id})`}
      ORDER BY created_at DESC, id DESC LIMIT ${f.limit}`;
    return rows.map(rampFromRow);
  }

  async listAllTokens(): Promise<AdminTokenRow[]> {
    const rows = await this.#sql<
      { chain_id: number; address: string; symbol: string; name: string; decimals: number; enabled: boolean; review: "manual" | "auto" | "pending"; risk: "standard" | "high"; sources: string[]; review_note: string | null }[]
    >`
      SELECT chain_id, address, symbol, name, decimals, enabled, review, risk, sources, review_note FROM tokens
      ORDER BY (review = 'pending') DESC, chain_id, rank NULLS LAST, symbol`;
    return rows.map((r) => ({
      chainId: r.chain_id as SupportedChainId, address: r.address as Address, symbol: r.symbol, name: r.name, decimals: r.decimals,
      enabled: r.enabled, review: r.review, risk: r.risk, sources: r.sources, note: r.review_note,
    }));
  }

  async setTokenEnabled(chainId: SupportedChainId, address: Address, enabled: boolean, a: Omit<AuditEntry, "action" | "target" | "before" | "after">) {
    return this.#sql.begin(async (tx) => {
      const before = await tx<{ enabled: boolean }[]>`SELECT enabled FROM tokens WHERE chain_id = ${chainId} AND address = ${address} FOR UPDATE`;
      if (before[0] === undefined) return null;
      const rows = await tx<{ chain_id: number; address: string; symbol: string; name: string; decimals: number; enabled: boolean }[]>`
        UPDATE tokens SET enabled = ${enabled}, review = 'manual', review_note = NULL WHERE chain_id = ${chainId} AND address = ${address}
        RETURNING chain_id, address, symbol, name, decimals, enabled`;
      await tx`
        INSERT INTO admin_audit_log (admin_id, action, target, before, after, ip)
        VALUES (${a.adminId}, 'token.enabled_changed', ${`${chainId}:${address}`}, ${tx.json({ enabled: before[0].enabled })}, ${tx.json({ enabled })}, ${a.ip})`;
      const r = rows[0];
      return r === undefined ? null : { chainId: r.chain_id as SupportedChainId, address: r.address as Address, symbol: r.symbol, name: r.name, decimals: r.decimals, enabled: r.enabled };
    });
  }

  async addToken(t: Omit<AdminTokenRow, "enabled">, a: Omit<AuditEntry, "action" | "target" | "before" | "after">): Promise<"added" | "exists"> {
    return this.#sql.begin(async (tx) => {
      // New tokens start disabled: an operator enables them after checking the contract.
      const rows = await tx`
        INSERT INTO tokens (chain_id, address, symbol, name, decimals, enabled)
        VALUES (${t.chainId}, ${t.address}, ${t.symbol}, ${t.name}, ${t.decimals}, false)
        ON CONFLICT (chain_id, address) DO NOTHING RETURNING address`;
      if (rows.length === 0) return "exists";
      await tx`
        INSERT INTO admin_audit_log (admin_id, action, target, before, after, ip)
        VALUES (${a.adminId}, 'token.added', ${`${t.chainId}:${t.address}`}, NULL, ${tx.json({ symbol: t.symbol, name: t.name, decimals: t.decimals })}, ${a.ip})`;
      return "added";
    });
  }

  async listSettings(keys: readonly string[]): Promise<SettingRow[]> {
    if (keys.length === 0) return [];
    const rows = await this.#sql<{ key: string; value: unknown; version: number; updated_at: Date }[]>`
      SELECT key, value, version, updated_at FROM settings WHERE key IN ${this.#sql(keys as string[])}`;
    return rows.map((r) => ({ key: r.key, value: r.value, version: r.version, updatedAt: r.updated_at }));
  }

  async updateSetting(key: string, value: unknown, expectedVersion: number, a: Omit<AuditEntry, "action" | "target" | "before" | "after">): Promise<SettingUpdate> {
    return this.#sql.begin(async (tx) => {
      const current = await tx<{ value: unknown; version: number }[]>`SELECT value, version FROM settings WHERE key = ${key} FOR UPDATE`;
      const row = current[0];
      if (row === undefined) return "not_found";
      if (row.version !== expectedVersion) return "version_conflict";
      await tx`
        UPDATE settings SET value = ${tx.json(value as never)}, version = version + 1, updated_by = ${a.adminId}, updated_at = now()
        WHERE key = ${key}`;
      await tx`
        INSERT INTO admin_audit_log (admin_id, action, target, before, after, ip)
        VALUES (${a.adminId}, 'setting.updated', ${key}, ${tx.json(row.value as never)}, ${tx.json(value as never)}, ${a.ip})`;
      return "updated";
    });
  }

  async trackerBacklog(): Promise<number> {
    const rows = await this.#sql<{ n: string }[]>`SELECT count(*)::text AS n FROM swap_operations WHERE next_check_at IS NOT NULL AND next_check_at <= now()`;
    return Number(rows[0]?.n ?? 0);
  }

  async lastWebhookAt(): Promise<Partial<Record<"moonpay" | "transak", Date>>> {
    const rows = await this.#sql<{ provider: "moonpay" | "transak"; at: Date }[]>`
      SELECT provider, max(received_at) AS at FROM webhook_events GROUP BY provider`;
    return Object.fromEntries(rows.map((r) => [r.provider, r.at]));
  }
}
