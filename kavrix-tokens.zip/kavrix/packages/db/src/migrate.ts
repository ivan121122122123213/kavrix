import { createHash } from "node:crypto";
import { readdir, readFile } from "node:fs/promises";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import type { SqlClient } from "./client.ts";

export const MIGRATIONS_DIR = fileURLToPath(new URL("../migrations/", import.meta.url));
const MIGRATION_FILE_RE = /^(\d{4})_[a-z0-9_]+\.sql$/;
/** Arbitrary but fixed: serializes concurrent migrators (e.g. two containers starting). */
const ADVISORY_LOCK_ID = 727_100_001;

export interface MigrationFile {
  readonly name: string;
  readonly sql: string;
  readonly sha256: string;
}

export async function loadMigrations(dir: string = MIGRATIONS_DIR): Promise<MigrationFile[]> {
  const names = (await readdir(dir)).filter((n) => n.endsWith(".sql")).sort();
  const files: MigrationFile[] = [];
  let expected = 1;
  for (const name of names) {
    const match = MIGRATION_FILE_RE.exec(name);
    if (match === null) throw new Error(`Invalid migration file name: ${name}`);
    if (Number(match[1]) !== expected) throw new Error(`Migration sequence gap at ${name}`);
    expected += 1;
    const content = await readFile(join(dir, name), "utf8");
    files.push({ name, sql: content, sha256: createHash("sha256").update(content).digest("hex") });
  }
  return files;
}

export interface MigrationResult {
  readonly applied: readonly string[];
  readonly alreadyApplied: number;
}

/**
 * Applies pending migrations, each in its own transaction, under an advisory lock.
 * Fails closed if an applied migration was modified or is missing locally.
 */
export async function migrate(sql: SqlClient, files: readonly MigrationFile[]): Promise<MigrationResult> {
  return sql.begin(async (tx) => {
    await tx`select pg_advisory_xact_lock(${ADVISORY_LOCK_ID})`;
    await tx`
      create table if not exists kavrix_migrations (
        name text primary key,
        sha256 text not null,
        applied_at timestamptz not null default now()
      )`;
    const rows = await tx<{ name: string; sha256: string }[]>`select name, sha256 from kavrix_migrations order by name`;
    const byName = new Map(files.map((f) => [f.name, f]));
    for (const row of rows) {
      const local = byName.get(row.name);
      if (local === undefined) throw new Error(`Applied migration ${row.name} is missing locally`);
      if (local.sha256 !== row.sha256) throw new Error(`Applied migration ${row.name} was modified`);
    }
    const done = new Set(rows.map((r) => r.name));
    const applied: string[] = [];
    for (const file of files) {
      if (done.has(file.name)) continue;
      await tx.savepoint(async (sp) => {
        // Simple protocol: migration files contain multiple statements and no parameters.
        await sp.unsafe(file.sql).simple();
        await sp`insert into kavrix_migrations (name, sha256) values (${file.name}, ${file.sha256})`;
      });
      applied.push(file.name);
    }
    return { applied, alreadyApplied: rows.length };
  });
}
