-- Token artwork may be self-hosted official files (apps/web/public/tokens/*) or an https URL.
ALTER TABLE tokens DROP CONSTRAINT tokens_logo_url_check;
ALTER TABLE tokens ADD CONSTRAINT tokens_logo_url_check
  CHECK (logo_url IS NULL OR logo_url ~ '^https://[^\s"''<>]+$' OR logo_url ~ '^/tokens/[a-z0-9-]+\.(svg|png|webp)$');
