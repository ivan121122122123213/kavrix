-- Stage 6: swap tracking. The transaction Kavrix handed to the wallet is recorded so the worker can
-- prove that the hash a client reports is that exact transaction (sender, target, value, calldata).
ALTER TABLE swap_operations
  ADD COLUMN tx_to          text        CHECK (tx_to IS NULL OR tx_to ~ '^0x[0-9a-f]{40}$'),
  ADD COLUMN tx_data_sha256 bytea       CHECK (tx_data_sha256 IS NULL OR length(tx_data_sha256) = 32),
  ADD COLUMN tx_value       numeric(78,0) CHECK (tx_value IS NULL OR tx_value >= 0),
  ADD COLUMN confirmations  integer     CHECK (confirmations IS NULL OR confirmations >= 0),
  ADD COLUMN submitted_at   timestamptz,
  ADD COLUMN next_check_at  timestamptz;

ALTER TABLE swap_operations ADD CONSTRAINT swap_tx_recorded
  CHECK (tx_to IS NOT NULL AND tx_data_sha256 IS NOT NULL AND tx_value IS NOT NULL) NOT VALID;
ALTER TABLE swap_operations ADD CONSTRAINT swap_submitted_at
  CHECK (status NOT IN ('submitted','confirmed','reverted','dropped') OR submitted_at IS NOT NULL) NOT VALID;

DROP INDEX IF EXISTS swap_operations_pending;
CREATE INDEX swap_operations_due ON swap_operations (next_check_at) WHERE next_check_at IS NOT NULL;
CREATE INDEX swap_operations_quoted_expiry ON swap_operations (quote_expires_at) WHERE status = 'quoted';
CREATE INDEX swap_operations_wallet_history ON swap_operations (taker, created_at DESC, id DESC) WHERE tx_hash IS NOT NULL;

CREATE OR REPLACE FUNCTION kavrix_swap_transition() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.status IS DISTINCT FROM OLD.status AND NOT (
    (OLD.status = 'quoted'            AND NEW.status IN ('awaiting_approval','submitted','rejected','expired','failed')) OR
    (OLD.status = 'awaiting_approval' AND NEW.status IN ('quoted','rejected','expired','failed')) OR
    (OLD.status = 'submitted'         AND NEW.status IN ('confirmed','reverted','dropped','failed')) OR
    (OLD.status = 'dropped'           AND NEW.status IN ('confirmed','reverted','failed'))
  ) THEN
    RAISE EXCEPTION 'illegal swap status transition % -> %', OLD.status, NEW.status USING ERRCODE = 'check_violation';
  END IF;
  -- Economic terms and the recorded transaction are immutable once quoted.
  IF (NEW.chain_id, NEW.taker, NEW.sell_token, NEW.buy_token, NEW.sell_amount, NEW.min_buy_amount,
      NEW.platform_fee_bps, NEW.idempotency_key, NEW.tx_to, NEW.tx_data_sha256, NEW.tx_value)
     IS DISTINCT FROM
     (OLD.chain_id, OLD.taker, OLD.sell_token, OLD.buy_token, OLD.sell_amount, OLD.min_buy_amount,
      OLD.platform_fee_bps, OLD.idempotency_key, OLD.tx_to, OLD.tx_data_sha256, OLD.tx_value) THEN
    RAISE EXCEPTION 'swap terms are immutable' USING ERRCODE = 'check_violation';
  END IF;
  IF OLD.tx_hash IS NOT NULL AND NEW.tx_hash IS DISTINCT FROM OLD.tx_hash THEN
    RAISE EXCEPTION 'tx_hash cannot change once set' USING ERRCODE = 'check_violation';
  END IF;
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;
