-- Launch token list. Addresses are the canonical contracts published by the issuers
-- (Circle, Tether, MakerDAO) and the chains' bridged WETH. Re-verify each address on the
-- chain explorer before production; see docs/TOKENS.md. Admins can disable any row.
-- Native assets are not stored here: the API adds them from the chain registry.

INSERT INTO tokens (chain_id, address, symbol, name, decimals, enabled) VALUES
  (1,     '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48', 'USDC', 'USD Coin',        6,  true),
  (1,     '0xdac17f958d2ee523a2206206994597c13d831ec7', 'USDT', 'Tether USD',      6,  true),
  (1,     '0x6b175474e89094c44da98b954eedeac495271d0f', 'DAI',  'Dai Stablecoin',  18, true),
  (1,     '0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2', 'WETH', 'Wrapped Ether',   18, true),
  (8453,  '0x833589fcd6edb6e08f4c7c32d4f71b54bda02913', 'USDC', 'USD Coin',        6,  true),
  (8453,  '0x4200000000000000000000000000000000000006', 'WETH', 'Wrapped Ether',   18, true),
  (42161, '0xaf88d065e77c8cc2239327c5edb3a432268e5831', 'USDC', 'USD Coin',        6,  true),
  (42161, '0xfd086bc7cd5c481dcc9c85ebe478a1c0b69fcbb9', 'USDT', 'Tether USD',      6,  true),
  (42161, '0x82af49447d8a07e3bd95bd0d56f35241523fbab1', 'WETH', 'Wrapped Ether',   18, true),
  (137,   '0x3c499c542cef5e3811e1192ce70d8cc03d5c3359', 'USDC', 'USD Coin',        6,  true),
  (137,   '0xc2132d05d31c914a87c6611c10748aeb04b58e8f', 'USDT', 'Tether USD',      6,  true),
  (137,   '0x7ceb23fd6bc0add59e62ac25578270cff1b9f619', 'WETH', 'Wrapped Ether',   18, true)
ON CONFLICT (chain_id, address) DO NOTHING;
