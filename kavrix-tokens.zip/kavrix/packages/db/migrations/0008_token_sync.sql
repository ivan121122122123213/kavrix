-- Stage: large token list. Tokens imported by the sync job carry their provenance and risk;
-- rows an operator added (review = 'manual') are never changed by the sync.
ALTER TABLE tokens
  ADD COLUMN review      text        NOT NULL DEFAULT 'manual' CHECK (review IN ('manual', 'auto', 'pending')),
  ADD COLUMN risk        text        NOT NULL DEFAULT 'standard' CHECK (risk IN ('standard', 'high')),
  ADD COLUMN rank        integer     CHECK (rank IS NULL OR rank > 0),
  ADD COLUMN sources     text[]      NOT NULL DEFAULT '{}' CHECK (sources <@ ARRAY['uniswap', 'coingecko', 'kyberswap']::text[]),
  ADD COLUMN review_note text        CHECK (review_note IS NULL OR length(review_note) <= 300),
  ADD COLUMN synced_at   timestamptz;

-- The picker lists enabled tokens by prominence.
CREATE INDEX tokens_enabled_rank ON tokens (chain_id, rank NULLS LAST, symbol) WHERE enabled;
