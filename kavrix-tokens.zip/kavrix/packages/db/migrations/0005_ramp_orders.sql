-- Stage 7: fiat orders via MoonPay / Transak.
ALTER TABLE ramp_orders
  ADD COLUMN token_address text CHECK (token_address IS NULL OR token_address ~ '^0x[0-9a-f]{40}$'),
  ADD COLUMN provider_currency text CHECK (provider_currency IS NULL OR length(provider_currency) <= 64),
  ADD COLUMN status_updated_at timestamptz;

CREATE INDEX ramp_orders_wallet_history ON ramp_orders (wallet_address, created_at DESC, id DESC) WHERE external_order_id IS NOT NULL;

CREATE OR REPLACE FUNCTION kavrix_ramp_transition() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.status IS DISTINCT FROM OLD.status AND NOT (
    (OLD.status = 'created'   AND NEW.status IN ('pending','completed','failed','cancelled','expired')) OR
    (OLD.status = 'pending'   AND NEW.status IN ('completed','failed','cancelled','refunded','expired')) OR
    (OLD.status = 'completed' AND NEW.status IN ('refunded'))
  ) THEN
    RAISE EXCEPTION 'illegal ramp status transition % -> %', OLD.status, NEW.status USING ERRCODE = 'check_violation';
  END IF;
  IF OLD.external_order_id IS NOT NULL AND NEW.external_order_id IS DISTINCT FROM OLD.external_order_id THEN
    RAISE EXCEPTION 'external_order_id cannot change once set' USING ERRCODE = 'check_violation';
  END IF;
  IF (NEW.provider, NEW.direction, NEW.wallet_address, NEW.chain_id, NEW.idempotency_key)
     IS DISTINCT FROM (OLD.provider, OLD.direction, OLD.wallet_address, OLD.chain_id, OLD.idempotency_key) THEN
    RAISE EXCEPTION 'ramp order terms are immutable' USING ERRCODE = 'check_violation';
  END IF;
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

-- Transak's partner access token is shared by all API replicas and survives restarts,
-- so webhooks signed with it can always be verified.
INSERT INTO settings (key, value) VALUES ('transak.access_token', 'null'::jsonb) ON CONFLICT (key) DO NOTHING;
