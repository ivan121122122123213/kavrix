-- Stage 8: admin authentication hardening and runtime settings.
ALTER TABLE admin_users
  ADD COLUMN failed_attempts integer NOT NULL DEFAULT 0 CHECK (failed_attempts >= 0),
  ADD COLUMN locked_until    timestamptz,
  -- Last accepted TOTP time step: a code can never be accepted twice.
  ADD COLUMN totp_last_step  bigint,
  ADD COLUMN last_login_at   timestamptz;

ALTER TABLE admin_sessions
  ADD COLUMN ip         inet,
  ADD COLUMN user_agent text CHECK (user_agent IS NULL OR length(user_agent) <= 256);

CREATE INDEX admin_audit_log_created ON admin_audit_log (created_at DESC, id DESC);
CREATE INDEX swap_operations_created ON swap_operations (created_at DESC, id DESC);
CREATE INDEX ramp_orders_created ON ramp_orders (created_at DESC, id DESC);

-- Runtime settings edited from the admin panel. Values are validated by the API before writing.
INSERT INTO settings (key, value) VALUES
  ('swap.enabled', 'true'::jsonb),
  ('swap.fee_bps_by_chain', '{}'::jsonb),
  ('swap.quote_rate_per_minute', '30'::jsonb),
  ('ramp.enabled', '{"moonpay": true, "transak": true}'::jsonb),
  ('ramp.buy_limits', '{"min": 20, "max": 5000}'::jsonb)
ON CONFLICT (key) DO NOTHING;
