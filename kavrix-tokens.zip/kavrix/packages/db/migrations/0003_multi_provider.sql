-- Swap quotes may come from KyberSwap (default) or 0x.
ALTER TABLE swap_operations DROP CONSTRAINT swap_operations_provider_check;
ALTER TABLE swap_operations ADD CONSTRAINT swap_operations_provider_check CHECK (provider IN ('kyberswap', '0x'));
ALTER TABLE swap_operations ALTER COLUMN provider SET DEFAULT 'kyberswap';
ALTER TABLE swap_operations DROP CONSTRAINT swap_operations_slippage_bps_check;
ALTER TABLE swap_operations ADD CONSTRAINT swap_operations_slippage_bps_check CHECK (slippage_bps BETWEEN 0 AND 2000);
