-- Kavrix initial schema. Amounts are numeric(78,0) base units (fits uint256); never floats.
-- Status transitions mirror packages/shared/src/statuses.ts.

CREATE OR REPLACE FUNCTION kavrix_touch_updated_at() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

CREATE TABLE tokens (
  chain_id     integer     NOT NULL CHECK (chain_id IN (1, 8453, 42161, 137)),
  address      text        NOT NULL CHECK (address ~ '^0x[0-9a-f]{40}$'),
  symbol       text        NOT NULL CHECK (length(symbol) BETWEEN 1 AND 16),
  name         text        NOT NULL CHECK (length(name) BETWEEN 1 AND 64),
  decimals     smallint    NOT NULL CHECK (decimals BETWEEN 0 AND 36),
  logo_url     text        CHECK (logo_url IS NULL OR logo_url ~ '^https://'),
  enabled      boolean     NOT NULL DEFAULT false,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (chain_id, address)
);
CREATE TRIGGER tokens_touch BEFORE UPDATE ON tokens FOR EACH ROW EXECUTE FUNCTION kavrix_touch_updated_at();

CREATE TABLE settings (
  key          text        PRIMARY KEY CHECK (key ~ '^[a-z][a-z0-9_.]{1,63}$'),
  value        jsonb       NOT NULL,
  version      integer     NOT NULL DEFAULT 1,
  updated_by   uuid,
  updated_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE swap_operations (
  id                   uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  idempotency_key      text        NOT NULL UNIQUE CHECK (length(idempotency_key) BETWEEN 16 AND 128),
  chain_id             integer     NOT NULL CHECK (chain_id IN (1, 8453, 42161, 137)),
  taker                text        NOT NULL CHECK (taker ~ '^0x[0-9a-f]{40}$'),
  sell_token           text        NOT NULL CHECK (sell_token ~ '^0x[0-9a-f]{40}$'),
  buy_token            text        NOT NULL CHECK (buy_token ~ '^0x[0-9a-f]{40}$' AND buy_token <> sell_token),
  sell_amount          numeric(78,0) NOT NULL CHECK (sell_amount > 0),
  quoted_buy_amount    numeric(78,0) NOT NULL CHECK (quoted_buy_amount > 0),
  min_buy_amount       numeric(78,0) NOT NULL CHECK (min_buy_amount > 0 AND min_buy_amount <= quoted_buy_amount),
  actual_buy_amount    numeric(78,0) CHECK (actual_buy_amount IS NULL OR actual_buy_amount >= 0),
  slippage_bps         integer     NOT NULL CHECK (slippage_bps BETWEEN 0 AND 5000),
  platform_fee_bps     integer     NOT NULL CHECK (platform_fee_bps BETWEEN 0 AND 300),
  platform_fee_amount  numeric(78,0) NOT NULL DEFAULT 0 CHECK (platform_fee_amount >= 0),
  provider_fee_amount  numeric(78,0) NOT NULL DEFAULT 0 CHECK (provider_fee_amount >= 0),
  network_fee_estimate numeric(78,0) CHECK (network_fee_estimate IS NULL OR network_fee_estimate >= 0),
  provider             text        NOT NULL DEFAULT '0x' CHECK (provider IN ('0x')),
  provider_quote_id    text        CHECK (provider_quote_id IS NULL OR length(provider_quote_id) <= 128),
  quote_expires_at     timestamptz NOT NULL,
  status               text        NOT NULL DEFAULT 'quoted' CHECK (status IN (
                          'quoted','awaiting_approval','submitted','confirmed','reverted','dropped','rejected','expired','failed')),
  tx_hash              text        CHECK (tx_hash IS NULL OR tx_hash ~ '^0x[0-9a-f]{64}$'),
  block_number         bigint      CHECK (block_number IS NULL OR block_number > 0),
  failure_code         text        CHECK (failure_code IS NULL OR failure_code ~ '^[A-Z0-9_]{2,64}$'),
  created_at           timestamptz NOT NULL DEFAULT now(),
  updated_at           timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT swap_tx_required CHECK (
    status IN ('quoted','awaiting_approval','rejected','expired','failed') OR tx_hash IS NOT NULL),
  CONSTRAINT swap_block_on_receipt CHECK (status NOT IN ('confirmed','reverted') OR block_number IS NOT NULL)
);
CREATE UNIQUE INDEX swap_operations_chain_tx ON swap_operations (chain_id, tx_hash) WHERE tx_hash IS NOT NULL;
CREATE INDEX swap_operations_taker_created ON swap_operations (taker, created_at DESC);
CREATE INDEX swap_operations_pending ON swap_operations (status, updated_at) WHERE status IN ('submitted','dropped');

CREATE TABLE ramp_orders (
  id                uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  idempotency_key   text        NOT NULL UNIQUE CHECK (length(idempotency_key) BETWEEN 16 AND 128),
  provider          text        NOT NULL CHECK (provider IN ('moonpay','transak')),
  direction         text        NOT NULL CHECK (direction IN ('buy','sell')),
  external_order_id text        CHECK (external_order_id IS NULL OR length(external_order_id) <= 128),
  wallet_address    text        NOT NULL CHECK (wallet_address ~ '^0x[0-9a-f]{40}$'),
  chain_id          integer     NOT NULL CHECK (chain_id IN (1, 8453, 42161, 137)),
  fiat_currency     text        NOT NULL CHECK (fiat_currency ~ '^[A-Z]{3}$'),
  fiat_amount       numeric(38,8) CHECK (fiat_amount IS NULL OR fiat_amount > 0),
  crypto_currency   text        NOT NULL CHECK (length(crypto_currency) BETWEEN 1 AND 32),
  crypto_amount     numeric(78,18) CHECK (crypto_amount IS NULL OR crypto_amount > 0),
  status            text        NOT NULL DEFAULT 'created' CHECK (status IN (
                       'created','pending','completed','failed','cancelled','expired','refunded')),
  provider_status   text        CHECK (provider_status IS NULL OR length(provider_status) <= 64),
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX ramp_orders_provider_external ON ramp_orders (provider, external_order_id) WHERE external_order_id IS NOT NULL;
CREATE INDEX ramp_orders_wallet_created ON ramp_orders (wallet_address, created_at DESC);

-- Webhooks: deduplicated by provider event id. Raw payloads are NOT stored (may contain PII);
-- only a SHA-256 for forensics and the fields we act on.
CREATE TABLE webhook_events (
  id             bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  provider       text        NOT NULL CHECK (provider IN ('moonpay','transak')),
  event_id       text        NOT NULL CHECK (length(event_id) BETWEEN 1 AND 256),
  event_type     text        NOT NULL CHECK (length(event_type) BETWEEN 1 AND 64),
  payload_sha256 bytea       NOT NULL CHECK (length(payload_sha256) = 32),
  ramp_order_id  uuid        REFERENCES ramp_orders (id),
  received_at    timestamptz NOT NULL DEFAULT now(),
  processed_at   timestamptz,
  error_code     text        CHECK (error_code IS NULL OR error_code ~ '^[A-Z0-9_]{2,64}$'),
  UNIQUE (provider, event_id)
);

CREATE TABLE admin_users (
  id             uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  email          text        NOT NULL UNIQUE CHECK (email = lower(email) AND length(email) <= 254),
  password_hash  text        NOT NULL CHECK (password_hash LIKE '$scrypt$%'),
  role           text        NOT NULL CHECK (role IN ('owner','operator','viewer')),
  totp_secret    bytea,
  disabled_at    timestamptz,
  created_at     timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE admin_sessions (
  token_sha256   bytea       PRIMARY KEY CHECK (length(token_sha256) = 32),
  admin_id       uuid        NOT NULL REFERENCES admin_users (id) ON DELETE CASCADE,
  created_at     timestamptz NOT NULL DEFAULT now(),
  expires_at     timestamptz NOT NULL,
  last_seen_at   timestamptz NOT NULL DEFAULT now(),
  revoked_at     timestamptz,
  CHECK (expires_at > created_at)
);
CREATE INDEX admin_sessions_admin ON admin_sessions (admin_id);

CREATE TABLE admin_audit_log (
  id          bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  admin_id    uuid        REFERENCES admin_users (id),
  action      text        NOT NULL CHECK (action ~ '^[a-z][a-z0-9_.]{1,63}$'),
  target      text        CHECK (target IS NULL OR length(target) <= 256),
  before      jsonb,
  after       jsonb,
  ip          inet,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE OR REPLACE FUNCTION kavrix_forbid_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'table % is append-only', TG_TABLE_NAME USING ERRCODE = 'insufficient_privilege';
END;
$$;
CREATE TRIGGER admin_audit_log_append_only BEFORE UPDATE OR DELETE ON admin_audit_log
  FOR EACH ROW EXECUTE FUNCTION kavrix_forbid_mutation();

CREATE OR REPLACE FUNCTION kavrix_swap_transition() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.status IS DISTINCT FROM OLD.status AND NOT (
    (OLD.status = 'quoted'            AND NEW.status IN ('awaiting_approval','submitted','rejected','expired','failed')) OR
    (OLD.status = 'awaiting_approval' AND NEW.status IN ('quoted','rejected','expired','failed')) OR
    (OLD.status = 'submitted'         AND NEW.status IN ('confirmed','reverted','dropped')) OR
    (OLD.status = 'dropped'           AND NEW.status IN ('confirmed','reverted'))
  ) THEN
    RAISE EXCEPTION 'illegal swap status transition % -> %', OLD.status, NEW.status USING ERRCODE = 'check_violation';
  END IF;
  -- Economic terms are immutable once quoted; only lifecycle fields may change.
  IF (NEW.chain_id, NEW.taker, NEW.sell_token, NEW.buy_token, NEW.sell_amount, NEW.min_buy_amount,
      NEW.platform_fee_bps, NEW.idempotency_key)
     IS DISTINCT FROM
     (OLD.chain_id, OLD.taker, OLD.sell_token, OLD.buy_token, OLD.sell_amount, OLD.min_buy_amount,
      OLD.platform_fee_bps, OLD.idempotency_key) THEN
    RAISE EXCEPTION 'swap terms are immutable' USING ERRCODE = 'check_violation';
  END IF;
  IF OLD.tx_hash IS NOT NULL AND NEW.tx_hash IS DISTINCT FROM OLD.tx_hash THEN
    RAISE EXCEPTION 'tx_hash cannot change once set' USING ERRCODE = 'check_violation';
  END IF;
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;
CREATE TRIGGER swap_operations_transition BEFORE UPDATE ON swap_operations
  FOR EACH ROW EXECUTE FUNCTION kavrix_swap_transition();

CREATE OR REPLACE FUNCTION kavrix_ramp_transition() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.status IS DISTINCT FROM OLD.status AND NOT (
    (OLD.status = 'created'   AND NEW.status IN ('pending','completed','failed','cancelled','expired')) OR
    (OLD.status = 'pending'   AND NEW.status IN ('completed','failed','cancelled','refunded')) OR
    (OLD.status = 'completed' AND NEW.status = 'refunded')
  ) THEN
    RAISE EXCEPTION 'illegal ramp status transition % -> %', OLD.status, NEW.status USING ERRCODE = 'check_violation';
  END IF;
  IF OLD.external_order_id IS NOT NULL AND NEW.external_order_id IS DISTINCT FROM OLD.external_order_id THEN
    RAISE EXCEPTION 'external_order_id cannot change once set' USING ERRCODE = 'check_violation';
  END IF;
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;
CREATE TRIGGER ramp_orders_transition BEFORE UPDATE ON ramp_orders
  FOR EACH ROW EXECUTE FUNCTION kavrix_ramp_transition();
