import { after, before, describe, it } from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import type { DatabaseHandle } from "../src/client.ts";
import { PgSwapRepository, type NewSwap } from "../src/swaps.ts";
import { NATIVE, ROUTER, TAKER, USDC_BASE, freshDatabase, hash } from "./harness.ts";

let n = 0;
const swap = (over: Partial<NewSwap> = {}): NewSwap => ({
  idempotencyKey: `it-swap-${Date.now()}-${n++}-padding`,
  provider: "kyberswap", chainId: 8453, taker: TAKER, sellToken: NATIVE, buyToken: USDC_BASE,
  sellAmount: 10n ** 15n, quotedBuyAmount: 3_500_000n, minBuyAmount: 3_465_000n, slippageBps: 100,
  platformFeeBps: 25, platformFeeAmount: 2_500_000_000_000n, providerFeeAmount: 0n, networkFeeEstimate: 10n ** 12n,
  quoteExpiresAt: new Date(Date.now() + 30_000), txTo: ROUTER,
  txDataSha256: createHash("sha256").update(String(n)).digest("hex"), txValue: 10n ** 15n,
  ...over,
});

describe("PgSwapRepository on PostgreSQL", () => {
  let db: DatabaseHandle;
  let repo: PgSwapRepository;
  before(async () => {
    db = await freshDatabase();
    repo = new PgSwapRepository(db.sql);
  });
  after(async () => {
    await db.close();
  });

  it("creates once per idempotency key and round-trips uint256 values", async () => {
    const big = (1n << 255n) + 7n;
    const input = swap({ sellAmount: big, quotedBuyAmount: big, minBuyAmount: big - 1n });
    const a = await repo.create(input);
    const b = await repo.create(input);
    assert.equal(a.created, true);
    assert.equal(b.created, false);
    assert.equal(b.record.id, a.record.id);
    assert.equal((await repo.get(a.record.id))?.sellAmount, big);
  });

  it("submits idempotently and detects a different hash", async () => {
    const { record } = await repo.create(swap());
    assert.equal(await repo.submit(record.id, hash(1), new Date()), "submitted");
    assert.equal(await repo.submit(record.id, hash(1), new Date()), "already_submitted");
    assert.equal(await repo.submit(record.id, hash(2), new Date()), "hash_conflict");
    assert.equal(await repo.reject(record.id), "wrong_state");
    assert.equal(await repo.submit("00000000-0000-4000-8000-000000000000", hash(3), new Date()), "not_found");
  });

  it("enforces the status machine and immutable terms in the database itself", async () => {
    const { record } = await repo.create(swap());
    await assert.rejects(db.sql`UPDATE swap_operations SET status = 'confirmed', tx_hash = ${hash(9)}, block_number = 1, submitted_at = now() WHERE id = ${record.id}`, /illegal swap status transition/);
    await assert.rejects(db.sql`UPDATE swap_operations SET sell_amount = 1 WHERE id = ${record.id}`, /immutable/);
    await assert.rejects(db.sql`UPDATE swap_operations SET tx_to = ${USDC_BASE} WHERE id = ${record.id}`, /immutable/);
    await repo.submit(record.id, hash(10), new Date());
    await assert.rejects(db.sql`UPDATE swap_operations SET tx_hash = ${hash(11)} WHERE id = ${record.id}`, /cannot change/);
  });

  it("leases due rows to exactly one worker at a time", async () => {
    const ids: string[] = [];
    for (let i = 0; i < 10; i++) {
      const { record } = await repo.create(swap());
      await repo.submit(record.id, hash(100 + i), new Date(Date.now() - 1000));
      ids.push(record.id);
    }
    const [a, b] = await Promise.all([repo.claimDue(10, 30_000), repo.claimDue(10, 30_000)]);
    const claimed = [...a, ...b].map((r) => r.id).filter((id) => ids.includes(id));
    assert.equal(new Set(claimed).size, claimed.length, "no row claimed twice");
    assert.equal(claimed.length, 10, "every due row claimed");
    assert.deepEqual(await repo.claimDue(10, 30_000), [], "leased rows are not due again");
  });

  it("applies chain results and stops tracking final swaps", async () => {
    const { record } = await repo.create(swap());
    await repo.submit(record.id, hash(200), new Date());
    await repo.applyCheck(record.id, { status: "confirmed", blockNumber: 123n, confirmations: 5, actualBuyAmount: 3_480_000n, nextCheckAt: null });
    const r = await repo.get(record.id);
    assert.equal(r?.status, "confirmed");
    assert.equal(r?.blockNumber, 123n);
    assert.equal(r?.actualBuyAmount, 3_480_000n);
    await assert.rejects(repo.applyCheck(record.id, { status: "reverted", nextCheckAt: null }), /illegal swap status transition/);
  });

  it("lists only on-chain swaps per wallet and expires stale quotes", async () => {
    const other = "0x1111111111111111111111111111111111111111" as const;
    const { record: unsent } = await repo.create(swap({ taker: other, quoteExpiresAt: new Date(Date.now() - 60 * 60_000) }));
    const { record: sent } = await repo.create(swap({ taker: other }));
    await repo.submit(sent.id, hash(300), new Date());
    assert.deepEqual((await repo.listByWallet(other, 10)).map((r) => r.id), [sent.id]);
    assert.ok((await repo.expireQuoted(new Date(Date.now() - 15 * 60_000))) >= 1);
    assert.equal((await repo.get(unsent.id))?.status, "expired");
  });
});
