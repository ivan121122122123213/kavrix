import { after, before, describe, it } from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import type { DatabaseHandle } from "../src/client.ts";
import { PgRampRepository, readSetting, writeSetting, type NewRampOrder, type ProviderEvent } from "../src/ramp.ts";
import { PgAdminRepository } from "../src/admin.ts";
import { PgSwapRepository } from "../src/swaps.ts";
import { NATIVE, ROUTER, TAKER, USDC_BASE, freshDatabase, hash } from "./harness.ts";

let k = 0;
const order = (over: Partial<NewRampOrder> = {}): NewRampOrder => ({
  idempotencyKey: `it-ramp-${Date.now()}-${k++}-padding`, provider: "moonpay", direction: "buy", walletAddress: TAKER, chainId: 8453,
  tokenAddress: USDC_BASE, cryptoCurrency: "USDC", providerCurrency: "usdc_base", fiatCurrency: "USD", fiatAmount: "100", cryptoAmount: null,
  ...over,
});
const event = (orderId: string | null, status: ProviderEvent["status"], eventId: string, externalOrderId = "mp-1"): ProviderEvent => ({
  provider: "moonpay", eventId, eventType: "transaction_updated", payloadSha256: createHash("sha256").update(eventId).digest(),
  orderId, externalOrderId, status, providerStatus: status,
});

describe("PgRampRepository on PostgreSQL", () => {
  let db: DatabaseHandle;
  let repo: PgRampRepository;
  before(async () => {
    db = await freshDatabase();
    repo = new PgRampRepository(db.sql);
  });
  after(async () => {
    await db.close();
  });

  it("applies each provider event exactly once and never moves backwards", async () => {
    const { record } = await repo.create(order());
    assert.equal(await repo.applyEvent(event(record.id, "pending", "e1")), "applied");
    assert.equal(await repo.applyEvent(event(record.id, "pending", "e1")), "duplicate");
    assert.equal(await repo.applyEvent(event(record.id, "completed", "e2")), "applied");
    assert.equal(await repo.applyEvent(event(record.id, "pending", "e3")), "stale");
    assert.equal(await repo.applyEvent(event(record.id, "completed", "e4", "mp-other")), "mismatch");
    const r = await repo.get(record.id);
    assert.equal(r?.status, "completed");
    assert.equal(r?.externalOrderId, "mp-1");
    const [events] = await db.sql<{ n: string }[]>`SELECT count(*)::text AS n FROM webhook_events WHERE ramp_order_id = ${record.id}`;
    assert.equal(events?.n, "4");
  });

  it("records events for unknown orders without failing", async () => {
    assert.equal(await repo.applyEvent(event("00000000-0000-4000-8000-000000000000", "pending", "e-unknown")), "unknown_order");
  });

  it("lists only provider-acknowledged orders", async () => {
    const other = "0x2222222222222222222222222222222222222222" as const;
    await repo.create(order({ walletAddress: other }));
    const { record } = await repo.create(order({ walletAddress: other }));
    await repo.applyEvent(event(record.id, "pending", "e-list", "mp-list"));
    assert.deepEqual((await repo.listByWallet(other, 10)).map((r) => r.id), [record.id]);
  });

  it("stores JSON settings", async () => {
    await writeSetting(db.sql, "transak.access_token", { accessToken: "t", expiresAt: 1, previous: null });
    assert.deepEqual(await readSetting(db.sql, "transak.access_token"), { accessToken: "t", expiresAt: 1, previous: null });
  });
});

describe("PgAdminRepository on PostgreSQL", () => {
  let db: DatabaseHandle;
  let repo: PgAdminRepository;
  before(async () => {
    db = await freshDatabase();
    repo = new PgAdminRepository(db.sql);
  });
  after(async () => {
    await db.close();
  });

  it("accepts each TOTP step once and locks after repeated failures", async () => {
    const id = await repo.createAdmin({ email: "Ops@Kavrix.Example", passwordHash: "$scrypt$N=32768,r=8,p=1$a$b", role: "owner" });
    assert.equal((await repo.findAdminByEmail("ops@kavrix.example"))?.id, id);
    assert.equal(await repo.acceptLogin(id, 100), true);
    assert.equal(await repo.acceptLogin(id, 100), false);
    assert.equal(await repo.acceptLogin(id, 99), false);
    for (let i = 0; i < 5; i++) await repo.recordFailedLogin(id, 5, 60_000);
    const u = await repo.findAdminByEmail("ops@kavrix.example");
    assert.ok(u?.lockedUntil !== null && (u?.lockedUntil?.getTime() ?? 0) > Date.now());
  });

  it("expires idle sessions and revokes them", async () => {
    const id = await repo.createAdmin({ email: "viewer@kavrix.example", passwordHash: "$scrypt$x", role: "viewer" });
    const h = createHash("sha256").update("session").digest();
    await repo.createSession({ tokenHash: h, adminId: id, expiresAt: new Date(Date.now() + 60_000), ip: "203.0.113.5", userAgent: "it" });
    assert.equal((await repo.touchSession(h, 60_000))?.role, "viewer");
    await db.sql`UPDATE admin_sessions SET last_seen_at = now() - interval '2 hours' WHERE token_sha256 = ${h}`;
    assert.equal(await repo.touchSession(h, 60_000), null, "idle");
    await db.sql`UPDATE admin_sessions SET last_seen_at = now() WHERE token_sha256 = ${h}`;
    await repo.revokeSession(h);
    assert.equal(await repo.touchSession(h, 60_000), null, "revoked");
  });

  it("versions settings and audits changes atomically", async () => {
    const [s] = await repo.listSettings(["swap.enabled"]);
    assert.ok(s);
    assert.equal(await repo.updateSetting("swap.enabled", false, s.version, { adminId: null, ip: "203.0.113.5" }), "updated");
    assert.equal(await repo.updateSetting("swap.enabled", true, s.version, { adminId: null, ip: null }), "version_conflict");
    assert.equal(await repo.updateSetting("no.such_key", true, 1, { adminId: null, ip: null }), "not_found");
    const audit = await repo.listAudit(10);
    assert.ok(audit.some((a) => a.action === "setting.updated" && a.target === "swap.enabled" && a.ip === "203.0.113.5"));
  });

  it("adds tokens disabled and audits enable/disable", async () => {
    const t = { chainId: 8453 as const, address: "0x3333333333333333333333333333333333333333" as const, symbol: "TKN", name: "Token", decimals: 18 };
    assert.equal(await repo.addToken(t, { adminId: null, ip: null }), "added");
    assert.equal(await repo.addToken(t, { adminId: null, ip: null }), "exists");
    assert.equal((await repo.listAllTokens()).find((x) => x.address === t.address)?.enabled, false);
    assert.equal((await repo.setTokenEnabled(8453, t.address, true, { adminId: null, ip: null }))?.enabled, true);
    assert.equal(await repo.setTokenEnabled(8453, "0x4444444444444444444444444444444444444444", true, { adminId: null, ip: null }), null);
  });

  it("computes statistics from confirmed swaps only", async () => {
    const swaps = new PgSwapRepository(db.sql);
    const { record } = await swaps.create({
      idempotencyKey: `it-stats-${Date.now()}-padding`, provider: "kyberswap", chainId: 8453, taker: TAKER, sellToken: NATIVE, buyToken: USDC_BASE,
      sellAmount: 10n ** 15n, quotedBuyAmount: 3_500_000n, minBuyAmount: 3_465_000n, slippageBps: 100, platformFeeBps: 25,
      platformFeeAmount: 2_500_000_000_000n, providerFeeAmount: 0n, networkFeeEstimate: null, quoteExpiresAt: new Date(Date.now() + 30_000),
      txTo: ROUTER, txDataSha256: "ab".repeat(32), txValue: 10n ** 15n,
    });
    await swaps.submit(record.id, hash(900), new Date());
    await swaps.applyCheck(record.id, { status: "confirmed", blockNumber: 1n, confirmations: 5, nextCheckAt: null });
    const stats = await repo.stats(30);
    assert.deepEqual(stats.confirmedVolume.find((v) => v.chainId === 8453 && v.token === NATIVE)?.amount, 10n ** 15n);
    assert.deepEqual(stats.feeRevenue.find((v) => v.chainId === 8453)?.amount, 2_500_000_000_000n);
    assert.equal(stats.dailyConfirmed.length, 1);
    assert.equal(await repo.trackerBacklog(), 0);
  });
});

describe("token ownership between the sync and operators", () => {
  let db: DatabaseHandle;
  before(async () => {
    db = await freshDatabase();
  });
  after(async () => {
    await db.close();
  });

  it("an operator decision is never reversed by the sync", async () => {
    const { PgTokenSyncRepository } = await import("../src/tokens.ts");
    const sync = new PgTokenSyncRepository(db.sql);
    const admin = new PgAdminRepository(db.sql);
    const token = "0x5555555555555555555555555555555555555555" as const;
    const row = { chainId: 1 as const, address: token, symbol: "MEME", name: "Meme", decimals: 18, logoUrl: null, risk: "high" as const, rank: null, sources: ["kyberswap"], note: "only KyberSwap lists it" };
    await sync.upsert([{ ...row, review: "pending", enabled: false }]);
    await admin.setTokenEnabled(1, token, true, { adminId: null, ip: null });
    assert.equal(await sync.upsert([{ ...row, review: "pending", enabled: false }]), 0, "sync skips operator-owned rows");
    const [t] = await db.sql<{ enabled: boolean; review: string }[]>`SELECT enabled, review FROM tokens WHERE address = ${token}`;
    assert.deepEqual(t, { enabled: true, review: "manual" });
    assert.equal(await sync.retire(1, new Set(), "x"), 0, "manual rows are never retired");
  });
});
