import { after, before, describe, it } from "node:test";
import assert from "node:assert/strict";
import type { DatabaseHandle } from "../src/client.ts";
import { loadMigrations, migrate } from "../src/migrate.ts";
import { freshDatabase } from "./harness.ts";

describe("migrations on PostgreSQL", () => {
  let db: DatabaseHandle;
  before(async () => {
    db = await freshDatabase();
  });
  after(async () => {
    await db.close();
  });

  it("are recorded and re-running applies nothing", async () => {
    const files = await loadMigrations();
    const rows = await db.sql<{ name: string }[]>`SELECT name FROM kavrix_migrations ORDER BY name`;
    assert.deepEqual(rows.map((r) => r.name), files.map((f) => f.name));
    const again = await migrate(db.sql, files);
    assert.deepEqual(again.applied, []);
  });

  it("refuse to run when an applied migration was edited", async () => {
    const files = await loadMigrations();
    const tampered = files.map((f, i) => (i === 0 ? { ...f, sha256: "0".repeat(64) } : f));
    await assert.rejects(migrate(db.sql, tampered), /was modified/);
  });

  it("seed the launch token list and runtime settings", async () => {
    const [tokens] = await db.sql<{ n: string }[]>`SELECT count(*)::text AS n FROM tokens WHERE enabled`;
    assert.equal(tokens?.n, "12");
    const settings = await db.sql<{ key: string }[]>`SELECT key FROM settings ORDER BY key`;
    for (const k of ["ramp.buy_limits", "ramp.enabled", "swap.enabled", "swap.fee_bps_by_chain", "swap.quote_rate_per_minute", "transak.access_token"]) {
      assert.ok(settings.some((s) => s.key === k), k);
    }
  });

  it("keep the admin audit log append-only", async () => {
    await db.sql`INSERT INTO admin_audit_log (action) VALUES ('test.entry')`;
    await assert.rejects(db.sql`UPDATE admin_audit_log SET action = 'test.changed'`, /append-only/);
    await assert.rejects(db.sql`DELETE FROM admin_audit_log`, /append-only/);
  });
});
