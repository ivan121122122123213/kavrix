import { createDatabase, type DatabaseHandle } from "../src/client.ts";
import { loadMigrations, migrate } from "../src/migrate.ts";

/**
 * Recreates the `public` schema of a dedicated test database and applies every migration.
 * Refuses to run against anything that does not look like a throwaway test database.
 */
export async function freshDatabase(): Promise<DatabaseHandle> {
  const url = process.env["DATABASE_URL_TEST"];
  if (url === undefined || url === "") throw new Error("DATABASE_URL_TEST is not set (see docs/TESTING.md)");
  if (process.env["NODE_ENV"] === "production") throw new Error("refusing to run integration tests with NODE_ENV=production");
  const dbName = decodeURIComponent(new URL(url).pathname.replace(/^\//, ""));
  if (!/test/i.test(dbName)) throw new Error(`refusing to wipe database "${dbName}": its name must contain "test"`);

  const handle = createDatabase({ url, maxConnections: 6 });
  await handle.sql.unsafe("DROP SCHEMA IF EXISTS public CASCADE; CREATE SCHEMA public;").simple();
  await migrate(handle.sql, await loadMigrations());
  return handle;
}

export const TAKER = "0x70a9f34f9b34c64957b9c401a97bfed35b95049e" as const;
export const ROUTER = "0x6131b5fae19ea4f9d964eac0408e4408b66337b5" as const;
export const USDC_BASE = "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913" as const;
export const NATIVE = "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee" as const;
export const hash = (n: number) => `0x${n.toString(16).padStart(64, "0")}` as `0x${string}`;
