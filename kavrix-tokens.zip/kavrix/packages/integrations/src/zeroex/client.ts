import {
  NATIVE_TOKEN_ADDRESS,
  assertBps,
  bpsToPpm,
  getChain,
  parseBaseUnits,
  sameAddress,
  type Address,
  type SupportedChainId,
} from "@kavrix/shared";
import type { z } from "zod";
import { ProviderError } from "../errors.ts";
import { MAX_PLATFORM_FEE_BPS } from "../swap/types.ts";
import { errorForStatus, requestJson, type HttpOptions } from "../http.ts";
import {
  zeroExNoLiquiditySchema,
  zeroExPriceSchema,
  zeroExQuoteSchema,
  type ZeroExPrice,
  type ZeroExQuote,
} from "./schema.ts";

export const ZEROEX_BASE_URL = "https://api.0x.org";

export interface ZeroExFeeConfig {
  readonly recipient: Address;
  readonly bps: number;
}

export interface ZeroExSwapParams {
  readonly chainId: SupportedChainId;
  readonly sellToken: Address;
  readonly buyToken: Address;
  readonly sellAmount: bigint;
  /** Required for firm quotes; optional for indicative prices. */
  readonly taker?: Address | undefined;
  readonly slippageBps: number;
  /** Platform fee, charged in the buy token so the user sees it as a reduced output. */
  readonly fee?: ZeroExFeeConfig;
}

export type ZeroExResult<T> = { readonly liquidityAvailable: true; readonly data: T } | { readonly liquidityAvailable: false };

export interface ZeroExClientOptions extends HttpOptions {
  readonly apiKey: string;
  readonly baseUrl?: string;
}

export const MAX_SLIPPAGE_BPS = 5_000;

export class ZeroExClient {
  readonly #apiKey: string;
  readonly #baseUrl: string;
  readonly #http: HttpOptions;

  constructor(options: ZeroExClientOptions) {
    if (options.apiKey.trim().length === 0) throw new TypeError("0x API key is required");
    this.#apiKey = options.apiKey;
    this.#baseUrl = options.baseUrl ?? ZEROEX_BASE_URL;
    this.#http = { fetch: options.fetch, timeoutMs: options.timeoutMs, maxResponseBytes: options.maxResponseBytes };
  }

  /** Indicative price (no calldata). */
  async getPrice(params: ZeroExSwapParams): Promise<ZeroExResult<ZeroExPrice>> {
    const result = await this.#get("/swap/allowance-holder/price", params, zeroExPriceSchema);
    if (result.liquidityAvailable) assertResponseMatchesRequest(result.data, params);
    return result;
  }

  /** Firm quote with calldata. The response is checked against the request before it is returned. */
  async getQuote(params: ZeroExSwapParams): Promise<ZeroExResult<ZeroExQuote>> {
    if (params.taker === undefined) throw new TypeError("taker is required for a firm 0x quote");
    const result = await this.#get("/swap/allowance-holder/quote", params, zeroExQuoteSchema);
    if (result.liquidityAvailable) assertQuoteSafe(result.data, params);
    return result;
  }

  async #get<S extends z.ZodType>(
    path: string,
    params: ZeroExSwapParams,
    schema: S,
  ): Promise<ZeroExResult<z.infer<S>>> {
    const url = new URL(path, this.#baseUrl);
    for (const [key, value] of Object.entries(buildQuery(params))) url.searchParams.set(key, value);

    const { status, body } = await requestJson(
      "0x",
      url,
      { method: "GET", headers: { "0x-api-key": this.#apiKey, "0x-version": "v2", accept: "application/json" } },
      this.#http,
    );
    if (status < 200 || status >= 300) throw errorForStatus("0x", status, body);

    if (zeroExNoLiquiditySchema.safeParse(body).success) return { liquidityAvailable: false };
    const parsed = schema.safeParse(body);
    if (!parsed.success) {
      throw new ProviderError("0x", "PROVIDER_BAD_RESPONSE", "0x response did not match the expected schema", {
        httpStatus: status,
      });
    }
    return { liquidityAvailable: true, data: parsed.data as z.infer<S> };
  }
}

export function buildQuery(params: ZeroExSwapParams): Record<string, string> {
  getChain(params.chainId);
  if (params.sellAmount <= 0n) throw new RangeError("sellAmount must be positive");
  if (sameAddress(params.sellToken, params.buyToken)) throw new RangeError("sellToken and buyToken must differ");
  assertBps(params.slippageBps, MAX_SLIPPAGE_BPS);

  const query: Record<string, string> = {
    chainId: String(params.chainId),
    sellToken: params.sellToken,
    buyToken: params.buyToken,
    sellAmount: params.sellAmount.toString(),
    slippagePpm: String(bpsToPpm(params.slippageBps)),
  };
  if (params.taker !== undefined) query["taker"] = params.taker;
  if (params.fee !== undefined && params.fee.bps > 0) {
    assertBps(params.fee.bps, MAX_PLATFORM_FEE_BPS);
    query["swapFeeRecipient"] = params.fee.recipient;
    query["swapFeeBps"] = String(params.fee.bps);
    query["swapFeeToken"] = params.buyToken;
  }
  return query;
}

function unsafe(message: string): ProviderError {
  return new ProviderError("0x", "QUOTE_UNSAFE", message);
}

function assertResponseMatchesRequest(res: ZeroExPrice | ZeroExQuote, params: ZeroExSwapParams): void {
  if (!sameAddress(res.sellToken, params.sellToken) || !sameAddress(res.buyToken, params.buyToken)) {
    throw unsafe("0x returned a different token pair than requested");
  }
  if (parseBaseUnits(res.sellAmount) !== params.sellAmount) {
    throw unsafe("0x returned a different sell amount than requested");
  }
  const buy = parseBaseUnits(res.buyAmount);
  const min = parseBaseUnits(res.minBuyAmount);
  if (buy === 0n || min === 0n || min > buy) throw unsafe("0x returned inconsistent output amounts");

  const holder = getChain(params.chainId).zeroExAllowanceHolder;
  if (res.issues.allowance !== null && !sameAddress(res.issues.allowance.spender, holder)) {
    throw unsafe("0x requested an allowance for an unexpected spender");
  }
  if (res.allowanceTarget != null && !sameAddress(res.allowanceTarget, holder)) {
    throw unsafe("0x returned an unexpected allowance target");
  }

  const integratorFee = res.fees.integratorFee;
  if (params.fee !== undefined && params.fee.bps > 0) {
    if (integratorFee == null || !sameAddress(integratorFee.token, params.buyToken)) {
      throw unsafe("0x did not apply the platform fee as requested");
    }
  } else if (integratorFee != null && parseBaseUnits(integratorFee.amount) > 0n) {
    throw unsafe("0x applied an integrator fee that was not requested");
  }
}

/**
 * Fail-closed checks before calldata reaches a wallet: the transaction must target the
 * documented AllowanceHolder on this chain and move exactly the requested value.
 */
export function assertQuoteSafe(quote: ZeroExQuote, params: ZeroExSwapParams): void {
  assertResponseMatchesRequest(quote, params);
  const holder = getChain(params.chainId).zeroExAllowanceHolder;
  if (!sameAddress(quote.transaction.to, holder)) {
    throw unsafe("0x transaction targets an unexpected contract");
  }
  const value = parseBaseUnits(quote.transaction.value);
  const sellsNative = sameAddress(params.sellToken, NATIVE_TOKEN_ADDRESS);
  if (sellsNative ? value !== params.sellAmount : value !== 0n) {
    throw unsafe("0x transaction value does not match the sell amount");
  }
  if (quote.transaction.data.length <= 10) throw unsafe("0x transaction has no calldata");
}
