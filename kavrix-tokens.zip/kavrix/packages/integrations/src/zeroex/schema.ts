import { z } from "zod";

const address = z.string().regex(/^0x[0-9a-fA-F]{40}$/);
const uintString = z.string().regex(/^\d+$/);
const hexData = z.string().regex(/^0x([0-9a-fA-F]{2})*$/);

const feeEntry = z
  .object({ amount: uintString, token: address, type: z.string() })
  .nullable()
  .optional();

const fees = z.object({
  integratorFee: feeEntry,
  integratorFees: z.array(z.object({ amount: uintString, token: address, type: z.string() })).nullable().optional(),
  zeroExFee: feeEntry,
  gasFee: feeEntry,
});

const issues = z.object({
  allowance: z.object({ actual: uintString, spender: address }).nullable(),
  balance: z.object({ token: address, actual: uintString, expected: uintString }).nullable(),
  simulationIncomplete: z.boolean(),
  invalidSourcesPassed: z.array(z.string()),
});

// Display-only fields are parsed leniently; amounts, tokens, spender and calldata are strict.
const route = z.object({
  fills: z.array(
    z.object({ from: address, to: address, source: z.string(), proportionBps: z.union([uintString, z.number()]) }),
  ),
  tokens: z.array(z.object({ address, symbol: z.string() })),
});

const taxBps = uintString.nullable().optional();
const tokenTaxes = z.object({ buyTaxBps: taxBps, sellTaxBps: taxBps, transferTaxBps: taxBps });

const common = {
  liquidityAvailable: z.literal(true),
  blockNumber: uintString.nullable().optional(),
  buyAmount: uintString,
  buyToken: address,
  sellAmount: uintString,
  sellToken: address,
  minBuyAmount: uintString,
  fees,
  issues,
  route: route.optional(),
  tokenMetadata: z.object({ buyToken: tokenTaxes, sellToken: tokenTaxes }).optional(),
  totalNetworkFee: uintString.nullable().optional(),
  allowanceTarget: address.nullable().optional(),
  zid: z.string().optional(),
};

export const zeroExNoLiquiditySchema = z.object({
  liquidityAvailable: z.literal(false),
  zid: z.string().optional(),
});

export const zeroExPriceSchema = z.object({
  ...common,
  gas: uintString.nullable().optional(),
  gasPrice: uintString.nullable().optional(),
});

export const zeroExQuoteSchema = z.object({
  ...common,
  transaction: z.object({
    to: address,
    data: hexData,
    gas: uintString.nullable(),
    gasPrice: uintString,
    value: uintString,
  }),
});

export type ZeroExPrice = z.infer<typeof zeroExPriceSchema>;
export type ZeroExQuote = z.infer<typeof zeroExQuoteSchema>;
