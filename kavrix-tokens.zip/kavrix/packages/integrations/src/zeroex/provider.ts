import { NATIVE_TOKEN_ADDRESS, getChain, parseBaseUnits, sameAddress } from "@kavrix/shared";
import type { FirmQuote, IndicativeQuote, PlatformFeeConfig, QuoteOutcome, SwapProvider, SwapRequest } from "../swap/types.ts";
import { MAX_SLIPPAGE_BPS, ZeroExClient, type ZeroExSwapParams } from "./client.ts";
import type { ZeroExPrice, ZeroExQuote } from "./schema.ts";

/** Adapts the 0x AllowanceHolder client to the provider-neutral interface. */
export class ZeroExProvider implements SwapProvider {
  readonly id = "0x" as const;
  readonly maxSlippageBps = MAX_SLIPPAGE_BPS;
  readonly #client: ZeroExClient;

  constructor(client: ZeroExClient) {
    this.#client = client;
  }

  async quote(request: SwapRequest, fee: PlatformFeeConfig | undefined): Promise<QuoteOutcome> {
    const params: ZeroExSwapParams = {
      chainId: request.chainId,
      sellToken: request.sellToken,
      buyToken: request.buyToken,
      sellAmount: request.sellAmount,
      slippageBps: request.slippageBps,
      taker: request.taker,
      ...(fee === undefined ? {} : { fee }),
    };
    if (request.taker === undefined) {
      const price = await this.#client.getPrice(params);
      return price.liquidityAvailable ? { kind: "indicative", quote: normalize(price.data, request, fee) } : { kind: "no_route" };
    }
    const quote = await this.#client.getQuote(params);
    if (!quote.liquidityAvailable) return { kind: "no_route" };
    const base = normalize(quote.data, request, fee);
    const sellsNative = sameAddress(request.sellToken, NATIVE_TOKEN_ADDRESS);
    const holder = getChain(request.chainId).zeroExAllowanceHolder;
    const firm: FirmQuote = {
      ...base,
      taker: request.taker,
      spender: sellsNative ? null : holder,
      tx: { to: holder, data: quote.data.transaction.data as `0x${string}`, value: parseBaseUnits(quote.data.transaction.value) },
    };
    return { kind: "firm", quote: firm };
  }
}

function normalize(res: ZeroExPrice | ZeroExQuote, request: SwapRequest, fee: PlatformFeeConfig | undefined): IndicativeQuote {
  const totalFills = res.route?.fills.reduce((s, f) => s + Number(f.proportionBps), 0) ?? 0;
  return {
    provider: "0x",
    chainId: request.chainId,
    sellToken: request.sellToken,
    buyToken: request.buyToken,
    sellAmount: request.sellAmount,
    buyAmount: parseBaseUnits(res.buyAmount),
    minBuyAmount: parseBaseUnits(res.minBuyAmount),
    platformFee: {
      bps: fee?.bps ?? 0,
      amount: res.fees.integratorFee == null ? 0n : parseBaseUnits(res.fees.integratorFee.amount),
      token: "buy",
    },
    providerFee: res.fees.zeroExFee == null ? 0n : parseBaseUnits(res.fees.zeroExFee.amount),
    networkFeeWei: res.totalNetworkFee == null ? null : parseBaseUnits(res.totalNetworkFee),
    route: totalFills > 0 ? (res.route?.fills ?? []).map((f) => ({ source: f.source, proportionBps: Number(f.proportionBps) })) : [],
    // 0x does not return USD values; the interface then shows no price-impact estimate rather than a guess.
    valueUsd: null,
  };
}
