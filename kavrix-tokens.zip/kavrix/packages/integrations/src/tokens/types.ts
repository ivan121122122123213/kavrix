import type { Address, SupportedChainId } from "@kavrix/shared";

export type TokenSourceId = "uniswap" | "coingecko" | "kyberswap";

/** One token as reported by one source. Addresses are lower-case. */
export interface SourceToken {
  readonly source: TokenSourceId;
  readonly chainId: SupportedChainId;
  readonly address: Address;
  readonly symbol: string;
  readonly name: string;
  readonly decimals: number;
  readonly logoUrl: string | null;
  /** KyberSwap only. */
  readonly cmcRank?: number | null;
  readonly marketCap?: number | null;
  readonly isHoneypot?: boolean | null;
  readonly isFeeOnTransfer?: boolean | null;
}

export type Decision =
  | { readonly kind: "auto"; readonly reasons: readonly string[] }
  | { readonly kind: "pending"; readonly reasons: readonly string[] }
  | { readonly kind: "reject"; readonly reasons: readonly string[] };

export interface Candidate {
  readonly chainId: SupportedChainId;
  readonly address: Address;
  readonly symbol: string;
  readonly name: string;
  readonly decimals: number;
  readonly logoUrl: string | null;
  readonly sources: readonly TokenSourceId[];
  readonly risk: "standard" | "high";
  /** Lower is more prominent; null = unranked. */
  readonly rank: number | null;
  readonly decision: Decision;
}
