import { z } from "zod";
import { isSupportedChainId, type Address } from "@kavrix/shared";
import { ProviderError } from "../errors.ts";
import { errorForStatus, requestJson, type HttpOptions } from "../http.ts";
import type { RateGate } from "../swap/gate.ts";
import type { SourceToken, TokenSourceId } from "./types.ts";

const ADDRESS = /^0x[0-9a-fA-F]{40}$/;

const listToken = z.object({
  chainId: z.number(),
  address: z.string().regex(ADDRESS),
  symbol: z.string().max(32),
  name: z.string().max(128),
  decimals: z.number().int(),
  logoURI: z.string().max(1000).optional(),
});

/**
 * Parses a Token Lists document (Uniswap / CoinGecko format). Only tokens on Kavrix's networks are kept;
 * malformed entries are skipped one by one so a single bad row never discards the list.
 */
export function parseTokenList(body: unknown, source: Exclude<TokenSourceId, "kyberswap">): SourceToken[] {
  const tokens = typeof body === "object" && body !== null ? (body as { tokens?: unknown }).tokens : undefined;
  if (!Array.isArray(tokens)) throw new ProviderError("kyberswap", "PROVIDER_BAD_RESPONSE", `${source} token list has no tokens array`);
  const out: SourceToken[] = [];
  for (const raw of tokens) {
    const t = listToken.safeParse(raw);
    if (!t.success || !isSupportedChainId(t.data.chainId)) continue;
    out.push({
      source,
      chainId: t.data.chainId,
      address: t.data.address.toLowerCase() as Address,
      symbol: t.data.symbol.trim(),
      name: t.data.name.trim(),
      decimals: t.data.decimals,
      logoUrl: t.data.logoURI !== undefined && t.data.logoURI.startsWith("https://") ? t.data.logoURI : null,
    });
  }
  return out;
}

const kyberToken = z.object({
  address: z.string().regex(ADDRESS),
  symbol: z.string().max(32),
  name: z.string().max(128),
  decimals: z.number().int(),
  logoURL: z.string().max(1000).nullable().optional(),
  cmcRank: z.number().nullable().optional(),
  marketCap: z.number().nullable().optional(),
  isWhitelisted: z.boolean().nullable().optional(),
  isHoneypot: z.boolean().nullable().optional(),
  isFOT: z.boolean().nullable().optional(),
});

/** The token array, wherever the envelope puts it (`data.tokens`, `data` or `tokens`). */
function tokenArray(body: unknown): unknown[] | undefined {
  if (typeof body !== "object" || body === null) return undefined;
  const b = body as { data?: unknown; tokens?: unknown };
  if (Array.isArray(b.tokens)) return b.tokens;
  if (Array.isArray(b.data)) return b.data;
  if (typeof b.data === "object" && b.data !== null && Array.isArray((b.data as { tokens?: unknown }).tokens)) {
    return (b.data as { tokens: unknown[] }).tokens;
  }
  return undefined;
}

export function parseKyberTokens(body: unknown, chainId: number): SourceToken[] {
  const arr = tokenArray(body);
  if (arr === undefined) throw new ProviderError("kyberswap", "PROVIDER_BAD_RESPONSE", "KyberSwap token list has an unknown shape");
  if (!isSupportedChainId(chainId)) return [];
  const out: SourceToken[] = [];
  for (const raw of arr) {
    const t = kyberToken.safeParse(raw);
    // Only tokens KyberSwap explicitly whitelists count as a KyberSwap endorsement.
    if (!t.success || t.data.isWhitelisted !== true) continue;
    out.push({
      source: "kyberswap",
      chainId,
      address: t.data.address.toLowerCase() as Address,
      symbol: t.data.symbol.trim(),
      name: t.data.name.trim(),
      decimals: t.data.decimals,
      logoUrl: t.data.logoURL != null && t.data.logoURL.startsWith("https://") ? t.data.logoURL : null,
      cmcRank: t.data.cmcRank ?? null,
      marketCap: t.data.marketCap ?? null,
      isHoneypot: t.data.isHoneypot ?? null,
      isFeeOnTransfer: t.data.isFOT ?? null,
    });
  }
  return out;
}

const honeypotInfo = z.object({ isHoneypot: z.boolean(), isFOT: z.boolean() });

export interface KyberTokenClientOptions extends HttpOptions {
  readonly clientId: string;
  readonly gate?: RateGate | undefined;
}

export const KYBER_TOKEN_API = "https://token-api.kyberswap.com/api/v1/public";

export class KyberTokenClient {
  readonly #o: KyberTokenClientOptions;

  constructor(options: KyberTokenClientOptions) {
    this.#o = options;
  }

  async #get(url: URL): Promise<unknown> {
    if (this.#o.gate !== undefined && !this.#o.gate.tryTake()) {
      throw new ProviderError("kyberswap", "PROVIDER_RATE_LIMITED", "Token API capacity exhausted");
    }
    const { status, body } = await requestJson("kyberswap", url, { method: "GET", headers: { accept: "application/json", "x-client-id": this.#o.clientId } }, this.#o);
    if (status !== 200) throw errorForStatus("kyberswap", status, body);
    return body;
  }

  /** Whitelisted tokens on one chain, page by page, stopping at an empty page or `maxPages`. */
  async whitelisted(chainId: number, maxPages = 10, pageSize = 100): Promise<SourceToken[]> {
    const out: SourceToken[] = [];
    for (let page = 1; page <= maxPages; page++) {
      const url = new URL(`${KYBER_TOKEN_API}/tokens`);
      url.searchParams.set("chainIds", String(chainId));
      url.searchParams.set("isWhitelisted", "true");
      url.searchParams.set("page", String(page));
      url.searchParams.set("pageSize", String(pageSize));
      const rows = parseKyberTokens(await this.#get(url), chainId);
      out.push(...rows);
      if (rows.length < pageSize) break;
    }
    return out;
  }

  /**
   * Honeypot / fee-on-transfer check for one token. Throws when the answer is missing or malformed:
   * an unknown result must never be treated as "safe".
   */
  async safety(chainId: number, address: Address): Promise<{ isHoneypot: boolean; isFeeOnTransfer: boolean }> {
    const url = new URL(`${KYBER_TOKEN_API}/tokens/honeypot-fot-info`);
    url.searchParams.set("chainId", String(chainId));
    url.searchParams.set("address", address);
    const body = await this.#get(url);
    const data = typeof body === "object" && body !== null && "data" in body ? (body as { data: unknown }).data : body;
    const parsed = honeypotInfo.safeParse(data);
    if (!parsed.success) throw new ProviderError("kyberswap", "PROVIDER_BAD_RESPONSE", "Honeypot check returned an unknown shape");
    return { isHoneypot: parsed.data.isHoneypot, isFeeOnTransfer: parsed.data.isFOT };
  }
}

/** Fetches and parses a Token Lists URL. */
export async function fetchTokenList(url: string, source: Exclude<TokenSourceId, "kyberswap">, http: HttpOptions = {}): Promise<SourceToken[]> {
  const { status, body } = await requestJson("kyberswap", new URL(url), { method: "GET", headers: { accept: "application/json" } }, { timeoutMs: 20_000, maxResponseBytes: 25 * 1024 * 1024, ...http });
  if (status !== 200) throw errorForStatus("kyberswap", status, body);
  return parseTokenList(body, source);
}
