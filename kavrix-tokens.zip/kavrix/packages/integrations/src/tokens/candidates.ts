import { NATIVE_TOKEN_ADDRESS, type Address, type SupportedChainId } from "@kavrix/shared";
import type { Candidate, SourceToken, TokenSourceId } from "./types.ts";

/** Symbols users type; exotic Unicode or whitespace is a classic impersonation trick, so it is refused. */
const SYMBOL_RE = /^[A-Za-z0-9][A-Za-z0-9.$_+-]{0,15}$/;
const NAME_RE = /^[\p{L}\p{N} .,'’()&$+_-]{1,64}$/u;
/** Tokens in this list or this high by market cap count as "standard" risk; everything else is flagged high. */
const STANDARD_RANK = 300;

export interface CuratedToken {
  readonly chainId: SupportedChainId;
  readonly address: Address;
  readonly symbol: string;
}

const NATIVE_SYMBOLS: Readonly<Record<SupportedChainId, readonly string[]>> = {
  1: ["ETH"],
  8453: ["ETH"],
  42161: ["ETH"],
  137: ["POL", "MATIC"],
};

/**
 * Merges every source's view of every token and decides what may be listed.
 * Pure function: same inputs, same output — the whole policy is testable without the network.
 *
 * - reject: malformed metadata, sources disagree on decimals, flagged honeypot or fee-on-transfer,
 *   or the symbol impersonates a curated token / the native coin on that chain.
 * - auto: in KyberSwap's whitelist AND in at least one independent list (Uniswap, CoinGecko).
 * - pending: everything else that is well-formed (needs a human in the admin panel).
 */
export function decideCandidates(tokens: readonly SourceToken[], curated: readonly CuratedToken[]): Candidate[] {
  const byKey = new Map<string, SourceToken[]>();
  for (const t of tokens) {
    if (t.address === NATIVE_TOKEN_ADDRESS) continue;
    const key = `${t.chainId}:${t.address}`;
    const list = byKey.get(key);
    if (list === undefined) byKey.set(key, [t]);
    else list.push(t);
  }

  const curatedByChain = new Map<SupportedChainId, Map<string, Address>>();
  for (const c of curated) {
    const m = curatedByChain.get(c.chainId) ?? new Map<string, Address>();
    m.set(c.symbol.toUpperCase(), c.address);
    curatedByChain.set(c.chainId, m);
  }

  const out: Candidate[] = [];
  for (const entries of byKey.values()) {
    const first = entries[0] as SourceToken;
    const sources = [...new Set(entries.map((e) => e.source))].sort() as TokenSourceId[];
    const kyber = entries.find((e) => e.source === "kyberswap");
    // Prefer the curated lists' metadata for display; fall back to KyberSwap's.
    const meta = entries.find((e) => e.source === "uniswap") ?? entries.find((e) => e.source === "coingecko") ?? first;
    const reasons: string[] = [];
    let reject = false;

    const decimals = new Set(entries.map((e) => e.decimals));
    if (decimals.size > 1) {
      reject = true;
      reasons.push(`sources disagree on decimals (${[...decimals].join(", ")})`);
    }
    if (!Number.isInteger(meta.decimals) || meta.decimals < 0 || meta.decimals > 36) {
      reject = true;
      reasons.push("decimals out of range");
    }
    if (!SYMBOL_RE.test(meta.symbol)) {
      reject = true;
      reasons.push("symbol has characters Kavrix does not accept");
    }
    if (!NAME_RE.test(meta.name)) {
      reject = true;
      reasons.push("name has characters Kavrix does not accept");
    }
    const upper = meta.symbol.toUpperCase();
    const curatedAddress = curatedByChain.get(meta.chainId)?.get(upper);
    if (curatedAddress !== undefined && curatedAddress !== meta.address) {
      reject = true;
      reasons.push(`symbol ${meta.symbol} belongs to a curated token at another address`);
    }
    if (NATIVE_SYMBOLS[meta.chainId].includes(upper)) {
      reject = true;
      reasons.push(`symbol ${meta.symbol} imitates the network's native coin`);
    }
    if (entries.some((e) => e.isHoneypot === true)) {
      reject = true;
      reasons.push("flagged as a honeypot");
    }
    if (entries.some((e) => e.isFeeOnTransfer === true)) {
      reject = true;
      reasons.push("fee-on-transfer: the received amount would not match the quote");
    }

    const independent = sources.filter((s) => s !== "kyberswap").length;
    const whitelisted = kyber !== undefined;
    const rank = kyber?.cmcRank != null && kyber.cmcRank > 0 ? kyber.cmcRank : null;
    const risk: Candidate["risk"] = sources.includes("uniswap") || (rank !== null && rank <= STANDARD_RANK) ? "standard" : "high";

    let decision: Candidate["decision"];
    if (reject) decision = { kind: "reject", reasons };
    else if (whitelisted && independent >= 1) decision = { kind: "auto", reasons: [`listed by ${sources.join(" + ")}`] };
    else decision = { kind: "pending", reasons: [whitelisted ? "only KyberSwap lists it" : `not whitelisted by KyberSwap (${sources.join(", ")})`] };

    out.push({
      chainId: meta.chainId,
      address: meta.address,
      symbol: meta.symbol,
      name: meta.name.trim(),
      decimals: meta.decimals,
      logoUrl: entries.map((e) => e.logoUrl).find((u) => u !== null && /^https:\/\/[^\s"'<>]{1,500}$/.test(u)) ?? null,
      sources,
      risk,
      rank,
      decision,
    });
  }
  return out.sort((a, b) => (a.rank ?? Infinity) - (b.rank ?? Infinity) || a.symbol.localeCompare(b.symbol));
}
