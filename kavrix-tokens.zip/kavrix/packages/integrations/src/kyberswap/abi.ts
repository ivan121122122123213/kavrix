import type { Address } from "@kavrix/shared";

/**
 * Strict decoder for the two MetaAggregationRouterV2 entry points KyberSwap's build API emits:
 *   swap((address,address,bytes,SwapDescriptionV2,bytes))                         selector 0xe21fd0e9
 *   swapSimpleMode(address,SwapDescriptionV2,bytes,bytes)                         selector 0x8af033fb
 * SwapDescriptionV2 = (address srcToken, address dstToken, address[] srcReceivers, uint256[] srcAmounts,
 *   address[] feeReceivers, uint256[] feeAmounts, address dstReceiver, uint256 amount,
 *   uint256 minReturnAmount, uint256 flags, bytes permit)
 * Only the fields Kavrix verifies are extracted. Every offset is bounds- and alignment-checked;
 * anything unexpected yields `undefined` so callers fail closed.
 */
export const KYBER_SELECTORS = { swap: "e21fd0e9", swapSimpleMode: "8af033fb" } as const;
const MAX_FEE_RECEIVERS = 8;

export interface KyberSwapDescription {
  readonly fn: "swap" | "swapSimpleMode";
  readonly srcToken: Address;
  readonly dstToken: Address;
  readonly feeReceivers: readonly Address[];
  readonly dstReceiver: Address;
  readonly amount: bigint;
  readonly minReturnAmount: bigint;
}

class Reader {
  readonly #buf: Buffer;
  constructor(buf: Buffer) {
    this.#buf = buf;
  }
  word(at: number): bigint {
    if (!Number.isSafeInteger(at) || at < 0 || at + 32 > this.#buf.length) throw new RangeError("out of bounds");
    return BigInt(`0x${this.#buf.subarray(at, at + 32).toString("hex")}`);
  }
  /** Offset word relative to `base`, validated to point inside the buffer on a word boundary. */
  offset(base: number, at: number): number {
    const rel = this.word(at);
    if (rel % 32n !== 0n || rel > BigInt(this.#buf.length)) throw new RangeError("bad offset");
    const abs = base + Number(rel);
    if (abs + 32 > this.#buf.length) throw new RangeError("bad offset");
    return abs;
  }
  address(at: number): Address {
    const w = this.word(at);
    if (w >> 160n !== 0n) throw new RangeError("dirty address");
    return `0x${w.toString(16).padStart(40, "0")}` as Address;
  }
}

function readDesc(r: Reader, d: number) {
  const feeArr = r.offset(d, d + 4 * 32);
  const count = r.word(feeArr);
  if (count > BigInt(MAX_FEE_RECEIVERS)) throw new RangeError("too many fee receivers");
  const feeReceivers: Address[] = [];
  for (let i = 0; i < Number(count); i++) feeReceivers.push(r.address(feeArr + 32 * (i + 1)));
  return {
    srcToken: r.address(d),
    dstToken: r.address(d + 32),
    feeReceivers,
    dstReceiver: r.address(d + 6 * 32),
    amount: r.word(d + 7 * 32),
    minReturnAmount: r.word(d + 8 * 32),
  };
}

export function decodeKyberSwap(data: `0x${string}`): KyberSwapDescription | undefined {
  if (!/^0x([0-9a-fA-F]{2})+$/.test(data) || data.length < 10 + 64) return undefined;
  const selector = data.slice(2, 10).toLowerCase();
  const r = new Reader(Buffer.from(data.slice(10), "hex"));
  try {
    if (selector === KYBER_SELECTORS.swapSimpleMode) {
      return { fn: "swapSimpleMode", ...readDesc(r, r.offset(0, 32)) };
    }
    if (selector === KYBER_SELECTORS.swap) {
      const exec = r.offset(0, 0);
      return { fn: "swap", ...readDesc(r, r.offset(exec, exec + 3 * 32)) };
    }
  } catch {
    return undefined;
  }
  return undefined;
}
