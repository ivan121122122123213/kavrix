import {
  NATIVE_TOKEN_ADDRESS,
  assertBps,
  getChain,
  minAmountAfterSlippage,
  applyBps,
  parseBaseUnits,
  sameAddress,
  type Address,
} from "@kavrix/shared";
import { ProviderError } from "../errors.ts";
import { errorForStatus, requestJson, type HttpOptions } from "../http.ts";
import type { RateGate } from "../swap/gate.ts";
import { MAX_PLATFORM_FEE_BPS, type FirmQuote, type IndicativeQuote, type PlatformFeeConfig, type QuoteOutcome, type RouteLeg, type SwapProvider, type SwapRequest } from "../swap/types.ts";
import { decodeKyberSwap } from "./abi.ts";
import { kyberBuildSchema, kyberErrorSchema, kyberRouteSchema, type KyberRoute } from "./schema.ts";

export const KYBER_PUBLIC_BASE_URL = "https://aggregator-api.kyberswap.com";
export const KYBER_GATEWAY_BASE_URL = "https://api.kyberswap.com/swap";
/** The build API caps slippage at 2000 bps unless `ignoreCappedSlippage` is set; we never set it. */
export const KYBER_MAX_SLIPPAGE_BPS = 2000;
/** Kyber error codes meaning "no route", not a broken request. */
const NO_ROUTE_CODES = new Set([4008, 4010]);
const TX_DEADLINE_SECONDS = 600;

export interface KyberClientOptions extends HttpOptions {
  readonly clientId: string;
  /** Optional API-gateway key (issued by KyberSwap BD). Without it the public, rate-limited endpoint is used. */
  readonly apiKey?: string | undefined;
  readonly gate?: RateGate | undefined;
  readonly now?: () => number;
}

function unsafe(message: string): ProviderError {
  return new ProviderError("kyberswap", "QUOTE_UNSAFE", message);
}

export class KyberSwapProvider implements SwapProvider {
  readonly id = "kyberswap" as const;
  readonly maxSlippageBps = KYBER_MAX_SLIPPAGE_BPS;
  readonly #opts: KyberClientOptions;
  readonly #base: string;

  constructor(opts: KyberClientOptions) {
    if (!/^[A-Za-z0-9_-]{2,64}$/.test(opts.clientId)) throw new TypeError("KyberSwap client id must be 2-64 [A-Za-z0-9_-]");
    this.#opts = opts;
    this.#base = opts.apiKey !== undefined && opts.apiKey !== "" ? KYBER_GATEWAY_BASE_URL : KYBER_PUBLIC_BASE_URL;
  }

  #headers(json: boolean): Record<string, string> {
    const h: Record<string, string> = { accept: "application/json", "x-client-id": this.#opts.clientId };
    if (json) h["content-type"] = "application/json";
    if (this.#opts.apiKey !== undefined && this.#opts.apiKey !== "") h["x-api-key"] = this.#opts.apiKey;
    return h;
  }

  #take(): void {
    if (this.#opts.gate !== undefined && !this.#opts.gate.tryTake()) {
      throw new ProviderError("kyberswap", "PROVIDER_RATE_LIMITED", "Quote capacity is temporarily exhausted");
    }
  }

  async quote(request: SwapRequest, fee: PlatformFeeConfig | undefined): Promise<QuoteOutcome> {
    validateRequest(request, fee);
    const route = await this.#route(request, fee);
    if (route === undefined) return { kind: "no_route" };
    const { routeSummary, routerAddress } = route.parsed.data;
    const chain = getChain(request.chainId);
    if (!sameAddress(routerAddress, chain.kyberRouter)) throw unsafe("KyberSwap returned an unexpected router");
    if (!sameAddress(routeSummary.tokenIn, request.sellToken) || !sameAddress(routeSummary.tokenOut, request.buyToken)) {
      throw unsafe("KyberSwap returned a different token pair");
    }
    if (parseBaseUnits(routeSummary.amountIn) !== request.sellAmount) throw unsafe("KyberSwap returned a different input amount");
    const amountOut = parseBaseUnits(routeSummary.amountOut);
    if (amountOut === 0n) return { kind: "no_route" };

    const indicative: IndicativeQuote = {
      provider: "kyberswap",
      chainId: request.chainId,
      sellToken: request.sellToken,
      buyToken: request.buyToken,
      sellAmount: request.sellAmount,
      buyAmount: amountOut,
      minBuyAmount: minAmountAfterSlippage(amountOut, request.slippageBps),
      platformFee: { bps: fee?.bps ?? 0, amount: fee === undefined ? 0n : applyBps(request.sellAmount, fee.bps), token: "sell" },
      providerFee: null,
      networkFeeWei: parseBaseUnits(routeSummary.gas) * parseBaseUnits(routeSummary.gasPrice),
      route: routeLegs(routeSummary.route, request.sellAmount),
      valueUsd: usdPair(routeSummary.amountInUsd, routeSummary.amountOutUsd),
    };
    if (request.taker === undefined) return { kind: "indicative", quote: indicative };
    return { kind: "firm", quote: await this.#build(request, fee, route.raw, indicative, routeSummary.gasPrice) };
  }

  async #route(request: SwapRequest, fee: PlatformFeeConfig | undefined): Promise<{ parsed: KyberRoute; raw: unknown } | undefined> {
    const chain = getChain(request.chainId);
    const url = new URL(`${this.#base}/${chain.kyberSlug}/api/v1/routes`);
    url.searchParams.set("tokenIn", request.sellToken);
    url.searchParams.set("tokenOut", request.buyToken);
    url.searchParams.set("amountIn", request.sellAmount.toString());
    url.searchParams.set("gasInclude", "true");
    if (request.taker !== undefined) url.searchParams.set("origin", request.taker);
    if (fee !== undefined && fee.bps > 0) {
      // Fee in the input token: the exact amount is known before the swap and shown to the user as-is.
      url.searchParams.set("chargeFeeBy", "currency_in");
      url.searchParams.set("isInBps", "true");
      url.searchParams.set("feeAmount", String(fee.bps));
      url.searchParams.set("feeReceiver", fee.recipient);
    }
    this.#take();
    const { status, body } = await requestJson("kyberswap", url, { method: "GET", headers: this.#headers(false) }, this.#opts);
    if (status !== 200) {
      const err = kyberErrorSchema.safeParse(body);
      if (err.success && NO_ROUTE_CODES.has(err.data.code)) return undefined;
      throw errorForStatus("kyberswap", status, body);
    }
    const parsed = kyberRouteSchema.safeParse(body);
    if (!parsed.success || parsed.data.code !== 0) {
      throw new ProviderError("kyberswap", "PROVIDER_BAD_RESPONSE", "KyberSwap route response did not match the expected schema");
    }
    // The build call needs routeSummary exactly as received, including fields we do not model.
    const raw = (body as { data: { routeSummary: unknown } }).data.routeSummary;
    return { parsed: parsed.data, raw };
  }

  async #build(
    request: SwapRequest,
    fee: PlatformFeeConfig | undefined,
    rawRouteSummary: unknown,
    indicative: IndicativeQuote,
    gasPrice: string,
  ): Promise<FirmQuote> {
    const taker = request.taker as Address;
    const chain = getChain(request.chainId);
    const nowSeconds = Math.floor((this.#opts.now ?? Date.now)() / 1000);
    const url = new URL(`${this.#base}/${chain.kyberSlug}/api/v1/route/build`);
    this.#take();
    const { status, body } = await requestJson(
      "kyberswap",
      url,
      {
        method: "POST",
        headers: this.#headers(true),
        body: JSON.stringify({
          routeSummary: rawRouteSummary,
          sender: taker,
          recipient: taker,
          origin: taker,
          slippageTolerance: request.slippageBps,
          deadline: nowSeconds + TX_DEADLINE_SECONDS,
          source: this.#opts.clientId,
        }),
      },
      this.#opts,
    );
    if (status !== 200) {
      const err = kyberErrorSchema.safeParse(body);
      if (err.success && NO_ROUTE_CODES.has(err.data.code)) {
        throw new ProviderError("kyberswap", "NO_LIQUIDITY", "Route is no longer available");
      }
      throw errorForStatus("kyberswap", status, body);
    }
    const parsed = kyberBuildSchema.safeParse(body);
    if (!parsed.success || parsed.data.code !== 0) {
      throw new ProviderError("kyberswap", "PROVIDER_BAD_RESPONSE", "KyberSwap build response did not match the expected schema");
    }
    const built = parsed.data.data;
    const sellsNative = sameAddress(request.sellToken, NATIVE_TOKEN_ADDRESS);
    const value = parseBaseUnits(built.transactionValue);
    const amountOut = parseBaseUnits(built.amountOut);

    if (!sameAddress(built.routerAddress, chain.kyberRouter)) throw unsafe("KyberSwap build targets an unexpected router");
    if (parseBaseUnits(built.amountIn) !== request.sellAmount) throw unsafe("KyberSwap build changed the input amount");
    if (sellsNative ? value !== request.sellAmount : value !== 0n) throw unsafe("Transaction value does not match the sell amount");

    const desc = decodeKyberSwap(built.data as `0x${string}`);
    if (desc === undefined) throw unsafe("Calldata is not a known router swap");
    if (!sameAddress(desc.srcToken, request.sellToken) || !sameAddress(desc.dstToken, request.buyToken)) {
      throw unsafe("Calldata swaps a different token pair");
    }
    if (!sameAddress(desc.dstReceiver, taker)) throw unsafe("Calldata sends output to another address");
    if (desc.amount === 0n || desc.amount > request.sellAmount) throw unsafe("Calldata spends more than the sell amount");
    const allowedFeeReceivers = fee !== undefined && fee.bps > 0 ? [fee.recipient] : [];
    if (!desc.feeReceivers.every((r) => allowedFeeReceivers.some((a) => sameAddress(a, r)))) {
      throw unsafe("Calldata pays fees to an unknown address");
    }
    // Allow 1 bps for rounding between Kyber's min-return math and ours, never more.
    const floor = minAmountAfterSlippage(amountOut, Math.min(request.slippageBps + 1, 10_000));
    if (desc.minReturnAmount === 0n || desc.minReturnAmount < floor || desc.minReturnAmount > amountOut) {
      throw unsafe("Calldata minimum output does not match the slippage tolerance");
    }

    return {
      ...indicative,
      buyAmount: amountOut,
      minBuyAmount: desc.minReturnAmount,
      // The built transaction's figures supersede the route's when present (they match the final amounts).
      valueUsd: usdPair(built.amountInUsd, built.amountOutUsd) ?? indicative.valueUsd,
      networkFeeWei: parseBaseUnits(built.gas) * parseBaseUnits(gasPrice),
      taker,
      spender: sellsNative ? null : chain.kyberRouter,
      tx: { to: chain.kyberRouter, data: built.data as `0x${string}`, value },
    };
  }
}

function validateRequest(request: SwapRequest, fee: PlatformFeeConfig | undefined): void {
  getChain(request.chainId);
  if (request.sellAmount <= 0n) throw new RangeError("sellAmount must be positive");
  if (sameAddress(request.sellToken, request.buyToken)) throw new RangeError("sellToken and buyToken must differ");
  assertBps(request.slippageBps, KYBER_MAX_SLIPPAGE_BPS);
  if (fee !== undefined) assertBps(fee.bps, MAX_PLATFORM_FEE_BPS);
}

/** Both USD figures or nothing: a one-sided estimate cannot give a price impact. */
export function usdPair(sell: string | undefined, buy: string | undefined): { sell: number; buy: number } | null {
  if (sell === undefined || buy === undefined) return null;
  const s = Number(sell);
  const b = Number(buy);
  return Number.isFinite(s) && Number.isFinite(b) && s > 0 && b >= 0 ? { sell: s, buy: b } : null;
}

/** Proportion of the input routed through each path, labelled by the exchanges it crosses. */
export function routeLegs(paths: KyberRoute["data"]["routeSummary"]["route"], amountIn: bigint): RouteLeg[] {
  if (amountIn <= 0n) return [];
  return paths
    .filter((path) => path.length > 0)
    .map((path) => {
      const first = path[0] as (typeof path)[number];
      const exchanges = [...new Set(path.map((h) => h.exchange))].join(" → ");
      return { source: exchanges, proportionBps: Number((parseBaseUnits(first.swapAmount) * 10_000n) / amountIn) };
    });
}
