import { z } from "zod";

const address = z.string().regex(/^0x[0-9a-fA-F]{40}$/);
const uint = z.string().regex(/^\d+$/);
/** USD figures are informational: accept plain decimals, anything else is treated as absent. */
const usd = z.string().regex(/^\d{1,15}(\.\d{1,18})?$/).optional().catch(undefined);

const hop = z.object({
  pool: z.string(),
  tokenIn: address,
  tokenOut: address,
  swapAmount: uint,
  amountOut: uint,
  exchange: z.string().max(64),
});

export const kyberRouteSchema = z.object({
  code: z.number(),
  data: z.object({
    routerAddress: address,
    routeSummary: z.object({
      tokenIn: address,
      amountIn: uint,
      amountInUsd: usd,
      tokenOut: address,
      amountOut: uint,
      amountOutUsd: usd,
      gas: uint,
      gasPrice: uint,
      route: z.array(z.array(hop)),
      routeID: z.string(),
    }),
  }),
});

export const kyberBuildSchema = z.object({
  code: z.number(),
  data: z.object({
    amountIn: uint,
    amountInUsd: usd,
    amountOut: uint,
    amountOutUsd: usd,
    gas: uint,
    data: z.string().regex(/^0x([0-9a-fA-F]{2})+$/),
    routerAddress: address,
    transactionValue: uint,
  }),
});

export const kyberErrorSchema = z.object({ code: z.number(), message: z.string().optional() });

export type KyberRoute = z.infer<typeof kyberRouteSchema>;
