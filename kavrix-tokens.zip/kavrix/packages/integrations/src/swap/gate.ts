/**
 * Token bucket shared by all callers of one upstream API, so a burst of users cannot push
 * Kavrix over the provider's limit (KyberSwap's default is 3 requests/second per client).
 */
export class RateGate {
  readonly #capacity: number;
  readonly #refillPerMs: number;
  readonly #now: () => number;
  #tokens: number;
  #last: number;

  constructor(perSecond: number, now: () => number = Date.now) {
    if (!(perSecond > 0)) throw new RangeError("perSecond must be positive");
    this.#capacity = perSecond;
    this.#refillPerMs = perSecond / 1000;
    this.#now = now;
    this.#tokens = perSecond;
    this.#last = now();
  }

  /** Takes `count` tokens if available; never waits. */
  tryTake(count = 1): boolean {
    const t = this.#now();
    this.#tokens = Math.min(this.#capacity, this.#tokens + (t - this.#last) * this.#refillPerMs);
    this.#last = t;
    if (this.#tokens < count) return false;
    this.#tokens -= count;
    return true;
  }
}
