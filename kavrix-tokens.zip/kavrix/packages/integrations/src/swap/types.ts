import type { Address, SupportedChainId } from "@kavrix/shared";

export type ProviderId = "kyberswap" | "0x";

/** Platform fee ceiling, stricter than any provider limit. */
export const MAX_PLATFORM_FEE_BPS = 300;

export interface SwapRequest {
  readonly chainId: SupportedChainId;
  readonly sellToken: Address;
  readonly buyToken: Address;
  readonly sellAmount: bigint;
  readonly slippageBps: number;
  /** Without a taker only an indicative price (no calldata) is returned. */
  readonly taker?: Address | undefined;
}

export interface PlatformFeeConfig {
  readonly recipient: Address;
  readonly bps: number;
}

export interface RouteLeg {
  readonly source: string;
  readonly proportionBps: number;
}

export interface IndicativeQuote {
  readonly provider: ProviderId;
  readonly chainId: SupportedChainId;
  readonly sellToken: Address;
  readonly buyToken: Address;
  readonly sellAmount: bigint;
  readonly buyAmount: bigint;
  /** For firm quotes this is the value enforced on-chain (decoded from calldata where possible). */
  readonly minBuyAmount: bigint;
  readonly platformFee: { readonly bps: number; readonly amount: bigint; readonly token: "sell" | "buy" };
  /** Explicit provider fee in the buy token; null when the provider charges none (it may still keep surplus). */
  readonly providerFee: bigint | null;
  readonly networkFeeWei: bigint | null;
  readonly route: readonly RouteLeg[];
  /**
   * Provider-reported USD value of what is sold and bought, for display and price-impact warnings only.
   * Never used for amounts or limits. null when the provider does not report it.
   */
  readonly valueUsd: { readonly sell: number; readonly buy: number } | null;
}

export interface FirmQuote extends IndicativeQuote {
  readonly taker: Address;
  /** Contract that needs an ERC-20 allowance; null when selling the native coin. */
  readonly spender: Address | null;
  readonly tx: { readonly to: Address; readonly data: `0x${string}`; readonly value: bigint };
}

export type QuoteOutcome =
  | { readonly kind: "indicative"; readonly quote: IndicativeQuote }
  | { readonly kind: "firm"; readonly quote: FirmQuote }
  | { readonly kind: "no_route" };

export interface SwapProvider {
  readonly id: ProviderId;
  readonly maxSlippageBps: number;
  quote(request: SwapRequest, fee: PlatformFeeConfig | undefined): Promise<QuoteOutcome>;
}
