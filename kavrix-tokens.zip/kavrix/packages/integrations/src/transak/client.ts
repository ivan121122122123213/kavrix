import { z } from "zod";
import { ProviderError } from "../errors.ts";
import { errorForStatus, requestJson, type HttpOptions } from "../http.ts";

export type TransakEnvironment = "staging" | "production";

const ENDPOINTS: Readonly<Record<TransakEnvironment, { api: string; gateway: string; widgetHost: string }>> = {
  staging: {
    api: "https://api-stg.transak.com",
    gateway: "https://api-gateway-stg.transak.com",
    widgetHost: "global-stg.transak.com",
  },
  production: {
    api: "https://api.transak.com",
    gateway: "https://api-gateway.transak.com",
    widgetHost: "global.transak.com",
  },
};

const accessTokenSchema = z.object({
  data: z.object({ accessToken: z.string().min(20), expiresAt: z.number().int().positive() }),
});

const widgetSessionSchema = z.object({ data: z.object({ widgetUrl: z.string().url() }) });

export interface StoredTransakToken {
  readonly accessToken: string;
  readonly expiresAt: number;
  readonly previous: string | null;
}

/** Shared persistence so every replica, and every restart, verifies webhooks with the live token. */
export interface TransakTokenStore {
  load(): Promise<StoredTransakToken | null>;
  save(token: StoredTransakToken): Promise<void>;
}

export interface TransakClientOptions extends HttpOptions {
  readonly environment: TransakEnvironment;
  readonly apiKey: string;
  readonly apiSecret: string;
  readonly now?: () => number;
  readonly tokenStore?: TransakTokenStore;
}

export type TransakWidgetParams = Readonly<Record<string, string | number | boolean>>;

/** Refresh slightly before expiry; Transak asks partners not to refresh on every request. */
const REFRESH_MARGIN_SECONDS = 300;

export class TransakClient {
  readonly #options: TransakClientOptions;
  readonly #endpoints: (typeof ENDPOINTS)[TransakEnvironment];
  #token: { value: string; expiresAt: number } | undefined;
  #previousToken: string | undefined;
  #inflight: Promise<string> | undefined;

  constructor(options: TransakClientOptions) {
    if (options.apiKey.length === 0 || options.apiSecret.length === 0) {
      throw new TypeError("Transak API key and secret are required");
    }
    this.#options = options;
    this.#endpoints = ENDPOINTS[options.environment];
  }

  #now(): number {
    return Math.floor((this.#options.now ?? Date.now)() / 1000);
  }

  async #loadStored(): Promise<void> {
    if (this.#token !== undefined || this.#options.tokenStore === undefined) return;
    const stored = await this.#options.tokenStore.load();
    if (stored === null) return;
    this.#token = { value: stored.accessToken, expiresAt: stored.expiresAt };
    this.#previousToken = stored.previous ?? undefined;
  }

  /** Current and previous access tokens, used as HS256 secrets when verifying webhooks. */
  async webhookSecrets(): Promise<readonly string[]> {
    await this.#loadStored();
    if (this.#token === undefined) await this.getAccessToken();
    return [this.#token?.value, this.#previousToken].filter((v): v is string => v !== undefined);
  }

  async getAccessToken(): Promise<string> {
    await this.#loadStored();
    if (this.#token !== undefined && this.#token.expiresAt - REFRESH_MARGIN_SECONDS > this.#now()) {
      return this.#token.value;
    }
    this.#inflight ??= this.#refresh().finally(() => {
      this.#inflight = undefined;
    });
    return this.#inflight;
  }

  async #refresh(): Promise<string> {
    const url = new URL("/partners/api/v2/refresh-token", this.#endpoints.api);
    const { status, body } = await requestJson(
      "transak",
      url,
      {
        method: "POST",
        headers: {
          accept: "application/json",
          "content-type": "application/json",
          "api-secret": this.#options.apiSecret,
          "x-api-key": this.#options.apiKey,
        },
        body: JSON.stringify({ apiKey: this.#options.apiKey }),
      },
      this.#options,
    );
    if (status < 200 || status >= 300) throw errorForStatus("transak", status, body);
    const parsed = accessTokenSchema.safeParse(body);
    if (!parsed.success) {
      throw new ProviderError("transak", "PROVIDER_BAD_RESPONSE", "Transak access token response is invalid");
    }
    if (this.#token !== undefined) this.#previousToken = this.#token.value;
    this.#token = { value: parsed.data.data.accessToken, expiresAt: parsed.data.data.expiresAt };
    await this.#options.tokenStore?.save({
      accessToken: this.#token.value,
      expiresAt: this.#token.expiresAt,
      previous: this.#previousToken ?? null,
    });
    return this.#token.value;
  }

  /**
   * Creates a single-use widget session (expires ~5 minutes after creation). Must be called
   * from the backend; `userIp` is the end user's originating IP.
   */
  async createWidgetUrl(widgetParams: TransakWidgetParams, userIp: string, referrerDomain: string): Promise<URL> {
    const accessToken = await this.getAccessToken();
    const url = new URL("/api/v2/auth/session", this.#endpoints.gateway);
    const { status, body } = await requestJson(
      "transak",
      url,
      {
        method: "POST",
        headers: {
          accept: "application/json",
          "content-type": "application/json",
          "access-token": accessToken,
          "x-api-key": this.#options.apiKey,
          "x-user-ip": userIp,
        },
        body: JSON.stringify({ widgetParams: { ...widgetParams, apiKey: this.#options.apiKey, referrerDomain } }),
      },
      this.#options,
    );
    if (status < 200 || status >= 300) throw errorForStatus("transak", status, body);
    const parsed = widgetSessionSchema.safeParse(body);
    if (!parsed.success) {
      throw new ProviderError("transak", "PROVIDER_BAD_RESPONSE", "Transak widget session response is invalid");
    }
    const widgetUrl = new URL(parsed.data.data.widgetUrl);
    if (widgetUrl.protocol !== "https:" || widgetUrl.host !== this.#endpoints.widgetHost) {
      throw new ProviderError("transak", "PROVIDER_BAD_RESPONSE", "Transak returned an unexpected widget host");
    }
    return widgetUrl;
  }
}
