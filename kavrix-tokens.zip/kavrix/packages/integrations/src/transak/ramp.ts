import { createHash } from "node:crypto";
import { z } from "zod";
import type { Address, RampStatus, SupportedChainId } from "@kavrix/shared";
import type { ParsedRampEvent } from "../moonpay/client.ts";
import type { TransakWidgetParams } from "./client.ts";

export const TRANSAK_NETWORK: Readonly<Record<SupportedChainId, string>> = {
  1: "ethereum",
  8453: "base",
  42161: "arbitrum",
  137: "polygon",
};

export interface TransakWidgetRequest {
  readonly direction: "buy" | "sell";
  readonly chainId: SupportedChainId;
  readonly cryptoSymbol: string;
  readonly fiatCurrency: "USD" | "EUR" | "GBP";
  readonly amount: string;
  readonly walletAddress: Address;
  readonly partnerOrderId: string;
  readonly redirectURL: string;
}

export function transakWidgetParams(r: TransakWidgetRequest): TransakWidgetParams {
  const common = {
    productsAvailed: r.direction === "buy" ? "BUY" : "SELL",
    cryptoCurrencyCode: r.cryptoSymbol,
    network: TRANSAK_NETWORK[r.chainId],
    fiatCurrency: r.fiatCurrency,
    partnerOrderId: r.partnerOrderId,
    redirectURL: r.redirectURL,
    colorMode: "DARK",
    themeColor: "22F2D0",
  };
  return r.direction === "buy"
    ? { ...common, fiatAmount: Number(r.amount), walletAddress: r.walletAddress, disableWalletAddressForm: true }
    : { ...common, cryptoAmount: Number(r.amount) };
}

const STATUS: Readonly<Record<string, RampStatus>> = {
  AWAITING_PAYMENT_FROM_USER: "pending",
  PAYMENT_DONE_MARKED_BY_USER: "pending",
  PROCESSING: "pending",
  PENDING_DELIVERY_FROM_TRANSAK: "pending",
  ON_HOLD_PENDING_DELIVERY_FROM_TRANSAK: "pending",
  COMPLETED: "completed",
  CANCELLED: "cancelled",
  FAILED: "failed",
  REFUNDED: "refunded",
  EXPIRED: "expired",
};

const payloadSchema = z.object({
  eventID: z.string().max(64),
  webhookData: z.object({
    id: z.string().min(1).max(128),
    status: z.string().max(64),
    partnerOrderId: z.string().max(128).nullable().optional(),
    updatedAt: z.string().max(64).nullable().optional(),
  }),
});

/** Interprets the claims of an already verified Transak webhook JWT. */
export function parseTransakWebhook(claims: Readonly<Record<string, unknown>>): ParsedRampEvent | undefined {
  const parsed = payloadSchema.safeParse(claims);
  if (!parsed.success) return undefined;
  const { eventID, webhookData: d } = parsed.data;
  return {
    eventId: createHash("sha256").update(`${eventID}|${d.id}|${d.status}|${d.updatedAt ?? ""}`).digest("hex"),
    eventType: eventID,
    orderId: d.partnerOrderId ?? null,
    externalOrderId: d.id,
    providerStatus: d.status,
    status: Object.hasOwn(STATUS, d.status) ? STATUS[d.status] : undefined,
  };
}
