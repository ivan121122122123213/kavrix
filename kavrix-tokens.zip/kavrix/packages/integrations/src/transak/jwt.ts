import { createHmac, timingSafeEqual } from "node:crypto";

export type JwtVerification =
  | { readonly ok: true; readonly payload: Readonly<Record<string, unknown>> }
  | { readonly ok: false; readonly reason: "malformed" | "unsupported_alg" | "mismatch" | "expired" };

function decodeSegment(segment: string): unknown {
  if (!/^[A-Za-z0-9_-]+$/.test(segment)) throw new TypeError("bad segment");
  return JSON.parse(Buffer.from(segment, "base64url").toString("utf8")) as unknown;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

/**
 * Minimal HS256 verifier for Transak webhooks (payload `data` is a JWT signed with the
 * partner access token). Only HS256 is accepted; `none` and asymmetric algs are rejected.
 * Several secrets may be supplied to survive access-token rotation.
 */
export function verifyHs256Jwt(
  token: string,
  secrets: readonly string[],
  nowSeconds: number = Math.floor(Date.now() / 1000),
): JwtVerification {
  if (token.length > 64 * 1024) return { ok: false, reason: "malformed" };
  const parts = token.split(".");
  if (parts.length !== 3) return { ok: false, reason: "malformed" };
  const [headerB64, payloadB64, signatureB64] = parts as [string, string, string];

  let header: unknown;
  let payload: unknown;
  try {
    header = decodeSegment(headerB64);
    payload = decodeSegment(payloadB64);
  } catch {
    return { ok: false, reason: "malformed" };
  }
  if (!isRecord(header) || !isRecord(payload)) return { ok: false, reason: "malformed" };
  if (header["alg"] !== "HS256") return { ok: false, reason: "unsupported_alg" };
  if (!/^[A-Za-z0-9_-]+$/.test(signatureB64)) return { ok: false, reason: "malformed" };

  const received = Buffer.from(signatureB64, "base64url");
  const signingInput = `${headerB64}.${payloadB64}`;
  const matched = secrets.some((secret) => {
    if (secret.length === 0) return false;
    const expected = createHmac("sha256", secret).update(signingInput).digest();
    return expected.length === received.length && timingSafeEqual(expected, received);
  });
  if (!matched) return { ok: false, reason: "mismatch" };

  const exp = payload["exp"];
  if (typeof exp === "number" && exp < nowSeconds) return { ok: false, reason: "expired" };
  return { ok: true, payload };
}
