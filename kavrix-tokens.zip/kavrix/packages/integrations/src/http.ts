import { ProviderError, type ProviderName } from "./errors.ts";

export type FetchLike = (input: string | URL, init?: RequestInit) => Promise<Response>;

export interface HttpOptions {
  readonly fetch?: FetchLike | undefined;
  readonly timeoutMs?: number | undefined;
  readonly maxResponseBytes?: number | undefined;
}

export interface JsonResponse {
  readonly status: number;
  readonly body: unknown;
}

const DEFAULT_TIMEOUT_MS = 8_000;
const DEFAULT_MAX_RESPONSE_BYTES = 2 * 1024 * 1024;

/**
 * Performs a request and parses JSON. Transport failures, timeouts and oversized or
 * non-JSON bodies become ProviderError; HTTP status handling is left to the caller.
 */
export async function requestJson(
  provider: ProviderName,
  url: URL,
  init: RequestInit,
  options: HttpOptions = {},
): Promise<JsonResponse> {
  const doFetch = options.fetch ?? globalThis.fetch;
  const timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  const maxBytes = options.maxResponseBytes ?? DEFAULT_MAX_RESPONSE_BYTES;

  let response: Response;
  try {
    response = await doFetch(url, { ...init, redirect: "error", signal: AbortSignal.timeout(timeoutMs) });
  } catch (cause) {
    const timedOut = cause instanceof DOMException && cause.name === "TimeoutError";
    throw new ProviderError(
      provider,
      timedOut ? "PROVIDER_TIMEOUT" : "PROVIDER_UNAVAILABLE",
      timedOut ? `${provider} did not respond within ${timeoutMs}ms` : `${provider} is unreachable`,
      { cause },
    );
  }

  const declared = Number(response.headers.get("content-length") ?? "0");
  if (declared > maxBytes) {
    throw new ProviderError(provider, "PROVIDER_BAD_RESPONSE", `${provider} response too large`, {
      httpStatus: response.status,
    });
  }

  let text: string;
  try {
    text = await response.text();
  } catch (cause) {
    throw new ProviderError(provider, "PROVIDER_UNAVAILABLE", `${provider} response was interrupted`, {
      httpStatus: response.status,
      cause,
    });
  }
  if (Buffer.byteLength(text, "utf8") > maxBytes) {
    throw new ProviderError(provider, "PROVIDER_BAD_RESPONSE", `${provider} response too large`, {
      httpStatus: response.status,
    });
  }

  if (text.length === 0) return { status: response.status, body: null };
  try {
    return { status: response.status, body: JSON.parse(text) as unknown };
  } catch {
    if (!response.ok) return { status: response.status, body: null };
    throw new ProviderError(provider, "PROVIDER_BAD_RESPONSE", `${provider} returned non-JSON body`, {
      httpStatus: response.status,
    });
  }
}

/** Maps non-2xx responses to a typed error. `providerCode` is read only if it is a short identifier. */
export function errorForStatus(provider: ProviderName, status: number, body: unknown): ProviderError {
  const providerCode = extractProviderCode(body);
  const details = providerCode === undefined ? { httpStatus: status } : { httpStatus: status, providerCode };
  if (status === 401 || status === 403) {
    return new ProviderError(provider, "PROVIDER_AUTH", `${provider} rejected credentials or access`, details);
  }
  if (status === 429) {
    return new ProviderError(provider, "PROVIDER_RATE_LIMITED", `${provider} rate limit reached`, details);
  }
  if (status >= 500) {
    return new ProviderError(provider, "PROVIDER_UNAVAILABLE", `${provider} server error`, details);
  }
  return new ProviderError(provider, "PROVIDER_REJECTED", `${provider} rejected the request`, details);
}

function extractProviderCode(body: unknown): string | undefined {
  if (typeof body !== "object" || body === null) return undefined;
  const record = body as Record<string, unknown>;
  for (const key of ["name", "code", "type"] as const) {
    const value = record[key];
    if (typeof value === "string" && /^[A-Z0-9_]{2,64}$/.test(value)) return value;
  }
  return undefined;
}
