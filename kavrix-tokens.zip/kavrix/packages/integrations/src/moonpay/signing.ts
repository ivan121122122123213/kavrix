import { createHmac, timingSafeEqual } from "node:crypto";

export const MOONPAY_WIDGET_HOSTS = {
  buy: { production: "https://buy.moonpay.com", sandbox: "https://buy-sandbox.moonpay.com" },
  sell: { production: "https://sell.moonpay.com", sandbox: "https://sell-sandbox.moonpay.com" },
} as const;

/**
 * Appends `signature` = base64(HMAC-SHA256(secretKey, url.search)). Every parameter must be set
 * before signing; MoonPay rejects URLs whose query was changed afterwards.
 */
export function signMoonPayWidgetUrl(url: URL, secretKey: string): URL {
  if (secretKey.length === 0) throw new TypeError("MoonPay secret key is required");
  if (url.searchParams.has("signature")) throw new TypeError("URL is already signed");
  const signature = createHmac("sha256", secretKey).update(url.search).digest("base64");
  const signed = new URL(url);
  signed.searchParams.set("signature", signature);
  return signed;
}

export type WebhookVerification =
  | { readonly ok: true; readonly timestamp: number }
  | { readonly ok: false; readonly reason: "malformed" | "stale" | "mismatch" };

/**
 * Verifies `Moonpay-Signature-V2: t=<unix>,s=<hex>` where s = HMAC-SHA256(webhookKey, `${t}.${rawBody}`).
 * `rawBody` must be the exact bytes received; re-serialized JSON will not verify.
 */
export function verifyMoonPayWebhook(
  header: string | undefined,
  rawBody: string,
  webhookKey: string,
  options: { nowSeconds?: number; toleranceSeconds?: number } = {},
): WebhookVerification {
  if (webhookKey.length === 0) throw new TypeError("MoonPay webhook key is required");
  if (header === undefined || header.length > 512) return { ok: false, reason: "malformed" };

  let timestamp: string | undefined;
  let signature: string | undefined;
  for (const part of header.split(",")) {
    const index = part.indexOf("=");
    if (index <= 0) continue;
    const key = part.slice(0, index).trim();
    const value = part.slice(index + 1).trim();
    if (key === "t") timestamp = value;
    else if (key === "s") signature = value;
  }
  if (timestamp === undefined || signature === undefined) return { ok: false, reason: "malformed" };
  if (!/^\d{1,12}$/.test(timestamp) || !/^[0-9a-f]{64}$/i.test(signature)) return { ok: false, reason: "malformed" };

  const now = options.nowSeconds ?? Math.floor(Date.now() / 1000);
  const tolerance = options.toleranceSeconds ?? 300;
  const ts = Number(timestamp);
  if (Math.abs(now - ts) > tolerance) return { ok: false, reason: "stale" };

  const expected = createHmac("sha256", webhookKey).update(`${timestamp}.${rawBody}`).digest();
  const received = Buffer.from(signature, "hex");
  if (received.length !== expected.length || !timingSafeEqual(received, expected)) {
    return { ok: false, reason: "mismatch" };
  }
  return { ok: true, timestamp: ts };
}
