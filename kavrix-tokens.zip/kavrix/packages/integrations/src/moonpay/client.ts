import { createHash } from "node:crypto";
import { z } from "zod";
import { NATIVE_TOKEN_ADDRESS, type Address, type RampStatus, type SupportedChainId } from "@kavrix/shared";
import { ProviderError } from "../errors.ts";
import { errorForStatus, requestJson, type HttpOptions } from "../http.ts";
import { MOONPAY_WIDGET_HOSTS, signMoonPayWidgetUrl } from "./signing.ts";

export type MoonPayEnvironment = "sandbox" | "production";

const currencySchema = z.object({
  type: z.string(),
  code: z.string().regex(/^[a-z0-9_]{1,32}$/),
  isSuspended: z.boolean().nullable().optional(),
  isSellSupported: z.boolean().nullable().optional(),
  metadata: z
    .object({
      contractAddress: z.union([z.string(), z.number()]).nullable().optional(),
      chainId: z.union([z.string(), z.number()]).nullable().optional(),
    })
    .nullable()
    .optional(),
});
export type MoonPayCurrency = z.infer<typeof currencySchema>;

const ZERO = "0x0000000000000000000000000000000000000000";

function isNativeContract(v: string | number | null | undefined): boolean {
  if (v === null || v === undefined || v === 0 || v === "0" || v === "") return true;
  const s = String(v).toLowerCase();
  return s === ZERO || s === NATIVE_TOKEN_ADDRESS;
}

/**
 * Finds MoonPay's currency code for a token on a chain from MoonPay's own metadata.
 * Returns undefined (fail closed) when there is no match or more than one.
 */
export function resolveMoonPayCurrency(
  currencies: readonly MoonPayCurrency[],
  chainId: SupportedChainId,
  token: Address,
  direction: "buy" | "sell",
): string | undefined {
  const native = token === NATIVE_TOKEN_ADDRESS;
  const matches = currencies.filter((c) => {
    if (c.type !== "crypto" || c.isSuspended === true || c.metadata == null) return false;
    if (String(c.metadata.chainId ?? "") !== String(chainId)) return false;
    if (direction === "sell" && c.isSellSupported !== true) return false;
    return native ? isNativeContract(c.metadata.contractAddress) : String(c.metadata.contractAddress ?? "").toLowerCase() === token;
  });
  return matches.length === 1 ? matches[0]?.code : undefined;
}

export interface MoonPayClientOptions extends HttpOptions {
  readonly environment: MoonPayEnvironment;
  readonly publishableKey: string;
  readonly secretKey: string;
  readonly now?: () => number;
}

export interface MoonPayWidgetRequest {
  readonly direction: "buy" | "sell";
  readonly currencyCode: string;
  readonly fiatCurrency: "usd" | "eur" | "gbp";
  /** Fiat amount for buys, crypto amount for sells, as a decimal string. */
  readonly amount: string;
  readonly walletAddress: Address;
  readonly externalTransactionId: string;
  readonly redirectURL: string;
}

const CURRENCY_CACHE_MS = 10 * 60_000;

export class MoonPayClient {
  readonly #o: MoonPayClientOptions;
  #cache: { at: number; list: MoonPayCurrency[] } | undefined;

  constructor(options: MoonPayClientOptions) {
    if (!/^pk_(test|live)_/.test(options.publishableKey)) throw new TypeError("MoonPay publishable key must start with pk_test_ or pk_live_");
    if (options.environment === "production" && options.publishableKey.startsWith("pk_test_")) {
      throw new TypeError("Test MoonPay key used with the production environment");
    }
    this.#o = options;
  }

  async currencies(): Promise<MoonPayCurrency[]> {
    const now = (this.#o.now ?? Date.now)();
    if (this.#cache !== undefined && now - this.#cache.at < CURRENCY_CACHE_MS) return this.#cache.list;
    const url = new URL("https://api.moonpay.com/v3/currencies");
    // Without `show`, MoonPay filters by the caller's IP; the server's location is irrelevant to users.
    url.searchParams.set("show", "enabled");
    url.searchParams.set("apiKey", this.#o.publishableKey);
    const { status, body } = await requestJson("moonpay", url, { method: "GET", headers: { accept: "application/json" } }, this.#o);
    if (status !== 200) throw errorForStatus("moonpay", status, body);
    if (!Array.isArray(body)) throw new ProviderError("moonpay", "PROVIDER_BAD_RESPONSE", "MoonPay currency list is invalid");
    const list = body.flatMap((c) => {
      const parsed = currencySchema.safeParse(c);
      return parsed.success ? [parsed.data] : [];
    });
    if (list.length === 0) throw new ProviderError("moonpay", "PROVIDER_BAD_RESPONSE", "MoonPay returned no currencies");
    this.#cache = { at: now, list };
    return list;
  }

  /** Builds and signs the hosted widget URL. Only server-chosen parameters are included. */
  widgetUrl(r: MoonPayWidgetRequest): URL {
    const host = MOONPAY_WIDGET_HOSTS[r.direction][this.#o.environment];
    const url = new URL(host);
    const p = url.searchParams;
    p.set("apiKey", this.#o.publishableKey);
    if (r.direction === "buy") {
      p.set("currencyCode", r.currencyCode);
      p.set("walletAddress", r.walletAddress);
      p.set("baseCurrencyCode", r.fiatCurrency);
      p.set("baseCurrencyAmount", r.amount);
    } else {
      p.set("baseCurrencyCode", r.currencyCode);
      p.set("baseCurrencyAmount", r.amount);
      p.set("quoteCurrencyCode", r.fiatCurrency);
      p.set("refundWalletAddress", r.walletAddress);
    }
    p.set("externalTransactionId", r.externalTransactionId);
    p.set("redirectURL", r.redirectURL);
    p.set("theme", "dark");
    p.set("colorCode", "#22F2D0");
    return signMoonPayWidgetUrl(url, this.#o.secretKey);
  }
}

const webhookSchema = z.object({
  type: z.string().max(64),
  data: z.object({
    id: z.string().min(1).max(128),
    status: z.string().max(64),
    externalTransactionId: z.string().max(128).nullable().optional(),
    updatedAt: z.string().max(64).nullable().optional(),
  }),
});

const BUY_STATUS: Readonly<Record<string, RampStatus>> = {
  waitingPayment: "pending",
  pending: "pending",
  waitingAuthorization: "pending",
  completed: "completed",
  failed: "failed",
};
const SELL_STATUS: Readonly<Record<string, RampStatus>> = {
  waitingForDeposit: "pending",
  pending: "pending",
  completed: "completed",
  failed: "failed",
};

export interface ParsedRampEvent {
  readonly eventId: string;
  readonly eventType: string;
  readonly orderId: string | null;
  readonly externalOrderId: string;
  readonly providerStatus: string;
  /** undefined when the provider status is not one Kavrix acts on. */
  readonly status: RampStatus | undefined;
}

/** Parses an already signature-verified MoonPay webhook body. */
export function parseMoonPayWebhook(rawBody: string): ParsedRampEvent | undefined {
  let json: unknown;
  try {
    json = JSON.parse(rawBody);
  } catch {
    return undefined;
  }
  const parsed = webhookSchema.safeParse(json);
  if (!parsed.success) return undefined;
  const { type, data } = parsed.data;
  if (!/^(sell_)?transaction_(created|updated|failed)$/.test(type)) return undefined;
  const table = type.startsWith("sell_") ? SELL_STATUS : BUY_STATUS;
  return {
    eventId: createHash("sha256").update(`${type}|${data.id}|${data.status}|${data.updatedAt ?? ""}`).digest("hex"),
    eventType: type,
    orderId: data.externalTransactionId ?? null,
    externalOrderId: data.id,
    providerStatus: data.status,
    status: Object.hasOwn(table, data.status) ? table[data.status] : undefined,
  };
}
