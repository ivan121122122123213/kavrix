export type ProviderName = "0x" | "kyberswap" | "moonpay" | "transak";

export type ProviderErrorCode =
  | "PROVIDER_UNAVAILABLE"
  | "PROVIDER_TIMEOUT"
  | "PROVIDER_REJECTED"
  | "PROVIDER_AUTH"
  | "PROVIDER_RATE_LIMITED"
  | "PROVIDER_BAD_RESPONSE"
  | "NO_LIQUIDITY"
  | "QUOTE_UNSAFE";

/**
 * Messages are written for logs and API problem details, so they must never contain
 * credentials, signed URLs or raw provider payloads.
 */
export class ProviderError extends Error {
  override readonly name = "ProviderError";
  readonly provider: ProviderName;
  readonly code: ProviderErrorCode;
  readonly httpStatus: number | undefined;
  readonly providerCode: string | undefined;

  constructor(
    provider: ProviderName,
    code: ProviderErrorCode,
    message: string,
    details: { httpStatus?: number; providerCode?: string; cause?: unknown } = {},
  ) {
    super(message, details.cause === undefined ? undefined : { cause: details.cause });
    this.provider = provider;
    this.code = code;
    this.httpStatus = details.httpStatus;
    this.providerCode = details.providerCode;
  }

  /** Whether a retry with the same input may succeed. */
  get retryable(): boolean {
    return (
      this.code === "PROVIDER_UNAVAILABLE" ||
      this.code === "PROVIDER_TIMEOUT" ||
      this.code === "PROVIDER_RATE_LIMITED"
    );
  }
}
