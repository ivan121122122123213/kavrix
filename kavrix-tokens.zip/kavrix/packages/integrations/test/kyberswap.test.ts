import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import type { Address } from "@kavrix/shared";
import { ProviderError } from "../src/errors.ts";
import { KYBER_SELECTORS, decodeKyberSwap } from "../src/kyberswap/abi.ts";
import { KyberSwapProvider, routeLegs } from "../src/kyberswap/client.ts";
import { RateGate } from "../src/swap/gate.ts";
import type { FetchLike } from "../src/http.ts";
import type { SwapRequest } from "../src/swap/types.ts";
import { KYBER_CALLDATA } from "./kyber-fixtures.ts";

const NATIVE: Address = "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee";
const USDC: Address = "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913";
const TAKER: Address = "0x70a9f34f9b34c64957b9c401a97bfed35b95049e";
const FEE: Address = "0x1111111111111111111111111111111111111111";
const ROUTER = "0x6131B5fae19EA4f9D964eAc0408E4408b66337b5";

const request: SwapRequest = { chainId: 8453, sellToken: NATIVE, buyToken: USDC, sellAmount: 10n ** 15n, slippageBps: 100, taker: TAKER };
const fee = { recipient: FEE, bps: 25 };

function routeBody(over: Record<string, unknown> = {}) {
  return {
    code: 0,
    message: "successfully",
    data: {
      routerAddress: ROUTER,
      routeSummary: {
        tokenIn: "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE",
        amountIn: "1000000000000000",
        amountInUsd: "3.5",
        tokenOut: USDC,
        amountOut: "3500000",
        amountOutUsd: "3.5",
        gas: "180000",
        gasPrice: "5000000",
        gasUsd: "0.003",
        l1FeeUsd: "0",
        extraFee: { feeAmount: "25", chargeFeeBy: "currency_in", isInBps: true, feeReceiver: FEE },
        route: [
          [{ pool: "0xp1", tokenIn: NATIVE, tokenOut: USDC, swapAmount: "700000000000000", amountOut: "2450000", exchange: "uniswap-v3", poolType: "x", poolExtra: {}, extra: {} }],
          [{ pool: "0xp2", tokenIn: NATIVE, tokenOut: USDC, swapAmount: "300000000000000", amountOut: "1050000", exchange: "aerodrome", poolType: "y", poolExtra: null, extra: null }],
        ],
        routeID: "abc",
        checksum: "123",
        timestamp: "1800000000",
        ...over,
      },
    },
  };
}

function buildBody(over: Record<string, unknown> = {}) {
  return {
    code: 0,
    data: {
      amountIn: "1000000000000000",
      amountInUsd: "3.5",
      amountOut: "3500000",
      amountOutUsd: "3.5",
      gas: "200000",
      gasUsd: "0.003",
      data: KYBER_CALLDATA.simple,
      routerAddress: ROUTER,
      transactionValue: "1000000000000000",
      ...over,
    },
  };
}

interface Call {
  method: string;
  url: URL;
  headers: Headers;
  body: unknown;
}

function fakeKyber(route: unknown, build: unknown, calls: Call[] = [], status = { route: 200, build: 200 }): FetchLike {
  return async (input, init) => {
    const url = new URL(input.toString());
    calls.push({ method: init?.method ?? "GET", url, headers: new Headers(init?.headers), body: init?.body ? JSON.parse(String(init.body)) : undefined });
    const isBuild = url.pathname.endsWith("/route/build");
    return Response.json(isBuild ? build : route, { status: isBuild ? status.build : status.route });
  };
}

const provider = (fetch: FetchLike) => new KyberSwapProvider({ clientId: "kavrix", fetch, now: () => 1_800_000_000_000 });

async function rejectsWith(p: Promise<unknown>, code: string) {
  await assert.rejects(p, (e: unknown) => e instanceof ProviderError && e.code === code);
}

describe("Kyber router calldata decoder", () => {
  it("uses the documented selectors", () => {
    const sha = createHash("sha256").update(JSON.stringify(KYBER_SELECTORS)).digest("hex");
    assert.equal(KYBER_SELECTORS.swap, "e21fd0e9");
    assert.equal(KYBER_SELECTORS.swapSimpleMode, "8af033fb");
    assert.ok(sha.length === 64);
  });

  it("decodes both entry points from independently encoded calldata", () => {
    for (const [key, fn] of [["simple", "swapSimpleMode"], ["full", "swap"]] as const) {
      const d = decodeKyberSwap(KYBER_CALLDATA[key]);
      assert.ok(d, key);
      assert.equal(d.fn, fn);
      assert.equal(d.srcToken, NATIVE);
      assert.equal(d.dstToken, USDC);
      assert.equal(d.dstReceiver, TAKER);
      assert.equal(d.amount, 10n ** 15n);
      assert.equal(d.minReturnAmount, 3_465_000n);
      assert.deepEqual(d.feeReceivers, [FEE]);
    }
  });

  it("rejects unknown selectors, truncation and garbage", () => {
    assert.equal(decodeKyberSwap(`0x095ea7b3${"00".repeat(64)}`), undefined);
    assert.equal(decodeKyberSwap(KYBER_CALLDATA.simple.slice(0, 200) as `0x${string}`), undefined);
    assert.equal(decodeKyberSwap(`0x8af033fb${"ff".repeat(128)}`), undefined);
    assert.equal(decodeKyberSwap("0x"), undefined);
  });
});

describe("KyberSwap provider", () => {
  it("returns a verified firm quote and sends documented parameters", async () => {
    const calls: Call[] = [];
    const out = await provider(fakeKyber(routeBody(), buildBody(), calls)).quote(request, fee);
    assert.equal(out.kind, "firm");
    if (out.kind !== "firm") return;
    assert.equal(out.quote.tx.to, "0x6131b5fae19ea4f9d964eac0408e4408b66337b5");
    assert.equal(out.quote.tx.value, 10n ** 15n);
    assert.equal(out.quote.minBuyAmount, 3_465_000n, "minimum comes from calldata");
    assert.equal(out.quote.spender, null, "native sells need no approval");
    assert.deepEqual(out.quote.platformFee, { bps: 25, amount: 2_500_000_000_000n, token: "sell" });
    assert.equal(out.quote.networkFeeWei, 200_000n * 5_000_000n);
    assert.deepEqual(out.quote.valueUsd, { sell: 3.5, buy: 3.5 }, "USD figures from the built transaction");
    assert.deepEqual(out.quote.valueUsd, { sell: 3.5, buy: 3.5 }, "USD figures from the build response");
    assert.deepEqual(out.quote.route, [
      { source: "uniswap-v3", proportionBps: 7000 },
      { source: "aerodrome", proportionBps: 3000 },
    ]);

    const [route, build] = calls;
    assert.equal(route?.url.origin + route!.url.pathname, "https://aggregator-api.kyberswap.com/base/api/v1/routes");
    assert.equal(route?.url.searchParams.get("chargeFeeBy"), "currency_in");
    assert.equal(route?.url.searchParams.get("feeAmount"), "25");
    assert.equal(route?.url.searchParams.get("isInBps"), "true");
    assert.equal(route?.headers.get("x-client-id"), "kavrix");
    const body = build?.body as Record<string, unknown>;
    assert.equal(body["sender"], TAKER);
    assert.equal(body["recipient"], TAKER);
    assert.equal(body["slippageTolerance"], 100);
    assert.equal((body["routeSummary"] as Record<string, unknown>)["checksum"], "123", "routeSummary forwarded verbatim");
  });

  it("returns an indicative price without calling build when there is no taker", async () => {
    const calls: Call[] = [];
    const { taker: _t, ...noTaker } = request;
    const out = await provider(fakeKyber(routeBody(), buildBody(), calls)).quote(noTaker, fee);
    assert.equal(out.kind, "indicative");
    assert.equal(calls.length, 1);
  });

  it("reports no route instead of inventing one", async () => {
    const out = await provider(fakeKyber({ code: 4008, message: "route not found", requestId: "r" }, {}, [], { route: 400, build: 200 })).quote(request, fee);
    assert.deepEqual(out, { kind: "no_route" });
  });

  it("fails closed on a wrong router, pair or amount", async () => {
    await rejectsWith(provider(fakeKyber({ ...routeBody(), data: { ...routeBody().data, routerAddress: FEE } }, buildBody())).quote(request, fee), "QUOTE_UNSAFE");
    await rejectsWith(provider(fakeKyber(routeBody({ tokenOut: NATIVE }), buildBody())).quote(request, fee), "QUOTE_UNSAFE");
    await rejectsWith(provider(fakeKyber(routeBody({ amountIn: "1" }), buildBody())).quote(request, fee), "QUOTE_UNSAFE");
    await rejectsWith(provider(fakeKyber(routeBody(), buildBody({ routerAddress: FEE }))).quote(request, fee), "QUOTE_UNSAFE");
    await rejectsWith(provider(fakeKyber(routeBody(), buildBody({ transactionValue: "0" }))).quote(request, fee), "QUOTE_UNSAFE");
  });

  it("fails closed when calldata disagrees with the request", async () => {
    await rejectsWith(provider(fakeKyber(routeBody(), buildBody({ data: KYBER_CALLDATA.simpleWrongReceiver }))).quote(request, fee), "QUOTE_UNSAFE");
    await rejectsWith(provider(fakeKyber(routeBody(), buildBody({ data: KYBER_CALLDATA.simpleForeignFee }))).quote(request, fee), "QUOTE_UNSAFE");
    await rejectsWith(provider(fakeKyber(routeBody(), buildBody({ data: KYBER_CALLDATA.simpleLowMin }))).quote(request, fee), "QUOTE_UNSAFE");
    await rejectsWith(provider(fakeKyber(routeBody(), buildBody({ data: "0x095ea7b3" + "00".repeat(64) }))).quote(request, fee), "QUOTE_UNSAFE");
    // Fee receiver present in calldata although no platform fee was requested.
    await rejectsWith(provider(fakeKyber(routeBody(), buildBody())).quote(request, undefined), "QUOTE_UNSAFE");
  });

  it("enforces limits before any network call", async () => {
    const p = provider(async () => assert.fail("must not fetch"));
    await assert.rejects(p.quote({ ...request, slippageBps: 2001 }, fee));
    await assert.rejects(p.quote({ ...request, sellAmount: 0n }, fee));
    await assert.rejects(p.quote({ ...request, buyToken: NATIVE }, fee));
    await assert.rejects(p.quote(request, { recipient: FEE, bps: 301 }));
  });

  it("maps provider outages and its own rate gate", async () => {
    await rejectsWith(provider(fakeKyber({}, {}, [], { route: 503, build: 200 })).quote(request, fee), "PROVIDER_UNAVAILABLE");
    const gated = new KyberSwapProvider({ clientId: "kavrix", gate: new RateGate(1, () => 0), fetch: fakeKyber(routeBody(), buildBody()) });
    await rejectsWith(gated.quote(request, fee), "PROVIDER_RATE_LIMITED");
  });
});

describe("USD estimates", () => {
  it("are optional and never break a quote", async () => {
    const noUsd = routeBody({ amountInUsd: undefined, amountOutUsd: undefined });
    const out = await provider(fakeKyber(noUsd, buildBody({ amountInUsd: undefined, amountOutUsd: undefined }))).quote(request, fee);
    assert.equal(out.kind, "firm");
    if (out.kind === "firm") assert.equal(out.quote.valueUsd, null);
    const junk = await provider(fakeKyber(routeBody({ amountInUsd: "NaN", amountOutUsd: "-1" }), buildBody({ amountInUsd: "abc" }))).quote(request, fee);
    assert.equal(junk.kind, "firm", "malformed USD fields are ignored, not fatal");
    if (junk.kind === "firm") assert.equal(junk.quote.valueUsd, null);
  });
});

describe("route legs and rate gate", () => {
  it("labels multi-hop paths and handles empty input", () => {
    const legs = routeLegs([[
      { pool: "a", tokenIn: NATIVE, tokenOut: USDC, swapAmount: "10", amountOut: "1", exchange: "curve" },
      { pool: "b", tokenIn: USDC, tokenOut: NATIVE, swapAmount: "1", amountOut: "1", exchange: "uniswap-v3" },
    ]], 10n);
    assert.deepEqual(legs, [{ source: "curve → uniswap-v3", proportionBps: 10_000 }]);
    assert.deepEqual(routeLegs([], 0n), []);
  });

  it("refills over time and never exceeds capacity", () => {
    let t = 0;
    const gate = new RateGate(3, () => t);
    assert.equal([gate.tryTake(), gate.tryTake(), gate.tryTake(), gate.tryTake()].filter(Boolean).length, 3);
    t = 334;
    assert.equal(gate.tryTake(), true);
    assert.equal(gate.tryTake(), false);
    t = 100_000;
    assert.equal(gate.tryTake(3), true);
    assert.equal(gate.tryTake(), false);
  });
});

import { usdPair } from "../src/kyberswap/client.ts";

describe("USD figures", () => {
  it("are informational and dropped unless both are valid", () => {
    assert.deepEqual(usdPair("10.5", "10.4"), { sell: 10.5, buy: 10.4 });
    assert.equal(usdPair("10.5", undefined), null);
    assert.equal(usdPair(undefined, "1"), null);
  });

  it("never break a quote when malformed", async () => {
    const out = await provider(fakeKyber(routeBody({ amountInUsd: "NaN", amountOutUsd: "-1" }), buildBody({ amountInUsd: "x", amountOutUsd: "y" }))).quote(request, fee);
    assert.equal(out.kind, "firm");
    if (out.kind === "firm") assert.equal(out.quote.valueUsd, null);
  });
});
