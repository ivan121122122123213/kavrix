import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { ProviderError } from "../src/errors.ts";
import { ZeroExClient, buildQuery, type ZeroExSwapParams } from "../src/zeroex/client.ts";
import { FEE_RECIPIENT, NATIVE, TAKER, USDC, WETH, mockFetch, quoteBody, type Captured } from "./fixtures.ts";

const params: ZeroExSwapParams = {
  chainId: 8453,
  sellToken: USDC,
  buyToken: WETH,
  sellAmount: 1_000_000n,
  taker: TAKER,
  slippageBps: 100,
  fee: { recipient: FEE_RECIPIENT, bps: 25 },
};

function client(status: number, body: unknown, captured?: Captured) {
  return new ZeroExClient({ apiKey: "test-key", fetch: mockFetch(status, body, captured) });
}

async function rejectsWith(promise: Promise<unknown>, code: string) {
  await assert.rejects(promise, (err: unknown) => err instanceof ProviderError && err.code === code);
}

describe("0x request building", () => {
  it("sends documented headers and parameters", async () => {
    const captured: Captured = {};
    await client(200, quoteBody(), captured).getQuote(params);
    assert.equal(captured.url?.pathname, "/swap/allowance-holder/quote");
    const q = captured.url?.searchParams;
    assert.equal(q?.get("chainId"), "8453");
    assert.equal(q?.get("sellAmount"), "1000000");
    assert.equal(q?.get("slippagePpm"), "10000");
    assert.equal(q?.get("swapFeeBps"), "25");
    assert.equal(q?.get("swapFeeToken"), WETH);
    const headers = new Headers(captured.init?.headers);
    assert.equal(headers.get("0x-api-key"), "test-key");
    assert.equal(headers.get("0x-version"), "v2");
  });

  it("rejects invalid input before any network call", () => {
    assert.throws(() => buildQuery({ ...params, chainId: 10 as 1 }), RangeError);
    assert.throws(() => buildQuery({ ...params, sellAmount: 0n }), RangeError);
    assert.throws(() => buildQuery({ ...params, buyToken: USDC }), RangeError);
    assert.throws(() => buildQuery({ ...params, slippageBps: 9000 }));
    assert.throws(() => buildQuery({ ...params, fee: { recipient: FEE_RECIPIENT, bps: 1000 } }));
  });
});

describe("0x quote validation", () => {
  it("accepts a consistent quote", async () => {
    const result = await client(200, quoteBody()).getQuote(params);
    assert.equal(result.liquidityAvailable, true);
  });

  it("reports missing liquidity without inventing a quote", async () => {
    const result = await client(200, { liquidityAvailable: false, zid: "0x1" }).getQuote(params);
    assert.deepEqual(result, { liquidityAvailable: false });
  });

  it("fails closed on an unexpected transaction target", async () => {
    await rejectsWith(client(200, quoteBody({}, { to: FEE_RECIPIENT })).getQuote(params), "QUOTE_UNSAFE");
  });

  it("fails closed on an unexpected allowance spender", async () => {
    const body = quoteBody({ issues: { allowance: { actual: "0", spender: FEE_RECIPIENT }, balance: null, simulationIncomplete: false, invalidSourcesPassed: [] } });
    await rejectsWith(client(200, body).getQuote(params), "QUOTE_UNSAFE");
  });

  it("fails closed when value does not match the native sell amount", async () => {
    const nativeParams = { ...params, sellToken: NATIVE, sellAmount: 10n ** 15n };
    const body = quoteBody({ sellToken: NATIVE, sellAmount: "1000000000000000" }, { value: "1" });
    await rejectsWith(client(200, body).getQuote(nativeParams), "QUOTE_UNSAFE");
    const ok = quoteBody({ sellToken: NATIVE, sellAmount: "1000000000000000" }, { value: "1000000000000000" });
    assert.equal((await client(200, ok).getQuote(nativeParams)).liquidityAvailable, true);
  });

  it("fails closed on pair, amount or min-output mismatch", async () => {
    await rejectsWith(client(200, quoteBody({ buyToken: USDC })).getQuote(params), "QUOTE_UNSAFE");
    await rejectsWith(client(200, quoteBody({ sellAmount: "999999" })).getQuote(params), "QUOTE_UNSAFE");
    await rejectsWith(client(200, quoteBody({ minBuyAmount: "500000000000000" })).getQuote(params), "QUOTE_UNSAFE");
  });

  it("fails closed when a requested fee is missing or an unrequested fee appears", async () => {
    const noFee = quoteBody({ fees: { integratorFee: null, zeroExFee: null, gasFee: null } });
    await rejectsWith(client(200, noFee).getQuote(params), "QUOTE_UNSAFE");
    const { fee: _fee, ...withoutFee } = params;
    await rejectsWith(client(200, quoteBody()).getQuote(withoutFee), "QUOTE_UNSAFE");
  });

  it("rejects malformed provider payloads", async () => {
    await rejectsWith(client(200, quoteBody({ buyAmount: "1.5" })).getQuote(params), "PROVIDER_BAD_RESPONSE");
    await rejectsWith(client(200, "<html>").getQuote(params), "PROVIDER_BAD_RESPONSE");
  });
});

describe("0x error mapping", () => {
  it("maps HTTP failures to typed, retry-aware errors", async () => {
    await rejectsWith(client(400, { name: "INPUT_INVALID" }).getQuote(params), "PROVIDER_REJECTED");
    await rejectsWith(client(401, {}).getQuote(params), "PROVIDER_AUTH");
    await rejectsWith(client(429, {}).getQuote(params), "PROVIDER_RATE_LIMITED");
    await rejectsWith(client(503, "").getQuote(params), "PROVIDER_UNAVAILABLE");
  });

  it("does not leak the API key in error messages", async () => {
    try {
      await client(401, {}).getQuote(params);
      assert.fail("expected rejection");
    } catch (err) {
      assert.ok(err instanceof ProviderError);
      assert.equal(String(err.message).includes("test-key"), false);
    }
  });

  it("maps network failures and timeouts", async () => {
    const down = new ZeroExClient({ apiKey: "k", fetch: async () => { throw new TypeError("fetch failed"); } });
    await rejectsWith(down.getQuote(params), "PROVIDER_UNAVAILABLE");
    const slow = new ZeroExClient({
      apiKey: "k",
      timeoutMs: 20,
      fetch: (_url, init) =>
        new Promise((_resolve, reject) => {
          // AbortSignal.timeout uses an unref'd timer; keep the test loop alive until it fires.
          const keepAlive = setTimeout(() => undefined, 1_000);
          init?.signal?.addEventListener("abort", () => {
            clearTimeout(keepAlive);
            reject(init.signal?.reason);
          });
        }),
    });
    await rejectsWith(slow.getQuote(params), "PROVIDER_TIMEOUT");
  });
});
