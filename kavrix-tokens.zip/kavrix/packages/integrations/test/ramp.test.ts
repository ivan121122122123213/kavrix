import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createHmac } from "node:crypto";
import { MoonPayClient, parseMoonPayWebhook, resolveMoonPayCurrency, type MoonPayCurrency } from "../src/moonpay/client.ts";
import { parseTransakWebhook, transakWidgetParams } from "../src/transak/ramp.ts";
import { TransakClient, type StoredTransakToken } from "../src/transak/client.ts";

const USDC_BASE = "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913";
const NATIVE = "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee";
const WALLET = "0x70a9f34f9b34c64957b9c401a97bfed35b95049e";

const currencies: MoonPayCurrency[] = [
  { type: "fiat", code: "usd" },
  { type: "crypto", code: "eth", isSellSupported: true, metadata: { contractAddress: "0x0000000000000000000000000000000000000000", chainId: "1" } },
  { type: "crypto", code: "eth_base", isSellSupported: false, metadata: { contractAddress: null, chainId: "8453" } },
  { type: "crypto", code: "usdc_base", isSellSupported: true, metadata: { contractAddress: "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913", chainId: "8453" } },
  { type: "crypto", code: "usdc_suspended", isSuspended: true, metadata: { contractAddress: "0xaf88d065e77c8cc2239327c5edb3a432268e5831", chainId: "42161" } },
];

describe("MoonPay currency resolution", () => {
  it("maps chain + contract to MoonPay's code from its own metadata", () => {
    assert.equal(resolveMoonPayCurrency(currencies, 8453, USDC_BASE, "buy"), "usdc_base");
    assert.equal(resolveMoonPayCurrency(currencies, 8453, NATIVE, "buy"), "eth_base");
    assert.equal(resolveMoonPayCurrency(currencies, 1, NATIVE, "sell"), "eth");
  });

  it("fails closed for sell-disabled, suspended, unknown or ambiguous assets", () => {
    assert.equal(resolveMoonPayCurrency(currencies, 8453, NATIVE, "sell"), undefined);
    assert.equal(resolveMoonPayCurrency(currencies, 42161, "0xaf88d065e77c8cc2239327c5edb3a432268e5831", "buy"), undefined);
    assert.equal(resolveMoonPayCurrency(currencies, 137, NATIVE, "buy"), undefined);
    const dup = [...currencies, { ...currencies[3]!, code: "usdc_base_2" }];
    assert.equal(resolveMoonPayCurrency(dup, 8453, USDC_BASE, "buy"), undefined);
  });
});

describe("MoonPay widget URL", () => {
  const client = new MoonPayClient({ environment: "sandbox", publishableKey: "pk_test_abc", secretKey: "sk_test_xyz" });

  it("builds a signed buy URL with only server-chosen parameters", () => {
    const url = client.widgetUrl({ direction: "buy", currencyCode: "usdc_base", fiatCurrency: "usd", amount: "100", walletAddress: WALLET, externalTransactionId: "order-1", redirectURL: "https://kavrix.example/history" });
    assert.equal(url.origin, "https://buy-sandbox.moonpay.com");
    assert.equal(url.searchParams.get("walletAddress"), WALLET);
    assert.equal(url.searchParams.get("baseCurrencyCode"), "usd");
    const sig = url.searchParams.get("signature");
    url.searchParams.delete("signature");
    assert.equal(sig, createHmac("sha256", "sk_test_xyz").update(url.search).digest("base64"));
  });

  it("builds a sell URL with a refund address", () => {
    const url = client.widgetUrl({ direction: "sell", currencyCode: "eth", fiatCurrency: "eur", amount: "0.5", walletAddress: WALLET, externalTransactionId: "order-2", redirectURL: "https://kavrix.example/history" });
    assert.equal(url.origin, "https://sell-sandbox.moonpay.com");
    assert.equal(url.searchParams.get("refundWalletAddress"), WALLET);
    assert.equal(url.searchParams.get("quoteCurrencyCode"), "eur");
  });

  it("refuses test keys in production", () => {
    assert.throws(() => new MoonPayClient({ environment: "production", publishableKey: "pk_test_x", secretKey: "s" }));
  });
});

describe("webhook parsing", () => {
  it("maps MoonPay buy and sell statuses and echoes our order id", () => {
    const buy = parseMoonPayWebhook(JSON.stringify({ type: "transaction_updated", data: { id: "mp-1", status: "completed", externalTransactionId: "order-1", updatedAt: "t" } }));
    assert.equal(buy?.status, "completed");
    assert.equal(buy?.orderId, "order-1");
    const sell = parseMoonPayWebhook(JSON.stringify({ type: "sell_transaction_created", data: { id: "mp-2", status: "waitingForDeposit" } }));
    assert.equal(sell?.status, "pending");
    assert.equal(sell?.orderId, null);
    const unknown = parseMoonPayWebhook(JSON.stringify({ type: "transaction_updated", data: { id: "mp-1", status: "somethingNew" } }));
    assert.equal(unknown?.status, undefined);
    assert.equal(parseMoonPayWebhook(JSON.stringify({ type: "identity_check_updated", data: { id: "x", status: "y" } })), undefined);
    assert.equal(parseMoonPayWebhook("{"), undefined);
  });

  it("gives the same event the same id and different states different ids", () => {
    const a = parseMoonPayWebhook(JSON.stringify({ type: "transaction_updated", data: { id: "mp-1", status: "pending", updatedAt: "1" } }));
    const b = parseMoonPayWebhook(JSON.stringify({ type: "transaction_updated", data: { id: "mp-1", status: "pending", updatedAt: "1" } }));
    const c = parseMoonPayWebhook(JSON.stringify({ type: "transaction_updated", data: { id: "mp-1", status: "completed", updatedAt: "2" } }));
    assert.equal(a?.eventId, b?.eventId);
    assert.notEqual(a?.eventId, c?.eventId);
  });

  it("maps Transak statuses including expiry of a pending order", () => {
    const ev = (status: string) => parseTransakWebhook({ eventID: "ORDER_FAILED", webhookData: { id: "tk-1", status, partnerOrderId: "order-3" } });
    assert.equal(ev("EXPIRED")?.status, "expired");
    assert.equal(ev("CANCELLED")?.status, "cancelled");
    assert.equal(ev("PENDING_DELIVERY_FROM_TRANSAK")?.status, "pending");
    assert.equal(ev("COMPLETED")?.orderId, "order-3");
    assert.equal(parseTransakWebhook({ nope: 1 }), undefined);
  });

  it("builds Transak params that lock the destination wallet for buys", () => {
    const buy = transakWidgetParams({ direction: "buy", chainId: 8453, cryptoSymbol: "USDC", fiatCurrency: "EUR", amount: "100", walletAddress: WALLET, partnerOrderId: "o", redirectURL: "https://k/h" });
    assert.equal(buy["network"], "base");
    assert.equal(buy["disableWalletAddressForm"], true);
    assert.equal(buy["fiatAmount"], 100);
    const sell = transakWidgetParams({ direction: "sell", chainId: 137, cryptoSymbol: "USDC", fiatCurrency: "USD", amount: "25.5", walletAddress: WALLET, partnerOrderId: "o", redirectURL: "https://k/h" });
    assert.equal(sell["productsAvailed"], "SELL");
    assert.equal(sell["cryptoAmount"], 25.5);
    assert.equal(sell["walletAddress"], undefined);
  });
});

describe("Transak token persistence", () => {
  it("reuses a stored token and persists refreshed ones with the previous token", async () => {
    let stored: StoredTransakToken | null = { accessToken: "stored-token-".padEnd(40, "x"), expiresAt: 2_000_000_000, previous: null };
    let refreshes = 0;
    const client = new TransakClient({
      environment: "staging", apiKey: "pk", apiSecret: "sk", now: () => 1_000_000_000_000,
      tokenStore: { load: async () => stored, save: async (t) => { stored = t; } },
      fetch: async () => {
        refreshes++;
        return Response.json({ data: { accessToken: "fresh-token-".padEnd(40, "y"), expiresAt: 2_100_000_000 } });
      },
    });
    assert.deepEqual(await client.webhookSecrets(), ["stored-token-".padEnd(40, "x")]);
    assert.equal(refreshes, 0);

    stored = { accessToken: "old-token-".padEnd(40, "z"), expiresAt: 1, previous: null };
    const fresh = new TransakClient({
      environment: "staging", apiKey: "pk", apiSecret: "sk", now: () => 1_000_000_000_000,
      tokenStore: { load: async () => stored, save: async (t) => { stored = t; } },
      fetch: async () => Response.json({ data: { accessToken: "fresh-token-".padEnd(40, "y"), expiresAt: 2_100_000_000 } }),
    });
    await fresh.getAccessToken();
    assert.equal(stored?.accessToken, "fresh-token-".padEnd(40, "y"));
    assert.equal(stored?.previous, "old-token-".padEnd(40, "z"), "old token kept for in-flight webhooks");
  });
});
