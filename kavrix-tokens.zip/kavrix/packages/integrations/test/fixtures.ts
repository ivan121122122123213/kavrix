import type { Address } from "@kavrix/shared";
import type { FetchLike } from "../src/http.ts";

export const USDC: Address = "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913";
export const WETH: Address = "0x4200000000000000000000000000000000000006";
export const NATIVE: Address = "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee";
export const TAKER: Address = "0x70a9f34f9b34c64957b9c401a97bfed35b95049e";
export const FEE_RECIPIENT: Address = "0x1111111111111111111111111111111111111111";
export const ALLOWANCE_HOLDER: Address = "0x0000000000001ff3684f28c67538d4d072c22734";

export interface Captured {
  url?: URL;
  init?: RequestInit;
}

export function mockFetch(status: number, body: unknown, captured: Captured = {}): FetchLike {
  return async (input, init) => {
    captured.url = new URL(input.toString());
    if (init !== undefined) captured.init = init;
    const text = typeof body === "string" ? body : JSON.stringify(body);
    return new Response(text, { status, headers: { "content-type": "application/json" } });
  };
}

export function quoteBody(overrides: Record<string, unknown> = {}, txOverrides: Record<string, unknown> = {}) {
  return {
    allowanceTarget: ALLOWANCE_HOLDER,
    blockNumber: "21000000",
    buyAmount: "400000000000000",
    buyToken: WETH,
    fees: {
      integratorFee: { amount: "1000000000000", token: WETH, type: "volume" },
      zeroExFee: { amount: "600000000000", token: WETH, type: "volume" },
      gasFee: null,
    },
    issues: {
      allowance: { actual: "0", spender: ALLOWANCE_HOLDER },
      balance: null,
      simulationIncomplete: false,
      invalidSourcesPassed: [],
    },
    liquidityAvailable: true,
    minBuyAmount: "396000000000000",
    route: {
      fills: [{ from: USDC, to: WETH, source: "Uniswap_V3", proportionBps: "10000" }],
      tokens: [
        { address: USDC, symbol: "USDC" },
        { address: WETH, symbol: "WETH" },
      ],
    },
    sellAmount: "1000000",
    sellToken: USDC,
    totalNetworkFee: "1500000000000",
    zid: "0x111111111111111111111111",
    transaction: {
      to: ALLOWANCE_HOLDER,
      data: "0x2213bc0b0000000000000000000000000000000000000000000000000000000000000001",
      gas: "250000",
      gasPrice: "6000000",
      value: "0",
      ...txOverrides,
    },
    ...overrides,
  };
}
