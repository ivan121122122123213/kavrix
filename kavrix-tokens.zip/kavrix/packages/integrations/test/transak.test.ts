import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createHmac } from "node:crypto";
import { ProviderError } from "../src/errors.ts";
import { verifyHs256Jwt } from "../src/transak/jwt.ts";
import { TransakClient } from "../src/transak/client.ts";
import type { FetchLike } from "../src/http.ts";

function b64url(value: unknown): string {
  return Buffer.from(JSON.stringify(value)).toString("base64url");
}

function sign(payload: unknown, secret: string, header: unknown = { alg: "HS256", typ: "JWT" }): string {
  const input = `${b64url(header)}.${b64url(payload)}`;
  return `${input}.${createHmac("sha256", secret).update(input).digest("base64url")}`;
}

describe("Transak webhook JWT", () => {
  const payload = { webhookData: { id: "order-1", status: "COMPLETED" }, eventID: "ORDER_COMPLETED" };

  it("verifies with the current or the previous access token", () => {
    const token = sign(payload, "old-token");
    const result = verifyHs256Jwt(token, ["new-token", "old-token"]);
    assert.equal(result.ok, true);
  });

  it("rejects alg confusion, tampering and expiry", () => {
    assert.deepEqual(verifyHs256Jwt(sign(payload, "s", { alg: "none" }), ["s"]), { ok: false, reason: "unsupported_alg" });
    const good = sign(payload, "s");
    const [h, , sig] = good.split(".");
    assert.deepEqual(verifyHs256Jwt(`${h}.${b64url({ ...payload, eventID: "X" })}.${sig}`, ["s"]), { ok: false, reason: "mismatch" });
    assert.deepEqual(verifyHs256Jwt(sign({ exp: 10 }, "s"), ["s"], 11), { ok: false, reason: "expired" });
    assert.deepEqual(verifyHs256Jwt("a.b", ["s"]), { ok: false, reason: "malformed" });
    assert.deepEqual(verifyHs256Jwt(good, []), { ok: false, reason: "mismatch" });
    assert.deepEqual(verifyHs256Jwt(good, [""]), { ok: false, reason: "mismatch" });
  });
});

describe("Transak client", () => {
  function routes(widgetUrl: string, calls: string[]): FetchLike {
    return async (input) => {
      const url = new URL(input.toString());
      calls.push(url.pathname);
      if (url.pathname === "/partners/api/v2/refresh-token") {
        return Response.json({ data: { accessToken: "a".repeat(40), expiresAt: 2_000_000_000 } });
      }
      return Response.json({ data: { widgetUrl } });
    };
  }

  it("caches the access token and creates a widget session", async () => {
    const calls: string[] = [];
    const client = new TransakClient({
      environment: "staging",
      apiKey: "pk",
      apiSecret: "sk",
      now: () => 1_000_000_000_000,
      fetch: routes("https://global-stg.transak.com?apiKey=pk&sessionId=abc", calls),
    });
    const first = await client.createWidgetUrl({ cryptoCurrencyCode: "ETH" }, "203.0.113.5", "kavrix.example");
    await client.createWidgetUrl({ cryptoCurrencyCode: "ETH" }, "203.0.113.5", "kavrix.example");
    assert.equal(first.searchParams.get("sessionId"), "abc");
    assert.deepEqual(calls, ["/partners/api/v2/refresh-token", "/api/v2/auth/session", "/api/v2/auth/session"]);
  });

  it("rejects a widget URL on an unexpected host", async () => {
    const client = new TransakClient({
      environment: "production",
      apiKey: "pk",
      apiSecret: "sk",
      now: () => 1_000_000_000_000,
      fetch: routes("https://evil.example/?sessionId=abc", []),
    });
    await assert.rejects(
      client.createWidgetUrl({}, "203.0.113.5", "kavrix.example"),
      (err: unknown) => err instanceof ProviderError && err.code === "PROVIDER_BAD_RESPONSE",
    );
  });
});
