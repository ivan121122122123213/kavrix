import { describe, it } from "node:test";
import assert from "node:assert/strict";
import type { Address } from "@kavrix/shared";
import { decideCandidates, type CuratedToken } from "../src/tokens/candidates.ts";
import { KyberTokenClient, parseKyberTokens, parseTokenList } from "../src/tokens/sources.ts";
import type { SourceToken } from "../src/tokens/types.ts";
import { ProviderError } from "../src/errors.ts";

const PEPE = "0x6982508145454ce325ddbe47a25d4ec3d2311933" as Address;
const USDC = "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48" as Address;
const FAKE = "0x1111111111111111111111111111111111111111" as Address;
const curated: CuratedToken[] = [{ chainId: 1, address: USDC, symbol: "USDC" }];

const tok = (o: Partial<SourceToken> & Pick<SourceToken, "source" | "address">): SourceToken => ({
  chainId: 1, symbol: "PEPE", name: "Pepe", decimals: 18, logoUrl: null, ...o,
});

describe("listing policy", () => {
  it("auto-lists a KyberSwap-whitelisted token confirmed by an independent list", () => {
    const [c] = decideCandidates([tok({ source: "kyberswap", address: PEPE, cmcRank: 40 }), tok({ source: "coingecko", address: PEPE })], curated);
    assert.equal(c?.decision.kind, "auto");
    assert.deepEqual(c?.sources, ["coingecko", "kyberswap"]);
    assert.equal(c?.risk, "standard", "top-300 by market cap");
    assert.equal(c?.rank, 40);
  });

  it("flags long-tail tokens as high risk and single-source tokens as pending", () => {
    const [meme] = decideCandidates([tok({ source: "kyberswap", address: PEPE, cmcRank: 2500 }), tok({ source: "coingecko", address: PEPE })], curated);
    assert.equal(meme?.risk, "high");
    const [solo] = decideCandidates([tok({ source: "kyberswap", address: PEPE })], curated);
    assert.equal(solo?.decision.kind, "pending");
    const [listOnly] = decideCandidates([tok({ source: "coingecko", address: PEPE }), tok({ source: "uniswap", address: PEPE })], curated);
    assert.equal(listOnly?.decision.kind, "pending", "without KyberSwap's whitelist the aggregator may not route it");
  });

  it("rejects impersonation of curated tokens and of the native coin", () => {
    const [fakeUsdc] = decideCandidates([tok({ source: "kyberswap", address: FAKE, symbol: "usdc" }), tok({ source: "coingecko", address: FAKE, symbol: "usdc" })], curated);
    assert.equal(fakeUsdc?.decision.kind, "reject");
    const [fakeEth] = decideCandidates([tok({ source: "kyberswap", address: FAKE, symbol: "ETH" }), tok({ source: "uniswap", address: FAKE, symbol: "ETH" })], curated);
    assert.equal(fakeEth?.decision.kind, "reject");
    const [realUsdc] = decideCandidates([tok({ source: "kyberswap", address: USDC, symbol: "USDC", decimals: 6 }), tok({ source: "uniswap", address: USDC, symbol: "USDC", decimals: 6 })], curated);
    assert.notEqual(realUsdc?.decision.kind, "reject", "the curated address itself is fine");
  });

  it("rejects honeypots, fee-on-transfer tokens, decimal disagreements and odd symbols", () => {
    const kinds = [
      [tok({ source: "kyberswap", address: PEPE, isHoneypot: true }), tok({ source: "coingecko", address: PEPE })],
      [tok({ source: "kyberswap", address: PEPE, isFeeOnTransfer: true }), tok({ source: "coingecko", address: PEPE })],
      [tok({ source: "kyberswap", address: PEPE, decimals: 18 }), tok({ source: "coingecko", address: PEPE, decimals: 9 })],
      [tok({ source: "kyberswap", address: PEPE, symbol: "PEPE\u200b" }), tok({ source: "coingecko", address: PEPE, symbol: "PEPE\u200b" })],
      [tok({ source: "kyberswap", address: PEPE, symbol: "P E P E" }), tok({ source: "coingecko", address: PEPE, symbol: "P E P E" })],
    ].map((pair) => decideCandidates(pair, curated)[0]?.decision.kind);
    assert.deepEqual(kinds, ["reject", "reject", "reject", "reject", "reject"]);
  });

  it("keeps only https logos and sorts by rank", () => {
    const out = decideCandidates(
      [
        tok({ source: "kyberswap", address: PEPE, cmcRank: 50, logoUrl: "javascript:alert(1)" }),
        tok({ source: "uniswap", address: PEPE, logoUrl: "https://example.com/pepe.png" }),
        tok({ source: "kyberswap", address: FAKE, symbol: "AAA", cmcRank: 5 }),
        tok({ source: "uniswap", address: FAKE, symbol: "AAA" }),
      ],
      curated,
    );
    assert.deepEqual(out.map((c) => c.symbol), ["AAA", "PEPE"]);
    assert.equal(out[1]?.logoUrl, "https://example.com/pepe.png");
  });
});

describe("source parsing", () => {
  it("reads Token Lists, keeps only Kavrix networks and skips bad rows", () => {
    const tokens = parseTokenList(
      {
        name: "x",
        tokens: [
          { chainId: 1, address: PEPE.toUpperCase().replace("0X", "0x"), symbol: "PEPE", name: "Pepe", decimals: 18, logoURI: "ipfs://x" },
          { chainId: 56, address: PEPE, symbol: "PEPE", name: "Pepe", decimals: 18 },
          { chainId: 1, address: "0xnope", symbol: "BAD", name: "Bad", decimals: 18 },
        ],
      },
      "uniswap",
    );
    assert.equal(tokens.length, 1);
    assert.equal(tokens[0]?.address, PEPE);
    assert.equal(tokens[0]?.logoUrl, null, "non-https logo dropped");
    assert.throws(() => parseTokenList({ nope: 1 }, "coingecko"), ProviderError);
  });

  it("reads KyberSwap tokens in any envelope and keeps only whitelisted ones", () => {
    const row = { address: PEPE, symbol: "PEPE", name: "Pepe", decimals: 18, isWhitelisted: true, cmcRank: 40, isHoneypot: false, isFOT: false };
    for (const body of [{ data: { tokens: [row] } }, { data: [row] }, { tokens: [row] }]) assert.equal(parseKyberTokens(body, 1).length, 1);
    assert.equal(parseKyberTokens({ data: { tokens: [{ ...row, isWhitelisted: false }] } }, 1).length, 0);
    assert.throws(() => parseKyberTokens({ data: "?" }, 1), ProviderError);
  });

  it("treats an unknown honeypot answer as an error, never as safe", async () => {
    const client = (body: unknown) => new KyberTokenClient({ clientId: "kavrix", fetch: async () => Response.json(body) });
    assert.deepEqual(await client({ data: { isHoneypot: false, isFOT: true, tax: 5 } }).safety(1, PEPE), { isHoneypot: false, isFeeOnTransfer: true });
    await assert.rejects(client({ data: {} }).safety(1, PEPE), ProviderError);
  });

  it("pages through KyberSwap's whitelist until a short page", async () => {
    let calls = 0;
    const row = (i: number) => ({ address: `0x${i.toString(16).padStart(40, "0")}`, symbol: `T${i}`, name: `T ${i}`, decimals: 18, isWhitelisted: true });
    const client = new KyberTokenClient({
      clientId: "kavrix",
      fetch: async (url) => {
        calls++;
        const page = Number(new URL(url.toString()).searchParams.get("page"));
        return Response.json({ data: { tokens: page === 1 ? [row(1), row(2)] : [row(3)] } });
      },
    });
    assert.equal((await client.whitelisted(1, 10, 2)).length, 3);
    assert.equal(calls, 2);
  });
});
