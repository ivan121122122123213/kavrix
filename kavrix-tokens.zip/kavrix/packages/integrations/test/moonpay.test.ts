import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createHmac } from "node:crypto";
import { signMoonPayWidgetUrl, verifyMoonPayWebhook } from "../src/moonpay/signing.ts";

describe("MoonPay widget URL signing", () => {
  it("signs the exact query string", () => {
    const url = new URL("https://buy-sandbox.moonpay.com/?apiKey=pk_test_x&currencyCode=eth&walletAddress=0xabc");
    const signed = signMoonPayWidgetUrl(url, "sk_test");
    const expected = createHmac("sha256", "sk_test").update(url.search).digest("base64");
    assert.equal(signed.searchParams.get("signature"), expected);
    assert.equal(url.searchParams.has("signature"), false, "input must not be mutated");
  });

  it("refuses double signing and empty keys", () => {
    assert.throws(() => signMoonPayWidgetUrl(new URL("https://x.test/?signature=a"), "k"));
    assert.throws(() => signMoonPayWidgetUrl(new URL("https://x.test/?a=b"), ""));
  });
});

describe("MoonPay webhook verification", () => {
  const key = "wk_test";
  const body = '{"type":"transaction_updated","data":{"id":"1"}}';
  const t = 1_800_000_000;
  const sig = createHmac("sha256", key).update(`${t}.${body}`).digest("hex");

  it("accepts a valid, fresh signature", () => {
    assert.deepEqual(verifyMoonPayWebhook(`t=${t},s=${sig}`, body, key, { nowSeconds: t + 10 }), { ok: true, timestamp: t });
  });

  it("rejects tampering, replays and malformed headers", () => {
    assert.equal(verifyMoonPayWebhook(`t=${t},s=${sig}`, `${body} `, key, { nowSeconds: t }).ok, false);
    assert.deepEqual(verifyMoonPayWebhook(`t=${t},s=${sig}`, body, key, { nowSeconds: t + 3600 }), { ok: false, reason: "stale" });
    assert.deepEqual(verifyMoonPayWebhook(undefined, body, key), { ok: false, reason: "malformed" });
    assert.deepEqual(verifyMoonPayWebhook(`t=${t}`, body, key, { nowSeconds: t }), { ok: false, reason: "malformed" });
    assert.deepEqual(verifyMoonPayWebhook(`t=${t},s=zz`, body, key, { nowSeconds: t }), { ok: false, reason: "malformed" });
    assert.deepEqual(verifyMoonPayWebhook(`t=${t},s=${sig}`, body, "other", { nowSeconds: t }), { ok: false, reason: "mismatch" });
  });
});
