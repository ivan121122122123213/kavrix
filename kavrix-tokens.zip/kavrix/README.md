# Kavrix

Некастодиальный обмен токенов в сетях Ethereum, Base, Arbitrum и Polygon через агрегатор KyberSwap (0x — опционально) и покупка/продажа крипты за фиат через MoonPay и Transak. Ключи пользователей не покидают их кошельков; каждая транзакция проверяется сервером до подписи и подтверждается по блокчейну после.

## Документация

| Документ | О чём |
|---|---|
| [`docs/REPORT.md`](docs/REPORT.md) | Итоговый отчёт: что сделано, что работает, риски |
| [`docs/DEPLOY.md`](docs/DEPLOY.md) | Установка на чистый Ubuntu VPS, домен, HTTPS |
| [`docs/OPERATIONS.md`](docs/OPERATIONS.md) | Бэкапы, обновления, восстановление, мониторинг, инциденты |
| [`docs/LAUNCH-CHECKLIST.md`](docs/LAUNCH-CHECKLIST.md) | Что сделать до реальных денег |
| [`docs/PROVIDERS.md`](docs/PROVIDERS.md) | Подключение MoonPay и Transak |
| [`docs/TESTING.md`](docs/TESTING.md) | Тесты и соответствие сценариям ТЗ |
| [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) | Архитектура, решения, проверенные API, модель угроз |
| [`docs/STATUS.md`](docs/STATUS.md) | Журнал этапов и известные ограничения |

## Локальная разработка

Требуется Node.js ≥ 24.12, pnpm 10, Docker.

```bash
pnpm install                                    # создаёт pnpm-lock.yaml — закоммитьте его
cp .env.example .env                            # раскомментируйте блок "Local development"
docker compose -f infra/compose.dev.yml up -d   # PostgreSQL: kavrix и kavrix_test
pnpm db:migrate
pnpm dev:api                                    # http://127.0.0.1:3000/health/ready
pnpm dev:web                                    # http://localhost:5173
```

Администратор для локальной разработки (нужен `ADMIN_ENCRYPTION_KEY` в `.env`, ≥ 32 символов):

```bash
pnpm --filter @kavrix/api run admin create you@example.com owner
```

## Первый реальный обмен

Ключи не нужны: котировки идут через KyberSwap, чтение блокчейна — через бесплатные узлы.

1. Откройте сайт, подключите кошелёк, выберите Base, ETH → USDC, сумма 1–2 $.
2. В кошельке проверьте контракт `0x6131B5fa…37b5` и сумму.
3. После подтверждения: «Swap confirmed», ссылка на basescan, запись в History.
4. Затем USDC → ETH: approve запрашивается ровно на введённую сумму.

## Проверка

```bash
export DATABASE_URL_TEST=postgres://kavrix:kavrix_dev_only@127.0.0.1:5432/kavrix_test
pnpm ci
```

## Production

Кратко (полностью — `docs/DEPLOY.md`):

```bash
cp .env.example .env && chmod 600 .env && nano .env
infra/scripts/init-secrets.sh
docker compose build && docker compose up -d
docker compose run --rm migrate node dist/admin-cli.js create you@example.com owner
infra/scripts/healthcheck.sh
```

Обновление: `infra/scripts/update.sh <версия>`. Бэкап: `infra/scripts/backup.sh`. Восстановление: `infra/scripts/restore.sh <dump> --yes-replace-production`.
