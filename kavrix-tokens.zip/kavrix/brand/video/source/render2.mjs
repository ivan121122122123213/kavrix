import { chromium } from "/home/claude/.npm-global/lib/node_modules/playwright/index.mjs";
import { mkdirSync, existsSync } from "node:fs";
// Renders frames [from, to) after silently simulating every earlier frame, so the field is continuous.
const [,, w, h, dir, fps, from, to] = process.argv;
mkdirSync(dir, { recursive: true });
const b = await chromium.launch();
const p = await b.newPage({ viewport: { width: +w, height: +h } });
await p.goto(`file://${process.env.SCENE ?? new URL("./scene.html", import.meta.url).pathname}`);
await p.evaluate(({ n, fps }) => { for (let i = 0; i < n; i++) window.render(i / fps); }, { n: +from, fps: +fps });
for (let i = +from; i < +to; i++) {
  await p.evaluate((t) => window.render(t), i / +fps);
  const file = `${dir}/f${String(i).padStart(4, "0")}.png`;
  await p.screenshot({ path: file });
}
await b.close();
