#!/usr/bin/env bash
# usage: run.sh W H DIR  — renders 450 frames in 3 parallel chunks
W=$1; H=$2; D=$3; rm -rf "$D"; mkdir -p "$D"
for r in "0 150" "150 300" "300 450"; do
  set -- $r; node "$(dirname "$0")/render2.mjs" "$W" "$H" "$D" 30 "$1" "$2" &
done
wait
echo done > "$D/.done"
