# Kavrix brand assets

## Avatars (1024 × 1024 PNG)

| File | Use |
|---|---|
| `avatars/kavrix-avatar-obsidian.png` | Default profile picture: X, Telegram, Discord, GitHub |
| `avatars/kavrix-avatar-glow.png` | Where the avatar sits on dark UI and needs presence (YouTube, Discord server icon) |
| `avatars/kavrix-avatar-light.png` | Light backgrounds, partner pages, documents |

The mark (two interlocked rings) sits inside the central circle, so circular crops never cut it.

## Video ads (15 s, H.264, silent)

> The current videos still use the previous crystal mark; re-render them with the link mark before publishing.

- `video/kavrix-ad-vertical-1080x1920.mp4` — Reels, Shorts, TikTok, Stories
- `video/kavrix-ad-horizontal-1920x1080.mp4` — YouTube, X, website

Add a licensed music track in your editor; the cut points are at 2.6 s, 4.2 s, 6.8 s, 10.8 s and 13.4 s. The swap amounts on screen are marked "Illustration" and are not a rate offer.

## Re-rendering (other copy, language or domain)

Edit the text in `video/source/scene.html` (headline, checks, end card), then:

```bash
# needs Node, Playwright with Chromium, ffmpeg; uses the site's design/kavrix.css next to scene.html
cp ../apps/web/src/design/kavrix.css video/source/
./video/source/run.sh 1080 1920 /tmp/frames      # ~6 min on 3 cores
ffmpeg -framerate 30 -i /tmp/frames/f%04d.png -c:v libx264 -crf 17 -pix_fmt yuv420p -movflags +faststart out.mp4
```

The scene is frame-driven (`window.render(t)`), so every render is identical and chunks can be rendered in parallel without seams.
